CREATE TABLE IF NOT EXISTS archive_jobs (
  id TEXT PRIMARY KEY,
  record_type TEXT NOT NULL,
  source_id TEXT NOT NULL,
  stage_key TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  checksum_sha256 TEXT NOT NULL,
  byte_size INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'queued',
  object_key TEXT,
  error_text TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_archive_jobs_status_created ON archive_jobs(status, created_at);

CREATE TABLE IF NOT EXISTS queue_probes (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'queued',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  consumed_at TEXT
);

CREATE TABLE IF NOT EXISTS queue_failures (
  message_id TEXT PRIMARY KEY,
  queue_name TEXT NOT NULL,
  message_type TEXT NOT NULL,
  job_id TEXT,
  dlq_attempts INTEGER NOT NULL DEFAULT 1,
  body_json TEXT NOT NULL DEFAULT '{}',
  error_text TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_queue_failures_created ON queue_failures(created_at);

CREATE TABLE IF NOT EXISTS queue_dlq_probes (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'queued',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  dead_lettered_at TEXT,
  source_message_id TEXT,
  dlq_attempts INTEGER,
  error_text TEXT
);
