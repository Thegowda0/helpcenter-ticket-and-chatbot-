CREATE TABLE IF NOT EXISTS archive_objects (
  id TEXT PRIMARY KEY,
  object_key TEXT NOT NULL UNIQUE,
  record_type TEXT NOT NULL,
  source_id TEXT NOT NULL,
  content_type TEXT NOT NULL DEFAULT 'application/json',
  byte_size INTEGER NOT NULL DEFAULT 0,
  checksum_sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  metadata_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_archive_type_source ON archive_objects(record_type, source_id);
CREATE INDEX IF NOT EXISTS idx_archive_created ON archive_objects(created_at);
CREATE TABLE IF NOT EXISTS migration_runs (
  id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  status TEXT NOT NULL,
  started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  completed_at TEXT,
  records_seen INTEGER NOT NULL DEFAULT 0,
  records_written INTEGER NOT NULL DEFAULT 0,
  error_text TEXT
);
