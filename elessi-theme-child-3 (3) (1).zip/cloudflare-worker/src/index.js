const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };

function response(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}

function safeId(value) {
  return typeof value === 'string' && value.length > 0 && value.length <= 160 && /^[a-zA-Z0-9._:-]+$/.test(value);
}

async function sha256Hex(bytes) {
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, '0')).join('');
}

function constantTimeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function authorized(request, env) {
  const supplied = request.headers.get('authorization') || '';
  const expected = env.HCK_API_SECRET ? `Bearer ${env.HCK_API_SECRET}` : '';
  return !!expected && constantTimeEqual(supplied, expected);
}

function validRecordType(value) {
  return typeof value === 'string' && /^[a-z][a-z0-9_-]{1,40}$/.test(value);
}

async function readJson(request) {
  try { return await request.json(); } catch (_) { return null; }
}

async function health(env) {
  let key = '';
  try {
    await env.DB.prepare('SELECT 1 AS ok').first();
    if (!env.BUCKET) throw new Error('R2 binding missing');
    key = `_health/${crypto.randomUUID()}`;
    const probe = new TextEncoder().encode('hck-r2-health');
    await env.BUCKET.put(key, probe);
    const object = await env.BUCKET.get(key);
    if (!object || (await object.text()) !== 'hck-r2-health') throw new Error('R2 read-after-write failed');
    await env.BUCKET.delete(key);
    return response({ ok: true, service: 'hck-support-storage', d1: 'connected', r2: 'read/write verified', queue_binding: !!(env.ARCHIVE_QUEUE && typeof env.ARCHIVE_QUEUE.send === 'function'), primary_queue: env.HCK_PRIMARY_QUEUE_NAME || '', dlq_queue: env.HCK_DLQ_QUEUE_NAME || '' });
  } catch (error) {
    if (key && env.BUCKET) { try { await env.BUCKET.delete(key); } catch (_) {} }
    console.error('[HCK Health] check failed', String(error && error.message || error));
    return response({ ok: false, error: 'D1 or R2 health check failed', queue_binding: !!env.ARCHIVE_QUEUE }, 503);
  }
}

async function createArchive(request, env) {
  const requestId = request.headers.get('idempotency-key') || '';
  if (!safeId(requestId)) return response({ ok: false, error: 'A valid Idempotency-Key header is required' }, 400);
  const input = await readJson(request);
  if (!input) return response({ ok: false, error: 'Invalid JSON body' }, 400);
  const recordType = String(input.record_type || '');
  const sourceId = String(input.source_id || '');
  const payload = input.payload;
  if (!validRecordType(recordType) || !safeId(sourceId) || payload === undefined) return response({ ok: false, error: 'record_type, source_id and payload are required' }, 400);
  const bytes = new TextEncoder().encode(JSON.stringify(payload));
  const maxBytes = Math.max(1024, Number(env.MAX_ARCHIVE_BYTES || 10485760));
  if (bytes.byteLength > maxBytes) return response({ ok: false, error: 'Archive payload exceeds configured size limit' }, 413);
  const checksum = await sha256Hex(bytes);
  const existing = await env.DB.prepare('SELECT id, object_key, checksum_sha256 FROM archive_objects WHERE id = ?').bind(requestId).first();
  if (existing) {
    if (existing.checksum_sha256 !== checksum) return response({ ok: false, error: 'Idempotency key was already used for different content' }, 409);
    return response({ ok: true, duplicate: true, id: existing.id, object_key: existing.object_key });
  }
  const objectKey = `${recordType}/${encodeURIComponent(sourceId)}/${requestId}.json`;
  await env.BUCKET.put(objectKey, bytes, { httpMetadata: { contentType: 'application/json; charset=utf-8' }, customMetadata: { recordType, sourceId, checksum } });
  try {
    await env.DB.prepare(`INSERT INTO archive_objects (id, object_key, record_type, source_id, content_type, byte_size, checksum_sha256, metadata_json)
      VALUES (?, ?, ?, ?, 'application/json', ?, ?, ?)`).bind(requestId, objectKey, recordType, sourceId, bytes.byteLength, checksum, JSON.stringify(input.metadata || {})).run();
  } catch (error) {
    const check = await env.DB.prepare('SELECT id, checksum_sha256 FROM archive_objects WHERE id = ?').bind(requestId).first();
    if (!check) return response({ ok: false, error: 'Metadata write failed; retry with the same idempotency key' }, 503);
    if (check.checksum_sha256 !== checksum) return response({ ok: false, error: 'Idempotency conflict' }, 409);
  }
  return response({ ok: true, id: requestId, object_key: objectKey, byte_size: bytes.byteLength, checksum_sha256: checksum }, 201);
}

async function enqueueArchive(request, env) {
  if (!env.ARCHIVE_QUEUE || typeof env.ARCHIVE_QUEUE.send !== 'function') return response({ ok: false, error: 'Queue binding is not configured' }, 503);
  const requestId = request.headers.get('idempotency-key') || '';
  if (!safeId(requestId)) return response({ ok: false, error: 'A valid Idempotency-Key header is required' }, 400);
  const input = await readJson(request);
  if (!input) return response({ ok: false, error: 'Invalid JSON body' }, 400);
  const recordType = String(input.record_type || '');
  const sourceId = String(input.source_id || '');
  if (!validRecordType(recordType) || !safeId(sourceId) || input.payload === undefined) return response({ ok: false, error: 'record_type, source_id and payload are required' }, 400);
  const bytes = new TextEncoder().encode(JSON.stringify(input.payload));
  const maxBytes = Math.max(1024, Number(env.MAX_ARCHIVE_BYTES || 10485760));
  if (bytes.byteLength > maxBytes) return response({ ok: false, error: 'Archive payload exceeds configured size limit' }, 413);
  const checksum = await sha256Hex(bytes);
  const existing = await env.DB.prepare('SELECT id, checksum_sha256, status, stage_key FROM archive_jobs WHERE id = ?').bind(requestId).first();
  if (existing && existing.checksum_sha256 !== checksum) return response({ ok: false, error: 'Idempotency key was already used for different content' }, 409);
  const stageKey = `_pending/${requestId}.json`;
  if (!existing) {
    await env.BUCKET.put(stageKey, bytes, { httpMetadata: { contentType: 'application/json; charset=utf-8' }, customMetadata: { checksum, jobId: requestId } });
    try {
      await env.DB.prepare(`INSERT INTO archive_jobs (id, record_type, source_id, stage_key, metadata_json, checksum_sha256, byte_size, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'queued')`).bind(requestId, recordType, sourceId, stageKey, JSON.stringify(input.metadata || {}), checksum, bytes.byteLength).run();
    } catch (error) {
      const check = await env.DB.prepare('SELECT id, checksum_sha256, status, stage_key FROM archive_jobs WHERE id = ?').bind(requestId).first();
      if (!check || check.checksum_sha256 !== checksum) {
        if (!check) { try { await env.BUCKET.delete(stageKey); } catch (_) {} }
        return response({ ok: false, error: 'Could not register archive job; retry with the same idempotency key' }, 503);
      }
    }
  }
  const job = await env.DB.prepare('SELECT status FROM archive_jobs WHERE id = ?').bind(requestId).first();
  if (job && job.status !== 'complete' && job.status !== 'dead_lettered') await env.ARCHIVE_QUEUE.send({ type: 'archive_record', job_id: requestId });
  return response({ ok: true, accepted: true, duplicate: !!existing, id: requestId, status: job ? job.status : 'queued' }, 202);
}

async function processArchiveJob(message, env) {
  const jobId = message && message.job_id;
  if (!safeId(jobId)) throw new Error('Invalid archive job id');
  const job = await env.DB.prepare('SELECT * FROM archive_jobs WHERE id = ?').bind(jobId).first();
  if (!job || job.status === 'complete') return;
  if (job.status === 'dead_lettered') return;
  const staged = await env.BUCKET.get(job.stage_key);
  if (!staged) {
    const already = await env.DB.prepare('SELECT id FROM archive_objects WHERE id = ?').bind(job.id).first();
    if (already) {
      await env.DB.prepare("UPDATE archive_jobs SET status='complete', completed_at=strftime('%Y-%m-%dT%H:%M:%fZ','now'), error_text=NULL WHERE id=?").bind(job.id).run();
      return;
    }
    throw new Error('Staged R2 object is missing');
  }
  const objectKey = `${job.record_type}/${encodeURIComponent(job.source_id)}/${job.id}.json`;
  await env.BUCKET.put(objectKey, staged.body, { httpMetadata: { contentType: 'application/json; charset=utf-8' }, customMetadata: { recordType: job.record_type, sourceId: job.source_id, checksum: job.checksum_sha256 } });
  await env.DB.prepare(`INSERT INTO archive_objects (id, object_key, record_type, source_id, content_type, byte_size, checksum_sha256, metadata_json)
    VALUES (?, ?, ?, ?, 'application/json', ?, ?, ?) ON CONFLICT(id) DO NOTHING`)
    .bind(job.id, objectKey, job.record_type, job.source_id, job.byte_size, job.checksum_sha256, job.metadata_json || '{}').run();
  await env.DB.prepare("UPDATE archive_jobs SET status='complete', object_key=?, completed_at=strftime('%Y-%m-%dT%H:%M:%fZ','now'), error_text=NULL WHERE id=?").bind(objectKey, job.id).run();
  await env.BUCKET.delete(job.stage_key);
}

async function recordDeadLetter(message, env, queueName) {
  const body = message && message.body && typeof message.body === 'object' ? message.body : { value: message ? message.body : null };
  const messageType = String(body.type || 'unknown').slice(0, 80);
  const jobId = safeId(body.job_id) ? body.job_id : null;
  const probeId = safeId(body.probe_id) ? body.probe_id : null;
  const errorText = messageType === 'hck_dlq_probe' ? 'Intentional synthetic retry/DLQ verification probe' : 'Message exhausted primary Queue retry limit';
  const messageId = String(message.id || `dlq-${crypto.randomUUID()}`);
  const bodyJson = JSON.stringify(body).slice(0, 32768);
  await env.DB.prepare(`INSERT INTO queue_failures (message_id, queue_name, message_type, job_id, dlq_attempts, body_json, error_text)
    VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(message_id) DO NOTHING`)
    .bind(messageId, String(queueName || env.HCK_DLQ_QUEUE_NAME || 'unknown').slice(0, 160), messageType, jobId, Math.max(1, Number(message.attempts || 1)), bodyJson, errorText).run();
  if (jobId) {
    await env.DB.prepare("UPDATE archive_jobs SET status='dead_lettered', error_text=? WHERE id=? AND status <> 'complete'")
      .bind(errorText, jobId).run();
  }
  if (probeId && messageType === 'hck_dlq_probe') {
    await env.DB.prepare("UPDATE queue_dlq_probes SET status='dead_lettered', dead_lettered_at=strftime('%Y-%m-%dT%H:%M:%fZ','now'), source_message_id=?, dlq_attempts=?, error_text=? WHERE id=?")
      .bind(messageId, Math.max(1, Number(message.attempts || 1)), errorText, probeId).run();
  }
}

async function processPrimaryMessage(message, env) {
  const body = message && message.body ? message.body : {};
  if (body.type === 'health_probe') {
    if (!safeId(body.probe_id)) throw new Error('Invalid queue probe');
    await env.DB.prepare("UPDATE queue_probes SET status='consumed', consumed_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?").bind(body.probe_id).run();
    return;
  }
  if (body.type === 'archive_record') {
    await processArchiveJob(body, env);
    return;
  }
  if (body.type === 'hck_dlq_probe') {
    throw new Error('Intentional synthetic retry/DLQ verification probe');
  }
  throw new Error('Unsupported queue message');
}

export default {
  fetch: async function(request, env) {
    const url = new URL(request.url);
    if (!authorized(request, env)) return response({ ok: false, error: 'Unauthorized' }, 401);
    if (request.method === 'GET' && url.pathname === '/health') return health(env);
    if (request.method === 'POST' && url.pathname === '/v1/archive') return createArchive(request, env);
    if (request.method === 'POST' && url.pathname === '/v1/archive/async') return enqueueArchive(request, env);
    if (request.method === 'POST' && url.pathname === '/v1/queue/probe') {
      if (!env.ARCHIVE_QUEUE || typeof env.ARCHIVE_QUEUE.send !== 'function') return response({ ok: false, error: 'Queue binding is not configured' }, 503);
      const probeId = request.headers.get('idempotency-key') || '';
      if (!safeId(probeId)) return response({ ok: false, error: 'A valid Idempotency-Key header is required' }, 400);
      await env.DB.prepare("INSERT INTO queue_probes (id, status) VALUES (?, 'queued') ON CONFLICT(id) DO NOTHING").bind(probeId).run();
      await env.ARCHIVE_QUEUE.send({ type: 'health_probe', probe_id: probeId });
      return response({ ok: true, probe_id: probeId, status: 'queued' }, 202);
    }
    if (request.method === 'GET' && url.pathname.startsWith('/v1/queue/probe/')) {
      const probeId = url.pathname.slice('/v1/queue/probe/'.length);
      if (!safeId(probeId)) return response({ ok: false, error: 'Invalid probe id' }, 400);
      const probe = await env.DB.prepare('SELECT id, status, created_at, consumed_at FROM queue_probes WHERE id = ?').bind(probeId).first();
      return probe ? response({ ok: true, probe }) : response({ ok: false, error: 'Not found' }, 404);
    }
    if (request.method === 'POST' && url.pathname === '/v1/queue/dlq-probe') {
      if (!env.ARCHIVE_QUEUE || typeof env.ARCHIVE_QUEUE.send !== 'function') return response({ ok: false, error: 'Queue binding is not configured' }, 503);
      const probeId = request.headers.get('idempotency-key') || '';
      if (!safeId(probeId)) return response({ ok: false, error: 'A valid Idempotency-Key header is required' }, 400);
      await env.DB.prepare("INSERT INTO queue_dlq_probes (id, status) VALUES (?, 'queued') ON CONFLICT(id) DO NOTHING").bind(probeId).run();
      await env.ARCHIVE_QUEUE.send({ type: 'hck_dlq_probe', probe_id: probeId });
      return response({ ok: true, probe_id: probeId, status: 'queued' }, 202);
    }
    if (request.method === 'GET' && url.pathname.startsWith('/v1/queue/dlq-probe/')) {
      const probeId = url.pathname.slice('/v1/queue/dlq-probe/'.length);
      if (!safeId(probeId)) return response({ ok: false, error: 'Invalid DLQ probe id' }, 400);
      const probe = await env.DB.prepare('SELECT id, status, created_at, dead_lettered_at, source_message_id, dlq_attempts, error_text FROM queue_dlq_probes WHERE id = ?').bind(probeId).first();
      return probe ? response({ ok: true, probe }) : response({ ok: false, error: 'Not found' }, 404);
    }
    if (request.method === 'GET' && url.pathname === '/v1/archive') {
      const type = url.searchParams.get('record_type') || '';
      const sourceId = url.searchParams.get('source_id') || '';
      if (!validRecordType(type) || !safeId(sourceId)) return response({ ok: false, error: 'record_type and source_id are required' }, 400);
      const rows = await env.DB.prepare(`SELECT id, object_key, record_type, source_id, byte_size, checksum_sha256, created_at FROM archive_objects WHERE record_type = ? AND source_id = ? ORDER BY created_at DESC LIMIT 100`).bind(type, sourceId).all();
      return response({ ok: true, items: rows.results || [] });
    }
    if (url.pathname.startsWith('/v1/archive/verify/')) {
      const id = decodeURIComponent(url.pathname.slice('/v1/archive/verify/'.length));
      if (!safeId(id)) return response({ ok: false, error: 'Invalid archive verification id' }, 400);
      const job = await env.DB.prepare('SELECT id, record_type, source_id, status, object_key, checksum_sha256 FROM archive_jobs WHERE id = ?').bind(id).first();
      if (!job) return response({ ok: false, error: 'Archive job not found' }, 404);
      const rows = await env.DB.prepare('SELECT id, object_key, checksum_sha256 FROM archive_objects WHERE record_type = ? AND source_id = ? ORDER BY created_at DESC LIMIT 3').bind(job.record_type, job.source_id).all();
      const matches = rows.results || [];
      const failure = await env.DB.prepare('SELECT COUNT(*) AS total FROM queue_failures WHERE job_id = ?').bind(id).first();
      let r2Matches = false;
      if (job.object_key) {
        const object = await env.BUCKET.get(job.object_key);
        if (object) {
          const bytes = await object.arrayBuffer();
          r2Matches = (await sha256Hex(bytes)) === job.checksum_sha256;
        }
      }
      return response({ ok: true, job_status: job.status, archive_object_count: matches.length, matching_archive_object: matches.length === 1 && matches[0].id === id, r2_readback_matches: r2Matches, dlq_failure_count: Number(failure && failure.total || 0) });
    }
    if (url.pathname.startsWith('/v1/archive/jobs/')) {
      const id = decodeURIComponent(url.pathname.slice('/v1/archive/jobs/'.length));
      if (!safeId(id)) return response({ ok: false, error: 'Invalid archive job id' }, 400);
      const job = await env.DB.prepare('SELECT id, status, object_key, error_text, created_at, completed_at FROM archive_jobs WHERE id = ?').bind(id).first();
      return job ? response({ ok: true, job }) : response({ ok: false, error: 'Not found' }, 404);
    }
    if (url.pathname.startsWith('/v1/archive/')) {
      let id = '';
      try { id = decodeURIComponent(url.pathname.slice('/v1/archive/'.length)); } catch (_) { return response({ ok: false, error: 'Invalid archive id' }, 400); }
      if (!safeId(id)) return response({ ok: false, error: 'Invalid archive id' }, 400);
      const row = await env.DB.prepare('SELECT object_key FROM archive_objects WHERE id = ?').bind(id).first();
      if (!row) return response({ ok: false, error: 'Not found' }, 404);
      if (request.method === 'DELETE') {
        await env.BUCKET.delete(row.object_key);
        await env.DB.prepare('DELETE FROM archive_objects WHERE id = ?').bind(id).run();
        return response({ ok: true, deleted: true, id });
      }
      if (request.method === 'GET') {
        const object = await env.BUCKET.get(row.object_key);
        if (!object) return response({ ok: false, error: 'Archive object missing from R2' }, 503);
        return new Response(object.body, { headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
      }
    }
    return response({ ok: false, error: 'Not found' }, 404);
  },
  async queue(batch, env) {
    const queueName = String(batch.queue || '');
    const isDlq = queueName === String(env.HCK_DLQ_QUEUE_NAME || '');
    const isPrimary = queueName === String(env.HCK_PRIMARY_QUEUE_NAME || '');
    console.log('[HCK Queue] batch received', { queue: queueName, messageCount: batch.messages.length, mode: isDlq ? 'dead-letter' : 'primary' });
    for (const message of batch.messages) {
      const body = message && message.body && typeof message.body === 'object' ? message.body : {};
      const messageType = String(body.type || 'unknown');
      try {
        if (isDlq) {
          await recordDeadLetter(message, env, queueName);
          message.ack();
          console.warn('[HCK Queue] dead-letter recorded', { messageId: message.id || null, type: messageType, jobId: body.job_id || null });
          continue;
        }
        if (!isPrimary) throw new Error('Queue batch came from an unrecognised Queue name');
        await processPrimaryMessage(message, env);
        message.ack();
        console.log('[HCK Queue] message acknowledged', { messageId: message.id || null, type: messageType });
      } catch (error) {
        const messageError = String(error && error.message || error).slice(0, 500);
        console.error('[HCK Queue] message processing failed', { queue: queueName, messageId: message && message.id || null, type: messageType, attempts: Number(message && message.attempts || 1), error: messageError });
        const jobId = body.job_id;
        if (!isDlq && safeId(jobId)) {
          try { await env.DB.prepare("UPDATE archive_jobs SET status='retrying', error_text=? WHERE id=? AND status <> 'complete'").bind(messageError, jobId).run(); } catch (dbError) { console.error('[HCK Queue] retry status update failed', String(dbError && dbError.message || dbError)); }
        }
        // A DLQ message is only acknowledged after its failure is durably recorded in D1.
        message.retry({ delaySeconds: isDlq ? 60 : 5 });
      }
    }
  }
};
