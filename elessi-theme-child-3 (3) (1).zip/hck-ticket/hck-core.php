<?php
/**
 * HCK Ticket System - Core Helpers
 */

if (!defined('ABSPATH')) exit;

// =============================================
// SETTINGS
// =============================================
function hck_get_setting($key, $default = '') {
    global $wpdb;
    $cache_key = 'hck_setting_' . sanitize_key($key);
    $found = false;
    $cached = wp_cache_get($cache_key, 'hck', false, $found);
    if ($found) return $cached;
    $table = $wpdb->prefix . 'hck_ticket_settings';
    $value = $wpdb->get_var($wpdb->prepare("SELECT setting_value FROM {$table} WHERE setting_key=%s LIMIT 1", $key));
    if ($value === null) $value = $default;
    wp_cache_set($cache_key, $value, 'hck', 60);
    return $value;
}

function hck_get_all_settings() {
    global $wpdb;
    $table = $wpdb->prefix . 'hck_ticket_settings';
    $rows = $wpdb->get_results("SELECT setting_key, setting_value FROM $table");
    $out = array();
    foreach ($rows as $r) $out[$r->setting_key] = $r->setting_value;
    return $out;
}

// =============================================
// TICKET HELPERS
// =============================================
function hck_get_ticket($id) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}hck_tickets WHERE id = %d",
        $id
    ));
}

function hck_get_messages($ticket_id, $include_internal = true) {
    global $wpdb;
    $where = $include_internal ? '' : ' AND is_internal = 0';
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}hck_ticket_messages WHERE ticket_id = %d{$where} ORDER BY created_at ASC,id ASC",
        $ticket_id
    ));
}

/** Fetch a bounded chronological transcript page using the message ID as a stable cursor. */
function hck_get_messages_page($ticket_id, $include_internal = true, $before_id = 0, $limit = 50) {
    global $wpdb;
    $ticket_id = absint($ticket_id);
    if (!$ticket_id) return array('messages' => array(), 'has_more' => false, 'next_before_id' => 0);
    $limit = max(1, min(100, absint($limit) ?: 50));
    $before_id = absint($before_id);
    $where = $include_internal ? '' : ' AND is_internal = 0';
    $cursor = $before_id ? $wpdb->prepare(' AND id < %d', $before_id) : '';
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}hck_ticket_messages WHERE ticket_id = %d{$where}{$cursor} ORDER BY id DESC LIMIT %d",
        $ticket_id, $limit + 1
    ));
    $has_more = count((array) $rows) > $limit;
    if ($has_more) array_pop($rows);
    $rows = array_reverse((array) $rows);
    $next_before_id = $rows ? (int) $rows[0]->id : 0;
    return array('messages' => $rows, 'has_more' => $has_more, 'next_before_id' => $next_before_id);
}

function hck_get_attachments($message_id) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}hck_ticket_attachments WHERE message_id = %d",
        $message_id
    ));
}

/**
 * Fetch attachments for a message collection in one query.
 * Returns a message_id => attachment rows map to avoid N+1 queries in transcripts.
 */
function hck_get_attachments_for_messages($message_ids) {
    global $wpdb;
    $ids = array_values(array_unique(array_filter(array_map('absint', (array) $message_ids))));
    if (!$ids) return array();
    // Keep the IN clause bounded even if a caller accidentally passes a huge transcript.
    $ids = array_slice($ids, 0, 1000);
    $placeholders = implode(',', array_fill(0, count($ids), '%d'));
    $sql = $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}hck_ticket_attachments WHERE message_id IN ({$placeholders}) ORDER BY message_id ASC,id ASC",
        $ids
    );
    $rows = $wpdb->get_results($sql);
    $grouped = array();
    foreach ((array) $rows as $row) {
        $message_id = (int) $row->message_id;
        if (!isset($grouped[$message_id])) $grouped[$message_id] = array();
        $grouped[$message_id][] = $row;
    }
    return $grouped;
}

function hck_get_ticket_number($ticket) {
    if (!empty($ticket->ticket_number)) return (string)$ticket->ticket_number;
    $type = isset($ticket->ticket_type) && $ticket->ticket_type === 'hc' ? 'hc' : 'tc';
    $year = !empty($ticket->created_at) ? (int)mysql2date('Y',$ticket->created_at) : (int)wp_date('Y');
    $sequence = !empty($ticket->ticket_sequence) ? (int)$ticket->ticket_sequence : (int)$ticket->id;
    return function_exists('hck_format_ticket_number') ? hck_format_ticket_number($year,$sequence,$type) : ('HCK-'.$year.'-'.str_pad((string)$sequence,6,'0',STR_PAD_LEFT));
}

function hck_get_ticket_user_id($ticket) {
    // Handle both schema variants — always return int for strict comparison
    if (isset($ticket->user_id) && $ticket->user_id) return (int) $ticket->user_id;
    if (isset($ticket->customer_id) && $ticket->customer_id) return (int) $ticket->customer_id;
    return 0;
}

function hck_get_ticket_agent_id($ticket) {
    if (isset($ticket->agent_id) && $ticket->agent_id) return (int) $ticket->agent_id;
    if (isset($ticket->assigned_to) && $ticket->assigned_to) return (int) $ticket->assigned_to;
    return 0;
}



/** Return the ticket ID authorized by the current short-lived guest ticket session. */
function hck_guest_session_ticket_id($requested_ticket_id = 0) {
    if (is_user_logged_in()) return 0;
    $requested_ticket_id = absint($requested_ticket_id);
    $cookie_name = $requested_ticket_id ? 'hck_guest_ticket_' . $requested_ticket_id : '';
    $token = $cookie_name && !empty($_COOKIE[$cookie_name]) ? sanitize_text_field(wp_unslash($_COOKIE[$cookie_name])) : '';
    if (!$token && !$requested_ticket_id && !empty($_COOKIE['hck_guest_ticket'])) $token = sanitize_text_field(wp_unslash($_COOKIE['hck_guest_ticket']));
    if (!preg_match('/^[A-Fa-f0-9]{64}$/', $token)) return 0;
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare('SELECT ticket_id FROM ' . $wpdb->prefix . 'hck_guest_sessions WHERE token_hash=%s AND expires_at>%s', hash('sha256', $token), current_time('mysql')));
    if (!$row || ($requested_ticket_id && (int)$row->ticket_id !== $requested_ticket_id)) return 0;
    return (int)$row->ticket_id;
}

// =============================================
// STATUS / PRIORITY LABELS
// =============================================
function hck_get_status_label($status) {
    $labels = array(
        'open'           => 'Open',
        'in_progress'    => 'In Progress',
        'awaiting_reply' => 'Awaiting Reply',
        'resolved'       => 'Resolved',
        'closed'         => 'Closed',
        'converted'      => 'Moved to HCK Ticket',
    );
    return isset($labels[$status]) ? $labels[$status] : ucfirst(str_replace('_', ' ', $status));
}

function hck_get_status_icon($status) {
    $icons = array(
        'open'           => 'folder-open',
        'in_progress'    => 'spinner',
        'awaiting_reply' => 'reply',
        'resolved'       => 'check-circle',
        'closed'         => 'lock',
    );
    return isset($icons[$status]) ? $icons[$status] : 'circle';
}

function hck_get_priority_label($priority) {
    return ucfirst($priority ?: 'normal');
}

function hck_get_priority_color($priority) {
    $colors = array(
        'low'    => '#94A3B8',
        'normal' => '#64748B',
        'high'   => '#F59E0B',
        'urgent' => '#EF4444',
    );
    return isset($colors[$priority]) ? $colors[$priority] : '#64748B';
}

// =============================================
// USER HELPERS
// =============================================
function hck_get_user_name($user_id) {
    return hck_get_user_display($user_id);
}

function hck_get_user_email($user_id) {
    $user = get_userdata($user_id);
    return $user ? $user->user_email : '';
}

function hck_get_avatar($user_id, $size = 40) {
    $url = get_avatar_url($user_id, array('size' => $size));
    return $url ?: 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&s=' . $size;
}

function hck_get_initials($name) {
    $words = preg_split('/\s+/', trim($name));
    $initials = '';
    foreach ($words as $w) {
        if ($w) $initials .= strtoupper(substr($w, 0, 1));
        if (strlen($initials) >= 2) break;
    }
    return strtoupper(substr($initials, 0, 2));
}

/**
 * Get a display name for a user — never falls back to email.
 * Priority: first_name → display_name (if not email) → user_login → "User"
 */
function hck_get_user_display($user_id) {
    $user = get_userdata($user_id);
    if (!$user) return 'User';
    
    $first = trim((string) get_user_meta($user_id, 'first_name', true));
    if ($first !== '') return $first;
    
    $display = trim((string) $user->display_name);
    // Reject display_name if it looks like an email
    if ($display !== '' && strpos($display, '@') === false) {
        return $display;
    }
    
    $login = trim((string) $user->user_login);
    if ($login !== '') return $login;
    
    return 'User';
}

// =============================================
// TICKET NUMBER GENERATOR
// =============================================
function hck_ticket_number_config($type = 'tc') {
    $type = ($type === 'hc') ? 'hc' : 'tc';
    $prefix = trim((string) hck_get_setting('hck_ticket_prefix', 'HCK'));
    $prefix = strtoupper(preg_replace('/[^A-Z0-9-]+/i', '', $prefix));
    if ($prefix === '') $prefix = 'HCK';
    $suffix_key = $type === 'hc' ? 'hck_ticket_suffix_hc' : 'hck_ticket_suffix_tc';
    $suffix_default = $type === 'hc' ? 'HC' : 'TC';
    $suffix = strtoupper(preg_replace('/[^A-Z0-9-]+/i', '', trim((string)hck_get_setting($suffix_key, $suffix_default))));
    return array('prefix'=>$prefix,'suffix'=>$suffix,'type'=>$type);
}

function hck_format_ticket_number($year, $sequence, $type = 'tc') {
    $cfg = hck_ticket_number_config($type);
    $number = $cfg['prefix'] . '-' . (int)$year . '-' . str_pad((string)max(1,(int)$sequence), 6, '0', STR_PAD_LEFT);
    return $number . ($cfg['suffix'] !== '' ? '-' . $cfg['suffix'] : '');
}

function hck_generate_ticket_number($type = 'tc', &$sequence_out = null, &$year_out = null) {
    global $wpdb;
    $type = ($type === 'hc') ? 'hc' : 'tc';
    $year = (int) wp_date('Y');
    $table = $wpdb->prefix . 'hck_ticket_sequences_v2';
    $wpdb->query($wpdb->prepare("INSERT INTO {$table} (year,ticket_type,last_number) VALUES (%d,%s,LAST_INSERT_ID(1)) ON DUPLICATE KEY UPDATE last_number=LAST_INSERT_ID(last_number+1)",$year,$type));
    $num = (int)$wpdb->get_var('SELECT LAST_INSERT_ID()');
    $sequence_out = max(1,$num); $year_out = $year;
    return hck_format_ticket_number($year,$num,$type);
}

/** Rebuild stored display numbers after a prefix/suffix change without changing sequence identity. */
function hck_regenerate_all_ticket_numbers() {
    global $wpdb;
    $table = $wpdb->prefix . 'hck_tickets';
    $rows = $wpdb->get_results("SELECT id,created_at,ticket_type,ticket_sequence,ticket_number,source FROM {$table} ORDER BY created_at ASC,id ASC");
    if (!$rows) return true;
    $wpdb->query('START TRANSACTION');
    foreach ($rows as $row) {
        $type = in_array((string)$row->ticket_type,array('hc','tc'),true) ? $row->ticket_type : (strpos((string)$row->source,'helpcenter')===0 ? 'hc' : 'tc');
        $year = (int)mysql2date('Y',$row->created_at ?: current_time('mysql'));
        $seq = (int)$row->ticket_sequence;
        if ($seq < 1) {
            if (preg_match('/-(\d{6,})/',(string)$row->ticket_number,$m)) $seq=(int)$m[1];
            if ($seq < 1) $seq=(int)$row->id;
        }
        $number = hck_format_ticket_number($year,$seq,$type);
        $ok = $wpdb->update($table,array('ticket_type'=>$type,'ticket_sequence'=>$seq,'ticket_number'=>$number),array('id'=>(int)$row->id));
        if ($ok === false) { $wpdb->query('ROLLBACK'); return false; }
    }
    $wpdb->query('COMMIT');
    return true;
}

// =============================================
// ACCESS + VALIDATION HELPERS
// =============================================
function hck_is_agent() {
    return current_user_can('manage_options') || current_user_can('manage_woocommerce') || current_user_can('hc_manage_ai_escalations') || current_user_can('hck_reply_tickets');
}

/**
 * Distinguish supervisors from HelpCenter agents.
 * The hc_support_agent role intentionally has hc_manage_ai_escalations for
 * live-chat conversion, so that capability alone must not grant supervisor UI.
 */
function hck_is_supervisor_user($user_id = 0) {
    $user_id = $user_id ? absint($user_id) : get_current_user_id();
    if (!$user_id) return false;

    if (user_can($user_id, 'manage_options') || user_can($user_id, 'manage_woocommerce')) {
        return true;
    }

    return user_can($user_id, 'hc_manage_ai_escalations')
        && !user_can($user_id, 'hc_agent_portal_access');
}

function hck_user_can_access_ticket($ticket, $user_id = 0) {
    if (!$ticket) return false;
    $user_id = $user_id ? (int) $user_id : (int) get_current_user_id();
    if (!$user_id) return false;
    if (user_can($user_id, 'manage_options') || user_can($user_id, 'manage_woocommerce') || user_can($user_id, 'hc_manage_ai_escalations') || user_can($user_id, 'hck_view_tickets')) return true;
    return hck_get_ticket_user_id($ticket) === $user_id;
}

function hck_valid_priorities() {
    return array('low', 'normal', 'high', 'urgent');
}

/**
 * Ticket categories configured in Settings, as slug => label.
 */
function hck_get_ticket_categories() {
    $raw = hck_get_setting('hck_ticket_categories', '');
    if (trim((string) $raw) === '') {
        $raw = 'Pre-Sale Question, Order Related, Technical Issue, Return / Refund, Other, HelpCenter';
    }
    $out = array();
    foreach (explode(',', $raw) as $label) {
        $label = trim($label);
        if ($label === '') continue;
        $slug = sanitize_title($label);
        if ($slug !== '') $out[$slug] = $label;
    }
    if (!isset($out['helpcenter'])) $out['helpcenter'] = 'HelpCenter';
    return $out;
}

function hck_user_can_handle_ticket($ticket, $user_id = 0) {
    if (!$ticket) return false;
    $user_id = $user_id ? (int)$user_id : (int)get_current_user_id();
    if (!$user_id || in_array((string)($ticket->status??''),array('resolved','closed'),true)) return false;
    if (user_can($user_id,'manage_options') || user_can($user_id,'manage_woocommerce')) return true;
    return hck_get_ticket_agent_id($ticket) === $user_id;
}

/**
 * Keep only WooCommerce order IDs that really belong to $user_id.
 */
function hck_filter_user_orders($ids, $user_id) {
    $out = array();
    if (!is_array($ids) || !function_exists('wc_get_order')) return $out;
    foreach ($ids as $oid) {
        $oid = (int) $oid;
        if ($oid <= 0) continue;
        $order = wc_get_order($oid);
        if ($order && (int) $order->get_user_id() === (int) $user_id) $out[] = $oid;
    }
    return array_values(array_unique($out));
}

// =============================================
// FILE UPLOAD HANDLER
// =============================================
function hck_blocked_extensions() {
    return array(
        'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'pht', 'phar', 'phps',
        'cgi', 'pl', 'py', 'sh', 'bash', 'exe', 'dll', 'bat', 'cmd', 'com', 'msi',
        'js', 'mjs', 'html', 'htm', 'xhtml', 'svg', 'swf', 'jar', 'vbs', 'htaccess', 'ini',
    );
}

function hck_upload_dir() {
    $upload = wp_upload_dir();
    $dir = trailingslashit($upload['basedir']) . 'hck-tickets/';
    if (!file_exists($dir)) wp_mkdir_p($dir);
    // Always (re)write the protection files. Downloads go through the /ticket/file/ID/ route.
    if (!file_exists($dir . '.htaccess')) {
        file_put_contents($dir . '.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    }
    if (!file_exists($dir . 'index.php')) {
        file_put_contents($dir . 'index.php', "<?php // silence");
    }
    return $dir;
}

function hck_handle_upload($file) {
    $max_mb   = max(1, intval(hck_get_setting('hck_max_attachment_size', '10')));
    $max_size = $max_mb * 1024 * 1024;
    $allowed  = array_filter(array_map('trim', explode(',', strtolower(hck_get_setting('hck_allowed_file_types', 'jpg,jpeg,png,webp,pdf,zip,doc,docx')))));
    $allowed  = array_values(array_diff($allowed, hck_blocked_extensions()));

    if (empty($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return array('error' => 'Upload failed');
    if (!is_uploaded_file($file['tmp_name'])) return array('error' => 'Upload failed');
    if ($file['size'] <= 0) return array('error' => 'The file is empty');
    if ($file['size'] > $max_size) return array('error' => 'File exceeds ' . $max_mb . 'MB');

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($ext === '' || !in_array($ext, $allowed, true)) {
        return array('error' => 'File type .' . $ext . ' not allowed');
    }
    // Validate the actual file content/MIME instead of trusting the browser's
    // supplied Content-Type. This is especially important for guest-uploaded files.
    $checked = wp_check_filetype_and_ext($file['tmp_name'], $file['name']);
    if (empty($checked['type']) || (empty($checked['ext']) || strtolower($checked['ext']) !== $ext)) {
        return array('error' => 'The file content does not match its file extension.');
    }

    // Images must really be images
    if (in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp'), true)) {
        $info = @getimagesize($file['tmp_name']);
        if (!$info) return array('error' => 'The image file is not valid');
    }

    $dir      = hck_upload_dir();
    $upload   = wp_upload_dir();
    $safe     = sanitize_file_name($file['name']);
    $new_name = wp_generate_password(24, false) . '_' . $safe;
    $target   = $dir . $new_name;

    if (!move_uploaded_file($file['tmp_name'], $target)) {
        return array('error' => 'Could not save file');
    }

    return array(
        'filename'      => sanitize_text_field($file['name']),
        'file_path'     => trailingslashit($upload['baseurl']) . 'hck-tickets/' . $new_name,
        'file_size'     => (int) $file['size'],
        'file_type'     => $ext,
        'original_name' => sanitize_text_field($file['name']),
    );
}

/** Link customers/agents use to download an attachment (access-checked). */
function hck_attachment_url($att) {
    return hck_customer_url('file/' . (int) $att->id . '/');
}

/** Absolute path of a stored attachment, or '' if it is not inside the ticket upload folder. */
function hck_attachment_path($att) {
    $base = basename((string) wp_parse_url($att->file_path, PHP_URL_PATH));
    if ($base === '' || $base === '.' || $base === '..') return '';
    $upload = wp_upload_dir();
    $dir  = trailingslashit($upload['basedir']) . 'hck-tickets/';
    $path = $dir . $base;
    $real = realpath($path);
    $real_dir = realpath($dir);
    if (!$real || !$real_dir || strpos($real, $real_dir) !== 0) return '';
    return $real;
}

// =============================================
// LOGGING
// =============================================
function hck_add_log($ticket_id, $user_id, $action, $details = '') {
    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'hck_ticket_logs', array(
        'ticket_id'  => $ticket_id,
        'user_id'    => $user_id,
        'action'     => $action,
        'details'    => $details,
        'created_at' => current_time('mysql'),
    ));
}

// =============================================
// STATISTICS
// =============================================
function hck_get_user_stats($user_id) {
    global $wpdb;
    $t = $wpdb->prefix . 'hck_tickets';
    
    // Handle both user_id and customer_id columns
    $col = hck_column_exists($t, 'user_id') ? 'user_id' : 'customer_id';
    
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT status, COUNT(*) as cnt FROM $t WHERE $col = %d GROUP BY status",
        $user_id
    ));
    
    $stats = array('total' => 0, 'open' => 0, 'in_progress' => 0, 'awaiting_reply' => 0, 'resolved' => 0, 'closed' => 0);
    foreach ($rows as $r) {
        $stats['total'] += $r->cnt;
        if (isset($stats[$r->status])) $stats[$r->status] = $r->cnt;
    }
    return $stats;
}

function hck_get_admin_stats() {
    global $wpdb;
    $t = $wpdb->prefix . 'hck_tickets';
    return array(
        'total'         => (int) $wpdb->get_var("SELECT COUNT(*) FROM $t"),
        'open'          => (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE status = 'open'"),
        'in_progress'   => (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE status IN ('in_progress','awaiting_reply')"),
        'resolved'      => (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE status = 'resolved'"),
        'closed'        => (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE status = 'closed'"),
        'unassigned'    => (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE " . (hck_column_exists($t, 'agent_id') ? 'agent_id' : 'assigned_to') . " IS NULL AND status NOT IN ('closed','resolved')"),
        'urgent'        => (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE priority = 'urgent' AND status NOT IN ('closed','resolved')"),
    );
}

// =============================================
// COLUMN EXISTENCE CHECK (for schema compatibility)
// =============================================
function hck_column_exists($table, $column) {
    global $wpdb;
    static $cache = array();
    $key = $table . '.' . $column;
    if (isset($cache[$key])) return $cache[$key];
    
    $found = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
         WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
        DB_NAME, $table, $column
    ));
    $cache[$key] = ($found > 0);
    return $cache[$key];
}

// =============================================
// TIME HELPERS
// =============================================
function hck_time_ago($datetime) {
    return human_time_diff(strtotime($datetime), current_time('timestamp')) . ' ago';
}

function hck_format_date($datetime, $format = 'M d, Y h:i A') {
    return date($format, strtotime($datetime));
}

// =============================================
// URL HELPERS
// =============================================
function hck_customer_url($path = '') {
    return home_url('/ticket/' . ltrim($path, '/'));
}

function hck_admin_url($path = '') {
    return home_url('/ticket/admin/' . ltrim($path, '/'));
}

// =============================================
// AVOID THEME POLLUTION
// =============================================
function hck_is_ticket_page() {
    return (bool) get_query_var('hck_page');
}


// =============================================
// COLOR HELPER
// =============================================
function hck_adjust_brightness($hex, $steps) {
    $hex = ltrim($hex, '#');
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = max(0, min(255, hexdec(substr($hex, 0, 2)) + $steps));
    $g = max(0, min(255, hexdec(substr($hex, 2, 2)) + $steps));
    $b = max(0, min(255, hexdec(substr($hex, 4, 2)) + $steps));
    return sprintf('#%02x%02x%02x', $r, $g, $b);
}
