<?php
/**
 * HCK Ticket System - AJAX Handlers
 */

if (!defined('ABSPATH')) exit;

// Send ticket-reply notifications after the AJAX response. This keeps the agent
// composer responsive and prevents SMTP latency from holding the message request.
add_action('hck_send_reply_notification', 'hck_send_reply_notification_job', 10, 3);
add_action('hck_generate_ticket_ai_summary_background', 'hck_generate_ticket_ai_summary_background', 10, 1);
function hck_send_reply_notification_job($ticket_id, $message_id, $is_admin) {
    $ticket_id = absint($ticket_id); $message_id = absint($message_id);
    if (!$ticket_id || !$message_id) return;
    $table = $wpdb->prefix . 'hck_ticket_messages';
    $message = $wpdb->get_row($wpdb->prepare("SELECT id,is_internal FROM {$table} WHERE id=%d AND ticket_id=%d", $message_id, $ticket_id));
    if (!$message || !empty($message->is_internal)) return;
    $done_key = 'hck_reply_notice_done_' . $message_id;
    if (get_option($done_key, false)) return;
    $lock_key = 'hck_reply_notice_lock_' . $message_id;
    if (!add_option($lock_key, time(), '', false)) return;
    $sent = $is_admin ? hck_notify_customer_on_reply($ticket_id) : hck_notify_admin_on_reply($ticket_id);
    if ($sent) update_option($done_key, 1, false);
    delete_option($lock_key);
}

function hck_register_ajax() {
    // Customer
    add_action('wp_ajax_hck_create_ticket', 'hck_ajax_create_ticket');
    add_action('wp_ajax_hck_send_reply',    'hck_ajax_send_reply');
    add_action('wp_ajax_nopriv_hck_send_reply', 'hck_ajax_send_reply');
    add_action('wp_ajax_hck_poll_new_messages', 'hck_ajax_poll_new_messages');
    add_action('wp_ajax_nopriv_hck_poll_new_messages', 'hck_ajax_poll_new_messages');
    add_action('wp_ajax_hck_publish_realtime_message', 'hck_ajax_publish_realtime_message');
    add_action('wp_ajax_nopriv_hck_publish_realtime_message', 'hck_ajax_publish_realtime_message');
    add_action('wp_ajax_hck_rate_ticket',   'hck_ajax_rate_ticket');
    add_action('wp_ajax_hck_upload_temp',   'hck_ajax_upload_temp');
    add_action('wp_ajax_nopriv_hck_upload_temp', 'hck_ajax_upload_temp');
    add_action('wp_ajax_hck_preview_email', 'hck_ajax_preview_email');

    // Admin
    add_action('wp_ajax_hck_load_older_messages', 'hck_ajax_load_older_messages');
    add_action('wp_ajax_hck_edit_internal_note', 'hck_ajax_edit_internal_note');
    add_action('wp_ajax_hck_delete_internal_note', 'hck_ajax_delete_internal_note');
    add_action('wp_ajax_hck_admin_reply',         'hck_ajax_admin_reply');
    add_action('wp_ajax_hck_admin_change_status', 'hck_ajax_admin_change_status');
    add_action('wp_ajax_hck_admin_change_agent',  'hck_ajax_admin_change_agent');
    add_action('wp_ajax_hck_admin_change_priority','hck_ajax_admin_change_priority');
    add_action('wp_ajax_hck_add_customer_note', 'hck_ajax_add_customer_note');
    add_action('wp_ajax_hck_generate_ticket_ai_summary', 'hck_ajax_generate_ticket_ai_summary');
    add_action('wp_ajax_hck_cleanup_orphan_attachments', 'hck_ajax_cleanup_orphan_attachments');
    add_action('wp_ajax_hck_save_settings',       'hck_ajax_save_settings');
    add_action('wp_ajax_hck_save_sla_policy', 'hck_ajax_save_sla_policy');
    add_action('wp_ajax_hck_save_agent_capacity', 'hck_ajax_save_agent_capacity');

    // Common
    add_action('wp_ajax_hck_upload_file', 'hck_ajax_upload_file');
}


// =============================================
// CLEAN UP ABANDONED PRE-UPLOADED ATTACHMENTS
// Only removes HCK uploads that were never linked to a ticket/message and are
// at least 24 hours old. Files referenced by any other row are never unlinked.
// =============================================
function hck_ajax_cleanup_orphan_attachments() {
    if (!current_user_can('manage_options')) wp_send_json_error(array('message'=>'Only a supervisor can clean up abandoned uploads.'),403);
    check_ajax_referer('hck_nonce','nonce');
    global $wpdb;
    $table = $wpdb->prefix . 'hck_ticket_attachments';
    $cutoff = wp_date('Y-m-d H:i:s', time() - DAY_IN_SECONDS);
    $mode = sanitize_key(wp_unslash($_POST['mode'] ?? 'scan'));
    $count = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE ticket_id=0 AND message_id=0 AND created_at < %s", $cutoff
    ));
    if ($mode !== 'cleanup') wp_send_json_success(array('count'=>$count,'message'=>$count.' abandoned upload(s) older than 24 hours can be safely removed.'));
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table} WHERE ticket_id=0 AND message_id=0 AND created_at < %s ORDER BY id ASC LIMIT 500", $cutoff
    ));
    $deleted = 0; $files = 0; $failed = 0;
    foreach ((array)$rows as $row) {
        $path = hck_attachment_path($row);
        // Delete only if this exact file path is not referenced by another row.
        $references = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE file_path=%s AND id<>%d", (string)$row->file_path, (int)$row->id
        ));
        if ($references === 0 && $path !== '' && is_file($path)) {
            if (@unlink($path)) $files++;
            else { $failed++; continue; }
        }
        if ($wpdb->delete($table, array('id'=>(int)$row->id), array('%d'))) $deleted++;
        else $failed++;
    }
    wp_send_json_success(array('deleted'=>$deleted,'files_deleted'=>$files,'failed'=>$failed,'remaining'=>max(0,$count-$deleted),'message'=>'Removed '.$deleted.' abandoned upload record(s) and '.$files.' file(s). '.max(0,$count-$deleted).' older record(s) remain for the next cleanup.'));
}

// =============================================
// CREATE TICKET (customer)
// =============================================
function hck_ajax_create_ticket() {
    if (!is_user_logged_in()) wp_send_json_error(array('message' => 'Please log in'));
    check_ajax_referer('hck_nonce', 'nonce');

    $user_id  = get_current_user_id();
    $subject  = sanitize_text_field(wp_unslash($_POST['subject'] ?? ''));
    $category = sanitize_title(wp_unslash($_POST['category'] ?? ''));
    $priority = sanitize_key(wp_unslash($_POST['priority'] ?? 'normal'));
    $message  = wp_kses_post(wp_unslash($_POST['message'] ?? ''));

    if (mb_strlen($subject) < 5)   wp_send_json_error(array('message' => 'Subject too short'));
    if (mb_strlen($subject) > 200) wp_send_json_error(array('message' => 'Subject too long (200 characters max)'));
    if (mb_strlen(trim(wp_strip_all_tags($message))) < 10) wp_send_json_error(array('message' => 'Message too short'));

    $allowed_categories = hck_get_ticket_categories();
    if (!isset($allowed_categories[$category])) {
        wp_send_json_error(array('message' => 'Please choose a valid category'));
    }
    if (!in_array($priority, hck_valid_priorities(), true)) $priority = 'normal';

    // Related orders: keep only orders that belong to this customer
    $orders_in = json_decode(wp_unslash($_POST['orders'] ?? '[]'), true);
    $orders    = hck_filter_user_orders(is_array($orders_in) ? $orders_in : array(), $user_id);

    global $wpdb;
    $tickets_table = $wpdb->prefix . 'hck_tickets';

    $row = array(
        'user_id'        => $user_id,
        'subject'        => $subject,
        'category'       => $category,
        'priority'       => $priority,
        'status'         => 'open',
        'related_orders' => wp_json_encode($orders),
        'created_at'     => current_time('mysql'),
        'updated_at'     => current_time('mysql'),
    );
    if (hck_column_exists($tickets_table, 'customer_id')) {
        $row['customer_id'] = $user_id;
    }

    // Insert, retrying if two customers grab the same ticket number at once
    $result = false;
    for ($try = 0; $try < 5 && !$result; $try++) {
        $seq = 0; $year = 0; $row['ticket_number'] = hck_generate_ticket_number('tc', $seq, $year);
        $row['ticket_type'] = 'tc'; $row['ticket_sequence'] = $seq;
        $result = $wpdb->insert($tickets_table, $row);
        if (!$result && stripos((string) $wpdb->last_error, 'duplicate') === false) break;
    }
    if (!$result) wp_send_json_error(array('message' => 'Could not create the ticket. Please try again.'));

    $ticket_id = (int) $wpdb->insert_id;
    if (function_exists('hck_sla_initialize_ticket')) hck_sla_initialize_ticket($ticket_id);

    // First message
    $wpdb->insert($wpdb->prefix . 'hck_ticket_messages', array(
        'ticket_id'  => $ticket_id,
        'user_id'    => $user_id,
        'message'    => $message,
        'is_admin'   => 0,
        'created_at' => current_time('mysql'),
    ));
    $message_id = (int) $wpdb->insert_id;

    hck_attach_uploads($ticket_id, $message_id, $user_id, true);

    if (function_exists('hck_notify_new_ticket_customer')) hck_notify_new_ticket_customer($ticket_id);
    if (function_exists('hck_notify_new_ticket_admin'))    hck_notify_new_ticket_admin($ticket_id);

    hck_add_log($ticket_id, $user_id, 'created', 'Ticket created');

    wp_send_json_success(array(
        'message'   => 'Ticket created',
        'ticket_id' => $ticket_id,
        'redirect'  => hck_customer_url('view/' . $ticket_id . '/'),
    ));
}

/**
 * Link files to a message: pre-uploaded temp files (only the user's own, still unattached)
 * and files sent directly with the form.
 */
function hck_attach_uploads($ticket_id, $message_id, $user_id, $is_new_ticket = false) {
    global $wpdb;

    $ticket_id = (int) $ticket_id;
    $message_id = (int) $message_id;
    $user_id = (int) $user_id;
    $att_table = $wpdb->prefix . 'hck_ticket_attachments';

    // Link only uploads belonging to this uploader and the correct
    // upload context. New-ticket uploads have ticket_id=0; reply
    // uploads are already bound to their existing ticket.
    if (!empty($_POST['uploaded_file_ids'])) {
        $ids = json_decode(wp_unslash($_POST['uploaded_file_ids']), true);

        if (is_array($ids)) {
            foreach (array_unique(array_map('absint', $ids)) as $att_id) {
                if ($att_id <= 0) continue;

                if ($is_new_ticket && $user_id > 0) {
                    // New ticket: claim only this user's unattached upload.
                    $wpdb->query($wpdb->prepare(
                        "UPDATE {$att_table}
                         SET ticket_id = %d, message_id = %d
                         WHERE id = %d
                           AND uploaded_by = %d
                           AND ticket_id = 0
                           AND message_id = 0",
                        $ticket_id, $message_id, $att_id, $user_id
                    ));
                } elseif (!$is_new_ticket && $ticket_id > 0) {
                    // Existing ticket: upload was already bound to this ticket.
                    $wpdb->query($wpdb->prepare(
                        "UPDATE {$att_table}
                         SET message_id = %d
                         WHERE id = %d
                           AND uploaded_by = %d
                           AND ticket_id = %d
                           AND message_id = 0",
                        $message_id, $att_id, $user_id, $ticket_id
                    ));
                }
            }
        }
    }

    // Direct uploads are stored against the already-created ticket/message.
    if (!empty($_FILES['attachments']['name'][0])) {
        $files = $_FILES['attachments'];

        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] !== UPLOAD_ERR_OK) continue;

            $up = hck_handle_upload(array(
                'name'     => $files['name'][$i],
                'type'     => $files['type'][$i],
                'tmp_name' => $files['tmp_name'][$i],
                'error'    => $files['error'][$i],
                'size'     => $files['size'][$i],
            ));

            if (!isset($up['error'])) {
                $wpdb->insert($att_table, array(
                    'ticket_id'   => $ticket_id,
                    'message_id'  => $message_id,
                    'filename'    => $up['filename'],
                    'file_path'   => $up['file_path'],
                    'file_size'   => $up['file_size'],
                    'file_type'   => $up['file_type'],
                    'uploaded_by' => $user_id,
                    'created_at'  => current_time('mysql'),
                ));
            }
        }
    }
}


// =============================================
/**
 * Bounded incremental recovery for open HCK ticket transcripts. Realtime Ably is
 * the primary transport; this endpoint only returns rows newer than after_id.
 */
function hck_ajax_poll_new_messages() {
    global $wpdb;
    check_ajax_referer('hck_nonce', 'nonce');
    $ticket_id = absint($_POST['ticket_id'] ?? 0);
    $after_id = absint($_POST['after_id'] ?? 0);
    if (!$ticket_id) wp_send_json_error(array('message'=>'Invalid ticket.'),400);
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket || !empty($ticket->merged_into)) wp_send_json_error(array('message'=>'Ticket not found.'),404);
    $uid = (int)get_current_user_id();
    $is_staff = $uid > 0 && function_exists('hck_is_agent') && hck_is_agent();
    if ($is_staff) {
        if (!function_exists('hck_user_can_access_ticket') || !hck_user_can_access_ticket($ticket,$uid)) wp_send_json_error(array('message'=>'You cannot view this ticket.'),403);
        $source_hc_ticket_id = absint($_POST['source_hc_ticket_id'] ?? 0);
        if ($source_hc_ticket_id) {
            $source_table = $wpdb->prefix . 'hc_ai_escalations';
            $source = $wpdb->get_row($wpdb->prepare("SELECT id,user_id,visitor_email,assigned_agent_id,closed_by_agent_id,status FROM {$source_table} WHERE id=%d",$source_hc_ticket_id));
            if (!$source) wp_send_json_error(array('message'=>'The linked HelpCenter conversation is unavailable.'),404);
            $source_access = ((int)$source->assigned_agent_id === $uid)
                || ((string)$source->status === 'closed' && (int)$source->closed_by_agent_id === $uid)
                || current_user_can('hck_view_tickets') || current_user_can('hc_manage_ai_escalations') || current_user_can('manage_options');
            $links_table = $wpdb->prefix . 'hck_hc_links';
            $verified_link = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$links_table} WHERE hc_ticket_id=%d AND hck_ticket_id=%d LIMIT 1",
                $source_hc_ticket_id, $ticket_id
            ));
            if (!$source_access || !$verified_link) wp_send_json_error(array('message'=>'You cannot access this linked customer ticket.'),403);
        }
    } else {
        $owner_id = (int)hck_get_ticket_user_id($ticket);
        $guest_ticket_id = (!$uid && function_exists('hck_guest_session_ticket_id')) ? (int)hck_guest_session_ticket_id($ticket_id) : 0;
        if (!(($uid > 0 && $owner_id === $uid) || (!$uid && $guest_ticket_id === $ticket_id))) wp_send_json_error(array('message'=>'Please verify your ticket access.'),403);
    }
    $table = $wpdb->prefix . 'hck_ticket_messages';
    $rows = $wpdb->get_results($wpdb->prepare("SELECT id,user_id,message,is_admin,is_internal,is_system,sender_name,sender_type,client_message_id,created_at FROM {$table} WHERE ticket_id=%d AND id>%d ORDER BY id ASC LIMIT 100",$ticket_id,$after_id));
    $last_id = $after_id;
    foreach ((array)$rows as $row) $last_id = max($last_id,(int)$row->id);
    $attachments_by_message = function_exists('hck_get_attachments_for_messages') ? hck_get_attachments_for_messages(wp_list_pluck((array)$rows,'id')) : array();
    $messages = array();
    foreach ((array)$rows as $row) {
        if (!$is_staff && !empty($row->is_internal)) continue;
        $id = (int)$row->id;
        $sender_type = (string)($row->sender_type ?? '');
        $sender = $sender_type !== '' ? (in_array($sender_type,array('agent','staff','ai'),true) ? 'agent' : 'customer') : (!empty($row->is_admin) ? 'agent' : 'customer');
        $attachments = array();
        foreach ((array)($attachments_by_message[$id] ?? array()) as $att) {
            $url = function_exists('hck_attachment_url') ? hck_attachment_url($att) : '';
            if (!$url) continue;
            $attachments[] = array('url'=>esc_url_raw($url),'name'=>sanitize_text_field((string)($att->filename ?? 'Attachment')),'mime'=>sanitize_text_field((string)($att->mime_type ?? $att->file_type ?? '')));
        }
        $messages[] = array('id'=>$id,'client_message_id'=>(string)($row->client_message_id ?? ''),'sender_type'=>$sender,'sender_name'=>sanitize_text_field((string)$row->sender_name),'content'=>wp_strip_all_tags((string)$row->message),'created_at'=>(string)$row->created_at,'is_internal'=>!empty($row->is_internal),'is_system'=>!empty($row->is_system),'attachments'=>$attachments);
    }
    wp_send_json_success(array('messages'=>$messages,'last_id'=>$last_id));
}


/**
 * Publish a public HCK message to Ably before its permanent database save.
 * This is a narrowly scoped fallback for browsers whose realtime client is
 * still connecting. It never writes a transcript row and never accepts notes.
 */
function hck_ajax_publish_realtime_message() {
    check_ajax_referer('hck_nonce', 'nonce');
    $ticket_id = absint($_POST['ticket_id'] ?? 0);
    $client_message_id = sanitize_text_field(wp_unslash($_POST['client_message_id'] ?? ''));
    $message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
    if (!$ticket_id || !$message || trim($message) === '') wp_send_json_error(array('message'=>'Missing message data.'),400);
    if (!preg_match('/^[A-Za-z0-9._:-]{8,64}$/', $client_message_id)) wp_send_json_error(array('message'=>'Invalid message reference.'),400);
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket || !empty($ticket->merged_into)) wp_send_json_error(array('message'=>'Ticket not found.'),404);

    $uid = (int)get_current_user_id();
    $is_staff = $uid > 0 && function_exists('hck_is_agent') && hck_is_agent();
    if ($is_staff) {
        if (!function_exists('hck_user_can_handle_ticket') || !hck_user_can_handle_ticket($ticket,$uid)) {
            wp_send_json_error(array('message'=>'Only the assigned agent can publish a reply to this ticket.'),403);
        }
        $user = get_userdata($uid);
        $sender_type = 'agent';
        $sender_name = $user ? (string)($user->display_name ?: $user->user_login) : 'Support';
    } else {
        $owner_id = function_exists('hck_get_ticket_user_id') ? (int)hck_get_ticket_user_id($ticket) : (int)($ticket->user_id ?? 0);
        $guest_ticket_id = (!$uid && function_exists('hck_guest_session_ticket_id')) ? (int)hck_guest_session_ticket_id($ticket_id) : 0;
        $is_owner = ($uid > 0 && $owner_id === $uid) || (!$uid && $guest_ticket_id === $ticket_id);
        if (!$is_owner) wp_send_json_error(array('message'=>'Please verify your ticket access.'),403);
        if (in_array((string)($ticket->status ?? ''),array('closed','resolved'),true)) wp_send_json_error(array('message'=>'This ticket is closed or resolved.'),403);
        $sender_type = 'customer';
        $sender_name = (string)($ticket->customer_name ?: 'Customer');
        if ($uid > 0) $sender_name = function_exists('hck_get_user_display') ? hck_get_user_display($uid) : $sender_name;
    }

    if (!class_exists('HC_Realtime') || !method_exists('HC_Realtime','publish_hck_message')) {
        wp_send_json_error(array('message'=>'Realtime publishing is unavailable.'),503);
    }
    $payload = array(
        'ticket_id' => $ticket_id,
        'message' => array(
            'client_message_id' => $client_message_id,
            'sender_type' => $sender_type,
            'sender_name' => sanitize_text_field($sender_name),
            'content' => $message,
            'created_at' => current_time('mysql'),
            'attachments' => array(),
        ),
    );
    if (!HC_Realtime::publish_hck_message($ticket_id,$sender_type,$payload)) {
        wp_send_json_error(array('message'=>'Realtime relay did not receive an acknowledgement.'),502);
    }
    wp_send_json_success(array('published'=>true,'client_message_id'=>$client_message_id));
}

// LOAD OLDER HCK TICKET MESSAGES (agent view)
// =============================================
/** Render one staff-side HCK transcript row in the shared WhatsApp-style layout. */
function hck_render_admin_message_markup($msg, $attachments = array()) {
    $id = (int)($msg->id ?? 0);
    $name = trim((string)($msg->sender_name ?? '')) ?: (function_exists('hck_get_user_display') ? hck_get_user_display((int)($msg->user_id ?? 0)) : 'Support');
    $is_system = !empty($msg->is_system); $is_internal = !empty($msg->is_internal); $is_admin = !empty($msg->is_admin);
    if ($is_system) return '<div class="hck-admin-system-msg"><span>'.esc_html((string)$msg->message).'</span></div>';
    if ($is_internal && $name === 'HelpCenter Handoff Brief') {
        return '<article class="hck-handoff-brief-card" data-hck-handoff-brief><div class="hck-handoff-brief-raw" hidden>'.esc_html((string)$msg->message).'</div><div class="hck-handoff-brief-rendered"><p>'.esc_html((string)$msg->message).'</p></div></article>';
    }
    $is_deleted = !empty($msg->is_deleted);
    $class = $is_internal ? 'hck-admin-msg-internal' : ($is_admin ? 'hck-admin-msg-admin' : 'hck-admin-msg-customer');
    $uid = (int)($msg->user_id ?? 0); $current = get_current_user_id();
    $supervisor = function_exists('hck_is_supervisor_user') ? hck_is_supervisor_user($current) : current_user_can('manage_options');
    $can_edit = $is_internal && !$is_deleted && !$is_system && ($uid === $current || $supervisor)
        && !in_array($name,array('HelpCenter Handoff Brief','AI Ticket Summary'),true);
    $sender_key = strtolower(($is_internal?'internal':($is_admin?'agent':'customer')).':'.($uid ?: $name));
    $created = (string)($msg->created_at ?? '');
    $html = '<div class="hck-admin-msg '.$class.($is_deleted?' is-deleted':'').'" id="msg-'.$id.'" data-message-id="'.$id.'" data-client-message-id="'.esc_attr((string)($msg->client_message_id ?? '')).'" data-user-id="'.$uid.'" data-is-internal="'.($is_internal?'1':'0').'" data-sender-key="'.esc_attr($sender_key).'" data-created-at="'.esc_attr($created).'" data-sender-name="'.esc_attr($name).'">';
    if ($is_deleted) {
        $actor = !empty($msg->deleted_by) ? get_userdata((int)$msg->deleted_by) : false;
        $actor_name = $actor ? ($actor->display_name ?: $actor->user_login) : 'support agent';
        $when = (string)($msg->deleted_at ?: $created);
        $html .= '<div class="hck-note-action-marker"><i class="fas fa-trash"></i><span>Private note deleted by '.esc_html($actor_name).' · '.esc_html($when).'</span></div></div>';
        return $html;
    }
    $first = function_exists('mb_substr') ? mb_strtoupper(mb_substr($name,0,1)) : strtoupper(substr($name,0,1));
    $role = $is_internal ? '<em class="hck-chat-role">Private note</em>' : '<em class="hck-chat-role">'.($is_admin?'Agent':'Customer').'</em>';
    $html .= '<div class="hck-admin-msg-author"><span class="hck-chat-avatar">'.esc_html($first ?: '?').'</span><div class="hck-chat-author-copy"><strong>'.esc_html($name).'</strong>'.$role.'</div></div>';
    $html .= '<div class="hck-admin-msg-body">'.wp_kses_post((string)$msg->message).'</div>';
    if (!empty($attachments)) {
        $html .= '<div class="hck-admin-msg-files">'; foreach ($attachments as $att) $html .= '<a href="'.esc_url(hck_attachment_url($att)).'" target="_blank" rel="noopener" class="hck-file-link"><i class="fas fa-paperclip"></i> '.esc_html($att->filename).'</a>'; $html .= '</div>';
    }
    if ($is_internal && !empty($msg->edited_at)) {
        $editor = !empty($msg->edited_by) ? get_userdata((int)$msg->edited_by) : false;
        $editor_name = $editor ? ($editor->display_name ?: $editor->user_login) : 'support agent';
        $html .= '<div class="hck-note-edited"><i class="fas fa-pen"></i> Edited by '.esc_html($editor_name).' · '.esc_html((string)$msg->edited_at).'</div>';
    }
    $html .= '<div class="hck-admin-msg-footer"><span><i class="far fa-clock"></i> '.esc_html($created).'</span>';
    if ($can_edit) $html .= '<span class="hck-note-actions"><button type="button" data-hck-edit-note="'.$id.'" title="Edit private note"><i class="fas fa-pen"></i> Edit</button><button type="button" data-hck-delete-note="'.$id.'" title="Delete private note"><i class="fas fa-trash"></i> Delete</button></span>';
    $html .= '</div></div>';
    return $html;
}

function hck_ajax_load_older_messages() {
    if (!hck_is_agent()) wp_send_json_error(array('message' => 'Unauthorized'), 403);
    check_ajax_referer('hck_nonce', 'nonce');

    $ticket_id = absint($_POST['ticket_id'] ?? 0);
    $before_id = absint($_POST['before_id'] ?? 0);
    if (!$ticket_id || !$before_id) wp_send_json_error(array('message' => 'Invalid conversation cursor.'), 400);

    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) wp_send_json_error(array('message' => 'Ticket not found.'), 404);
    if (!hck_user_can_access_ticket($ticket)) wp_send_json_error(array('message' => 'You cannot view this ticket.'), 403);

    $page = hck_get_messages_page($ticket_id, true, $before_id, 50);
    $messages = $page['messages'];
    $attachments = function_exists('hck_get_attachments_for_messages')
        ? hck_get_attachments_for_messages(wp_list_pluck($messages, 'id')) : array();

    $html = '';
    foreach ($messages as $msg) {
        $atts = $attachments[(int) $msg->id] ?? array();
        $html .= hck_render_admin_message_markup($msg, $atts);
    }
    wp_send_json_success(array(
        'html' => $html,
        'has_more' => !empty($page['has_more']),
        'next_before_id' => (int) $page['next_before_id'],
        'loaded' => count($messages),
    ));
}

// =============================================
// SEND REPLY (customer + admin)
// =============================================
/**
 * Publish a saved, public HCK message only when the browser's direct Ably publish
 * was not acknowledged. Internal notes are never eligible for this channel.
 */
function hck_publish_saved_message_realtime($ticket_id, $message_id) {
    if (!class_exists('HC_Realtime') || !method_exists('HC_Realtime', 'publish_hck_message')) return false;
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT id,ticket_id,user_id,is_admin,message,is_internal,sender_name,sender_type,client_message_id,created_at FROM {$wpdb->prefix}hck_ticket_messages WHERE id=%d AND ticket_id=%d",
        absint($message_id), absint($ticket_id)
    ));
    if (!$row || !empty($row->is_internal)) return false;
    $attachments = array();
    if (function_exists('hck_get_attachments') && function_exists('hck_attachment_url')) {
        foreach ((array) hck_get_attachments((int)$row->id) as $att) {
            $url = hck_attachment_url($att);
            if (!$url) continue;
            $attachments[] = array(
                'url' => esc_url_raw($url),
                'name' => sanitize_text_field((string)($att->filename ?? 'Attachment')),
                'mime' => sanitize_text_field((string)($att->mime_type ?? $att->file_type ?? '')),
            );
        }
    }
    $sender_type = in_array((string)$row->sender_type, array('agent','staff'), true) || !empty($row->is_admin) ? 'agent' : 'customer';
    $payload = array(
        'ticket_id' => (int)$row->ticket_id,
        'message' => array(
            'id' => (int)$row->id,
            'client_message_id' => (string)($row->client_message_id ?? ''),
            'sender_type' => $sender_type,
            'user_id' => (int)($row->user_id ?? 0),
            'sender_name' => sanitize_text_field((string)$row->sender_name),
            'content' => wp_strip_all_tags((string)$row->message),
            'created_at' => (string)$row->created_at,
            'attachments' => $attachments,
        ),
    );
    return HC_Realtime::publish_hck_message((int)$row->ticket_id, $sender_type, $payload);
}

function hck_internal_note_authorized($ticket, $message) {
    $uid = get_current_user_id();
    if (!$uid || !$ticket || !$message || empty($message->is_internal) || !empty($message->is_system) || !empty($message->is_deleted)) return false;
    if (!function_exists('hck_user_can_access_ticket') || !hck_user_can_access_ticket($ticket)) return false;
    $name = (string)($message->sender_name ?? '');
    if (in_array($name,array('HelpCenter Handoff Brief','AI Ticket Summary'),true)) return false;
    $supervisor = function_exists('hck_is_supervisor_user') ? hck_is_supervisor_user($uid) : current_user_can('manage_options');
    return ((int)$message->user_id === $uid) || $supervisor;
}

function hck_ajax_edit_internal_note() {
    check_ajax_referer('hck_nonce','nonce');
    if (!function_exists('hck_is_agent') || !hck_is_agent()) wp_send_json_error(array('message'=>'Agent permission required.'),403);
    global $wpdb; $ticket_id=absint($_POST['ticket_id']??0); $message_id=absint($_POST['message_id']??0);
    $ticket=hck_get_ticket($ticket_id); $table=$wpdb->prefix.'hck_ticket_messages';
    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND ticket_id=%d",$message_id,$ticket_id));
    if (!hck_internal_note_authorized($ticket,$row)) wp_send_json_error(array('message'=>'Only the note author or a supervisor can edit this private note.'),403);
    $message=trim(wp_kses_post(wp_unslash($_POST['message']??'')));
    if ($message==='' || mb_strlen(wp_strip_all_tags($message))>5000) wp_send_json_error(array('message'=>'Enter a private note up to 5,000 characters.'),400);
    $now=current_time('mysql'); $uid=get_current_user_id();
    $ok=$wpdb->update($table,array('message'=>$message,'edited_at'=>$now,'edited_by'=>$uid),array('id'=>$message_id,'ticket_id'=>$ticket_id),array('%s','%s','%d'),array('%d','%d'));
    if ($ok===false) wp_send_json_error(array('message'=>'The private note could not be updated.'),500);
    if (function_exists('hck_add_log')) hck_add_log($ticket_id,$uid,'internal_note_edited','Private note #'.$message_id.' edited.');
    $user=wp_get_current_user();
    wp_send_json_success(array('message'=>'Private note updated.','message_id'=>$message_id,'message_text'=>$message,'edited_at'=>$now,'edited_by_name'=>$user->display_name?:$user->user_login));
}

function hck_ajax_delete_internal_note() {
    check_ajax_referer('hck_nonce','nonce');
    if (!function_exists('hck_is_agent') || !hck_is_agent()) wp_send_json_error(array('message'=>'Agent permission required.'),403);
    global $wpdb; $ticket_id=absint($_POST['ticket_id']??0); $message_id=absint($_POST['message_id']??0);
    $ticket=hck_get_ticket($ticket_id); $table=$wpdb->prefix.'hck_ticket_messages';
    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND ticket_id=%d",$message_id,$ticket_id));
    if (!hck_internal_note_authorized($ticket,$row)) wp_send_json_error(array('message'=>'Only the note author or a supervisor can delete this private note.'),403);
    $now=current_time('mysql'); $uid=get_current_user_id();
    $ok=$wpdb->update($table,array('message'=>'','is_deleted'=>1,'deleted_at'=>$now,'deleted_by'=>$uid),array('id'=>$message_id,'ticket_id'=>$ticket_id),array('%s','%d','%s','%d'),array('%d','%d'));
    if ($ok===false) wp_send_json_error(array('message'=>'The private note could not be deleted.'),500);
    if (function_exists('hck_add_log')) hck_add_log($ticket_id,$uid,'internal_note_deleted','Private note #'.$message_id.' deleted.');
    $user=wp_get_current_user();
    wp_send_json_success(array('message'=>'Private note deleted.','message_id'=>$message_id,'deleted_at'=>$now,'deleted_by_name'=>$user->display_name?:$user->user_login));
}

function hck_ajax_send_reply() {
    check_ajax_referer('hck_nonce', 'nonce');

    $user_id   = (int) get_current_user_id();
    $ticket_id = intval($_POST['ticket_id'] ?? 0);
    $message   = wp_kses_post(wp_unslash($_POST['message'] ?? ''));
    $internal  = !empty($_POST['internal']) ? 1 : 0;
    $client_message_id = sanitize_text_field(wp_unslash($_POST['client_message_id'] ?? ''));
    $realtime_delivered = !empty($_POST['realtime_delivered']);
    $realtime_attempted = !empty($_POST['realtime_attempted']);
    if ($client_message_id !== '' && !preg_match('/^[A-Za-z0-9._:-]{8,64}$/', $client_message_id)) wp_send_json_error(array('message'=>'Invalid message reference.'), 400);

    if (!$ticket_id || trim(wp_strip_all_tags($message)) === '') {
        wp_send_json_error(array('message' => 'Missing data'));
    }

    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) wp_send_json_error(array('message' => 'Ticket not found'));

    // A guest can reply only to the exact ticket bound to their verified OTP session.
    $guest_ticket_id = $user_id ? 0 : hck_guest_session_ticket_id($ticket_id);
    $is_guest = !$user_id && $guest_ticket_id === $ticket_id;
    if (!$user_id && !$is_guest) wp_send_json_error(array('message' => 'Please verify your ticket email access first.'));
    $is_admin = hck_is_agent() ? 1 : 0;
    if ($is_admin && !hck_user_can_handle_ticket($ticket, $user_id)) wp_send_json_error(array('message'=>'This ticket is assigned to another agent. You can view it, but only the assigned agent can reply.'),403);
    $owner_id = (int) hck_get_ticket_user_id($ticket);
    if (!$is_admin && !$is_guest && $owner_id !== $user_id) {
        wp_send_json_error(array('message' => 'Access denied'));
    }

    // Only staff can post internal notes
    if ($internal && !$is_admin) $internal = 0;

    // Closed/resolved tickets require the controlled reopen approval workflow.
    if (!$is_admin && in_array((string)$ticket->status, array('closed','resolved'), true)) {
        wp_send_json_error(array('message' => 'This ticket is closed or resolved. Please request reopening from the ticket page.'));
    }
    if (!empty($ticket->merged_into)) wp_send_json_error(array('message'=>'This ticket was merged and is read-only. Please use the consolidated ticket.'));

    global $wpdb;

    // Idempotency: network retries must return the original saved message,
    // not create another row or send another customer notification.
    if ($client_message_id !== '') {
        $existing_row = $wpdb->get_row($wpdb->prepare(
            "SELECT id,is_internal,created_at FROM {$wpdb->prefix}hck_ticket_messages WHERE ticket_id=%d AND client_message_id=%s LIMIT 1",
            $ticket_id, $client_message_id
        ));
        if ($existing_row) {
            if (!$realtime_delivered && !$realtime_attempted && empty($existing_row->is_internal)) hck_publish_saved_message_realtime($ticket_id, (int)$existing_row->id);
            wp_send_json_success(array('message'=>'Reply was already saved.','message_id'=>(int)$existing_row->id,'created_at'=>(string)($existing_row->created_at ?? ''),'duplicate'=>true));
        }
    }

    // 1. The message
    $reply_user = $user_id ? get_userdata($user_id) : false;
    $reply_name = $is_admin ? ($reply_user ? ($reply_user->display_name ?: $reply_user->user_login) : 'Support') : ($is_guest ? ($ticket->customer_name ?: 'Customer') : ($reply_user ? hck_get_user_display($user_id) : 'Customer'));
    $message_created_at = current_time('mysql');
    $message_inserted = $wpdb->insert($wpdb->prefix . 'hck_ticket_messages', array(
        'ticket_id'   => $ticket_id,
        'user_id'     => $user_id,
        'message'     => $message,
        'is_admin'    => $is_admin,
        'is_internal' => $internal,
        'sender_name' => $reply_name,
        'sender_type' => $is_admin ? 'agent' : 'customer',
        'is_system'   => 0,
        'client_message_id' => ($client_message_id !== '' ? $client_message_id : null),
        'created_at'  => $message_created_at,
    ));
    if (!$message_inserted) {
        if ($client_message_id !== '') {
            $existing_row = $wpdb->get_row($wpdb->prepare(
                "SELECT id,is_internal,created_at FROM {$wpdb->prefix}hck_ticket_messages WHERE ticket_id=%d AND client_message_id=%s LIMIT 1",
                $ticket_id, $client_message_id
            ));
            if ($existing_row) {
                if (!$realtime_delivered && !$realtime_attempted && empty($existing_row->is_internal)) hck_publish_saved_message_realtime($ticket_id, (int)$existing_row->id);
                wp_send_json_success(array('message'=>'Reply was already saved.','message_id'=>(int)$existing_row->id,'created_at'=>(string)($existing_row->created_at ?? ''),'duplicate'=>true));
            }
        }
        wp_send_json_error(array('message' => 'The reply could not be saved. Please retry.'));
    }
    $msg_id = (int) $wpdb->insert_id;

    // 2. Attachments (own, unattached uploads only)
    hck_attach_uploads($ticket_id, $msg_id, $user_id);

    // 3. Ticket status
    $update = array('updated_at' => current_time('mysql'));
    if (!$internal) {
        if ($is_admin) {
            $update['status'] = 'awaiting_reply';
            $update['last_reply_by_admin'] = 1;
            // A fresh staff reply restarts the reminder / auto-close clock
            $update['reminder_sent_at'] = null;
        } else {
            $update['status'] = 'in_progress';
            $update['last_reply_by_admin'] = 0;
            $update['reminder_sent_at'] = null;
            if ($ticket->status === 'resolved') {
                // Customer replied to a resolved ticket: it is open again
                $update['resolved_at'] = null;
                $update['closed_at']   = null;
            }
        }
    }
    $ticket_updated = $wpdb->update($wpdb->prefix . 'hck_tickets', $update, array('id' => $ticket_id));
    if ($ticket_updated === false) error_log('[HCK] Reply saved but ticket status update failed for ticket ' . $ticket_id . ': ' . $wpdb->last_error);
    elseif (!$internal && (string)$ticket->status==='resolved') {
        // Customer reply reopens a resolved ticket; remove the previous resolution summary immediately.
        delete_option('hck_ticket_ai_summary_'.$ticket_id);
        $links_table=$wpdb->prefix.'hck_hc_links';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links_table))===$links_table) {
            $linked_hc_id=(int)$wpdb->get_var($wpdb->prepare("SELECT hc_ticket_id FROM {$links_table} WHERE hck_ticket_id=%d LIMIT 1",$ticket_id));
            if ($linked_hc_id) { $hc_table=$wpdb->prefix.'hc_ai_escalations'; if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hc_table))===$hc_table) $wpdb->update($hc_table,array('ai_summary'=>'','ai_summary_at'=>null),array('id'=>$linked_hc_id),array('%s','%s'),array('%d')); }
        }
    }

    // Record the first public staff response; internal notes never satisfy first-response SLA.
    if ($is_admin && !$internal && function_exists('hck_sla_mark_first_response')) hck_sla_mark_first_response($ticket_id);

    // 4. Emails (never for internal notes)
    if (!$internal) {
        if (function_exists('wp_schedule_single_event')) wp_schedule_single_event(time() + 5, 'hck_send_reply_notification', array((int)$ticket_id, (int)$msg_id, (int)$is_admin));
    }

    hck_add_log($ticket_id, $user_id, $internal ? 'internal_note' : 'replied', $internal ? 'Internal note added' : 'Reply posted');

    // The browser publishes first over Ably. If it could not confirm that publish,
    // use this server-side fallback after persistence. Never publish private notes.
    if (!$internal && !$realtime_delivered && !$realtime_attempted) {
        hck_publish_saved_message_realtime($ticket_id, $msg_id);
    }

    wp_send_json_success(array(
        'message'    => 'Reply sent',
        'message_id' => $msg_id,
        'created_at' => $message_created_at,
    ));
}


// =============================================
// RATE TICKET
// =============================================
function hck_ajax_rate_ticket() {
    if (!is_user_logged_in()) wp_send_json_error(array('message' => 'Please log in'));
    check_ajax_referer('hck_nonce', 'nonce');

    $user_id   = (int) get_current_user_id();
    $ticket_id = intval($_POST['ticket_id'] ?? 0);
    $rating    = intval($_POST['rating'] ?? 0);
    $resolved  = sanitize_key(wp_unslash($_POST['resolved'] ?? 'yes'));
    $comment   = sanitize_textarea_field(wp_unslash($_POST['comment'] ?? ''));

    if ($rating < 1 || $rating > 5) wp_send_json_error(array('message' => 'Please choose a rating from 1 to 5 stars'));
    if (!in_array($resolved, array('yes', 'no'), true)) $resolved = 'yes';

    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket || hck_get_ticket_user_id($ticket) !== $user_id || !empty($ticket->merged_into)) {
        wp_send_json_error(array('message' => 'Access denied'));
    }
    if (!in_array($ticket->status, array('resolved', 'closed'), true)) {
        wp_send_json_error(array('message' => 'You can rate a ticket once it has been resolved.'));
    }
    if ($resolved === 'no') {
        $closed_at = !empty($ticket->closed_at) ? $ticket->closed_at : (!empty($ticket->resolved_at) ? $ticket->resolved_at : $ticket->updated_at);
        $window_days = max(1,min(90,(int)get_option('hck_reopen_window_days',14)));
        $closed_ts = $closed_at ? strtotime($closed_at) : 0;
        if (!$closed_ts || $closed_ts < current_time('timestamp')-$window_days*DAY_IN_SECONDS) {
            wp_send_json_error(array('message'=>'The reopen request period has expired. Please create a new ticket.'));
        }
    }
    if (!empty($ticket->rated_at)) {
        wp_send_json_error(array('message' => 'You have already rated this ticket.'));
    }

    global $wpdb;
    $now = current_time('mysql');

    $rating_saved=$wpdb->insert($wpdb->prefix . 'hck_ticket_ratings', array(
        'ticket_id' => $ticket_id, 'user_id' => $user_id,
        'rating' => $rating, 'resolved' => $resolved, 'comment' => $comment,
        'agent_id' => hck_get_ticket_agent_id($ticket) ?: null, 'created_at' => $now,
    ));
    if (!$rating_saved) wp_send_json_error(array('message'=>'Your feedback could not be saved. Please try again.'));
    $rating_id=(int)$wpdb->insert_id;

    if ($resolved === 'no') {
        // A negative resolution answer requests a controlled reopen; it does not bypass agent review.
        $reopen_table = $wpdb->prefix . 'hck_ticket_reopen_requests';
        $pending = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$reopen_table} WHERE ticket_id=%d AND status='pending' LIMIT 1", $ticket_id));
        $created_reopen_request = false;
        if (!$pending) {
            $request_saved=$wpdb->insert($reopen_table, array(
                'ticket_id'=>$ticket_id, 'user_id'=>$user_id, 'customer_email'=>$ticket->customer_email ?? '',
                'reason'=>$comment, 'status'=>'pending', 'created_at'=>$now,
            ));
            if (!$request_saved) { $wpdb->delete($wpdb->prefix.'hck_ticket_ratings',array('id'=>$rating_id)); wp_send_json_error(array('message'=>'Your feedback could not be submitted with the reopen request. Please try again.')); }
            $created_reopen_request = true;
        }
        $ticket_rating_update=$wpdb->update($wpdb->prefix . 'hck_tickets', array(
            'rating'=>$rating, 'rating_comment'=>$comment, 'rated_at'=>$now, 'updated_at'=>$now,
        ), array('id'=>$ticket_id));
        if ($ticket_rating_update===false) { $wpdb->delete($wpdb->prefix.'hck_ticket_ratings',array('id'=>$rating_id)); if($created_reopen_request) $wpdb->delete($reopen_table,array('ticket_id'=>$ticket_id,'status'=>'pending')); wp_send_json_error(array('message'=>'Your feedback could not be attached to the ticket. Please try again.')); }
        hck_add_log($ticket_id, $user_id, 'reopen_requested', "Customer rated {$rating}/5 and reported the issue is not resolved.");
        if ($created_reopen_request && function_exists('hck_phase2_notify_reopen_request')) hck_phase2_notify_reopen_request($ticket);
        if (function_exists('hck_notify_admin_on_reply')) hck_notify_admin_on_reply($ticket_id);
        wp_send_json_success(array('message'=>'Thank you for the feedback. Your request to reopen this ticket has been sent to our support team for review.'));
    }

    $ticket_rating_update=$wpdb->update($wpdb->prefix . 'hck_tickets', array(
        'rating' => $rating, 'rating_comment' => $comment, 'rated_at' => $now,
        'status' => 'closed', 'closed_at' => $now, 'updated_at' => $now,
    ), array('id' => $ticket_id));
    if ($ticket_rating_update===false) { $wpdb->delete($wpdb->prefix.'hck_ticket_ratings',array('id'=>$rating_id)); wp_send_json_error(array('message'=>'Your feedback could not be attached to the ticket. Please try again.')); }

    hck_add_log($ticket_id, $user_id, 'rated', "Rated {$rating}/5");
    if (class_exists('HCK_HelpCenter_Integration')) HCK_HelpCenter_Integration::sync_helpcenter_status($ticket_id,'closed');

    wp_send_json_success(array('message' => 'Thank you!'));
}


// =============================================
// ADMIN - CHANGE STATUS
// =============================================
function hck_ajax_admin_change_status() {
    if (!hck_is_agent()) wp_send_json_error(array('message' => 'Unauthorized'));
    check_ajax_referer('hck_nonce', 'nonce');

    $ticket_id = intval($_POST['ticket_id'] ?? 0);
    $status    = sanitize_text_field(wp_unslash($_POST['status'] ?? ''));
    $valid     = array('open', 'in_progress', 'awaiting_reply', 'resolved', 'closed');

    if (!$ticket_id || !in_array($status, $valid, true)) wp_send_json_error(array('message' => 'Invalid'));

    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) wp_send_json_error(array('message' => 'Ticket not found'));
    if (!hck_user_can_handle_ticket($ticket)) wp_send_json_error(array('message'=>'Only the assigned agent can change this ticket.'),403);
    if ($ticket->status === $status) wp_send_json_success(array('message' => 'Status unchanged'));

    global $wpdb;
    $hck_reopening = in_array((string)$ticket->status,array('resolved','closed'),true) && in_array($status,array('open','in_progress','awaiting_reply'),true);
    $data = array('status' => $status, 'updated_at' => current_time('mysql'), 'reminder_sent_at' => null);
    if ($status === 'resolved') { $data['resolved_at'] = current_time('mysql'); if (function_exists('hck_sla_mark_resolution')) hck_sla_mark_resolution($ticket_id); }
    if ($status === 'closed')   $data['closed_at']   = current_time('mysql');
    if (in_array($status, array('open', 'in_progress', 'awaiting_reply'), true)) {
        $data['closed_at']   = null;
        $data['resolved_at'] = null;
    }

    $wpdb->update($wpdb->prefix . 'hck_tickets', $data, array('id' => $ticket_id));
    hck_add_log($ticket_id, get_current_user_id(), 'status_changed', 'Status: ' . $ticket->status . ' -> ' . $status);
    $links=$wpdb->prefix.'hck_hc_links';
    $linked_hc=($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links))===$links)?(int)$wpdb->get_var($wpdb->prepare("SELECT hc_ticket_id FROM {$links} WHERE hck_ticket_id=%d LIMIT 1",$ticket_id)):0;
    if ($hck_reopening) {
        // A reopened/reclaimed case starts a new resolution cycle: discard the old summary so it cannot masquerade as the latest outcome.
        delete_option('hck_ticket_ai_summary_'.$ticket_id);
        if ($linked_hc) {
            $hc_table=$wpdb->prefix.'hc_ai_escalations';
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hc_table))===$hc_table) $wpdb->update($hc_table,array('ai_summary'=>'','ai_summary_at'=>null),array('id'=>$linked_hc),array('%s','%s'),array('%d'));
            if (function_exists('wp_clear_scheduled_hook')) wp_clear_scheduled_hook('hc_agent_generate_handover_summary',array($linked_hc));
        }
    }
    if (in_array($status,array('resolved','closed'),true) && class_exists('HCK_HelpCenter_Integration')) HCK_HelpCenter_Integration::sync_helpcenter_status($ticket_id,$status,get_current_user_id());
    if (in_array($status,array('resolved','closed'),true)) {
        // Always replace a pending summary job; a previous resolution must never win this race.
        if ($linked_hc && class_exists('HC_Agent_Portal')) {
            if(function_exists('wp_clear_scheduled_hook')) wp_clear_scheduled_hook('hc_agent_generate_handover_summary',array($linked_hc));
            wp_schedule_single_event(time()+2,'hc_agent_generate_handover_summary',array($linked_hc));
        } elseif (!$linked_hc) {
            if(function_exists('wp_clear_scheduled_hook')) wp_clear_scheduled_hook('hck_generate_ticket_ai_summary_background',array($ticket_id));
            wp_schedule_single_event(time()+2,'hck_generate_ticket_ai_summary_background',array($ticket_id));
        }
    }

    if ($status === 'resolved' && function_exists('hck_notify_ticket_resolved')) hck_notify_ticket_resolved($ticket_id);
    if ($status === 'closed'   && function_exists('hck_notify_ticket_closed'))   hck_notify_ticket_closed($ticket_id);

    wp_send_json_success(array('message' => 'Status updated'));
}


// =============================================
// ADMIN - CHANGE AGENT
// =============================================
function hck_ajax_admin_change_agent() {
    if (!hck_is_agent()) wp_send_json_error(array('message' => 'Unauthorized'));
    check_ajax_referer('hck_nonce', 'nonce');

    $ticket_id = intval($_POST['ticket_id'] ?? 0);
    $agent_id  = intval($_POST['agent_id'] ?? 0);
    $current_ticket = $ticket_id ? hck_get_ticket($ticket_id) : null;
    if (!$current_ticket || !empty($current_ticket->merged_into)) wp_send_json_error(array('message' => 'Invalid or merged ticket'));
    $is_supervisor = hck_is_supervisor_user();
    if (!$is_supervisor && !hck_user_can_handle_ticket($current_ticket)) {
        wp_send_json_error(array('message'=>'Only the assigned agent or a supervisor can transfer this ticket.'),403);
    }

    // The target must be an eligible support staff member (or 0 = unassigned).
    if ($agent_id) {
        $agent_user = get_userdata($agent_id);
        $staff_roles = array('administrator', 'shop_manager', 'hc_support_agent');
        if (!$agent_user || !(array_intersect($staff_roles, (array) $agent_user->roles) || user_can($agent_id, 'manage_options') || user_can($agent_id, 'hc_manage_ai_escalations') || user_can($agent_id, 'hck_reply_tickets'))) {
            wp_send_json_error(array('message' => 'That user cannot be assigned as an agent'));
        }
    }

    global $wpdb;
    $old_agent_id = hck_get_ticket_agent_id($current_ticket);
    if ($old_agent_id === $agent_id) wp_send_json_success(array('message' => 'Ticket is already assigned to that agent.'));
    $old_agent = $old_agent_id ? get_userdata($old_agent_id) : false;
    $new_agent = $agent_id ? get_userdata($agent_id) : false;
    $old_name = $old_agent ? $old_agent->display_name : 'Unassigned';
    $new_name = $new_agent ? $new_agent->display_name : 'Unassigned';
    $wpdb->update($wpdb->prefix . 'hck_tickets', array(
        'agent_id'   => $agent_id ? $agent_id : null,
        'updated_at' => current_time('mysql'),
    ), array('id' => $ticket_id));

    hck_add_log($ticket_id, get_current_user_id(), 'agent_transferred', sprintf('Ticket transferred from %s to %s by %s.', $old_name, $new_name, wp_get_current_user()->display_name));
    delete_option('hck_ticket_ai_summary_'.$ticket_id);
    $links_table=$wpdb->prefix.'hck_hc_links';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links_table))===$links_table) {
        $linked_hc_id=(int)$wpdb->get_var($wpdb->prepare("SELECT hc_ticket_id FROM {$links_table} WHERE hck_ticket_id=%d LIMIT 1",$ticket_id));
        if ($linked_hc_id) {
            $hc_table=$wpdb->prefix.'hc_ai_escalations';
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hc_table))===$hc_table) $wpdb->update($hc_table,array('ai_summary'=>'','ai_summary_at'=>null),array('id'=>$linked_hc_id),array('%s','%s'),array('%d'));
        }
    }
    wp_send_json_success(array('message' => 'Ticket transferred to ' . $new_name . '. The previous AI summary was cleared and will be regenerated after the next resolution.'));
}


// =============================================
// ADMIN - CHANGE PRIORITY
// =============================================
function hck_ajax_admin_change_priority() {
    if (!hck_is_agent()) wp_send_json_error(array('message' => 'Unauthorized'));
    check_ajax_referer('hck_nonce', 'nonce');

    $ticket_id = intval($_POST['ticket_id'] ?? 0);
    $priority  = sanitize_key(wp_unslash($_POST['priority'] ?? ''));
    $current_ticket = $ticket_id ? hck_get_ticket($ticket_id) : null;
    if (!$current_ticket || !empty($current_ticket->merged_into) || !in_array($priority, hck_valid_priorities(), true)) {
        wp_send_json_error(array('message' => 'Invalid'));
    }
    if (!hck_user_can_handle_ticket($current_ticket)) wp_send_json_error(array('message'=>'Only the assigned agent can change this ticket.'),403);

    global $wpdb;
    $wpdb->update($wpdb->prefix . 'hck_tickets', array(
        'priority' => $priority, 'updated_at' => current_time('mysql'),
    ), array('id' => $ticket_id));

    hck_add_log($ticket_id, get_current_user_id(), 'priority_changed', 'Priority: ' . $priority);
    wp_send_json_success(array('message' => 'Priority updated'));
}



// =============================================
// PHASE 2 - SAVE AGENT WORKLOAD CAPACITY
// =============================================
function hck_ajax_save_agent_capacity() {
    if (!hck_is_supervisor_user()) {
        wp_send_json_error(array('message' => 'Supervisor access required.'), 403);
    }
    check_ajax_referer('hck_nonce', 'nonce');
    $agent_id = absint($_POST['agent_id'] ?? 0);
    $capacity = absint($_POST['capacity'] ?? 0);
    $agent = $agent_id ? get_userdata($agent_id) : false;
    if (!$agent || $capacity < 1 || $capacity > 500) {
        wp_send_json_error(array('message' => 'Choose a valid agent and a capacity between 1 and 500.'), 400);
    }
    $staff_roles = array('administrator', 'shop_manager', 'hc_support_agent');
    $eligible = (bool)array_intersect($staff_roles, (array)$agent->roles) || user_can($agent_id, 'hc_manage_ai_escalations') || user_can($agent_id, 'hck_reply_tickets');
    if (!$eligible) wp_send_json_error(array('message' => 'This user is not an eligible support agent.'), 400);
    update_user_meta($agent_id, 'hck_agent_capacity', $capacity);
    wp_send_json_success(array('message' => 'Capacity updated.', 'capacity' => $capacity));
}

// =============================================
// PHASE 2 - ADD CUSTOMER-LEVEL INTERNAL NOTE
// =============================================
function hck_ajax_add_customer_note() {
    if (!hck_is_agent()) wp_send_json_error(array('message'=>'Unauthorized'),403);
    check_ajax_referer('hck_nonce','nonce');
    $ticket_id = absint($_POST['ticket_id'] ?? 0);
    $note = trim(sanitize_textarea_field(wp_unslash($_POST['note'] ?? '')));
    if (!$ticket_id || mb_strlen($note) < 3) wp_send_json_error(array('message'=>'Please enter a note with at least 3 characters.'),400);
    if (mb_strlen($note) > 5000) wp_send_json_error(array('message'=>'Customer notes cannot exceed 5,000 characters.'),400);
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) wp_send_json_error(array('message'=>'Customer reference not found.'),404);
    $assigned_agent = hck_get_ticket_agent_id($ticket);
    $is_supervisor = current_user_can('manage_options') || current_user_can('manage_woocommerce');
    if (!$is_supervisor && $assigned_agent !== get_current_user_id()) wp_send_json_error(array('message'=>'Only the assigned agent or a supervisor can add customer notes.'),403);
    $uid = hck_get_ticket_user_id($ticket);
    $email = sanitize_email((string)($ticket->customer_email ?? ''));
    if (!$email && $uid) $email = sanitize_email((string)hck_get_user_email($uid));
    if (!$uid && !is_email($email)) wp_send_json_error(array('message'=>'This guest customer has no verified email. A customer-level note cannot be safely linked.'),400);
    global $wpdb;
    $table = $wpdb->prefix.'hck_customer_notes';
    $ok = $wpdb->insert($table,array('customer_user_id'=>$uid,'customer_email'=>$email,'note'=>$note,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')),array('%d','%s','%s','%d','%s'));
    if (!$ok) wp_send_json_error(array('message'=>'Could not save the customer note. '.$wpdb->last_error),500);
    $note_id = (int)$wpdb->insert_id;
    $actor = wp_get_current_user();
    wp_send_json_success(array('message'=>'Internal customer note saved.','note'=>array('id'=>$note_id,'note'=>$note,'created_by'=>$actor->display_name,'created_at'=>current_time('mysql'))));
}


function hck_ajax_save_sla_policy(){
    if(!current_user_can('manage_options'))wp_send_json_error(array('message'=>'Only administrators can change SLA policy.'),403);
    check_ajax_referer('hck_nonce','nonce');
    $policy=array(); foreach(array('urgent','high','normal','low') as $p){foreach(array('first','resolve') as $k){$name=$p.'_'.$k;$v=isset($_POST[$name])?absint($_POST[$name]):0;if($v<5||$v>43200)wp_send_json_error(array('message'=>'All SLA targets must be between 5 and 43,200 minutes.'));$policy[$p][$k]=$v;} if($policy[$p]['resolve']<$policy[$p]['first'])wp_send_json_error(array('message'=>ucfirst($p).' resolution target must be equal to or greater than its first-response target.'));}
    update_option('hck_sla_policy',$policy,false); wp_send_json_success(array('message'=>'SLA policy saved.'));
}

// =============================================
// ADMIN - SAVE SETTINGS
// =============================================
function hck_ajax_save_settings() {
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Unauthorized'));
    check_ajax_referer('hck_nonce', 'nonce');

    global $wpdb;
    $table = $wpdb->prefix . 'hck_ticket_settings';

    $allowed = array(
        'hck_site_title', 'hck_support_email', 'hck_email_notifications',
        'hck_auto_close_enabled', 'hck_auto_close_days', 'hck_reminder_days', 'hck_reopen_window_days',
        'hck_max_attachment_size', 'hck_allowed_file_types', 'hck_primary_color', 'hck_ticket_categories',
        'hck_ticket_prefix','hck_ticket_suffix_tc','hck_ticket_suffix_hc','hck_helpcenter_category',
        // email templates
        'email_new_ticket_customer', 'email_new_ticket_customer_subject',
        'email_new_ticket_admin',    'email_new_ticket_admin_subject',
        'email_admin_reply',         'email_admin_reply_subject',
        'email_customer_reply',      'email_customer_reply_subject',
        'email_ticket_resolved',     'email_ticket_resolved_subject',
        'email_ticket_closed',       'email_ticket_closed_subject',
        'email_reminder',            'email_reminder_subject',
    );

    $errors = array();
    $tc_suffix = strtoupper(preg_replace('/[^A-Z0-9-]/i','',sanitize_text_field(wp_unslash($_POST['hck_ticket_suffix_tc'] ?? hck_get_setting('hck_ticket_suffix_tc','TC')))));
    $hc_suffix = strtoupper(preg_replace('/[^A-Z0-9-]/i','',sanitize_text_field(wp_unslash($_POST['hck_ticket_suffix_hc'] ?? hck_get_setting('hck_ticket_suffix_hc','HC')))));
    if ($tc_suffix==='' || $hc_suffix==='' || $tc_suffix===$hc_suffix) wp_send_json_error(array('message'=>'Ticket Center and HelpCenter suffixes must both be filled in and must be different.'));

    foreach ($allowed as $key) {
        if (!isset($_POST[$key])) continue;
        $raw = wp_unslash($_POST[$key]);

        if (strpos($key, '_subject') !== false) {
            $value = sanitize_text_field($raw);
        } elseif (strpos($key, 'email_') === 0) {
            $value = wp_kses_post($raw);
        } elseif ($key === 'hck_support_email') {
            $value = sanitize_email($raw);
            if (!is_email($value)) { $errors[] = 'Support email is not a valid address'; continue; }
        } elseif ($key === 'hck_primary_color') {
            $value = sanitize_hex_color($raw);
            if (!$value) { $errors[] = 'Primary colour must be a hex value like #6366F1'; continue; }
        } elseif ($key === 'hck_auto_close_days') {
            $value = (string) max(1, min(90, absint($raw)));
        } elseif ($key === 'hck_reminder_days') {
            $value = (string) max(1, min(30, absint($raw)));
        } elseif ($key === 'hck_reopen_window_days') {
            update_option('hck_reopen_window_days', max(1,min(90,absint($raw))));
            continue;
        } elseif ($key === 'hck_max_attachment_size') {
            $value = (string) max(1, min(100, absint($raw)));
        } elseif ($key === 'hck_email_notifications' || $key === 'hck_auto_close_enabled') {
            $value = ($raw === '1' || $raw === 1) ? '1' : '0';
        } elseif ($key === 'hck_allowed_file_types') {
            $types = array_filter(array_map(function ($t) {
                return preg_replace('/[^a-z0-9]/', '', strtolower(trim($t)));
            }, explode(',', $raw)));
            $types = array_diff($types, hck_blocked_extensions());
            $value = implode(',', array_unique($types));
            if ($value === '') { $errors[] = 'Allowed file types cannot be empty (executable types are always blocked)'; continue; }
        } elseif (in_array($key,array('hck_ticket_prefix','hck_ticket_suffix_tc','hck_ticket_suffix_hc'),true)) {
            $value = strtoupper(preg_replace('/[^A-Z0-9-]/i','',sanitize_text_field($raw)));
            if ($key==='hck_ticket_prefix' && $value==='') { $errors[]='Ticket prefix cannot be empty'; continue; }
        } elseif ($key === 'hck_helpcenter_category') {
            $value = sanitize_title($raw);
        } elseif ($key === 'hck_ticket_categories') {
            $value = sanitize_text_field($raw);
            if (empty(array_filter(array_map('trim', explode(',', $value))))) {
                $errors[] = 'Add at least one ticket category'; continue;
            }
        } else {
            $value = sanitize_text_field($raw);
        }

        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE setting_key = %s", $key));
        if ($exists) {
            $wpdb->update($table, array('setting_value' => $value), array('setting_key' => $key));
        } else {
            $wpdb->insert($table, array('setting_key' => $key, 'setting_value' => $value));
        }
        wp_cache_delete('hck_setting_' . sanitize_key($key), 'hck');
    }

    // Apply configured HelpCenter category and regenerate all historical numbers when format changes.
    $number_keys=array('hck_ticket_prefix','hck_ticket_suffix_tc','hck_ticket_suffix_hc');
    $number_changed=false; foreach($number_keys as $nk) if(isset($_POST[$nk])) $number_changed=true;
    if($number_changed && function_exists('hck_regenerate_all_ticket_numbers')) {
        if(!hck_regenerate_all_ticket_numbers()) $errors[]='Ticket numbering settings were saved, but existing ticket numbers could not all be updated. Please retry and check the database log.';
    }

    // Reminder must come before auto-close, otherwise the reminder could never fire
    $all    = hck_get_all_settings();
    $close  = isset($all['hck_auto_close_days']) ? (int) $all['hck_auto_close_days'] : 7;
    $remind = isset($all['hck_reminder_days'])   ? (int) $all['hck_reminder_days']   : 3;
    if (!empty($all['hck_auto_close_enabled']) && $all['hck_auto_close_enabled'] === '1' && $remind >= $close) {
        $errors[] = 'The reminder should be sent before the auto-close day (reminder: ' . $remind . ', auto-close: ' . $close . ')';
    }

    if (!empty($errors)) {
        wp_send_json_error(array('message' => 'Saved with warnings: ' . implode('; ', $errors)));
    }
    wp_send_json_success(array('message' => 'Settings saved'));
}


// =============================================
// ADMIN REPLY (wrapper — for admin-side reply form)
// =============================================
function hck_ajax_admin_reply() {
    if (!hck_is_agent()) wp_send_json_error(array('message' => 'Unauthorized'));
    hck_ajax_send_reply();
}

// =============================================
// AI HANDOVER SUMMARY — INDIVIDUAL TICKET VIEW
// =============================================
function hck_generate_ticket_ai_summary_background($ticket_id) {
    $ticket_id=absint($ticket_id); if(!$ticket_id || !class_exists('HC_AI') || !method_exists('HC_AI','chat_model')) return;
    $ticket=hck_get_ticket($ticket_id); if(!$ticket || !in_array((string)$ticket->status,array('resolved','closed'),true)) return;
    $summary_basis_updated=(string)($ticket->updated_at??'');
    $messages=function_exists('hck_get_messages')?hck_get_messages($ticket_id,true):array(); $lines=array();
    foreach((array)$messages as $m){$body=trim(wp_strip_all_tags((string)($m->message??'')));if($body==='')continue;$internal=!empty($m->is_internal)?'Internal note':'Public message';$sender=!empty($m->sender_name)?(string)$m->sender_name:(!empty($m->is_admin)?'Support agent':'Customer');$lines[]='['.(string)($m->created_at??'').'] '.$internal.' — '.$sender.': '.$body;}
    $transcript=implode("\n",array_slice($lines,-180));
    $prompt="Create a complete, concise internal case summary in Markdown with exactly these sections: ## Customer's original issue, ## Investigation and agent actions, ## Final resolution and outcome, ## Outstanding items. Begin with what the customer contacted support about. Describe what the agent actually investigated, verified, explained, requested or changed. State exactly what finally happened and distinguish completed actions from promises. If the transcript does not confirm a final outcome, write **No final resolution was recorded** and state what remains pending. Never assume the customer is satisfied or the issue is fixed. Include exact ticket/order references, product names, amounts and dates only when present. Internal notes are staff-only evidence; do not describe them as customer-facing statements. Use only verified facts and never invent an action or resolution.\n\nTicket: ".(function_exists('hck_get_ticket_number')?hck_get_ticket_number($ticket):'#'.$ticket_id)."\nSubject: ".(string)$ticket->subject."\nCustomer: ".(string)($ticket->customer_name??'Not recorded')."\nStatus: ".(string)$ticket->status."\n\nChronological conversation:\n".$transcript;
    try{$summary=HC_AI::chat_model(array(array('role'=>'system','content'=>'You are a precise internal support case analyst. Produce a factual Markdown summary only. Do not write to the customer. Do not invent missing information.'),array('role'=>'user','content'=>$prompt)));}
    catch(Throwable $e){error_log('[HCK] Background AI summary failed for ticket '.$ticket_id.': '.$e->getMessage());return;}
    if(is_wp_error($summary)||!is_string($summary)||trim($summary)===''){error_log('[HCK] Background AI summary returned no content for ticket '.$ticket_id);return;}
    $fresh_ticket=hck_get_ticket($ticket_id);
    if(!$fresh_ticket || !in_array((string)$fresh_ticket->status,array('resolved','closed'),true) || (string)($fresh_ticket->updated_at??'')!==$summary_basis_updated){error_log('[HCK] Discarded stale AI summary for ticket '.$ticket_id.' because the ticket changed during generation.');return;}
    update_option('hck_ticket_ai_summary_'.$ticket_id,array('summary'=>mb_substr(trim($summary),0,10000),'generated_at'=>current_time('mysql'),'source'=>'closed_ticket_background'),false);
}

function hck_ajax_generate_ticket_ai_summary() {
    if (!hck_is_agent() || current_user_can('manage_options') || current_user_can('manage_woocommerce')) wp_send_json_error(array('message'=>'Only support agents can generate ticket summaries.'),403);
    check_ajax_referer('hck_nonce','nonce');
    $ticket_id=absint($_POST['ticket_id']??0);
    if(!$ticket_id) wp_send_json_error(array('message'=>'Invalid ticket ID.'),400);
    $ticket=hck_get_ticket($ticket_id);
    if(!$ticket) wp_send_json_error(array('message'=>'Ticket not found.'),404);
    if(!hck_user_can_handle_ticket($ticket)) wp_send_json_error(array('message'=>'Only the assigned support agent can generate this summary.'),403);
    // AI summaries are available to authorized support staff whenever the AI provider is configured.
    if(!class_exists('HC_AI') || !method_exists('HC_AI','chat_model')) wp_send_json_error(array('message'=>'The HelpCenter AI provider is not available. Check that AI is configured and enabled.'),503);
    $messages=function_exists('hck_get_messages')?hck_get_messages($ticket_id,true):array();
    $lines=array();
    foreach((array)$messages as $m){
        $body=trim(wp_strip_all_tags((string)($m->message??'')));
        if($body==='') continue;
        $internal=!empty($m->is_internal)?'Internal note':'Public message';
        $sender=!empty($m->sender_name)?(string)$m->sender_name:(!empty($m->is_admin)?'Support agent':'Customer');
        $lines[]='['.(string)($m->created_at??'').'] '.$internal.' — '.$sender.': '.$body;
    }
    if(!$lines && trim((string)$ticket->subject)==='') wp_send_json_error(array('message'=>'There is not enough ticket information to summarize.'),400);
    $transcript=implode("\n",array_slice($lines,-180));
    $customer=trim((string)($ticket->customer_name??''));
    $prompt="Create a complete, concise internal case summary in Markdown with exactly these sections: ## Customer's original issue, ## Investigation and agent actions, ## Final resolution and outcome, ## Outstanding items. Start by stating what the customer contacted support about. Explain what the agent actually checked, verified, explained, requested or changed. State what finally happened and distinguish completed actions from promises. If no final outcome is confirmed, write **No final resolution was recorded** and identify what remains pending. Never claim the issue is fixed or the customer is satisfied without transcript evidence. Include exact ticket/order IDs, products, amounts, dates and reference numbers only when present. Treat internal notes as staff-only evidence, not customer-facing statements. Use only verified transcript facts and never invent details.\n\nTicket number: ".(function_exists('hck_get_ticket_number')?hck_get_ticket_number($ticket):'#'.$ticket_id)."\nSubject: ".(string)$ticket->subject."\nCustomer: ".($customer!==''?$customer:'Not recorded')."\nCategory: ".(string)($ticket->category??'')."\nPriority: ".(string)($ticket->priority??'')."\nStatus: ".(string)($ticket->status??'')."\nSource: ".(string)($ticket->source??'')."\n\nChronological ticket conversation:\n".$transcript;
    try {
        $summary=HC_AI::chat_model(array(
            array('role'=>'system','content'=>'You are a precise internal customer-support case analyst. Produce a factual Markdown handover summary only. Do not write a customer reply. Do not invent missing details.'),
            array('role'=>'user','content'=>$prompt)
        ));
    } catch(Throwable $e) {
        error_log('[HCK] AI ticket summary exception for ticket '.$ticket_id.': '.$e->getMessage());
        wp_send_json_error(array('message'=>'The AI provider failed while generating the summary. Check the HelpCenter PHP error log.'),502);
    }
    if(is_wp_error($summary)||!is_string($summary)||trim($summary)==='') {
        $reason=is_wp_error($summary)?$summary->get_error_message():'The AI provider returned an empty summary.';
        error_log('[HCK] AI ticket summary provider error for ticket '.$ticket_id.': '.$reason);
        wp_send_json_error(array('message'=>$reason),502);
    }
    $summary=mb_substr(trim($summary),0,10000);
    $generated=current_time('mysql');
    update_option('hck_ticket_ai_summary_'.$ticket_id,array('summary'=>$summary,'generated_at'=>$generated),false);
    wp_send_json_success(array('summary'=>$summary,'generated_at'=>$generated));
}

// =============================================
// UPLOAD FILE (shared / legacy)
// =============================================
function hck_ajax_upload_file() {
    if (!is_user_logged_in()) wp_send_json_error(array('message' => 'Please log in'));
    check_ajax_referer('hck_nonce', 'nonce');

    if (empty($_FILES['file'])) wp_send_json_error(array('message' => 'No file'));

    $up = hck_handle_upload($_FILES['file']);
    if (isset($up['error'])) wp_send_json_error($up);

    wp_send_json_success($up);
}

// =============================================
// TEMP UPLOAD — pre-upload files before message send
// =============================================
function hck_ajax_upload_temp() {
    check_ajax_referer('hck_nonce', 'nonce');

    $ticket_id = absint($_POST['ticket_id'] ?? 0);
    $user_id = (int) get_current_user_id();

    if ($ticket_id > 0) {
        $ticket = hck_get_ticket($ticket_id);

        if (!$ticket) {
            wp_send_json_error(array('message' => 'Ticket not found.'), 404);
        }

        if ($user_id > 0) {
            if (hck_is_agent()) {
                if (!hck_user_can_handle_ticket($ticket, $user_id)) {
                    wp_send_json_error(array('message' => 'You cannot upload files to this ticket.'), 403);
                }
            } elseif ((int) hck_get_ticket_user_id($ticket) !== $user_id) {
                wp_send_json_error(array('message' => 'Access denied.'), 403);
            }
        } else {
            if ((int) hck_guest_session_ticket_id($ticket_id) !== $ticket_id) {
                wp_send_json_error(array('message' => 'Please verify your ticket email access first.'), 403);
            }
        }
    } else {
        // Creating a new ticket is a logged-in customer workflow.
        // Anonymous uploads must always be associated with an existing,
        // OTP-verified ticket.
        if ($user_id <= 0 || hck_is_agent()) {
            wp_send_json_error(array('message' => 'Please sign in or verify your ticket access first.'), 403);
        }
    }

    if (empty($_FILES['file'])) {
        wp_send_json_error(array('message' => 'No file'));
    }

    $up = hck_handle_upload($_FILES['file']);
    if (isset($up['error'])) {
        wp_send_json_error(array('message' => $up['error']));
    }

    global $wpdb;
    $table = $wpdb->prefix . 'hck_ticket_attachments';

    // New-ticket uploads remain unattached. Existing-ticket uploads
    // are bound to their authorized ticket immediately.
    $inserted = $wpdb->insert($table, array(
        'ticket_id'   => $ticket_id,
        'message_id'  => 0,
        'filename'    => $up['filename'],
        'file_path'   => $up['file_path'],
        'file_size'   => $up['file_size'],
        'file_type'   => $up['file_type'],
        'uploaded_by' => $user_id,
        'created_at'  => current_time('mysql'),
    ));

    if (!$inserted) {
        $stored_name = basename((string) wp_parse_url($up['file_path'], PHP_URL_PATH));
        if ($stored_name !== '') {
            @unlink(trailingslashit(hck_upload_dir()) . $stored_name);
        }
        wp_send_json_error(array('message' => 'The file was uploaded but could not be registered. Please retry.'));
    }

    wp_send_json_success(array(
        'attachment_id' => (int) $wpdb->insert_id,
        'filename'      => $up['filename'],
        'file_path'     => $up['file_path'],
        'file_size'     => $up['file_size'],
        'file_type'     => $up['file_type'],
    ));
}

// =============================================
// PREVIEW EMAIL TEMPLATE
// =============================================
function hck_ajax_preview_email() {
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Unauthorized'));
    check_ajax_referer('hck_nonce', 'nonce');

    $key     = sanitize_text_field(wp_unslash($_POST['template'] ?? ''));
    $body    = wp_kses_post(wp_unslash($_POST['body'] ?? ''));
    $subject = sanitize_text_field(wp_unslash($_POST['subject'] ?? ''));

    $tags = array(
        '{ticket_number}'  => 'TKT-2026-000042',
        '{ticket_subject}' => 'Product arrived damaged',
        '{ticket_id}'      => '42',
        '{customer_name}'  => 'John Smith',
        '{customer_email}' => 'john@example.com',
        '{site_name}'      => hck_get_setting('hck_site_title', get_bloginfo('name')),
        '{status}'         => 'Open',
        '{priority}'       => 'Normal',
        '{category}'       => 'Order',
        '{admin_name}'     => 'Support Team',
        '{reply}'          => 'Thanks for reaching out. We will look into this.',
        '{ticket_url}'     => hck_customer_url('view/42/'),
        '{admin_url}'      => hck_admin_url('view/42/'),
        '{create_url}'     => hck_customer_url('create/'),
        '{order_id}'       => '#3812',
        '{order_details}'  => '',
        '{rating}'         => '5',
        '{current_date}'   => date('F j, Y'),
        '{current_time}'   => date('g:i A'),
        '{days_inactive}'  => '3',
        '{days_remaining}' => '4',
    );

    $rendered_body    = hck_replace_email_tags($body, $tags);
    $rendered_subject = hck_replace_email_tags($subject, $tags);

    wp_send_json_success(array(
        'subject' => $rendered_subject,
        'body'    => $rendered_body,
    ));
}
