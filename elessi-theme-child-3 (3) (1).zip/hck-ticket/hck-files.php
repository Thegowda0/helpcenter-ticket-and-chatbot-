<?php
/**
 * HCK Ticket System - Protected attachment downloads
 *
 * Files live in wp-content/uploads/hck-tickets/ and are NEVER linked directly.
 * Every download goes through /ticket/file/{id}/ which checks who is asking:
 *   - administrators can open any attachment
 *   - a customer can open attachments of their OWN tickets (not those on internal notes)
 *   - an unattached upload can only be opened by the person who uploaded it
 */

if (!defined('ABSPATH')) exit;

function hck_file_error($code, $message) {
    status_header($code);
    nocache_headers();
    wp_die(esc_html($message), esc_html($message), array('response' => $code));
}

function hck_serve_attachment($att_id) {
    global $wpdb;

    $att_id = (int) $att_id;
    if ($att_id <= 0) hck_file_error(404, 'File not found');

    $att = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}hck_ticket_attachments WHERE id = %d",
        $att_id
    ));

    if (!$att) hck_file_error(404, 'File not found');

    $user_id = (int) get_current_user_id();
    $ticket_id = (int) $att->ticket_id;
    $message_id = (int) $att->message_id;
    $allowed = false;

    // Preserve existing agent access.
    if ($user_id > 0 && hck_is_agent()) {
        $allowed = true;

    // Unattached uploads are accessible only to their logged-in uploader.
    // Never authorize anonymous users by uploaded_by=0.
    } elseif ($ticket_id === 0) {
        $allowed = (
            $user_id > 0 &&
            (int) $att->uploaded_by === $user_id &&
            $message_id === 0
        );

    } else {
        $ticket = hck_get_ticket($ticket_id);

        if ($ticket) {
            $is_owner = (
                $user_id > 0 &&
                (int) hck_get_ticket_user_id($ticket) === $user_id
            );

            $is_verified_guest = (
                $user_id === 0 &&
                (int) hck_guest_session_ticket_id($ticket_id) === $ticket_id
            );

            if ($is_owner || $is_verified_guest) {
                // Temporary uploads bound to a ticket have message_id=0.
                // Once linked, the message must exist, belong to this same
                // ticket, and must not be an internal note.
                if ($message_id === 0) {
                    $allowed = true;
                } else {
                    $message = $wpdb->get_row($wpdb->prepare(
                        "SELECT ticket_id, is_internal
                         FROM {$wpdb->prefix}hck_ticket_messages
                         WHERE id = %d",
                        $message_id
                    ));

                    $allowed = (
                        $message &&
                        (int) $message->ticket_id === $ticket_id &&
                        (int) $message->is_internal === 0
                    );
                }
            }
        }
    }

    if (!$allowed) {
        hck_file_error(403, 'You do not have access to this file');
    }

    $path = hck_attachment_path($att);
    if ($path === '' || !is_readable($path)) {
        hck_file_error(404, 'File not found');
    }

    $ext = strtolower(pathinfo(
        $att->filename ? $att->filename : $path,
        PATHINFO_EXTENSION
    ));

    $inline_types = array(
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'webp' => 'image/webp',
        'pdf' => 'application/pdf',
    );

    $is_inline = isset($inline_types[$ext]);
    $type = $is_inline ? $inline_types[$ext] : 'application/octet-stream';

    $download_name = sanitize_file_name(
        $att->filename ? $att->filename : basename($path)
    );

    while (ob_get_level()) ob_end_clean();

    nocache_headers();
    header('X-Content-Type-Options: nosniff');
    header('Content-Type: ' . $type);
    header('Content-Length: ' . filesize($path));
    header(
        'Content-Disposition: ' .
        ($is_inline ? 'inline' : 'attachment') .
        '; filename="' . $download_name .
        '"; filename*=UTF-8\'\'' . rawurlencode($download_name)
    );

    readfile($path);
    exit;
}
