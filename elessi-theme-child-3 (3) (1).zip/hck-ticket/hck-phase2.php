<?php
/** Phase 2 Milestone 4: safe ticket merge, controlled reopen requests and CSAT reporting. */
if (!defined('ABSPATH')) exit;

function hck_phase2_install() {
    if (get_option('hck_phase2_m4_db_version') === '1') return;
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $p = $wpdb->prefix; $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE {$p}hck_ticket_reopen_requests (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        ticket_id BIGINT(20) UNSIGNED NOT NULL,
        user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        customer_email VARCHAR(190) NOT NULL DEFAULT '',
        reason TEXT DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        reviewed_by BIGINT(20) UNSIGNED DEFAULT NULL,
        review_note TEXT DEFAULT NULL,
        created_at DATETIME NOT NULL,
        reviewed_at DATETIME DEFAULT NULL,
        PRIMARY KEY (id), KEY ticket_id (ticket_id), KEY status (status), KEY created_at (created_at)
    ) $charset;";
    dbDelta($sql);
    $cols = $wpdb->get_col("DESCRIBE {$p}hck_tickets", 0);
    if (!in_array('merged_into', $cols, true)) $wpdb->query("ALTER TABLE {$p}hck_tickets ADD merged_into BIGINT(20) UNSIGNED DEFAULT NULL");
    if (!in_array('merged_at', $cols, true)) $wpdb->query("ALTER TABLE {$p}hck_tickets ADD merged_at DATETIME DEFAULT NULL");
    $rating_cols=$wpdb->get_col("DESCRIBE {$p}hck_ticket_ratings",0);
    if (!in_array('agent_id',$rating_cols,true)) $wpdb->query("ALTER TABLE {$p}hck_ticket_ratings ADD agent_id BIGINT(20) UNSIGNED DEFAULT NULL");
    if (!get_option('hck_reopen_window_days')) add_option('hck_reopen_window_days', 14);
    update_option('hck_phase2_m4_db_version', '1');
}
add_action('init', 'hck_phase2_install', 6);

function hck_phase2_is_supervisor() {
    return function_exists('hck_is_supervisor_user') && hck_is_supervisor_user();
}
function hck_phase2_customer_matches($a, $b) {
    $au = (int) hck_get_ticket_user_id($a); $bu = (int) hck_get_ticket_user_id($b);
    if ($au > 0 || $bu > 0) return $au > 0 && $au === $bu;
    $ae = strtolower(trim((string)($a->customer_email ?? '')));
    $be = strtolower(trim((string)($b->customer_email ?? '')));
    return $ae !== '' && $ae === $be;
}

function hck_phase2_merge_tickets($source_id, $target_id, $actor_id) {
    global $wpdb;
    $source = hck_get_ticket($source_id); $target = hck_get_ticket($target_id);
    if (!$source || !$target) return new WP_Error('not_found', 'One or both tickets could not be found.');
    if ($source_id === $target_id) return new WP_Error('same_ticket', 'Choose two different tickets.');
    if (!empty($source->merged_into) || !empty($target->merged_into)) return new WP_Error('already_merged', 'A merged ticket cannot be used in another merge.');
    if (!hck_phase2_customer_matches($source, $target)) return new WP_Error('customer_mismatch', 'Tickets can only be merged when they belong to the same customer.');
    if ((int)$source->user_id === 0 && empty($source->customer_email)) return new WP_Error('unverified_guest', 'Guest tickets need a matching customer email before they can be merged.');
    $t = $wpdb->prefix;
    $hc_links=$t.'hck_hc_links';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hc_links))===$hc_links) {
        $linked=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$hc_links} WHERE hck_ticket_id IN (%d,%d)",$source_id,$target_id));
        if ($linked) return new WP_Error('helpcenter_linked', 'At least one ticket is directly linked to a HelpCenter conversation. Merge is blocked to protect the existing HelpCenter-to-ticket mapping.');
    }
    $pending_reopen=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t}hck_ticket_reopen_requests WHERE ticket_id IN (%d,%d) AND status='pending'",$source_id,$target_id));
    if ($pending_reopen) return new WP_Error('pending_reopen','A ticket with a pending reopen request cannot be merged. Review the reopen request first.');
    $wpdb->query('START TRANSACTION');
    $locked = $wpdb->get_results($wpdb->prepare("SELECT id,merged_into,user_id,customer_id,customer_email FROM {$t}hck_tickets WHERE id IN (%d,%d) ORDER BY id FOR UPDATE", $source_id, $target_id));
    if (count((array)$locked) !== 2) { $wpdb->query('ROLLBACK'); return new WP_Error('lock_failed', 'Could not lock both tickets for a safe merge.'); }
    $locked_map=array(); foreach($locked as $locked_ticket) $locked_map[(int)$locked_ticket->id]=$locked_ticket;
    if (!empty($locked_map[$source_id]->merged_into) || !empty($locked_map[$target_id]->merged_into)) { $wpdb->query('ROLLBACK'); return new WP_Error('already_merged', 'One of these tickets was merged by another user. Refresh and try again.'); }
    $locked_pending=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t}hck_ticket_reopen_requests WHERE ticket_id IN (%d,%d) AND status='pending'",$source_id,$target_id));
    if ($locked_pending) { $wpdb->query('ROLLBACK'); return new WP_Error('pending_reopen','A ticket with a pending reopen request cannot be merged. Review the reopen request first.'); }
    $messages = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t}hck_ticket_messages WHERE ticket_id=%d ORDER BY created_at ASC,id ASC", $source_id), ARRAY_A);
    $map = array();
    foreach ((array)$messages as $message) {
        $old_id = (int)$message['id']; unset($message['id']); $message['ticket_id'] = $target_id;
        if ($wpdb->insert($t.'hck_ticket_messages', $message) === false) { $wpdb->query('ROLLBACK'); return new WP_Error('copy_message', 'Could not safely copy every message. No merge was applied.'); }
        $map[$old_id] = (int)$wpdb->insert_id;
    }
    $attachments = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t}hck_ticket_attachments WHERE ticket_id=%d ORDER BY id ASC", $source_id), ARRAY_A);
    foreach ((array)$attachments as $attachment) {
        unset($attachment['id']); $old_message = (int)$attachment['message_id'];
        $attachment['ticket_id'] = $target_id;
        if (!isset($map[$old_message])) { $wpdb->query('ROLLBACK'); return new WP_Error('orphan_attachment', 'An attachment is not linked to a source message. No merge was applied.'); }
        $attachment['message_id'] = $map[$old_message];
        if ($wpdb->insert($t.'hck_ticket_attachments', $attachment) === false) { $wpdb->query('ROLLBACK'); return new WP_Error('copy_attachment', 'Could not safely copy every attachment. No merge was applied.'); }
    }
    $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t}hck_ticket_logs WHERE ticket_id=%d ORDER BY id ASC", $source_id), ARRAY_A);
    foreach ((array)$logs as $log) {
        unset($log['id']); $log['ticket_id'] = $target_id;
        if ($wpdb->insert($t.'hck_ticket_logs', $log) === false) { $wpdb->query('ROLLBACK'); return new WP_Error('copy_log', 'Could not preserve ticket history. No merge was applied.'); }
    }
    $now = current_time('mysql');
    $system_insert=$wpdb->insert($t.'hck_ticket_messages', array('ticket_id'=>$target_id,'user_id'=>$actor_id,'message'=>'Ticket history merged from '.hck_get_ticket_number($source).'. Original ticket remains available as a read-only record.','is_admin'=>1,'is_system'=>1,'created_at'=>$now));
    if (!$system_insert) { $wpdb->query('ROLLBACK'); return new WP_Error('system_message', 'Could not add the merge audit message. No merge was committed.'); }
    $source_update=$wpdb->update($t.'hck_tickets', array('merged_into'=>$target_id,'merged_at'=>$now,'status'=>'closed','closed_at'=>$now,'updated_at'=>$now), array('id'=>$source_id));
    $target_update=$wpdb->update($t.'hck_tickets', array('updated_at'=>$now), array('id'=>$target_id));
    if ($source_update===false || $target_update===false) { $wpdb->query('ROLLBACK'); return new WP_Error('merge_failed', 'Ticket records could not be updated. No merge was committed.'); }
    $source_log=$wpdb->insert($t.'hck_ticket_logs', array('ticket_id'=>$source_id,'user_id'=>$actor_id,'action'=>'merged_into','details'=>'Merged into '.hck_get_ticket_number($target).'. Messages, attachments and audit history copied to destination.','created_at'=>$now));
    $target_log=$wpdb->insert($t.'hck_ticket_logs', array('ticket_id'=>$target_id,'user_id'=>$actor_id,'action'=>'ticket_merge_received','details'=>'Received history from '.hck_get_ticket_number($source).'.','created_at'=>$now));
    if (!$source_log || !$target_log) { $wpdb->query('ROLLBACK'); return new WP_Error('merge_failed', 'Merge audit history could not be saved. No merge was committed.'); }
    $wpdb->query('COMMIT');
    return true;
}

function hck_phase2_notify_merge($source, $target) {
    $email=sanitize_email($target->customer_email ?? '');
    if (!$email && hck_get_ticket_user_id($target)) { $u=get_userdata(hck_get_ticket_user_id($target)); if($u) $email=$u->user_email; }
    if (!$email || !is_email($email)) return;
    $body="Your support tickets ".hck_get_ticket_number($source)." and ".hck_get_ticket_number($target)." have been consolidated so our team can continue helping you in one conversation. Your previous messages and attachments are available in the consolidated ticket: ".hck_customer_url('view/'.(int)$target->id.'/');
    wp_mail($email,'Your support tickets have been consolidated',$body,array('Content-Type: text/plain; charset=UTF-8'));
}
function hck_phase2_notify_reopen_request($ticket) {
    $agent_id=hck_get_ticket_agent_id($ticket); $agent=$agent_id?get_userdata($agent_id):false;
    $email=$agent?$agent->user_email:get_option('admin_email');
    if (!$email || !is_email($email)) return;
    $body='A customer requested that support ticket '.hck_get_ticket_number($ticket).' be reopened. Review the request in the Agent Desk: '.hck_admin_url('view/'.(int)$ticket->id.'/');
    wp_mail($email,'Customer reopen request: '.hck_get_ticket_number($ticket),$body,array('Content-Type: text/plain; charset=UTF-8'));
}

function hck_ajax_phase2_merge_ticket() {
    if (!hck_phase2_is_supervisor()) wp_send_json_error(array('message'=>'Only supervisors can merge tickets.'),403);
    check_ajax_referer('hck_nonce','nonce');
    $source = absint($_POST['source_ticket_id'] ?? 0); $target = absint($_POST['target_ticket_id'] ?? 0);
    $result = hck_phase2_merge_tickets($source,$target,get_current_user_id());
    if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()));
    hck_phase2_notify_merge(hck_get_ticket($source),hck_get_ticket($target));
    wp_send_json_success(array('message'=>'Ticket history merged successfully. The original ticket remains read-only.','redirect'=>hck_admin_url('view/'.$target.'/')));
}
add_action('wp_ajax_hck_phase2_merge_ticket','hck_ajax_phase2_merge_ticket');

function hck_ajax_phase2_request_reopen() {
    check_ajax_referer('hck_nonce','nonce');
    global $wpdb; $ticket_id=absint($_POST['ticket_id'] ?? 0); $reason=sanitize_textarea_field(wp_unslash($_POST['reason'] ?? ''));
    $ticket=hck_get_ticket($ticket_id);
    $guest_ok=!is_user_logged_in() && hck_guest_session_ticket_id($ticket_id)===$ticket_id;
    if (!$ticket || (is_user_logged_in() ? hck_get_ticket_user_id($ticket)!==get_current_user_id() : !$guest_ok)) wp_send_json_error(array('message'=>'Ticket access denied.'),403);
    if (!in_array($ticket->status,array('closed','resolved'),true) || !empty($ticket->merged_into)) wp_send_json_error(array('message'=>'Only closed or resolved tickets can be reopened by request.'));
    $days=max(1,min(90,(int)get_option('hck_reopen_window_days',14)));
    $closed_ts=!empty($ticket->closed_at)?strtotime($ticket->closed_at):(!empty($ticket->resolved_at)?strtotime($ticket->resolved_at):strtotime($ticket->updated_at));
    if (!$closed_ts || $closed_ts < current_time('timestamp')-$days*DAY_IN_SECONDS) wp_send_json_error(array('message'=>'The reopen request period has expired. Please create a new ticket.'));
    $table=$wpdb->prefix.'hck_ticket_reopen_requests';
    $wpdb->query('START TRANSACTION');
    $locked_ticket=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}hck_tickets WHERE id=%d FOR UPDATE",$ticket_id));
    if (!$locked_ticket) { $wpdb->query('ROLLBACK'); wp_send_json_error(array('message'=>'Ticket no longer exists.')); }
    $ticket=hck_get_ticket($ticket_id);
    if (!$ticket || !in_array($ticket->status,array('closed','resolved'),true) || !empty($ticket->merged_into)) { $wpdb->query('ROLLBACK'); wp_send_json_error(array('message'=>'This ticket is no longer eligible for reopening.')); }
    $closed_ts=!empty($ticket->closed_at)?strtotime($ticket->closed_at):(!empty($ticket->resolved_at)?strtotime($ticket->resolved_at):strtotime($ticket->updated_at));
    if (!$closed_ts || $closed_ts < current_time('timestamp')-$days*DAY_IN_SECONDS) { $wpdb->query('ROLLBACK'); wp_send_json_error(array('message'=>'The reopen request period has expired. Please create a new ticket.')); }
    $pending=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE ticket_id=%d AND status='pending' LIMIT 1",$ticket_id));
    if ($pending) { $wpdb->query('ROLLBACK'); wp_send_json_error(array('message'=>'A reopen request is already waiting for review.')); }
    $ok=$wpdb->insert($table,array('ticket_id'=>$ticket_id,'user_id'=>get_current_user_id(),'customer_email'=>$ticket->customer_email ?? '', 'reason'=>$reason,'status'=>'pending','created_at'=>current_time('mysql')));
    if (!$ok) { $wpdb->query('ROLLBACK'); wp_send_json_error(array('message'=>'Could not submit your request. Please try again.')); }
    $wpdb->query('COMMIT');
    hck_add_log($ticket_id,get_current_user_id(),'reopen_requested','Customer requested ticket reopening.');
    hck_phase2_notify_reopen_request($ticket);
    wp_send_json_success(array('message'=>'Your reopen request has been sent to our support team.'));
}
add_action('wp_ajax_hck_phase2_request_reopen','hck_ajax_phase2_request_reopen');
add_action('wp_ajax_nopriv_hck_phase2_request_reopen','hck_ajax_phase2_request_reopen');

function hck_phase2_notify_reopen_decision($ticket, $approved, $note='') {
    $email = sanitize_email($ticket->customer_email ?? '');
    if (!$email && hck_get_ticket_user_id($ticket)) { $u=get_userdata(hck_get_ticket_user_id($ticket)); if($u) $email=$u->user_email; }
    if (!$email || !is_email($email)) return;
    $number=hck_get_ticket_number($ticket);
    $subject=$approved ? "Your support ticket {$number} has been reopened" : "Update on your support ticket {$number}";
    $body=$approved ? "Your request to reopen support ticket {$number} has been approved. You can continue the conversation in your support portal: ".hck_customer_url('view/'.(int)$ticket->id.'/') : "Your request to reopen support ticket {$number} was not approved. ".($note ? "Reason: {$note} " : '')."If you still need assistance, please create a new support ticket: ".hck_customer_url('create/');
    wp_mail($email,$subject,$body,array('Content-Type: text/plain; charset=UTF-8'));
}

function hck_ajax_phase2_review_reopen() {
    if (!hck_is_agent()) wp_send_json_error(array('message'=>'Unauthorized'),403);
    check_ajax_referer('hck_nonce','nonce');
    $id=absint($_POST['request_id'] ?? 0); $decision=sanitize_key($_POST['decision'] ?? ''); $note=sanitize_textarea_field(wp_unslash($_POST['note'] ?? ''));
    if (!$id || !in_array($decision,array('approve','reject'),true)) wp_send_json_error(array('message'=>'Invalid request.'));
    global $wpdb; $table=$wpdb->prefix.'hck_ticket_reopen_requests'; $request=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND status='pending'",$id));
    if (!$request) wp_send_json_error(array('message'=>'This request has already been reviewed.'));
    $ticket=hck_get_ticket((int)$request->ticket_id); if (!$ticket || !empty($ticket->merged_into)) wp_send_json_error(array('message'=>'Ticket is no longer eligible for reopening.'));
    $reviewer_id=(int)get_current_user_id();
    $is_assigned_agent=(hck_get_ticket_agent_id($ticket)===$reviewer_id) || ((int)($ticket->assigned_to ?? 0)===$reviewer_id);
    if (!hck_phase2_is_supervisor() && !$is_assigned_agent) wp_send_json_error(array('message'=>'Only the assigned agent or a supervisor can review this request.'),403);
    $now=current_time('mysql');
    $wpdb->query('START TRANSACTION');
    $updated=$wpdb->update($table,array('status'=>$decision==='approve'?'approved':'rejected','reviewed_by'=>get_current_user_id(),'review_note'=>$note,'reviewed_at'=>$now),array('id'=>$id,'status'=>'pending'));
    if ($updated!==1) { $wpdb->query('ROLLBACK'); wp_send_json_error(array('message'=>'Request changed while you were reviewing it. Refresh and try again.')); }
    if ($decision==='approve') {
        $ticket_update=$wpdb->update($wpdb->prefix.'hck_tickets',array('status'=>'in_progress','resolved_at'=>null,'closed_at'=>null,'reminder_sent_at'=>null,'last_reply_by_admin'=>0,'rating'=>null,'rating_comment'=>null,'rated_at'=>null,'updated_at'=>$now),array('id'=>$ticket->id));
        if ($ticket_update===false) { $wpdb->query('ROLLBACK'); wp_send_json_error(array('message'=>'Ticket could not be reopened. The request remains pending.')); }
        $system_message=$wpdb->insert($wpdb->prefix.'hck_ticket_messages',array('ticket_id'=>$ticket->id,'user_id'=>get_current_user_id(),'message'=>'Support approved the customer’s request to reopen this ticket.','is_admin'=>1,'is_system'=>1,'created_at'=>$now));
        if (!$system_message) { $wpdb->query('ROLLBACK'); wp_send_json_error(array('message'=>'The reopen event could not be recorded. No changes were committed.')); }
    }
    hck_add_log((int)$ticket->id,get_current_user_id(),$decision==='approve'?'reopen_approved':'reopen_rejected',$note ?: ('Reopen request '.$decision.'.'));
    $wpdb->query('COMMIT');
    if ($decision==='approve') {
        // Approved reopen starts a new resolution cycle; never leave the old summary visible.
        delete_option('hck_ticket_ai_summary_'.(int)$ticket->id);
        $links_table=$wpdb->prefix.'hck_hc_links';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links_table))===$links_table) {
            $linked_hc_id=(int)$wpdb->get_var($wpdb->prepare("SELECT hc_ticket_id FROM {$links_table} WHERE hck_ticket_id=%d LIMIT 1",(int)$ticket->id));
            if ($linked_hc_id) { $hc_table=$wpdb->prefix.'hc_ai_escalations'; if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hc_table))===$hc_table) $wpdb->update($hc_table,array('ai_summary'=>'','ai_summary_at'=>null),array('id'=>$linked_hc_id),array('%s','%s'),array('%d')); }
        }
        if (class_exists('HCK_HelpCenter_Integration')) HCK_HelpCenter_Integration::sync_helpcenter_status((int)$ticket->id,'in_progress',get_current_user_id());
    }
    hck_phase2_notify_reopen_decision($ticket,$decision==='approve',$note);
    wp_send_json_success(array('message'=>$decision==='approve'?'Ticket reopened.':'Reopen request rejected.'));
}
add_action('wp_ajax_hck_phase2_review_reopen','hck_ajax_phase2_review_reopen');

function hck_phase2_admin_csat_page() {
    if (!hck_phase2_is_supervisor()) { echo '<div class="hck-admin-empty">Access denied.</div>'; return; }
    global $wpdb; $table=$wpdb->prefix.'hck_ticket_ratings'; $tickets=$wpdb->prefix.'hck_tickets';
    $days=isset($_GET['days'])?absint($_GET['days']):30; if (!in_array($days,array(7,30,90,365),true)) $days=30;
    $agent_filter=absint($_GET['agent'] ?? 0); $category_filter=sanitize_key(wp_unslash($_GET['category'] ?? ''));
    $since=gmdate('Y-m-d H:i:s',current_time('timestamp')-$days*DAY_IN_SECONDS);
    $where='r.created_at >= %s'; $args=array($since);
    if ($agent_filter) { $where.=' AND COALESCE(r.agent_id,t.agent_id)=%d'; $args[]=$agent_filter; }
    if ($category_filter!=='') { $where.=' AND t.category=%s'; $args[]=$category_filter; }
    $stats=$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) total,ROUND(AVG(r.rating),2) average_rating,SUM(r.rating=5) five_star,SUM(r.rating=4) four_star,SUM(r.rating=3) three_star,SUM(r.rating=2) two_star,SUM(r.rating=1) one_star,SUM(r.resolved='no') unresolved FROM {$table} r LEFT JOIN {$tickets} t ON t.id=r.ticket_id WHERE {$where}",$args));
    $rows=$wpdb->get_results($wpdb->prepare("SELECT r.id,r.ticket_id,r.user_id,r.rating,r.resolved,r.comment,r.created_at,t.ticket_number,t.subject,COALESCE(r.agent_id,t.agent_id) AS agent_id,t.category FROM {$table} r LEFT JOIN {$tickets} t ON t.id=r.ticket_id WHERE {$where} ORDER BY r.created_at DESC LIMIT 250",$args));
    $agent_rows=$wpdb->get_results($wpdb->prepare("SELECT COALESCE(r.agent_id,t.agent_id) AS agent_id,COUNT(*) responses,ROUND(AVG(r.rating),2) average_rating,SUM(r.rating>=4) positive FROM {$table} r LEFT JOIN {$tickets} t ON t.id=r.ticket_id WHERE {$where} GROUP BY COALESCE(r.agent_id,t.agent_id) ORDER BY average_rating DESC,responses DESC",$args));
    $total=(int)($stats->total ?? 0); $positive=$total?round(((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} r LEFT JOIN {$tickets} t ON t.id=r.ticket_id WHERE {$where} AND r.rating>=4",$args)))/$total*100):0;
    $staff=array_merge((array)get_users(array('role__in'=>array('administrator','shop_manager','hc_support_agent'),'orderby'=>'display_name','number'=>300)),(array)get_users(array('capability'=>'hc_manage_ai_escalations','orderby'=>'display_name','number'=>300)),(array)get_users(array('capability'=>'hck_reply_tickets','orderby'=>'display_name','number'=>300)));
    $staff_map=array(); foreach($staff as $staff_user) $staff_map[(int)$staff_user->ID]=$staff_user; $staff=array_values($staff_map);
    $categories=hck_get_ticket_categories();
    echo '<div class="hck-admin-page-head"><div><h1>Customer Satisfaction</h1><p>Customer ratings, comments and agent-level quality signals.</p></div></div>';
    echo '<form method="get" class="hck-admin-card" style="padding:14px;display:flex;gap:10px;flex-wrap:wrap;align-items:end"><input type="hidden" name="hck_page" value="admin-csat"><label>Period<select name="days">'; foreach(array(7=>'7 days',30=>'30 days',90=>'90 days',365=>'12 months') as $n=>$label) echo '<option value="'.(int)$n.'" '.selected($days,$n,false).'>'.esc_html($label).'</option>'; echo '</select></label><label>Agent<select name="agent"><option value="0">All agents</option>'; foreach($staff as $u) echo '<option value="'.(int)$u->ID.'" '.selected($agent_filter,(int)$u->ID,false).'>'.esc_html($u->display_name).'</option>'; echo '</select></label><label>Category<select name="category"><option value="">All categories</option>'; foreach($categories as $slug=>$label) echo '<option value="'.esc_attr($slug).'" '.selected($category_filter,$slug,false).'>'.esc_html($label).'</option>'; echo '</select></label><button class="hck-admin-btn hck-admin-btn-primary" type="submit">Apply filters</button></form>';
    echo '<div class="hck-admin-stats-grid">'; $cards=array('Responses'=>$total,'Average rating'=>$total?number_format((float)$stats->average_rating,2).'/5':'—','Positive ratings'=>$positive.'%','Needs more help'=>(int)$stats->unresolved); foreach($cards as $label=>$value) echo '<div class="hck-admin-stat-card"><span>'.esc_html($label).'</span><strong>'.esc_html((string)$value).'</strong></div>'; echo '</div>';
    echo '<div class="hck-admin-card"><div class="hck-admin-card-head"><h2>Rating distribution</h2></div><div class="hck-admin-card-body"><div class="hck-csat-distribution">'; foreach(array(5=>'five_star',4=>'four_star',3=>'three_star',2=>'two_star',1=>'one_star') as $star=>$field) { $count=(int)($stats->$field ?? 0); $pct=$total?round($count/$total*100):0; echo '<div class="hck-csat-distribution-row"><strong>'.$star.' ★</strong><div><span style="width:'.$pct.'%"></span></div><small>'.$count.' ('.$pct.'%)</small></div>'; } echo '</div></div></div>';
    echo '<div class="hck-admin-card"><div class="hck-admin-card-head"><h2>Agent satisfaction</h2></div><div class="hck-admin-card-body"><div class="hck-admin-table-wrap"><table class="hck-admin-table"><thead><tr><th>Agent</th><th>Responses</th><th>Average rating</th><th>Positive ratings</th></tr></thead><tbody>';
    if (!$agent_rows) echo '<tr><td colspan="4">No agent ratings in this period.</td></tr>';
    foreach((array)$agent_rows as $ar) { $u=$ar->agent_id?get_userdata((int)$ar->agent_id):false; $pct=(int)$ar->responses?round(((int)$ar->positive/(int)$ar->responses)*100):0; echo '<tr><td>'.esc_html($u?$u->display_name:'Unassigned / historical').'</td><td>'.(int)$ar->responses.'</td><td>'.esc_html($ar->average_rating===null?'—':number_format((float)$ar->average_rating,2).'/5').'</td><td>'.$pct.'%</td></tr>'; }
    echo '</tbody></table></div></div></div>';
    echo '<div class="hck-admin-card"><div class="hck-admin-card-head"><h2>Customer feedback</h2></div><div class="hck-admin-card-body"><div class="hck-admin-table-wrap"><table class="hck-admin-table"><thead><tr><th>Ticket</th><th>Rating</th><th>Outcome</th><th>Customer comment</th><th>Agent</th><th>Category</th><th>Date</th></tr></thead><tbody>';
    if (!$rows) echo '<tr><td colspan="7">No ratings in this period.</td></tr>';
    foreach((array)$rows as $r) { $agent=$r->agent_id?get_userdata((int)$r->agent_id):false; $url=hck_admin_url('view/'.(int)$r->ticket_id.'/'); echo '<tr><td><a href="'.esc_url($url).'">'.esc_html($r->ticket_number ?: '#'.$r->ticket_id).'</a><small>'.esc_html(wp_trim_words($r->subject,9,'…')).'</small></td><td><strong>'.(int)$r->rating.'/5 ★</strong></td><td>'.(!empty($r->resolved) && $r->resolved==='no' ? '<span class="hck-csat-needs-help">Needs more help</span>' : 'Resolved').'</td><td>'.esc_html($r->comment ?: '—').'</td><td>'.esc_html($agent?$agent->display_name:'Unassigned').'</td><td>'.esc_html($categories[$r->category] ?? ($r->category ?: '—')).'</td><td>'.esc_html(hck_format_date($r->created_at)).'</td></tr>'; }
    echo '</tbody></table></div></div></div>';
}
