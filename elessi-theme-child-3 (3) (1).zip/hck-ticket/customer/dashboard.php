<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$user_id = get_current_user_id();
$stats = hck_get_user_stats($user_id);

// Recent tickets
$t = $wpdb->prefix . 'hck_tickets';
$col = hck_column_exists($t, 'user_id') ? 'user_id' : 'customer_id';
$recent = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM $t WHERE $col = %d ORDER BY updated_at DESC LIMIT 5",
    $user_id
));
?>

<div class="hck-page-header">
    <div>
        <h1><i class="fas fa-th-large"></i> Support Dashboard</h1>
        <p class="hck-subtitle">Welcome back, <?php echo esc_html(wp_get_current_user()->display_name); ?></p>
    </div>
    <a href="<?php echo esc_url(hck_customer_url('create/')); ?>" class="hck-btn hck-btn-primary">
        <i class="fas fa-plus"></i> New Ticket
    </a>
</div>

<div class="hck-stats">
    <a href="<?php echo esc_url(hck_customer_url('my-tickets/')); ?>" class="hck-stat">
        <div class="hck-stat-icon" style="background:#EEF2FF;color:#6366F1;"><i class="fas fa-ticket-alt"></i></div>
        <div class="hck-stat-value"><?php echo $stats['total']; ?></div>
        <div class="hck-stat-label">Total</div>
    </a>
    <a href="<?php echo esc_url(hck_customer_url('my-tickets/?status=open')); ?>" class="hck-stat">
        <div class="hck-stat-icon" style="background:#FEF2F2;color:#EF4444;"><i class="fas fa-folder-open"></i></div>
        <div class="hck-stat-value"><?php echo $stats['open']; ?></div>
        <div class="hck-stat-label">Open</div>
    </a>
    <a href="<?php echo esc_url(hck_customer_url('my-tickets/?status=in_progress')); ?>" class="hck-stat">
        <div class="hck-stat-icon" style="background:#FFFBEB;color:#F59E0B;"><i class="fas fa-spinner"></i></div>
        <div class="hck-stat-value"><?php echo $stats['in_progress']; ?></div>
        <div class="hck-stat-label">In Progress</div>
    </a>
    <a href="<?php echo esc_url(hck_customer_url('my-tickets/?status=awaiting_reply')); ?>" class="hck-stat">
        <div class="hck-stat-icon" style="background:#F5F3FF;color:#8B5CF6;"><i class="fas fa-reply"></i></div>
        <div class="hck-stat-value"><?php echo $stats['awaiting_reply']; ?></div>
        <div class="hck-stat-label">Awaiting</div>
    </a>
    <a href="<?php echo esc_url(hck_customer_url('my-tickets/?status=resolved')); ?>" class="hck-stat">
        <div class="hck-stat-icon" style="background:#ECFDF5;color:#10B981;"><i class="fas fa-check-circle"></i></div>
        <div class="hck-stat-value"><?php echo $stats['resolved']; ?></div>
        <div class="hck-stat-label">Resolved</div>
    </a>
    <a href="<?php echo esc_url(hck_customer_url('my-tickets/?status=closed')); ?>" class="hck-stat">
        <div class="hck-stat-icon" style="background:#F1F5F9;color:#64748B;"><i class="fas fa-lock"></i></div>
        <div class="hck-stat-value"><?php echo $stats['closed']; ?></div>
        <div class="hck-stat-label">Closed</div>
    </a>
</div>

<?php if ($stats['awaiting_reply'] > 0): ?>
<div class="hck-alert hck-alert-warning">
    <i class="fas fa-exclamation-triangle"></i>
    <div>
        <strong>Action Required</strong>
        <p>You have <?php echo $stats['awaiting_reply']; ?> ticket(s) waiting for your reply.</p>
    </div>
    <a href="<?php echo esc_url(hck_customer_url('my-tickets/?status=awaiting_reply')); ?>" class="hck-btn hck-btn-sm">View</a>
</div>
<?php endif; ?>

<div class="hck-card">
    <div class="hck-card-header">
        <h2><i class="fas fa-clock"></i> Recent Tickets</h2>
        <a href="<?php echo esc_url(hck_customer_url('my-tickets/')); ?>" class="hck-btn hck-btn-outline hck-btn-sm">View All <i class="fas fa-arrow-right"></i></a>
    </div>
    
    <?php if ($recent): ?>
    <div class="hck-ticket-list">
        <?php foreach ($recent as $ticket): ?>
        <a href="<?php echo esc_url(hck_customer_url('view/' . $ticket->id . '/')); ?>" class="hck-ticket-row">
            <div class="hck-ticket-status-dot" data-status="<?php echo esc_attr($ticket->status); ?>"></div>
            <div class="hck-ticket-content">
                <div class="hck-ticket-top">
                    <span class="hck-ticket-number"><?php echo esc_html(hck_get_ticket_number($ticket)); ?></span>
                    <span class="hck-badge hck-badge-<?php echo esc_attr($ticket->status); ?>"><?php echo esc_html(hck_get_status_label($ticket->status)); ?></span>
                </div>
                <div class="hck-ticket-subject"><?php echo esc_html($ticket->subject); ?></div>
                <div class="hck-ticket-meta">
                    <span><i class="far fa-clock"></i> <?php echo esc_html(hck_time_ago($ticket->updated_at)); ?></span>
                </div>
            </div>
            <i class="fas fa-chevron-right hck-ticket-arrow"></i>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="hck-empty">
        <i class="fas fa-inbox"></i>
        <h3>No tickets yet</h3>
        <p>You haven't created any support tickets.</p>
        <a href="<?php echo esc_url(hck_customer_url('create/')); ?>" class="hck-btn hck-btn-primary">
            <i class="fas fa-plus"></i> Create First Ticket
        </a>
    </div>
    <?php endif; ?>
</div>
