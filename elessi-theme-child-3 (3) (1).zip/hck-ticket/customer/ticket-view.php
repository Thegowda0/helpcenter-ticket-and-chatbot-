<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$ticket_id = (int) get_query_var('hck_ticket');
$ticket = hck_get_ticket($ticket_id);
$user_id = (int) get_current_user_id();

if (!$ticket) {
    echo '<div class="hck-empty"><i class="fas fa-exclamation-circle"></i><h3>Ticket not found</h3><a href="' . esc_url(hck_customer_url()) . '" class="hck-btn hck-btn-primary">Back to Dashboard</a></div>';
    return;
}

$owner_id = (int) hck_get_ticket_user_id($ticket);
if ($owner_id !== $user_id) {
    echo '<div class="hck-empty"><i class="fas fa-lock"></i><h3>Access Denied</h3><p>This ticket belongs to someone else.</p><a href="' . esc_url(hck_customer_url()) . '" class="hck-btn hck-btn-primary">Back</a></div>';
    return;
}

if (isset($_POST['hck_close_ticket'], $_POST['hck_close_nonce'])
    && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hck_close_nonce'])), 'hck_close_ticket_' . $ticket_id)
    && !in_array($ticket->status, array('closed', 'resolved'), true)) {
    global $wpdb;
    $wpdb->update($wpdb->prefix . 'hck_tickets', array(
        'status' => 'closed',
        'closed_at' => current_time('mysql'),
        'updated_at' => current_time('mysql'),
    ), array('id' => $ticket_id));

    $wpdb->insert($wpdb->prefix . 'hck_ticket_messages', array(
        'ticket_id' => $ticket_id,
        'user_id' => $user_id,
        'message' => 'Ticket closed by customer.',
        'is_admin' => 0,
        'is_system' => 1,
        'created_at' => current_time('mysql'),
    ));
    hck_add_log($ticket_id, $user_id, 'closed', 'Closed by customer');

    wp_safe_redirect(hck_customer_url('view/' . $ticket_id . '/'));
    exit;
}

$messages = hck_get_messages($ticket_id, false);
$hck_last_message_id = 0; foreach ((array)$messages as $loaded_message) $hck_last_message_id = max($hck_last_message_id, (int)$loaded_message->id);
$hck_attachments_by_message = function_exists('hck_get_attachments_for_messages') ? hck_get_attachments_for_messages(wp_list_pluck($messages, 'id')) : array();
$can_reply = !in_array($ticket->status, array('closed','resolved'), true) && empty($ticket->merged_into);
$can_close = !in_array($ticket->status, array('closed', 'resolved'));
$reopen_request = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}hck_ticket_reopen_requests WHERE ticket_id=%d ORDER BY id DESC LIMIT 1", $ticket_id));
$can_rate  = in_array($ticket->status, array('resolved', 'closed')) && empty($ticket->rated_at) && empty($ticket->merged_into) && (!$reopen_request || $reopen_request->status !== 'pending');
$reopen_days = max(1,min(90,(int)get_option('hck_reopen_window_days',14)));
$closed_time = !empty($ticket->closed_at) ? strtotime($ticket->closed_at) : (!empty($ticket->resolved_at) ? strtotime($ticket->resolved_at) : strtotime($ticket->updated_at));
$reopen_allowed = in_array($ticket->status,array('closed','resolved'),true) && empty($ticket->merged_into) && $closed_time && $closed_time >= current_time('timestamp')-$reopen_days*DAY_IN_SECONDS;

$order_details = array();
$related = hck_filter_user_orders(json_decode((string) $ticket->related_orders, true), $owner_id);
if (!empty($related) && function_exists('wc_get_order')) {
    foreach ($related as $oid) {
        $o = wc_get_order($oid);
        if ($o) $order_details[] = $o;
    }
}
?>

<div class="hck-ticket-hero">
    <div class="hck-ticket-hero-top">
        <a href="<?php echo esc_url(is_user_logged_in() ? hck_customer_url('my-tickets/') : home_url('/')); ?>" class="hck-back-btn">
            <i class="fas fa-arrow-left"></i>
        </a>
        <div class="hck-ticket-hero-id">
            <span class="hck-ticket-hero-label">Ticket</span>
            <span class="hck-ticket-hero-number"><?php echo esc_html(hck_get_ticket_number($ticket)); ?></span>
        </div>
        <span class="hck-badge hck-badge-lg hck-badge-<?php echo esc_attr($ticket->status); ?>">
            <i class="fas fa-<?php echo esc_attr(hck_get_status_icon($ticket->status)); ?>"></i>
            <?php echo esc_html(hck_get_status_label($ticket->status)); ?>
        </span>
    </div>

    <h1 class="hck-ticket-hero-title"><?php echo esc_html($ticket->subject); ?></h1>

    <div class="hck-ticket-hero-meta">
        <span class="hck-meta-chip hck-meta-chip-category">
            <i class="fas fa-tag"></i> <?php echo esc_html(ucfirst($ticket->category)); ?>
        </span>
        <span class="hck-meta-chip"><i class="fas fa-flag"></i> <?php echo esc_html(hck_get_priority_label($ticket->priority)); ?></span>
        <span class="hck-meta-chip"><i class="far fa-clock"></i> <?php echo esc_html(hck_time_ago($ticket->created_at)); ?></span>
    </div>

    <?php if (!empty($order_details)): ?>
    <div class="hck-ticket-hero-orders">
        <span class="hck-hero-orders-label"><i class="fas fa-shopping-cart"></i> Orders:</span>
        <?php foreach ($order_details as $order): ?>
        <a href="<?php echo esc_url($order->get_view_order_url()); ?>" class="hck-order-pill">
            #<?php echo (int) $order->get_id(); ?> · <?php echo $order->get_formatted_order_total(); ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php if (!empty($ticket->merged_into)): $merge_target=hck_get_ticket((int)$ticket->merged_into); ?>
<div class="hck-card" style="border-left:4px solid #64748b"><h3>This ticket was merged</h3><p>This original ticket is kept for your records. Please continue in the consolidated ticket <?php if($merge_target): ?><a href="<?php echo esc_url(hck_customer_url('view/'.(int)$merge_target->id.'/')); ?>"><?php echo esc_html(hck_get_ticket_number($merge_target)); ?></a><?php else: ?>linked by our support team<?php endif; ?>.</p></div>
<?php endif; ?>

<div class="hck-card">
    <h3 class="hck-card-title"><i class="fas fa-comments"></i> Conversation</h3>
    <div class="hck-admin-thread" data-ticket-id="<?php echo (int)$ticket_id; ?>" data-after-id="<?php echo (int)$hck_last_message_id; ?>">
        <?php if (empty($messages)): ?>
        <div class="hck-empty-mini">
            <i class="fas fa-comment-slash"></i>
            <p>No messages yet</p>
        </div>
        <?php else: foreach ($messages as $msg):
            $author = get_userdata($msg->user_id);
            $is_system   = !empty($msg->is_system);
            $is_internal = !empty($msg->is_internal);
            if ($is_internal) continue;
            $sender_type = (string)($msg->sender_type ?? '');
            $is_admin = $sender_type ? in_array($sender_type, array('agent','ai'), true) : ((int) $msg->user_id !== $owner_id);
            $atts = $hck_attachments_by_message[(int) $msg->id] ?? (function_exists('hck_get_attachments') ? hck_get_attachments($msg->id) : array());
            if ($is_system) {
                $when = hck_time_ago($msg->created_at);
                echo '<div class="hck-admin-system-msg"><span><i class="fas fa-info-circle"></i> ' . esc_html($msg->message) . ' · ' . esc_html($when) . '</span></div>';
                continue;
            }
            $msg_class = $is_admin ? 'hck-admin-msg-admin' : 'hck-admin-msg-customer';
           $name      = !empty($msg->sender_name) ? $msg->sender_name : ($is_admin ? 'Support' : hck_get_user_display($owner_id));
            $initial   = strtoupper(substr($name, 0, 1));
        ?>
        <div class="hck-admin-msg <?php echo $msg_class; ?>" id="msg-<?php echo (int) $msg->id; ?>" data-message-id="<?php echo (int) $msg->id; ?>" data-client-message-id="<?php echo esc_attr((string) ($msg->client_message_id ?? "")); ?>">
            <div class="hck-admin-msg-avatar">
                <?php if ($is_admin): ?><i class="fas fa-headset"></i><?php else: echo esc_html($initial); endif; ?>
            </div>
            <div class="hck-admin-msg-content">
                <div class="hck-admin-msg-head">
                    <strong><?php echo esc_html($name); ?></strong>
                    <span class="hck-msg-time"><i class="far fa-clock"></i> <?php echo esc_html(hck_time_ago($msg->created_at)); ?></span>
                </div>
                <div class="hck-admin-msg-body">
                    <div class="hck-msg-text"><?php echo wp_kses_post($msg->message); ?></div>
                    <?php if (!empty($atts)): ?>
                    <div class="hck-admin-msg-files">
                        <?php foreach ($atts as $att):
                            $ext = strtolower($att->file_type ?: pathinfo($att->file_path, PATHINFO_EXTENSION));
                            $is_img = in_array($ext, array('jpg','jpeg','png','webp','gif'));
                            $is_pdf = $ext === 'pdf';
                            $icon = $is_img ? 'image' : ($is_pdf ? 'file-pdf' : 'file');
                        ?>
                        <a href="<?php echo esc_url(hck_attachment_url($att)); ?>" target="_blank" rel="noopener" class="hck-file-link">
                            <i class="fas fa-<?php echo $icon; ?>"></i>
                            <span><?php echo esc_html($att->filename); ?></span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; endif; ?>
    </div>
</div>

<?php if ($can_rate): ?>
<div class="hck-card hck-rate-card">
    <div class="hck-rate-icon"><i class="fas fa-star"></i></div>
    <h3>How did we do?</h3>
    <p>Your feedback helps us improve.</p>
    <form id="hckRateForm">
        <input type="hidden" name="ticket_id" value="<?php echo (int) $ticket_id; ?>">
        <input type="hidden" name="rating" id="hckRatingValue" value="0">
        <div class="hck-stars" id="hckStars">
            <?php for ($i = 1; $i <= 5; $i++): ?>
            <span data-rating="<?php echo $i; ?>" class="hck-star"><i class="fas fa-star"></i></span>
            <?php endfor; ?>
        </div>
        <div class="hck-rate-resolved">
            <label class="hck-radio-card"><input type="radio" name="resolved" value="yes" required><span>Yes, resolved</span></label>
            <label class="hck-radio-card"><input type="radio" name="resolved" value="no"><span>Still need help</span></label>
        </div>
        <textarea name="comment" rows="2" placeholder="Anything to add? (optional)" class="hck-input" style="margin-bottom:16px;"></textarea>
        <button type="submit" class="hck-btn hck-btn-primary hck-btn-lg hck-btn-block">Submit Rating</button>
    </form>
</div>
<?php elseif ($ticket->rating && in_array($ticket->status, array('resolved', 'closed'))): ?>
<div class="hck-card hck-rated-card">
    <div class="hck-rate-icon"><i class="fas fa-check"></i></div>
    <h3>Thanks for your feedback!</h3>
    <div class="hck-rated-stars"><?php echo str_repeat('★', (int) $ticket->rating) . str_repeat('☆', 5 - (int) $ticket->rating); ?></div>
</div>
<?php endif; ?>

<?php if ($reopen_request && $reopen_request->status==='pending'): ?>
<div class="hck-card hck-customer-reopen-request"><h3><i class="fas fa-hourglass-half"></i> Reopen request pending</h3><p>Your request was submitted on <?php echo esc_html(hck_format_date($reopen_request->created_at)); ?>. Our support team will review it.</p></div>
<?php elseif ($reopen_allowed): ?>
<div class="hck-card hck-customer-reopen-request">
<?php if ($reopen_request && $reopen_request->status==='rejected'): ?><h3>Reopen request not approved</h3><p><?php echo esc_html($reopen_request->review_note ?: 'Our support team could not reopen this ticket.'); ?></p><textarea id="hckReopenReason" class="hck-input" rows="3" maxlength="2000" placeholder="Add any new information (optional)"></textarea><button type="button" id="hckRequestReopen" class="hck-btn hck-btn-primary hck-btn-block" style="margin-top:10px">Submit another reopen request</button>
<?php else: ?><h3><i class="fas fa-folder-open"></i> Need more help with this issue?</h3><p>You can request to reopen this ticket within <?php echo (int)$reopen_days; ?> days of closure. Our team will review your request.</p><textarea id="hckReopenReason" class="hck-input" rows="3" maxlength="2000" placeholder="Tell us why you need this ticket reopened (optional)"></textarea><button type="button" id="hckRequestReopen" class="hck-btn hck-btn-primary hck-btn-block" style="margin-top:10px">Request to reopen ticket</button><?php endif; ?>
</div>
<?php elseif (in_array($ticket->status,array('closed','resolved'),true) && empty($ticket->merged_into)): ?>
<div class="hck-card"><h3>Need further assistance?</h3><p>The reopen request period has expired. Please create a new ticket for further assistance.</p><a class="hck-btn hck-btn-primary hck-btn-block" href="<?php echo esc_url(hck_customer_url('create/')); ?>">Create a new ticket</a></div>
<?php endif; ?>

<?php if ($can_reply): ?>
<div class="hck-card hck-reply-card">
    <h3 class="hck-card-title"><i class="fas fa-reply"></i> Add a Reply</h3>

    <form id="hckReplyForm" enctype="multipart/form-data">
        <input type="hidden" name="ticket_id" value="<?php echo (int) $ticket_id; ?>">

        <textarea name="message" required rows="5" placeholder="Type your reply here..." class="hck-input" id="hckReplyText"></textarea>

        <div class="hck-reply-files" id="hckReplyFiles"></div>

        <div class="hck-reply-actions">
            <label class="hck-btn hck-btn-outline hck-attach-label">
                <i class="fas fa-paperclip"></i> Attach Files
                <input type="file" name="attachments[]" id="hckReplyInput" multiple style="display:none" onchange="hckAddReplyFiles(this)">
            </label>
            <button type="submit" class="hck-btn hck-btn-primary hck-send-btn" id="hckReplyBtn">
                <i class="fas fa-paper-plane"></i> Send Reply
            </button>
        </div>
    </form>
</div>
<?php endif; ?>

<?php if ($can_close): ?>
<div class="hck-card">
    <form method="post" onsubmit="return confirm('Are you sure you want to close this ticket?')">
        <input type="hidden" name="hck_close_ticket" value="1">
        <?php wp_nonce_field('hck_close_ticket_' . $ticket_id, 'hck_close_nonce'); ?>
        <button type="submit" class="hck-btn hck-btn-danger hck-btn-block">
            <i class="fas fa-times-circle"></i> Close This Ticket
        </button>
    </form>
</div>
<?php elseif ($ticket->status === 'closed' && empty($ticket->merged_into)): ?>
<div class="hck-card hck-reopen-card">
    <div class="hck-reopen-icon"><i class="fas fa-lock"></i></div>
    <h3>This ticket is closed</h3>
    <p><?php echo $reopen_allowed ? 'You can request reopening using the option above.' : 'If you still need help, please create a new ticket.'; ?></p>
    <a href="<?php echo esc_url(hck_customer_url('create/')); ?>" class="hck-btn hck-btn-primary hck-btn-block">
        <i class="fas fa-plus"></i> Create New Ticket
    </a>
</div>
<?php endif; ?>

<script id="hck-customer-thread-autobottom-v106">
(function(){
  'use strict';
  var selector='.hck-admin-thread';
  function init(panel){
    if(!panel || panel.dataset.hckAutoBottomInit==='1') return;
    panel.dataset.hckAutoBottomInit='1';
    var pinned=true;
    function bottom(){ panel.scrollTop=panel.scrollHeight; }
    function nearBottom(){ return panel.scrollHeight-panel.clientHeight-panel.scrollTop<100; }
    function initialBottom(){
      bottom();
      requestAnimationFrame(function(){ bottom(); requestAnimationFrame(bottom); });
      [80,220,500,900].forEach(function(ms){ window.setTimeout(bottom,ms); });
    }
    panel.addEventListener('scroll',function(){ pinned=nearBottom(); },{passive:true});
    // Keep native scroll chaining: at either boundary the page may continue scrolling.
    panel.style.overscrollBehaviorY='auto';
    panel.style.webkitOverflowScrolling='touch';
    initialBottom();
    panel.querySelectorAll('img').forEach(function(img){
      if(!img.complete) img.addEventListener('load',function(){ if(pinned) bottom(); },{once:true});
    });
    if(window.ResizeObserver){
      var ro=new ResizeObserver(function(){ if(pinned) bottom(); });
      ro.observe(panel);
      if(panel.firstElementChild) ro.observe(panel.firstElementChild);
      panel._hckAutoBottomResizeObserver=ro;
    }
    if(window.MutationObserver){
      var mo=new MutationObserver(function(){ if(pinned) requestAnimationFrame(bottom); });
      mo.observe(panel,{childList:true,subtree:true,characterData:true});
      panel._hckAutoBottomMutationObserver=mo;
    }
    if(document.fonts && document.fonts.ready){ document.fonts.ready.then(function(){ if(pinned) bottom(); }); }
  }
  function run(){ document.querySelectorAll(selector).forEach(init); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',run,{once:true}); else run();
  window.addEventListener('load',run,{once:true});
})();
</script>

<script>
(function(){var b=document.getElementById('hckRequestReopen');if(!b)return;b.addEventListener('click',function(){b.disabled=true;b.textContent='Submitting…';var fd=new FormData();fd.append('action','hck_phase2_request_reopen');fd.append('nonce',window.hckData.nonce);fd.append('ticket_id',window.hckData.ticketId);fd.append('reason',(document.getElementById('hckReopenReason')||{}).value||'');fetch(window.hckData.ajaxUrl,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(function(r){if(!r.success)throw new Error((r.data&&r.data.message)||'Could not submit request');alert(r.data.message);location.reload();}).catch(function(e){alert(e.message);b.disabled=false;b.textContent='Request to reopen ticket';});});})();
</script>
