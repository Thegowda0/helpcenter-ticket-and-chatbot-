<?php
if (!defined('ABSPATH')) exit;

$orders = array();
if (function_exists('wc_get_orders')) {
    $orders = wc_get_orders(array(
        'customer_id' => get_current_user_id(),
        'limit'       => 30,
        'orderby'     => 'date',
        'order'       => 'DESC',
    ));
}
?>

<div class="hck-page-header">
    <div>
        <h1><i class="fas fa-plus-circle"></i> Create New Ticket</h1>
        <p class="hck-subtitle">Describe your issue and we'll get back to you.</p>
    </div>
    <a href="<?php echo esc_url(hck_customer_url()); ?>" class="hck-btn hck-btn-outline">
        <i class="fas fa-arrow-left"></i> Back
    </a>
</div>

<form id="hckCreateForm" class="hck-card" enctype="multipart/form-data">
    <div class="hck-form-group">
        <label><i class="fas fa-pen"></i> Subject <span class="req">*</span></label>
        <input type="text" name="subject" required minlength="5" maxlength="200" placeholder="e.g. Order not delivered" class="hck-input">
    </div>
    
    <div class="hck-form-row">
        <div class="hck-form-group">
            <label><i class="fas fa-tag"></i> Category</label>
            <select name="category" class="hck-input">
                <?php 
                // Get categories from custom settings table
                global $wpdb;
                $tbl = $wpdb->prefix . "hck_ticket_settings";
                $cats_string = $wpdb->get_var("SELECT setting_value FROM $tbl WHERE setting_key = \"hck_ticket_categories\"");
                if (!$cats_string) $cats_string = "Pre-Sale Question, Order Related, Technical Issue, Return / Refund, Other";
                
                $cats = array_map("trim", explode(",", $cats_string));
                foreach($cats as $cat) {
                    $val = sanitize_title($cat);
                    $sel = (strpos($val, "order") !== false) ? " selected" : "";
                    echo "<option value=\"" . esc_attr($val) . "\"$sel>" . esc_html($cat) . "</option>";
                }
                ?>
            </select>
        </div>
        <div class="hck-form-group">
            <label><i class="fas fa-flag"></i> Priority</label>
            <select name="priority" class="hck-input">
                <option value="low">Low</option>
                <option value="normal" selected>Normal</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
            </select>
        </div>
    </div>
    
    <?php if (!empty($orders)): ?>
    <div class="hck-form-group">
        <div class="hck-orders-header">
            <label style="margin: 0;"><i class="fas fa-shopping-cart"></i> Related Orders <small>(optional)</small></label>
            <span class="hck-orders-count" id="hckOrderCount">0 selected</span>
        </div>
        
        <!-- Selected orders shown as tags -->
        <div class="hck-selected-orders" id="hckSelectedOrders"></div>
        
        <!-- Available orders grid -->
        <div class="hck-order-grid" id="hckOrderGrid">
            <?php foreach ($orders as $order):
                $items = $order->get_items();
                $name = '';
                $thumb = '';
                foreach ($items as $item) {
                    $name = $item->get_name();
                    $product = $item->get_product();
                    if ($product) {
                        $img = $product->get_image_id();
                        $thumb = $img ? wp_get_attachment_image_url($img, 'thumbnail') : wc_placeholder_img_src('thumbnail');
                    }
                    break;
                }
                $oid = $order->get_id();
            ?>
            <div class="hck-order-card" data-order-id="<?php echo (int) $oid; ?>" onclick="hckToggleOrder(<?php echo (int) $oid; ?>, this)">
                <div class="hck-order-check"><i class="fas fa-check"></i></div>
                <?php if ($thumb): ?>
                <img src="<?php echo esc_url($thumb); ?>" alt="">
                <?php endif; ?>
                <div>
                    <strong>Order #<?php echo $oid; ?></strong>
                    <span><?php echo esc_html(wp_trim_words($name, 8)); ?></span>
                    <small>
                        <?php echo get_woocommerce_currency_symbol() . number_format($order->get_total(), 2); ?>
                        · <?php echo $order->get_date_created() ? $order->get_date_created()->date('M j, Y') : ''; ?>
                    </small>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <input type="hidden" name="orders" id="hckOrdersInput" value="[]">
    </div>
    <?php endif; ?>
    
    <div class="hck-form-group">
        <label><i class="fas fa-align-left"></i> Description <span class="req">*</span></label>
        <textarea name="message" required minlength="10" rows="6" placeholder="Explain your issue in detail..." class="hck-input"></textarea>
        <small class="hck-form-hint">Include any relevant info: what happened, when, and what you expected.</small>
    </div>
    
    <div class="hck-form-group">
        <label><i class="fas fa-paperclip"></i> Attachments <small>(max 10MB each)</small></label>
        <label class="hck-dropzone" id="hckDropzone">
            <i class="fas fa-cloud-upload-alt"></i>
            <span>Click to select files</span>
            <small>JPG, PNG, PDF, ZIP, DOC · Max 10MB</small>
            <input type="file" id="hckFileInput" multiple accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.zip,.doc,.docx">
        </label>
        <div class="hck-reply-files" id="hckFileList"></div>
    </div>
    
    <div class="hck-form-actions">
        <button type="submit" class="hck-btn hck-btn-primary hck-btn-lg hck-btn-block" id="hckSubmitBtn">
            <i class="fas fa-paper-plane"></i> Submit Ticket
        </button>
    </div>
</form>