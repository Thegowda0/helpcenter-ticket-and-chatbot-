<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$user_id = get_current_user_id();
$t = $wpdb->prefix . 'hck_tickets';
$col = hck_column_exists($t, 'user_id') ? 'user_id' : 'customer_id';

$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$search        = isset($_GET['q']) ? sanitize_text_field($_GET['q']) : '';
$paged         = isset($_GET['pg']) ? max(1, intval($_GET['pg'])) : 1;
$per_page      = 15;
$offset        = ($paged - 1) * $per_page;

$where = array($wpdb->prepare("$col = %d", $user_id));
if ($status_filter) $where[] = $wpdb->prepare("status = %s", $status_filter);
if ($search) {
    $like = '%' . $wpdb->esc_like($search) . '%';
    $where[] = $wpdb->prepare("(subject LIKE %s OR ticket_number LIKE %s)", $like, $like);
}
$where_sql = implode(' AND ', $where);

$total   = (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE $where_sql");
$tickets = $wpdb->get_results("SELECT * FROM $t WHERE $where_sql ORDER BY updated_at DESC LIMIT $offset, $per_page");
$pages   = ceil($total / $per_page);

$stats = hck_get_user_stats($user_id);

$status_tabs = array(
    ''               => 'All',
    'open'           => 'Open',
    'in_progress'    => 'In Progress',
    'awaiting_reply' => 'Awaiting',
    'resolved'       => 'Resolved',
    'closed'         => 'Closed',
);
?>

<div class="hck-page-header">
    <div>
        <h1><i class="fas fa-ticket-alt"></i> My Tickets</h1>
        <p class="hck-subtitle"><?php echo $total; ?> ticket<?php echo $total == 1 ? '' : 's'; ?> found</p>
    </div>
    <a href="<?php echo esc_url(hck_customer_url('create/')); ?>" class="hck-btn hck-btn-primary">
        <i class="fas fa-plus"></i> New Ticket
    </a>
</div>

<div class="hck-card">
    <div class="hck-filter-bar">
        <form method="get" class="hck-search">
            <?php if ($status_filter): ?><input type="hidden" name="status" value="<?php echo esc_attr($status_filter); ?>"><?php endif; ?>
            <i class="fas fa-search"></i>
            <input type="text" name="q" value="<?php echo esc_attr($search); ?>" placeholder="Search tickets...">
        </form>
    </div>
    
    <div class="hck-tabs">
        <?php foreach ($status_tabs as $key => $label): 
            $url = hck_customer_url('my-tickets/');
            $args = array();
            if ($key) $args['status'] = $key;
            if ($search) $args['q'] = $search;
            if (!empty($args)) $url = add_query_arg($args, $url);
        ?>
        <a href="<?php echo esc_url($url); ?>" class="hck-tab <?php echo $status_filter === $key ? 'active' : ''; ?>"><?php echo esc_html($label); ?></a>
        <?php endforeach; ?>
    </div>
    
    <?php if ($tickets): ?>
    <div class="hck-ticket-list">
        <?php foreach ($tickets as $ticket): ?>
        <a href="<?php echo esc_url(hck_customer_url('view/' . $ticket->id . '/')); ?>" class="hck-ticket-row">
            <div class="hck-ticket-status-dot" data-status="<?php echo esc_attr($ticket->status); ?>"></div>
            <div class="hck-ticket-content">
                <div class="hck-ticket-top">
                    <span class="hck-ticket-number"><?php echo esc_html(hck_get_ticket_number($ticket)); ?></span>
                    <span class="hck-badge hck-badge-<?php echo esc_attr($ticket->status); ?>"><?php echo esc_html(hck_get_status_label($ticket->status)); ?></span>
                </div>
                <div class="hck-ticket-subject" title="<?php echo esc_attr($ticket->subject); ?>"><?php echo esc_html(hck_ticket_subject_short($ticket->subject,50)); ?></div>
                <div class="hck-ticket-meta">
                    <span><i class="fas fa-tag"></i> <?php echo esc_html(ucfirst($ticket->category)); ?></span>
                    <span style="color:<?php echo esc_attr(hck_get_priority_color($ticket->priority)); ?>;font-weight:600;"><i class="fas fa-flag"></i> <?php echo esc_html(hck_get_priority_label($ticket->priority)); ?></span>
                    <span><i class="far fa-clock"></i> <?php echo esc_html(hck_time_ago($ticket->updated_at)); ?></span>
                    <?php if ($ticket->rating): ?><span style="color:#F59E0B;"><i class="fas fa-star"></i> <?php echo (int)$ticket->rating; ?>/5</span><?php endif; ?>
                </div>
            </div>
            <i class="fas fa-chevron-right hck-ticket-arrow"></i>
        </a>
        <?php endforeach; ?>
    </div>
    
    <?php if ($pages > 1): ?>
    <div class="hck-pagination">
        <?php for ($i = 1; $i <= $pages; $i++):
            $url = add_query_arg(array_filter(array(
                'status' => $status_filter ?: null,
                'q'      => $search ?: null,
                'pg'     => $i > 1 ? $i : null,
            )), hck_customer_url('my-tickets/'));
        ?>
        <a href="<?php echo esc_url($url); ?>" class="hck-page <?php echo $i === $paged ? 'active' : ''; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
    
    <?php else: ?>
    <div class="hck-empty">
        <i class="fas fa-inbox"></i>
        <h3>No tickets found</h3>
        <p><?php echo $status_filter || $search ? 'Try a different filter.' : "You haven't created any tickets yet."; ?></p>
        <?php if (!$status_filter && !$search): ?>
        <a href="<?php echo esc_url(hck_customer_url('create/')); ?>" class="hck-btn hck-btn-primary"><i class="fas fa-plus"></i> Create Ticket</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
