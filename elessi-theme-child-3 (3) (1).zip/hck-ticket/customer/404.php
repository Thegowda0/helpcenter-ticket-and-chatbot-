<?php
if (!defined('ABSPATH')) exit;
?>

<div class="hck-empty-lg">
    <div class="hck-404-visual">
        <div class="hck-404-number">404</div>
        <div class="hck-404-circle"></div>
    </div>
    <h1>Page not found</h1>
    <p>The page you're looking for doesn't exist or has been moved.</p>
    <div class="hck-empty-actions">
        <a href="<?php echo esc_url(hck_customer_url()); ?>" class="hck-btn hck-btn-primary">
            <i class="fas fa-home"></i> Go to Dashboard
        </a>
        <a href="<?php echo esc_url(hck_customer_url('create/')); ?>" class="hck-btn hck-btn-outline">
            <i class="fas fa-plus"></i> New Ticket
        </a>
    </div>
</div>
