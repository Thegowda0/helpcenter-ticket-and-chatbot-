<?php
/**
 * HCK Ticket System - Customer Wrapper
 * Isolated HTML shell for customer pages. No theme header/footer.
 */

if (!defined('ABSPATH')) exit;

$hck_page = get_query_var('hck_page') ?: 'dashboard';
$ticket_id = get_query_var('hck_ticket');

// Read theme color from Elessi theme, fallback to default
$theme_color = get_theme_mod('nasa_primary_color', '#6366F1');
if (empty($theme_color)) $theme_color = '#6366F1';

// Read site name
$site_name = hck_get_setting('hck_site_title', 'Support Center');

// Current user
$current_user = wp_get_current_user();
$user_name = $current_user->ID ? $current_user->display_name : 'Guest';

// User stats for nav badges
$user_stats = is_user_logged_in() ? hck_get_user_stats(get_current_user_id()) : array();
$awaiting_count = isset($user_stats['awaiting_reply']) ? $user_stats['awaiting_reply'] : 0;

// Load CSS / JS with cache-busting
$css_file = HCK_PATH . 'assets/customer/customer.css';
$js_file  = HCK_PATH . 'assets/customer/customer.js';
$css_ver  = file_exists($css_file) ? filemtime($css_file) : HCK_VERSION;
$js_ver   = file_exists($js_file)  ? filemtime($js_file)  : HCK_VERSION;
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html($site_name); ?> - Support</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?php echo esc_url(HCK_ASSETS . 'customer/customer.css?v=' . $css_ver); ?>">
<style>
:root {
    --hck-primary: <?php echo esc_attr($theme_color); ?>;
    --hck-primary-hover: <?php echo esc_attr(hck_adjust_brightness($theme_color, -20)); ?>;
    --hck-primary-light: <?php echo esc_attr(hck_adjust_brightness($theme_color, 180)); ?>;
}
</style>
</head>
<body class="hck-body">

<header class="hck-header">
    <div class="hck-header-inner">
        <a href="<?php echo esc_url(hck_customer_url()); ?>" class="hck-logo">
            <i class="fas fa-headset"></i>
            <span><?php echo esc_html($site_name); ?></span>
        </a>
        
        <?php if (is_user_logged_in()): ?>
        <nav class="hck-nav">
            <a href="<?php echo esc_url(hck_customer_url()); ?>" class="hck-nav-link <?php echo $hck_page === 'dashboard' ? 'active' : ''; ?>">
                <i class="fas fa-th-large"></i> <span>Dashboard</span>
            </a>
            <a href="<?php echo esc_url(hck_customer_url('create/')); ?>" class="hck-nav-link <?php echo $hck_page === 'create' ? 'active' : ''; ?>">
                <i class="fas fa-plus-circle"></i> <span>New Ticket</span>
            </a>
            <a href="<?php echo esc_url(hck_customer_url('my-tickets/')); ?>" class="hck-nav-link <?php echo in_array($hck_page, array('my-tickets','view')) ? 'active' : ''; ?>">
                <i class="fas fa-ticket-alt"></i> <span>My Tickets</span>
                <?php if ($awaiting_count > 0): ?><span class="hck-nav-badge"><?php echo $awaiting_count; ?></span><?php endif; ?>
            </a>
        </nav>
        
        <div class="hck-user">
            <span class="hck-user-name"><?php echo esc_html($user_name); ?></span>
        </div>

        <?php else: ?>
        <a href="<?php echo esc_url(hck_customer_url('login/')); ?>" class="hck-btn hck-btn-primary hck-btn-sm">
            <i class="fas fa-sign-in-alt"></i> Sign In
        </a>
        <?php endif; ?>
    </div>
</header>

<main class="hck-main">
    <div class="hck-container">
        <?php
        switch ($hck_page) {
            case 'login':       include HCK_CUSTOMER . 'login.php';       break;
            case 'dashboard':   include HCK_CUSTOMER . 'dashboard.php';   break;
            case 'create':      include HCK_CUSTOMER . 'create-ticket.php'; break;
            case 'my-tickets':  include HCK_CUSTOMER . 'my-tickets.php';  break;
            case 'view':        include HCK_CUSTOMER . 'ticket-view.php'; break;
            default:            include HCK_CUSTOMER . '404.php';         break;
        }
        ?>
    </div>
</main>

<footer class="hck-footer">
    <p>&copy; <?php echo date('Y'); ?> <?php echo esc_html(get_bloginfo('name')); ?>. Support Center.</p>
</footer>

<?php if ($hck_page !== 'view'): ?>
<nav class="hck-mobile-nav">
    <a href="<?php echo esc_url(hck_customer_url()); ?>" class="hck-mobile-link <?php echo $hck_page === 'dashboard' ? 'active' : ''; ?>">
        <i class="fas fa-home"></i><span>Home</span>
    </a>
    <a href="<?php echo esc_url(hck_customer_url('create/')); ?>" class="hck-mobile-link hck-mobile-create">
        <i class="fas fa-plus"></i>
    </a>
    <a href="<?php echo esc_url(hck_customer_url('my-tickets/')); ?>" class="hck-mobile-link <?php echo in_array($hck_page, array('my-tickets','view')) ? 'active' : ''; ?>">
        <i class="fas fa-ticket-alt"></i><span>Tickets</span>
        <?php if ($awaiting_count > 0): ?><span class="hck-mobile-badge"><?php echo (int) $awaiting_count; ?></span><?php endif; ?>
    </a>
</nav>
<?php endif; ?>

<script>
window.hckData = {
    ajaxUrl: '<?php echo esc_url(admin_url("admin-ajax.php")); ?>',
    nonce: '<?php echo wp_create_nonce("hck_nonce"); ?>',
    homeUrl: '<?php echo esc_url(hck_customer_url()); ?>',
    userId: <?php echo (int) get_current_user_id(); ?>,
    ticketId: <?php echo $hck_page === 'view' ? (int) get_query_var('hck_ticket') : 0; ?>,
    realtimeEnabled: <?php echo (class_exists('HC_Realtime') && HC_Realtime::is_configured()) ? 'true' : 'false'; ?>
};
</script>
<?php if ($hck_page === 'view' && class_exists('HC_Realtime') && HC_Realtime::is_configured()): ?>
<script src="https://cdn.ably.com/lib/ably.min-2.js"></script>
<script src="<?php echo esc_url(HC_ASSETS . 'js/hc-realtime-client.js?v=' . (defined('HC_PATH') && file_exists(HC_PATH . 'assets/js/hc-realtime-client.js') ? filemtime(HC_PATH . 'assets/js/hc-realtime-client.js') : HCK_VERSION)); ?>"></script>
<?php endif; ?>
<script src="<?php echo esc_url(HCK_ASSETS . 'customer/customer.js?v=' . $js_ver); ?>"></script>

</body>
</html>
