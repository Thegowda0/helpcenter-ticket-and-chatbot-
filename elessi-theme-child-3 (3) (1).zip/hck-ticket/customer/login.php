<?php
if (!defined('ABSPATH')) exit;

// Already logged in? Redirect to dashboard
if (is_user_logged_in()) {
    wp_safe_redirect(hck_customer_url());
    exit;
}

$my_account_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : home_url('/my-account/');
$redirect_param = isset($_GET['redirect_to']) ? wp_validate_redirect(wp_unslash($_GET['redirect_to']), home_url('/ticket/')) : home_url('/ticket/');
$my_account_with_redirect = add_query_arg('redirect_to', $redirect_param, $my_account_url);
$sign_in_url = wp_login_url($redirect_param);
$site_name = hck_get_setting('hck_site_title', 'Support Center');
?>

<div class="hck-login-wrap">
    <div class="hck-login-card">
        <div class="hck-login-logo">
            <i class="fas fa-headset"></i>
        </div>

        <h1>Sign in to <?php echo esc_html($site_name); ?></h1>
        <p>Access your support tickets, track progress, and chat with our team.</p>

        <a href="<?php echo esc_url($sign_in_url); ?>" class="hck-btn hck-btn-primary hck-btn-lg hck-btn-block">
            <i class="fas fa-sign-in-alt"></i> Sign In
        </a>

        <div class="hck-login-divider"><span>or</span></div>

        <a href="<?php echo esc_url($my_account_with_redirect . '#register'); ?>" class="hck-login-register">
            <i class="fas fa-user-plus"></i> Create New Account
        </a>

        <div class="hck-login-note">
            <i class="fas fa-info-circle"></i>
            <p>Sign in with your email and password, or use OTP login from the account page. You'll be redirected back here after signing in.</p>
        </div>
    </div>
</div>
