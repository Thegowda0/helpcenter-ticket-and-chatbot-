<?php
/**
 * HCK Ticket System - URL Rewriting
 */

if (!defined('ABSPATH')) exit;

function hck_register_rewrites() {
    // =============================================
    // CUSTOMER URLS
    // =============================================
    add_rewrite_rule('^ticket/?$',                    'index.php?hck_page=dashboard',  'top');
    add_rewrite_rule('^ticket/login/?$',              'index.php?hck_page=login',      'top');
    add_rewrite_rule('^ticket/claim/([A-Za-z0-9]{48,96})/?$', 'index.php?hck_page=claim&hck_claim_token=$matches[1]', 'top');
    add_rewrite_rule('^ticket/create/?$',             'index.php?hck_page=create',     'top');
    add_rewrite_rule('^ticket/my-tickets/?$',         'index.php?hck_page=my-tickets', 'top');
    add_rewrite_rule('^ticket/view/([0-9]+)/?$',      'index.php?hck_page=view&hck_ticket=$matches[1]', 'top');
    add_rewrite_rule('^ticket/file/([0-9]+)/?$',      'index.php?hck_page=file&hck_file=$matches[1]', 'top');
    
    // =============================================
    // ADMIN URLS
    // =============================================
    add_rewrite_rule('^ticket/agent/?$',                  'index.php?hck_page=agent-dashboard', 'top');
    add_rewrite_rule('^ticket/admin/section/([a-z0-9-]+)/?$', 'index.php?hck_page=admin-hub&hck_hub=$matches[1]', 'top');
    add_rewrite_rule('^ticket/admin/?$',              'index.php?hck_page=admin-dashboard', 'top');
    add_rewrite_rule('^ticket/admin/tickets/?$',      'index.php?hck_page=admin-tickets',   'top');
    add_rewrite_rule('^ticket/admin/view/([0-9]+)/?$','index.php?hck_page=admin-view&hck_ticket=$matches[1]', 'top');
    add_rewrite_rule('^ticket/admin/customer/([0-9]+)/?$','index.php?hck_page=admin-customer&hck_ticket=$matches[1]', 'top');
    add_rewrite_rule('^ticket/admin/customers/?$','index.php?hck_page=admin-customers', 'top');
    add_rewrite_rule('^ticket/admin/settings/([a-z0-9-]+)/?$', 'index.php?hck_page=admin-settings&hck_settings_section=$matches[1]', 'top');
    add_rewrite_rule('^ticket/admin/settings/?$',     'index.php?hck_page=admin-settings&hck_settings_section=general',  'top');
    add_rewrite_rule('^ticket/admin/sla/?$',           'index.php?hck_page=admin-sla',       'top');
    add_rewrite_rule('^ticket/admin/team/?$',          'index.php?hck_page=admin-team',      'top');
    add_rewrite_rule('^ticket/admin/csat/?$',          'index.php?hck_page=admin-csat',      'top');
    
    // Fallback
    add_rewrite_rule('^ticket/(.*)/?$', 'index.php?hck_page=404', 'top');
}

// Register query vars
add_filter('query_vars', function($vars) {
    $vars[] = 'hck_page';
    $vars[] = 'hck_settings_section';
    $vars[] = 'hck_hub';
    $vars[] = 'hck_ticket';
    $vars[] = 'hck_file';
    $vars[] = 'hck_claim_token';
    return $vars;
});

// Flush on theme activation
function hck_flush_rewrite() {
    hck_register_rewrites();
    flush_rewrite_rules();
}
