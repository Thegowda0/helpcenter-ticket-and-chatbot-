<?php
/**
 * HCK Ticket System - Main Loader
 * Entry point. Loads all system files, registers hooks.
 * 
 * @version 3.0.4
 */

if (!defined('ABSPATH')) exit;

// =============================================
// CONSTANTS
// =============================================
define('HCK_VERSION',   '3.0.4');
define('HCK_REWRITE_VERSION', '3.0.5-settings-workspaces');
define('HCK_PATH',      get_stylesheet_directory() . '/hck-ticket/');
define('HCK_URL',       get_stylesheet_directory_uri() . '/hck-ticket/');
define('HCK_CUSTOMER',  HCK_PATH . 'customer/');
define('HCK_ADMIN',     HCK_PATH . 'admin/');
define('HCK_ASSETS',    HCK_URL  . 'assets/');
define('HCK_CUST_URL',  HCK_URL  . 'customer/');
define('HCK_ADMIN_URL', HCK_URL  . 'admin/');

// =============================================
// LOAD CORE FILES
// =============================================
$hck_files = array(
    'hck-database.php',
    'hck-core.php',
    'hck-rewrite.php',
    'hck-ajax.php',
    'hck-emails.php',
    'hck-files.php',
    'hck-cron.php',
    'hck-sla.php',
    'hck-phase2.php',
    'hck-integration.php',
    'hck-cloudflare.php',
    'hck-cloudflare-setup.php',
);

foreach ($hck_files as $file) {
    $path = HCK_PATH . $file;
    if (file_exists($path)) {
        require_once $path;
    }
}

// =============================================
// INITIALIZE
// =============================================
add_action('init', 'hck_init', 5);
function hck_init() {
    // Create/update database tables
    if (function_exists('hck_install_database')) {
        hck_install_database();
    }
    
    // Register rewrite rules
    if (function_exists('hck_register_rewrites')) {
        hck_register_rewrites();
    }
    
    // Register AJAX handlers
    if (function_exists('hck_register_ajax')) {
        hck_register_ajax();
    }

    // Refresh permalinks once per version so new /ticket/ URLs work without visiting Settings > Permalinks
    if (get_option('hck_rewrite_version') !== HCK_REWRITE_VERSION) {
        flush_rewrite_rules(false);
        update_option('hck_rewrite_version', HCK_REWRITE_VERSION);
    }

    // Daily auto-close / reminders
    if (function_exists('hck_schedule_cron')) {
        hck_schedule_cron();
    }
}

// =============================================
// TEMPLATE REDIRECT - Route /ticket/* URLs
// =============================================
add_action('template_redirect', 'hck_template_router', 1);
function hck_template_router() {
    $page = get_query_var('hck_page');
    if (!$page) return;
    
    // Prevent WP from returning 404
    global $wp_query;
    $wp_query->is_404 = false;
    status_header(200);
    
    // Ticket pages are standalone HTML (no theme header/footer)
    add_filter('show_admin_bar', '__return_false');

    // Protected attachment download: access-checked, streams the file and exits
    if ($page === 'file') {
        hck_serve_attachment((int) get_query_var('hck_file'));
        exit;
    }

    // Customer pages requiring login
    $customer_pages = array('dashboard', 'create', 'my-tickets', 'view');
    $admin_pages    = array('agent-dashboard', 'admin-dashboard', 'admin-hub', 'admin-tickets', 'admin-view', 'admin-customer', 'admin-customers', 'admin-settings', 'admin-sla', 'admin-team', 'admin-csat');
    
    // A non-supervisor agent's default landing page is the dedicated agent workspace.
    if ($page === 'admin-dashboard' && hck_is_agent() && !hck_is_supervisor_user()) { wp_safe_redirect(home_url('/ticket/agent/')); exit; }
    // Admin pages require staff access; settings and SLA policies are administrator-only.
    if (in_array($page, $admin_pages) && (!function_exists('hck_is_agent') || !hck_is_agent() || (in_array($page, array('admin-settings','admin-sla'), true) && !current_user_can('manage_options')) || (in_array($page, array('admin-team','admin-csat','admin-hub','admin-tickets','admin-customer','admin-customers'), true) && !hck_is_supervisor_user()))) {
        wp_redirect(home_url('/ticket/login/'));
        exit;
    }
    
    // Customer pages require login (except login itself)
    // If logged in user tries to hit /ticket/login/, redirect them to /ticket/
    if ($page === 'login' && is_user_logged_in()) {
        $is_supervisor = hck_is_supervisor_user();

        if ($is_supervisor) {
            $destination = home_url('/ticket/admin/');
        } elseif (hck_is_agent()) {
            $destination = home_url('/ticket/agent/');
        } else {
            $destination = home_url('/ticket/');
        }

        wp_safe_redirect($destination);
        exit;
    }
    
    // Customer pages require login (except login itself)
    if (in_array($page, $customer_pages) && !is_user_logged_in()) {
        $guest_ticket = ($page === 'view') ? hck_guest_session_ticket_id((int)get_query_var('hck_ticket')) : 0;
        if (!$guest_ticket || $guest_ticket !== (int)get_query_var('hck_ticket')) {
            $redirect_to = home_url('/ticket/login/');
            wp_safe_redirect($redirect_to);
            exit;
        }
    }
    
    // Route to correct wrapper
    if (in_array($page, $admin_pages)) {
        include HCK_ADMIN . 'wrapper.php';
    } else {
        include HCK_CUSTOMER . 'wrapper.php';
    }
    exit;
}

// =============================================
// ACTIVATION - Flush rewrites on theme switch
// =============================================
add_action('after_switch_theme', function() {
    if (function_exists('hck_register_rewrites')) {
        hck_register_rewrites();
    }
    flush_rewrite_rules();
});
