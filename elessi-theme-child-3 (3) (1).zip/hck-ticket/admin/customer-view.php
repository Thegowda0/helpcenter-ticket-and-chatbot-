<?php
/**
 * HCK Phase 2 — Customer 360 profile.
 * Uses existing HCK ticket, message, log and HelpCenter escalation records; no data is copied.
 */
if (!defined('ABSPATH')) exit;
if (!hck_is_agent()) { echo '<div class="hck-admin-empty">Access denied.</div>'; return; }

global $wpdb;
$ref_ticket_id = absint(get_query_var('hck_ticket'));
$ref_ticket = $ref_ticket_id ? hck_get_ticket($ref_ticket_id) : null;
if (!$ref_ticket) {
    echo '<div class="hck-admin-empty"><h2>Customer reference not found</h2><a class="hck-admin-btn hck-admin-btn-outline" href="'.esc_url(hck_admin_url('tickets/')).'">Back to tickets</a></div>';
    return;
}

$uid = hck_get_ticket_user_id($ref_ticket);
$email = sanitize_email((string)($ref_ticket->customer_email ?? ''));
if (!$email && $uid) $email = sanitize_email((string)hck_get_user_email($uid));
$name = trim((string)($ref_ticket->customer_name ?? ''));
$user = $uid ? get_userdata($uid) : false;
if (!$name && $user) $name = hck_get_user_display($uid);
if (!$name) $name = 'Guest customer';

$tickets_table = $wpdb->prefix.'hck_tickets';
$messages_table = $wpdb->prefix.'hck_ticket_messages';
$logs_table = $wpdb->prefix.'hck_ticket_logs';
$esc_table = $wpdb->prefix.'hc_ai_escalations';

// Registered users are grouped by immutable WP user ID. Guest tickets are attached
// by exact email only when their stored user/customer IDs are both zero.
if ($uid > 0) {
    if (is_email($email)) {
        $identity_sql = '(user_id=%d OR customer_id=%d OR ((COALESCE(user_id,0)=0 AND COALESCE(customer_id,0)=0) AND LOWER(customer_email)=LOWER(%s)))';
        $identity_args = array($uid, $uid, $email);
        $hc_identity_sql = '(user_id=%d OR (COALESCE(user_id,0)=0 AND LOWER(visitor_email)=LOWER(%s)))';
        $hc_identity_args = array($uid, $email);
    } else {
        $identity_sql = '(user_id=%d OR customer_id=%d)'; $identity_args = array($uid,$uid);
        $hc_identity_sql = 'user_id=%d'; $hc_identity_args = array($uid);
    }
} elseif (is_email($email)) {
    $identity_sql = '((COALESCE(user_id,0)=0 AND COALESCE(customer_id,0)=0) AND LOWER(customer_email)=LOWER(%s))';
    $identity_args = array($email);
    $hc_identity_sql = '(COALESCE(user_id,0)=0 AND LOWER(visitor_email)=LOWER(%s))';
    $hc_identity_args = array($email);
} else {
    $identity_sql = 'id=%d'; $identity_args = array($ref_ticket_id);
    $hc_identity_sql = 'id=0'; $hc_identity_args = array();
}

$ticket_query = "SELECT id,ticket_number,subject,status,priority,category,source,created_at,updated_at,agent_id,customer_name,customer_email FROM {$tickets_table} WHERE {$identity_sql} ORDER BY created_at DESC,id DESC LIMIT 100";
$tickets = $wpdb->get_results($wpdb->prepare($ticket_query, $identity_args));
$ticket_ids = array_map(function($r){ return (int)$r->id; }, (array)$tickets);
if (!in_array($ref_ticket_id, $ticket_ids, true)) { array_unshift($ticket_ids, $ref_ticket_id); }
$ticket_ids = array_values(array_unique(array_filter($ticket_ids)));
$ticket_number_map = array();
foreach ((array)$tickets as $ticket_row) $ticket_number_map[(int)$ticket_row->id] = hck_get_ticket_number($ticket_row);
$ticket_number_map[$ref_ticket_id] = hck_get_ticket_number($ref_ticket);

$counts = array('total'=>0,'open'=>0,'in_progress'=>0,'awaiting'=>0,'resolved'=>0,'closed'=>0);
$total_ticket_count = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tickets_table} WHERE {$identity_sql}", $identity_args));
$status_rows = $wpdb->get_results($wpdb->prepare("SELECT status,COUNT(*) AS cnt FROM {$tickets_table} WHERE {$identity_sql} GROUP BY status", $identity_args));
foreach ((array)$status_rows as $status_row) {
    $status = (string)$status_row->status; $cnt = (int)$status_row->cnt;
    if (in_array($status,array('open','in_progress','awaiting_reply','waiting_agent','waiting_customer','queued','active'),true)) $counts['open'] += $cnt;
    if ($status === 'in_progress') $counts['in_progress'] = $cnt;
    if (in_array($status,array('awaiting_reply','waiting_agent','waiting_customer','queued','active'),true)) $counts['awaiting'] += $cnt;
    if ($status === 'resolved') $counts['resolved'] = $cnt;
    if ($status === 'closed') $counts['closed'] = $cnt;
}
$counts['total'] = $total_ticket_count;

$chats = array();
$chat_count = 0;
if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$esc_table)) === $esc_table) {
    $chats = $wpdb->get_results($wpdb->prepare("SELECT id,issue,status,created_at,last_activity,assigned_agent_name FROM {$esc_table} WHERE {$hc_identity_sql} ORDER BY created_at DESC,id DESC LIMIT 50", $hc_identity_args));
    $chat_count = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$esc_table} WHERE {$hc_identity_sql}", $hc_identity_args));
}

// Unified customer activity: ticket messages (including internal notes/system events) + ticket audit logs.
$activity = array();
if ($ticket_ids) {
    $id_placeholders = implode(',', array_fill(0, count($ticket_ids), '%d'));
    $message_rows = $wpdb->get_results($wpdb->prepare("SELECT id,ticket_id,user_id,sender_name,sender_type,is_admin,is_internal,is_system,message,created_at FROM {$messages_table} WHERE ticket_id IN ({$id_placeholders}) ORDER BY created_at DESC,id DESC LIMIT 80", $ticket_ids));
    foreach ((array)$message_rows as $m) {
        $kind = !empty($m->is_internal) ? 'Internal note' : (!empty($m->is_system) ? 'System event' : (in_array((string)$m->sender_type,array('agent','admin'),true) || !empty($m->is_admin) ? 'Agent reply' : 'Customer message'));
        $activity[] = array('time'=>$m->created_at,'kind'=>$kind,'actor'=>$m->sender_name ?: ($m->user_id ? hck_get_user_display((int)$m->user_id) : 'System'),'detail'=>wp_trim_words(wp_strip_all_tags((string)$m->message),28,'…'),'ticket_id'=>(int)$m->ticket_id,'ticket_ref'=>'Message #'.(int)$m->id,'internal'=>!empty($m->is_internal));
    }
    $log_rows = $wpdb->get_results($wpdb->prepare("SELECT id,ticket_id,user_id,action,details,created_at FROM {$logs_table} WHERE ticket_id IN ({$id_placeholders}) ORDER BY created_at DESC,id DESC LIMIT 80", $ticket_ids));
    foreach ((array)$log_rows as $l) {
        $actor = $l->user_id ? hck_get_user_display((int)$l->user_id) : 'System';
        $activity[] = array('time'=>$l->created_at,'kind'=>ucwords(str_replace('_',' ',(string)$l->action)),'actor'=>$actor,'detail'=>(string)$l->details,'ticket_id'=>(int)$l->ticket_id,'ticket_ref'=>'Activity #'.(int)$l->id,'internal'=>false);
    }
}
usort($activity, function($a,$b){ $c=strcmp((string)$b['time'],(string)$a['time']); return $c ?: ((int)$b['ticket_id'] <=> (int)$a['ticket_id']); });
$activity = array_slice($activity,0,100);

$can_add_customer_note = current_user_can('manage_options') || current_user_can('manage_woocommerce') || hck_get_ticket_agent_id($ref_ticket) === get_current_user_id();
$notes_table = $wpdb->prefix.'hck_customer_notes';
$customer_notes = array();
if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$notes_table)) === $notes_table) {
    if ($uid > 0 && is_email($email)) {
        $customer_notes = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$notes_table} WHERE customer_user_id=%d OR (customer_user_id=0 AND LOWER(customer_email)=LOWER(%s)) ORDER BY created_at DESC,id DESC LIMIT 100",$uid,$email));
    } elseif ($uid > 0) {
        $customer_notes = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$notes_table} WHERE customer_user_id=%d ORDER BY created_at DESC,id DESC LIMIT 100",$uid));
    } elseif (is_email($email)) {
        $customer_notes = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$notes_table} WHERE customer_user_id=0 AND LOWER(customer_email)=LOWER(%s) ORDER BY created_at DESC,id DESC LIMIT 100",$email));
    }
}
$order_count = 0; $order_total = 0; $orders = array();
if ($uid && function_exists('wc_get_orders')) {
    $order_count = (int)wc_get_customer_order_count($uid);
    $order_total = (float)wc_get_customer_total_spent($uid);
    $orders = wc_get_orders(array('customer_id'=>$uid,'limit'=>5,'orderby'=>'date','order'=>'DESC','return'=>'objects'));
}
?>
<div class="hck-c360-head">
 <div><a class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm" href="<?php echo esc_url(hck_admin_url('view/'.$ref_ticket_id.'/')); ?>"><i class="fas fa-arrow-left"></i> Back to Ticket</a><h1>Customer 360</h1><p class="hck-muted">Consolidated support history and activity. Original ticket and conversation records remain unchanged.</p></div>
</div>
<div class="hck-c360-profile hck-admin-card"><div class="hck-admin-card-body"><div class="hck-c360-identity"><img src="<?php echo esc_url(hck_get_avatar($uid,64)); ?>" alt=""><div><h2><?php echo esc_html($name); ?></h2><div><?php echo esc_html($email ?: 'No email on record'); ?></div><small><?php echo $uid ? 'Registered customer · WordPress user #'.(int)$uid : 'Guest customer'; ?></small></div></div>
<?php if ($user): ?><a class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm" href="<?php echo esc_url(admin_url('user-edit.php?user_id='.(int)$uid)); ?>" target="_blank" rel="noopener">WordPress profile <i class="fas fa-external-link-alt"></i></a><?php endif; ?>
</div></div>
<section class="hck-admin-card hck-c360-notes"><div class="hck-admin-card-head"><h2><i class="fas fa-sticky-note"></i> Internal customer notes</h2><span class="hck-muted">Visible to support staff only</span></div><div class="hck-admin-card-body">
<?php if ($can_add_customer_note): ?><form id="hckCustomerNoteForm"><input type="hidden" name="ticket_id" value="<?php echo (int)$ref_ticket_id; ?>"><textarea name="note" rows="3" maxlength="5000" required placeholder="Record customer preferences, recurring issues, or important context..."></textarea><div class="hck-c360-note-actions"><small class="hck-muted">Never include passwords, payment card details or authentication codes.</small><button class="hck-admin-btn hck-admin-btn-primary" type="submit" id="hckCustomerNoteSubmit"><i class="fas fa-plus"></i> Add internal note</button></div><div id="hckCustomerNoteFeedback" role="status" aria-live="polite"></div></form><?php else: ?><p class="hck-muted">Only the assigned agent or a supervisor can add customer notes. You can view the existing notes.</p><?php endif; ?>
<div id="hckCustomerNoteList"><?php if($customer_notes): foreach($customer_notes as $cn): $note_author=get_userdata((int)$cn->created_by); ?><article class="hck-c360-note"><div><strong><?php echo esc_html($note_author?$note_author->display_name:'Support staff'); ?></strong><time><?php echo esc_html(hck_format_date($cn->created_at)); ?> · <?php echo esc_html(hck_time_ago($cn->created_at)); ?></time></div><p><?php echo nl2br(esc_html($cn->note)); ?></p></article><?php endforeach; else: ?><p class="hck-muted" id="hckCustomerNotesEmpty">No internal customer notes yet.</p><?php endif; ?></div>
</div></section>
<div class="hck-c360-stats">
 <?php foreach (array('Total tickets'=>$counts['total'],'Active / waiting'=>$counts['open'],'Resolved'=>$counts['resolved'],'Closed'=>$counts['closed'],'HelpCenter live chats'=>$chat_count) as $label=>$value): ?><div class="hck-admin-stat"><div class="hck-admin-stat-info"><span class="hck-admin-stat-value"><?php echo (int)$value; ?></span><span class="hck-admin-stat-label"><?php echo esc_html($label); ?></span></div></div><?php endforeach; ?>
 <?php if ($uid && function_exists('wc_get_orders')): ?><div class="hck-admin-stat"><div class="hck-admin-stat-info"><span class="hck-admin-stat-value"><?php echo (int)$order_count; ?></span><span class="hck-admin-stat-label">WooCommerce orders</span></div></div><?php endif; ?>
</div>
<div class="hck-c360-grid">
 <section class="hck-admin-card"><div class="hck-admin-card-head"><h2><i class="fas fa-ticket-alt"></i> Support tickets</h2><span class="hck-muted"><?php echo (int)$counts['total']; ?> found (latest 100)</span></div><div class="hck-admin-card-body hck-c360-list">
 <?php if ($tickets): ?><table class="hck-admin-table"><thead><tr><th>Ticket</th><th>Subject</th><th>Status</th><th>Priority</th><th>Created</th></tr></thead><tbody><?php foreach($tickets as $t): ?><tr><td><a href="<?php echo esc_url(hck_admin_url('view/'.(int)$t->id.'/')); ?>"><?php echo esc_html(hck_get_ticket_number($t)); ?></a></td><td title="<?php echo esc_attr($t->subject); ?>"><?php echo esc_html(hck_ticket_subject_short($t->subject,50)); ?></td><td><span class="hck-badge hck-badge-<?php echo esc_attr($t->status); ?>"><?php echo esc_html(hck_get_status_label($t->status)); ?></span></td><td><?php echo esc_html(hck_get_priority_label($t->priority)); ?></td><td><?php echo esc_html(hck_format_date($t->created_at)); ?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><p class="hck-muted">No tickets found for this customer.</p><?php endif; ?>
 </div></section>
 <section class="hck-admin-card"><div class="hck-admin-card-head"><h2><i class="fas fa-comments"></i> HelpCenter conversations</h2><span class="hck-muted"><?php echo (int)$chat_count; ?></span></div><div class="hck-admin-card-body hck-c360-list">
 <?php if ($chats): ?><?php foreach($chats as $chat): ?><a class="hck-c360-chat" href="<?php echo esc_url(add_query_arg(array('tab'=>'all','ticket'=>(int)$chat->id),home_url('/support-agent/'))); ?>" target="_blank" rel="noopener"><strong>Conversation #<?php echo (int)$chat->id; ?></strong><span><?php echo esc_html(wp_trim_words(wp_strip_all_tags((string)$chat->issue),22,'…')); ?></span><small><?php echo esc_html(hck_get_status_label($chat->status)); ?> · <?php echo esc_html($chat->assigned_agent_name ?: 'Unassigned'); ?> · <?php echo esc_html(hck_format_date($chat->created_at)); ?></small></a><?php endforeach; ?><?php else: ?><p class="hck-muted">No HelpCenter live conversations found.</p><?php endif; ?>
 </div></section>
 <section class="hck-admin-card"><div class="hck-admin-card-head"><h2><i class="fas fa-history"></i> Customer activity timeline</h2><span class="hck-muted">Latest 100 events</span></div><div class="hck-admin-card-body hck-c360-timeline">
 <?php if ($activity): ?><ol><?php foreach($activity as $event): ?><li class="<?php echo !empty($event['internal'])?'is-internal':''; ?>"><div class="hck-c360-event-top"><strong><?php echo esc_html($event['kind']); ?></strong><time><?php echo esc_html(hck_format_date($event['time'])); ?> · <?php echo esc_html(hck_time_ago($event['time'])); ?></time></div><div class="hck-c360-event-meta"><?php echo esc_html($event['actor']); ?> · <a href="<?php echo esc_url(hck_admin_url('view/'.(int)$event['ticket_id'].'/')); ?>"><?php echo esc_html($ticket_number_map[(int)$event['ticket_id']] ?? ('#'.(int)$event['ticket_id'])); ?></a></div><?php if ($event['detail']!==''): ?><p><?php echo esc_html($event['detail']); ?></p><?php endif; ?></li><?php endforeach; ?></ol><?php else: ?><p class="hck-muted">No activity has been recorded yet.</p><?php endif; ?>
 </div></section>
 <?php if ($orders): ?><section class="hck-admin-card"><div class="hck-admin-card-head"><h2><i class="fas fa-shopping-bag"></i> Recent WooCommerce orders</h2><span class="hck-muted">Lifetime spend: <?php echo wp_kses_post(wc_price($order_total)); ?></span></div><div class="hck-admin-card-body"><table class="hck-admin-table"><thead><tr><th>Order</th><th>Date</th><th>Status</th><th>Total</th></tr></thead><tbody><?php foreach($orders as $o): ?><tr><td><a href="<?php echo esc_url(admin_url('post.php?post='.$o->get_id().'&action=edit')); ?>" target="_blank" rel="noopener">#<?php echo (int)$o->get_id(); ?></a></td><td><?php echo esc_html($o->get_date_created()?$o->get_date_created()->date_i18n('M j, Y'):''); ?></td><td><?php echo esc_html(wc_get_order_status_name($o->get_status())); ?></td><td><?php echo wp_kses_post($o->get_formatted_order_total()); ?></td></tr><?php endforeach; ?></tbody></table></div></section><?php endif; ?>
</div>
<script>
(function(){var form=document.getElementById('hckCustomerNoteForm');if(!form)return;form.addEventListener('submit',function(e){e.preventDefault();var btn=document.getElementById('hckCustomerNoteSubmit'),feedback=document.getElementById('hckCustomerNoteFeedback'),fd=new FormData(form);fd.append('action','hck_add_customer_note');fd.append('nonce',window.hckData&&window.hckData.nonce?window.hckData.nonce:'');btn.disabled=true;feedback.textContent='Saving…';fetch(window.hckData.ajaxUrl,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(function(res){if(!res||!res.success)throw new Error(res&&res.data&&res.data.message?res.data.message:'Could not save note.');var n=res.data.note,empty=document.getElementById('hckCustomerNotesEmpty');if(empty)empty.remove();var article=document.createElement('article');article.className='hck-c360-note';var head=document.createElement('div'),strong=document.createElement('strong'),time=document.createElement('time'),body=document.createElement('p');strong.textContent=n.created_by;time.textContent=n.created_at+' · just now';body.textContent=n.note;head.appendChild(strong);head.appendChild(time);article.appendChild(head);article.appendChild(body);document.getElementById('hckCustomerNoteList').prepend(article);form.querySelector('textarea').value='';feedback.textContent='Internal customer note saved.';}).catch(function(err){feedback.textContent=err.message;}).finally(function(){btn.disabled=false;});});})();
</script>
<style>
.hck-c360-notes textarea{width:100%;box-sizing:border-box;border:1px solid #dbe2ec;border-radius:8px;padding:11px;font:inherit;resize:vertical;min-height:76px}.hck-c360-note-actions{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:8px}.hck-c360-note{padding:12px 0;border-bottom:1px solid #e8edf3}.hck-c360-note>div{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.hck-c360-note time{font-size:11px;color:#7b8495}.hck-c360-note p{margin:7px 0 0;white-space:pre-wrap;overflow-wrap:anywhere}#hckCustomerNoteFeedback{font-size:12px;margin-top:7px;color:#475569}
.hck-c360-head{display:flex;justify-content:space-between;align-items:flex-start;margin:0 0 18px}.hck-c360-head h1{margin:14px 0 4px;font-size:24px}.hck-c360-profile .hck-admin-card-body{display:flex;align-items:center;justify-content:space-between;gap:16px}.hck-c360-identity{display:flex;align-items:center;gap:14px;min-width:0}.hck-c360-identity img{width:60px;height:60px;border-radius:50%;object-fit:cover}.hck-c360-identity h2{margin:0 0 4px;font-size:18px}.hck-c360-identity div div{overflow-wrap:anywhere}.hck-c360-identity small{display:block;color:#7b8495;margin-top:4px}.hck-c360-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:12px;margin:14px 0}.hck-c360-stats .hck-admin-stat{min-height:76px}.hck-c360-stats .hck-admin-stat-value{font-size:23px}.hck-c360-grid{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(280px,.8fr);gap:16px}.hck-c360-grid>.hck-admin-card:last-of-type{grid-column:1/-1}.hck-c360-list{max-height:460px;overflow:auto}.hck-c360-chat{display:flex;flex-direction:column;gap:5px;padding:11px 0;border-bottom:1px solid #e8edf3;color:inherit;text-decoration:none}.hck-c360-chat span,.hck-c360-chat small{overflow-wrap:anywhere}.hck-c360-chat small{color:#7b8495}.hck-c360-timeline{max-height:560px;overflow:auto}.hck-c360-timeline ol{list-style:none;padding:0;margin:0}.hck-c360-timeline li{position:relative;padding:0 0 18px 22px;border-left:2px solid #dfe5ee;margin-left:7px}.hck-c360-timeline li:before{content:'';position:absolute;left:-6px;top:3px;width:10px;height:10px;border-radius:50%;background:#64748b}.hck-c360-timeline li.is-internal:before{background:#d97706}.hck-c360-event-top{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}.hck-c360-event-top time,.hck-c360-event-meta{font-size:11px;color:#7b8495}.hck-c360-event-meta{margin-top:4px}.hck-c360-timeline p{margin:6px 0 0;white-space:pre-wrap;overflow-wrap:anywhere}.hck-c360-timeline a{color:#4f46e5}@media(max-width:900px){.hck-c360-grid{grid-template-columns:1fr}.hck-c360-grid>.hck-admin-card:last-of-type{grid-column:auto}.hck-c360-profile .hck-admin-card-body{align-items:flex-start;flex-direction:column}.hck-c360-list{max-height:none;overflow:visible}.hck-c360-list table{min-width:620px}.hck-c360-list{overflow-x:auto}}
</style>
