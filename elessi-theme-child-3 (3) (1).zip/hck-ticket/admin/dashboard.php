<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$t = $wpdb->prefix . 'hck_tickets';
$stats = hck_get_admin_stats();

// Recent tickets
$recent = $wpdb->get_results("SELECT * FROM $t ORDER BY updated_at DESC LIMIT 8");

// Urgent tickets
$urgent = $wpdb->get_results("SELECT * FROM $t WHERE priority = 'urgent' AND status NOT IN ('closed','resolved') ORDER BY created_at ASC LIMIT 5");

// Average rating
$avg_rating = $wpdb->get_var("SELECT AVG(rating) FROM {$wpdb->prefix}hck_ticket_ratings");
?>

<div class="hck-admin-stats">
    <div class="hck-admin-stat">
        <div class="hck-admin-stat-icon" style="background:rgba(99,102,241,0.15);color:#818CF8;"><i class="fas fa-ticket-alt"></i></div>
        <div class="hck-admin-stat-info">
            <span class="hck-admin-stat-value"><?php echo $stats['total']; ?></span>
            <span class="hck-admin-stat-label">Total Tickets</span>
        </div>
    </div>
    <div class="hck-admin-stat">
        <div class="hck-admin-stat-icon" style="background:rgba(239,68,68,0.15);color:#F87171;"><i class="fas fa-folder-open"></i></div>
        <div class="hck-admin-stat-info">
            <span class="hck-admin-stat-value"><?php echo $stats['open']; ?></span>
            <span class="hck-admin-stat-label">Open</span>
        </div>
    </div>
    <div class="hck-admin-stat">
        <div class="hck-admin-stat-icon" style="background:rgba(245,158,11,0.15);color:#FBBF24;"><i class="fas fa-spinner"></i></div>
        <div class="hck-admin-stat-info">
            <span class="hck-admin-stat-value"><?php echo $stats['in_progress']; ?></span>
            <span class="hck-admin-stat-label">In Progress</span>
        </div>
    </div>
    <div class="hck-admin-stat">
        <div class="hck-admin-stat-icon" style="background:rgba(16,185,129,0.15);color:#34D399;"><i class="fas fa-check-circle"></i></div>
        <div class="hck-admin-stat-info">
            <span class="hck-admin-stat-value"><?php echo $stats['resolved'] + $stats['closed']; ?></span>
            <span class="hck-admin-stat-label">Resolved</span>
        </div>
    </div>
    <div class="hck-admin-stat">
        <div class="hck-admin-stat-icon" style="background:rgba(239,68,68,0.15);color:#F87171;"><i class="fas fa-user-slash"></i></div>
        <div class="hck-admin-stat-info">
            <span class="hck-admin-stat-value"><?php echo $stats['unassigned']; ?></span>
            <span class="hck-admin-stat-label">Unassigned</span>
        </div>
    </div>
    <div class="hck-admin-stat">
        <div class="hck-admin-stat-icon" style="background:rgba(245,158,11,0.15);color:#FBBF24;"><i class="fas fa-star"></i></div>
        <div class="hck-admin-stat-info">
            <span class="hck-admin-stat-value"><?php echo $avg_rating ? round($avg_rating, 1) : '—'; ?></span>
            <span class="hck-admin-stat-label">Avg Rating</span>
        </div>
    </div>
</div>

<div class="hck-dashboard-workspaces">
    <div class="hck-dashboard-workspaces-head"><div><span>WORKSPACES</span><h2>Support operations</h2><p>Tickets, customers, team performance and system configuration are grouped into dedicated workspaces.</p></div></div>
    <div class="hck-dashboard-workspaces-grid">
        <a href="<?php echo esc_url(hck_admin_url('section/tickets/')); ?>"><i class="fas fa-ticket-alt"></i><strong>Ticket Management</strong><span>Queue, routing and ticket creation</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(hck_admin_url('section/customers/')); ?>"><i class="fas fa-users"></i><strong>Customers</strong><span>Customer records and history</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(hck_admin_url('section/agents-team/')); ?>"><i class="fas fa-users-gear"></i><strong>Agents & Team</strong><span>Team, assignments and CSAT</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(hck_admin_url('section/sla/')); ?>"><i class="fas fa-stopwatch"></i><strong>SLA Management</strong><span>Response and resolution targets</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(hck_admin_url('section/settings/')); ?>"><i class="fas fa-sliders"></i><strong>Settings</strong><span>Ticket system configuration</span><b>Open workspace →</b></a>
    </div>
</div>

<?php if ($urgent): ?>
<div class="hck-admin-card hck-admin-card-urgent">
    <div class="hck-admin-card-head">
        <h2><i class="fas fa-exclamation-triangle"></i> Urgent Tickets</h2>
    </div>
    <div class="hck-admin-card-body">
        <table class="hck-admin-table">
            <thead><tr><th>Ticket</th><th>Subject</th><th>Customer</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($urgent as $t): ?>
                <tr>
                    <td class="hck-mono"><?php echo esc_html(hck_get_ticket_number($t)); ?></td>
                    <td title="<?php echo esc_attr($t->subject); ?>"><?php echo esc_html(hck_ticket_subject_short($t->subject,50)); ?></td>
                    <td><?php echo esc_html(!empty($t->customer_name) ? $t->customer_name : hck_get_user_name(hck_get_ticket_user_id($t))); ?></td>
                    <td><a href="<?php echo esc_url(hck_admin_url('view/' . $t->id . '/')); ?>" class="hck-admin-btn hck-admin-btn-primary hck-admin-btn-xs">View</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>


<?php
$pending_reopens = $wpdb->get_results("SELECT r.id request_id,r.created_at request_created,t.id ticket_id,t.ticket_number,t.subject,t.agent_id FROM {$wpdb->prefix}hck_ticket_reopen_requests r INNER JOIN {$t} t ON t.id=r.ticket_id WHERE r.status='pending' AND (t.merged_into IS NULL OR t.merged_into=0) ORDER BY r.created_at ASC LIMIT 10");
if ($pending_reopens): ?>
<div class="hck-admin-card"><div class="hck-admin-card-head"><h2><i class="fas fa-rotate-left"></i> Pending reopen requests</h2></div><div class="hck-admin-card-body"><table class="hck-admin-table"><thead><tr><th>Ticket</th><th>Customer request</th><th>Assigned agent</th><th>Submitted</th><th></th></tr></thead><tbody>
<?php foreach($pending_reopens as $rr): $rr_agent=$rr->agent_id?get_userdata((int)$rr->agent_id):false; ?>
<tr><td><?php echo esc_html($rr->ticket_number ?: '#'.$rr->ticket_id); ?></td><td><?php echo esc_html(wp_trim_words($rr->subject,10,'…')); ?></td><td><?php echo esc_html($rr_agent?$rr_agent->display_name:'Unassigned'); ?></td><td><?php echo esc_html(hck_time_ago($rr->request_created)); ?></td><td><a class="hck-admin-btn hck-admin-btn-primary hck-admin-btn-xs" href="<?php echo esc_url(hck_admin_url('view/'.(int)$rr->ticket_id.'/')); ?>">Review</a></td></tr>
<?php endforeach; ?></tbody></table></div></div>
<?php endif; ?>

<div class="hck-admin-card">
    <div class="hck-admin-card-head">
        <h2><i class="fas fa-clock"></i> Recent Activity</h2>
        <a href="<?php echo esc_url(hck_admin_url('tickets/')); ?>" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm">All Tickets <i class="fas fa-arrow-right"></i></a>
    </div>
    <div class="hck-admin-card-body">
        <?php if ($recent): ?>
        <table class="hck-admin-table">
            <thead>
                <tr>
                    <th>Ticket</th>
                    <th>Subject</th>
                    <th>Customer</th>
                    <th>Status</th>
                    <th>Priority</th>
                    <th>Updated</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent as $t): ?>
                <tr>
                    <td class="hck-mono"><?php echo esc_html(hck_get_ticket_number($t)); ?></td>
                    <td title="<?php echo esc_attr($t->subject); ?>"><?php echo esc_html(hck_ticket_subject_short($t->subject,50)); ?></td>
                    <td><?php echo esc_html(!empty($t->customer_name) ? $t->customer_name : hck_get_user_name(hck_get_ticket_user_id($t))); ?></td>
                    <td><span class="hck-badge hck-badge-<?php echo esc_attr($t->status); ?>"><?php echo esc_html(hck_get_status_label($t->status)); ?></span></td>
                    <td style="color:<?php echo esc_attr(hck_get_priority_color($t->priority)); ?>;font-weight:600;"><?php echo esc_html(hck_get_priority_label($t->priority)); ?></td>
                    <td class="hck-muted"><?php echo esc_html(hck_time_ago($t->updated_at)); ?></td>
                    <td><a href="<?php echo esc_url(hck_admin_url('view/' . $t->id . '/')); ?>" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-xs">View</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="hck-admin-empty">No tickets yet.</div>
        <?php endif; ?>
    </div>
</div>
