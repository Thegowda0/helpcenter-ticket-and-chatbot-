<?php
/**
 * Phase 2 - Team workload and agent performance.
 */
if (!defined('ABSPATH')) exit;
if (!(current_user_can('manage_options') || current_user_can('manage_woocommerce') || current_user_can('hc_manage_ai_escalations'))) {
    echo '<div class="hck-admin-card"><div class="hck-admin-card-body">Only supervisors can view team performance.</div></div>';
    return;
}

global $wpdb;
$t = $wpdb->prefix . 'hck_tickets';
$m = $wpdb->prefix . 'hck_ticket_messages';
$now = current_time('mysql');
$range = isset($_GET['range']) ? absint($_GET['range']) : 30;
if (!in_array($range, array(7, 30, 90), true)) $range = 30;
$since = wp_date('Y-m-d H:i:s', current_time('timestamp', true) - ($range * DAY_IN_SECONDS));
$active_statuses = "('open','in_progress','awaiting_reply')";

$staff = get_users(array('role__in' => array('administrator','shop_manager','hc_support_agent'), 'orderby' => 'display_name', 'order' => 'ASC', 'number' => 500));
$staff = array_merge((array)$staff, (array)get_users(array('capability' => 'hc_manage_ai_escalations', 'orderby' => 'display_name', 'number' => 500)), (array)get_users(array('capability' => 'hck_reply_tickets', 'orderby' => 'display_name', 'number' => 500)));
$staff_map = array();
foreach ($staff as $person) $staff_map[(int)$person->ID] = $person;
$staff = array_values($staff_map);
usort($staff, function($a, $b) { return strcasecmp($a->display_name, $b->display_name); });

$unassigned = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE (agent_id IS NULL OR agent_id=0) AND status IN {$active_statuses}");
$active_total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status IN {$active_statuses}");
$overdue_total = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE status IN {$active_statuses} AND ((sla_first_responded_at IS NULL AND sla_first_response_due_at IS NOT NULL AND sla_first_response_due_at < %s) OR (sla_resolution_due_at IS NOT NULL AND sla_resolution_due_at < %s))", $now, $now));
$resolved_total = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE status IN ('resolved','closed') AND COALESCE(resolved_at,closed_at) >= %s", $since));

$rows = array();
foreach ($staff as $person) {
    $uid = (int)$person->ID;
    $active = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE agent_id=%d AND status IN {$active_statuses}", $uid));
    $overdue = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE agent_id=%d AND status IN {$active_statuses} AND ((sla_first_responded_at IS NULL AND sla_first_response_due_at IS NOT NULL AND sla_first_response_due_at < %s) OR (sla_resolution_due_at IS NOT NULL AND sla_resolution_due_at < %s))", $uid, $now, $now));
    $resolved = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE agent_id=%d AND status IN ('resolved','closed') AND COALESCE(resolved_at,closed_at) >= %s", $uid, $since));
    $avg_response = $wpdb->get_var($wpdb->prepare(
        "SELECT AVG(TIMESTAMPDIFF(SECOND, x.created_at, fr.first_reply_at))/60
         FROM {$t} x
         INNER JOIN (SELECT ticket_id, MIN(created_at) AS first_reply_at FROM {$m} WHERE is_admin=1 AND is_internal=0 GROUP BY ticket_id) fr ON fr.ticket_id=x.id
         WHERE x.agent_id=%d AND x.created_at >= %s AND fr.first_reply_at >= x.created_at", $uid, $since
    ));
    $avg_resolution = $wpdb->get_var($wpdb->prepare(
        "SELECT AVG(TIMESTAMPDIFF(SECOND, created_at, COALESCE(resolved_at,closed_at)))/60 FROM {$t}
         WHERE agent_id=%d AND COALESCE(resolved_at,closed_at) >= %s AND COALESCE(resolved_at,closed_at) > created_at", $uid, $since
    ));
    $capacity = (int)get_user_meta($uid, 'hck_agent_capacity', true);
    if ($capacity < 1) $capacity = 15;
    $rows[] = array('user'=>$person, 'active'=>$active, 'overdue'=>$overdue, 'resolved'=>$resolved, 'capacity'=>$capacity, 'response'=>$avg_response !== null ? (float)$avg_response : null, 'resolution'=>$avg_resolution !== null ? (float)$avg_resolution : null);
}

$format_minutes = function($minutes) {
    if ($minutes === null) return '—';
    $minutes = max(0, (int)round($minutes));
    if ($minutes < 60) return $minutes . ' min';
    $hours = intdiv($minutes, 60); $mins = $minutes % 60;
    if ($hours < 48) return $hours . 'h ' . $mins . 'm';
    return intdiv($hours, 24) . 'd ' . ($hours % 24) . 'h';
};
?>
<div class="hck-team-page">
    <div class="hck-admin-card">
        <div class="hck-admin-card-head"><h2><i class="fas fa-users-gear"></i> Team workload</h2><form method="get" class="hck-team-range"><label for="hckTeamRange">Performance period</label><select id="hckTeamRange" name="range" class="hck-admin-input" onchange="this.form.submit()"><option value="7" <?php selected($range,7); ?>>Last 7 days</option><option value="30" <?php selected($range,30); ?>>Last 30 days</option><option value="90" <?php selected($range,90); ?>>Last 90 days</option></select></form></div>
        <div class="hck-admin-card-body">
            <div class="hck-team-summary">
                <div><span>Active tickets</span><strong><?php echo number_format_i18n($active_total); ?></strong></div>
                <div><span>Unassigned</span><strong><?php echo number_format_i18n($unassigned); ?></strong></div>
                <div><span>Currently overdue</span><strong><?php echo number_format_i18n($overdue_total); ?></strong></div>
                <div><span>Resolved in period</span><strong><?php echo number_format_i18n($resolved_total); ?></strong></div>
            </div>
            <p class="hck-muted">Workload counts include open, in-progress and awaiting-reply tickets. Capacity is a planning indicator (15 active tickets by default), not an automatic assignment limit. Supervisors can change it per agent. Response and resolution averages use tickets currently assigned to each agent and the selected period.</p>
            <?php if ($rows): ?>
            <div class="hck-team-table-wrap"><table class="hck-admin-table hck-team-table"><thead><tr><th>Agent</th><th>Active workload / capacity</th><th>Overdue</th><th>Resolved</th><th>Avg. first response</th><th>Avg. resolution</th></tr></thead><tbody>
            <?php foreach ($rows as $r): $pct = min(100, (int)round(($r['active'] / max(1,$r['capacity'])) * 100)); ?>
                <tr>
                    <td><div class="hck-team-agent"><img src="<?php echo esc_url(hck_get_avatar($r['user']->ID,36)); ?>" alt=""><span><strong><?php echo esc_html($r['user']->display_name); ?></strong><small><?php echo esc_html($r['user']->user_email); ?></small></span></div></td>
                    <td><strong><?php echo (int)$r['active']; ?></strong><div class="hck-team-meter"><span style="width:<?php echo $pct; ?>%"></span></div><form class="hck-agent-capacity-form" data-agent-id="<?php echo (int)$r['user']->ID; ?>"><label>Capacity <input type="number" min="1" max="500" name="capacity" value="<?php echo (int)$r['capacity']; ?>" aria-label="Active ticket capacity for <?php echo esc_attr($r['user']->display_name); ?>"></label><button type="submit" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-xs">Save</button><span role="status"></span></form></td>
                    <td><?php if ($r['overdue']): ?><span class="hck-team-overdue"><?php echo (int)$r['overdue']; ?></span><?php else: ?>0<?php endif; ?></td>
                    <td><?php echo (int)$r['resolved']; ?></td>
                    <td><?php echo esc_html($format_minutes($r['response'])); ?></td>
                    <td><?php echo esc_html($format_minutes($r['resolution'])); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table></div>
            <?php else: ?><div class="hck-admin-empty">No support agents were found. Add users with an Administrator, Shop Manager or Support Agent role.</div><?php endif; ?>
            <div class="hck-team-actions"><a class="hck-admin-btn hck-admin-btn-primary" href="<?php echo esc_url(hck_admin_url('tickets/')); ?>">Review all tickets <i class="fas fa-arrow-right"></i></a><a class="hck-admin-btn hck-admin-btn-outline" href="<?php echo esc_url(hck_admin_url('sla/')); ?>">Open SLA management</a></div>
        </div>
    </div>
</div>
<style>
.hck-team-range{display:flex;align-items:center;gap:9px}.hck-team-range label{font-size:12px;color:var(--hck-admin-text-3);font-weight:600}.hck-team-range select{min-width:145px}.hck-team-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:4px 0 18px}.hck-team-summary>div{padding:16px;border:1px solid var(--hck-admin-border);border-radius:12px;background:var(--hck-admin-surface)}.hck-team-summary span{display:block;color:var(--hck-admin-text-3);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em}.hck-team-summary strong{display:block;font-size:26px;line-height:1.2;margin-top:7px;color:var(--hck-admin-text)}.hck-team-table-wrap{width:100%;overflow-x:auto}.hck-team-table{min-width:760px}.hck-team-agent{display:flex;align-items:center;gap:10px;min-width:180px}.hck-team-agent img{width:36px;height:36px;border-radius:50%;object-fit:cover}.hck-team-agent span,.hck-team-agent small{display:block;min-width:0}.hck-team-agent small{font-size:11px;color:var(--hck-admin-text-3);overflow-wrap:anywhere}.hck-team-meter{height:6px;width:100px;background:var(--hck-admin-border);border-radius:10px;overflow:hidden;margin:5px 0}.hck-team-meter span{display:block;height:100%;background:var(--hck-sidebar-active);border-radius:10px}.hck-team-table td small{font-size:10px;color:var(--hck-admin-text-3)}.hck-agent-capacity-form{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:4px}.hck-agent-capacity-form label{font-size:10px;color:var(--hck-admin-text-3);display:flex;align-items:center;gap:4px}.hck-agent-capacity-form input{width:58px;padding:4px 5px;border:1px solid var(--hck-admin-border);border-radius:6px;font-size:11px}.hck-agent-capacity-form span{font-size:10px;color:#16834b}.hck-team-overdue{display:inline-flex;padding:4px 8px;border-radius:20px;background:#fff0f0;color:#c62828;font-weight:800}.hck-team-actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:18px}@media(max-width:700px){.hck-team-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.hck-admin-card-head{align-items:flex-start;gap:12px;flex-wrap:wrap}.hck-team-range{width:100%;justify-content:space-between}}
</style>
<script>
(function(){
 document.querySelectorAll('.hck-agent-capacity-form').forEach(function(form){
  form.addEventListener('submit',function(e){
   e.preventDefault();var button=form.querySelector('button'),out=form.querySelector('[role="status"]');
   var data=new FormData();data.append('action','hck_save_agent_capacity');data.append('nonce',window.hckData.nonce);data.append('agent_id',form.getAttribute('data-agent-id'));data.append('capacity',form.querySelector('[name="capacity"]').value);
   button.disabled=true;out.textContent='Saving…';
   fetch(window.hckData.ajaxUrl,{method:'POST',credentials:'same-origin',body:data}).then(function(r){return r.json();}).then(function(r){out.textContent=r.success?'Saved':((r.data&&r.data.message)||'Failed');}).catch(function(){out.textContent='Network error';}).finally(function(){button.disabled=false;});
  });
 });
})();
</script>
