<?php
/**
 * HCK Ticket System - Admin Wrapper
 * Standalone dark-sidebar layout. No theme header/footer.
 */

if (!defined('ABSPATH')) exit;

$hck_page = get_query_var('hck_page') ?: 'admin-dashboard';
$ticket_id = get_query_var('hck_ticket');

$current_user = wp_get_current_user();
$is_agent_workspace = !hck_is_supervisor_user();
if ($hck_page === 'admin-dashboard' && $is_agent_workspace) { wp_safe_redirect(home_url('/ticket/agent/')); exit; }
$site_name = hck_get_setting('hck_site_title', 'Support Center');

// Stats for sidebar badges
$stats = hck_get_admin_stats();

$css_file = HCK_PATH . 'assets/admin/admin.css';
$js_file  = HCK_PATH . 'assets/admin/admin.js';
$css_ver  = file_exists($css_file) ? filemtime($css_file) : HCK_VERSION;
$js_ver   = file_exists($js_file)  ? filemtime($js_file)  : HCK_VERSION;

// Determine active menu
$menu = array(
    'agent-dashboard' => 'agent-dashboard',
    'admin-dashboard' => 'dashboard',
    'admin-hub' => 'hub',
    'admin-tickets'   => 'tickets',
    'admin-view'      => $is_agent_workspace ? 'agent-dashboard' : 'tickets',
    'admin-customer'  => 'customers',
    'admin-customers' => 'customers',
    'admin-settings'  => 'settings',
    'admin-sla'       => 'sla',
    'admin-team'      => 'team',
    'admin-csat'      => 'csat',
);
$active = isset($menu[$hck_page]) ? $menu[$hck_page] : 'dashboard';
if ($hck_page === 'admin-hub') {
    $hub_key = sanitize_key(get_query_var('hck_hub'));
    $active = ($hub_key === 'tickets') ? 'tickets' : (($hub_key === 'customers') ? 'customers' : (($hub_key === 'agents-team') ? 'team' : (($hub_key === 'sla') ? 'sla' : (($hub_key === 'settings') ? 'settings' : 'hub'))));
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>Admin - <?php echo esc_html($site_name); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
<link rel="stylesheet" href="<?php echo esc_url(HCK_ASSETS . 'admin/admin.css?v=' . $css_ver); ?>">
</head>
<body class="hck-admin-body">

<div class="hck-admin-layout">

    <!-- SIDEBAR -->
    <aside class="hck-sidebar" id="hckSidebar">
        <div class="hck-sidebar-header">
            <i class="fas fa-headset"></i>
            <span><?php echo $is_agent_workspace ? 'Agent Workspace' : 'Support Admin'; ?></span>
            <button type="button" class="hck-sidebar-close" id="hckSidebarClose" aria-label="Close sidebar">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <nav class="hck-sidebar-nav">
            <?php if ($is_agent_workspace): ?>
            <?php $agent_view = sanitize_key(wp_unslash($_GET['view'] ?? 'active')); $agent_views = array('active'=>'My Workspace','action'=>'Needs action','waiting'=>'Waiting for customer','overdue'=>'Overdue','due-soon'=>'Due soon','completed'=>'Completed'); if (!isset($agent_views[$agent_view])) $agent_view='active'; ?>
            <div class="hck-sidebar-section-label">MY WORK</div>
            <?php foreach ($agent_views as $agent_view_key=>$agent_view_label): ?>
                <a href="<?php echo esc_url(add_query_arg(array('view'=>$agent_view_key),home_url('/ticket/agent/'))); ?>" class="hck-sidebar-link <?php echo $agent_view === $agent_view_key ? 'active' : ''; ?>" <?php echo $agent_view === $agent_view_key ? 'aria-current="page"' : ''; ?>>
                    <i class="fas <?php echo esc_attr(array('active'=>'fa-layer-group','action'=>'fa-reply','waiting'=>'fa-hourglass-half','overdue'=>'fa-triangle-exclamation','due-soon'=>'fa-stopwatch','completed'=>'fa-circle-check')[$agent_view_key]); ?>"></i><span><?php echo esc_html($agent_view_label); ?></span>
                </a>
            <?php endforeach; ?>
            <?php else: ?>
            <div class="hck-sidebar-section-label">OVERVIEW</div>
            <a href="<?php echo esc_url(hck_admin_url()); ?>" class="hck-sidebar-link <?php echo $active === 'dashboard' ? 'active' : ''; ?>">
                <i class="fas fa-chart-pie"></i>
                <span>Dashboard</span>
            </a>
            <div class="hck-sidebar-section-label">SUPPORT</div>
            <a href="<?php echo esc_url(hck_admin_url('section/tickets/')); ?>" class="hck-sidebar-link <?php echo in_array($active,array('tickets','hub'),true) && sanitize_key(get_query_var('hck_hub')) === 'tickets' ? 'active' : ($active === 'tickets' ? 'active' : ''); ?>"><i class="fas fa-ticket-alt"></i><span>Ticket Management</span><?php if ($stats['unassigned'] > 0): ?><span class="hck-sidebar-badge"><?php echo (int)$stats['unassigned']; ?></span><?php endif; ?></a>
            <div class="hck-sidebar-section-label">CUSTOMERS</div>
            <a href="<?php echo esc_url(hck_admin_url('section/customers/')); ?>" class="hck-sidebar-link <?php echo $active === 'customers' || ($active === 'hub' && sanitize_key(get_query_var('hck_hub')) === 'customers') ? 'active' : ''; ?>"><i class="fas fa-users"></i><span>Customers</span></a>
            <?php if (hck_is_supervisor_user()): ?>
            <div class="hck-sidebar-section-label">TEAM & PERFORMANCE</div>
            <a href="<?php echo esc_url(hck_admin_url('section/agents-team/')); ?>" class="hck-sidebar-link <?php echo $active === 'team' || ($active === 'hub' && sanitize_key(get_query_var('hck_hub')) === 'agents-team') ? 'active' : ''; ?>"><i class="fas fa-users-gear"></i><span>Agents & Team</span></a>
            <?php if (current_user_can('manage_options')): ?>
            <div class="hck-sidebar-section-label">ADMINISTRATION</div>
            <a href="<?php echo esc_url(hck_admin_url('section/sla/')); ?>" class="hck-sidebar-link <?php echo $active === 'sla' || ($active === 'hub' && sanitize_key(get_query_var('hck_hub')) === 'sla') ? 'active' : ''; ?>"><i class="fas fa-stopwatch"></i><span>SLA Management</span></a>
            <a href="<?php echo esc_url(hck_admin_url('section/settings/')); ?>" class="hck-sidebar-link <?php echo $active === 'settings' || ($active === 'hub' && sanitize_key(get_query_var('hck_hub')) === 'settings') ? 'active' : ''; ?>"><i class="fas fa-cog"></i><span>Settings</span></a>
            <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>
        </nav>
        
                <div class="hck-sidebar-footer">
            <?php if ($is_agent_workspace): ?>
            <a href="<?php echo esc_url(home_url('/support-agent/')); ?>" class="hck-sidebar-link"><i class="fas fa-comments"></i><span>HelpCenter Agent Desk</span></a>
            <?php else: ?>
            <a href="<?php echo esc_url(home_url('/ticket/')); ?>" target="_blank" class="hck-sidebar-link">
                <i class="fas fa-external-link-alt"></i>
                <span>Customer View</span>
            </a>
            <a href="<?php echo esc_url(home_url('/helpcenter/admin/')); ?>" target="_blank" class="hck-sidebar-link"><i class="fas fa-circle-question"></i><span>Help Center Admin</span></a>
            <?php endif; ?>
            <a href="<?php echo esc_url(wp_logout_url($is_agent_workspace ? home_url('/support-agent/login/') : home_url('/ticket/admin/'))); ?>" class="hck-sidebar-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>

    <!-- MAIN -->
    <div class="hck-admin-main">
        
        <header class="hck-admin-topbar">
            <button type="button" class="hck-sidebar-toggle" id="hckSidebarToggle">
    <i class="fas fa-bars"></i>
</button>
            <div class="hck-admin-topbar-title">
                <?php
                $titles = array(
                    'agent-dashboard' => 'My Workspace',
                    'admin-dashboard' => 'Dashboard',
                    'admin-hub' => array('tickets'=>'Ticket Management','customers'=>'Customers','agents-team'=>'Agents & Team','sla'=>'SLA Management','settings'=>'Settings')[sanitize_key(get_query_var('hck_hub'))] ?? 'Workspace',
                    'admin-tickets'   => 'All Tickets',
                    'admin-view'      => 'Ticket Details',
                    'admin-customer'  => 'Customer 360',
                    'admin-customers' => 'Customers',
                    'admin-settings'  => 'Settings — ' . ucwords(str_replace('-', ' ', sanitize_key(get_query_var('hck_settings_section') ?: 'general'))),
                    'admin-sla'       => 'SLA Management',
                    'admin-team'      => 'Team & Performance',
                    'admin-csat'      => 'Customer Satisfaction',
                );
                echo isset($titles[$hck_page]) ? esc_html($titles[$hck_page]) : 'Admin';
                ?>
            </div>
            <div class="hck-header-alert-control" id="hckHeaderAlertControl">
                <button type="button" class="hck-header-alert-toggle" id="hckHeaderAlertToggle" aria-expanded="false" aria-controls="hckHeaderAlertPanel" title="Notification preferences"><i class="fas fa-bell"></i><span>Alerts</span></button>
                <section class="hck-header-alert-panel" id="hckHeaderAlertPanel" hidden>
                    <strong>Notification preferences</strong>
                    <p id="hckHeaderAlertStatus">Administrator-selected sound</p>
                    <label><span>Sound alerts</span><input type="checkbox" id="hckHeaderAlertEnabled"></label>
                    <label class="hck-alert-volume"><span>Volume</span><input type="range" id="hckHeaderAlertVolume" min="0" max="1" step="0.05"><output id="hckHeaderAlertVolumeValue">90%</output></label>
                    <div class="hck-header-alert-actions"><button type="button" id="hckHeaderAlertTest"><i class="fas fa-volume-high"></i> Test sound</button><button type="button" id="hckHeaderAlertClose">Close</button></div>
                </section>
            </div>
            <div class="hck-admin-topbar-user">
                <span><?php echo esc_html($current_user->display_name); ?></span>
                <img src="<?php echo esc_url(hck_get_avatar($current_user->ID, 32)); ?>" alt="">
            </div>
        </header>
        
        <div class="hck-admin-content">
            <?php
            switch ($hck_page) {
                case 'agent-dashboard': include HCK_ADMIN . 'agent-dashboard.php'; break;
                case 'admin-dashboard': include HCK_ADMIN . 'dashboard.php';     break;
                case 'admin-hub':       include HCK_ADMIN . 'section-hub.php'; break;
                case 'admin-tickets':   include HCK_ADMIN . 'tickets.php';       break;
                case 'admin-view':      include HCK_ADMIN . 'ticket-view.php';   break;
                case 'admin-customer':  include HCK_ADMIN . 'customer-view.php';  break;
                case 'admin-customers': include HCK_ADMIN . 'customers.php';       break;
                case 'admin-settings':  include HCK_ADMIN . 'settings.php';      break;
                case 'admin-sla':       include HCK_ADMIN . 'sla.php';           break;
                case 'admin-team':      include HCK_ADMIN . 'team.php';          break;
                case 'admin-csat':      hck_phase2_admin_csat_page();             break;
                default:
                    echo '<div class="hck-admin-empty"><h2>Page not found</h2></div>';
            }
            ?>
        </div>
        
    </div>

</div>

<div class="hck-sidebar-overlay" id="hckSidebarOverlay"></div>

<script>
window.hckData = {
    ajaxUrl: '<?php echo esc_url(admin_url("admin-ajax.php")); ?>',
    nonce: '<?php echo wp_create_nonce("hck_nonce"); ?>',
    userId: <?php echo (int) get_current_user_id(); ?>,
    alertsEnabled: <?php echo class_exists('HC_Core') && HC_Core::get_setting('hc_ai_support_notifications_enabled','1') === '1' ? 'true' : 'false'; ?>,
    alertSound: <?php echo wp_json_encode(class_exists('HC_Core') ? HC_Core::get_setting('hc_ai_support_alert_sound','urgent') : 'urgent'); ?>,
    alertVolume: <?php echo (float)max(0.2,min(1,(float)(class_exists('HC_Core') ? HC_Core::get_setting('hc_ai_support_alert_volume','0.9') : '0.9'))); ?>,
    homeUrl: '<?php echo esc_url(hck_admin_url()); ?>',
    ticketId: <?php echo $hck_page === 'admin-view' ? (int) $ticket_id : 0; ?>,
    realtimeEnabled: <?php echo (class_exists('HC_Realtime') && HC_Realtime::is_configured()) ? 'true' : 'false'; ?>
};
</script>
<?php if ($hck_page === 'admin-view' && class_exists('HC_Realtime') && HC_Realtime::is_configured()): ?>
<script src="https://cdn.ably.com/lib/ably.min-2.js"></script>
<script src="<?php echo esc_url(HC_ASSETS . 'js/hc-realtime-client.js?v=' . (defined('HC_PATH') && file_exists(HC_PATH . 'assets/js/hc-realtime-client.js') ? filemtime(HC_PATH . 'assets/js/hc-realtime-client.js') : HCK_VERSION)); ?>"></script>
<?php endif; ?>
<script src="<?php echo esc_url(HCK_ASSETS . 'admin/admin.js?v=' . $js_ver); ?>"></script>

<script>
(function() {
    var sidebar = document.getElementById('hckSidebar');
    var overlay = document.getElementById('hckSidebarOverlay');
    var toggle  = document.getElementById('hckSidebarToggle');
    
    if (!sidebar) return;
    
    function openSidebar() {
        sidebar.classList.add('open');
        if (overlay) overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function closeSidebar() {
        sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('active');
        document.body.style.overflow = '';
    }
    function toggleSidebar() {
        if (sidebar.classList.contains('open')) closeSidebar();
        else openSidebar();
    }
    
    if (toggle) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleSidebar();
        });
        toggle.addEventListener('touchend', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleSidebar();
        });
    }
    
    var closeBtn = document.getElementById('hckSidebarClose');
    if (closeBtn) {
        closeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            closeSidebar();
        });
        closeBtn.addEventListener('touchend', function(e) {
            e.preventDefault();
            e.stopPropagation();
            closeSidebar();
        });
    }
    
    if (overlay) {
        var closeHandler = function(e) {
            e.preventDefault();
            e.stopPropagation();
            closeSidebar();
        };
        overlay.addEventListener('click', closeHandler);
        overlay.addEventListener('touchend', closeHandler);
    }

    // Close on ESC
    document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeSidebar(); });
    
    // Close when clicking a sidebar link
    sidebar.querySelectorAll('a').forEach(function(a) {
        a.addEventListener('click', function() {
            if (window.innerWidth <= 900) closeSidebar();
        });
    });
})();
</script>



</body>
</html>
