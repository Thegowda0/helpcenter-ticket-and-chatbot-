<?php
if (!defined('ABSPATH')) exit;

$s = hck_get_all_settings();
$hck_settings_section = sanitize_key(get_query_var('hck_settings_section') ?: 'general');
$hck_settings_sections = array('general'=>'General & Branding','categories'=>'Ticket Categories','identity'=>'Ticket Identity','email'=>'Email & Notifications','automation'=>'Automation & Lifecycle','attachments'=>'Attachments','cloudflare'=>'Cloudflare Infrastructure');
if (!isset($hck_settings_sections[$hck_settings_section])) $hck_settings_section = 'general';
$categories_value = hck_get_setting('hck_ticket_categories', 'General, Order, Technical, Billing');
if (stripos($categories_value, 'helpcenter') === false) $categories_value = trim($categories_value, ' ,') . ', HelpCenter';
?>

<div class="hck-settings-workspace-nav"><a href="<?php echo esc_url(hck_admin_url('section/settings/')); ?>">All settings</a><?php foreach ($hck_settings_sections as $key=>$label): ?><a class="<?php echo $hck_settings_section === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url(hck_admin_url('settings/' . $key . '/')); ?>"><?php echo esc_html($label); ?></a><?php endforeach; ?></div><div class="hck-settings-workspace-intro"><h2><?php echo esc_html($hck_settings_sections[$hck_settings_section]); ?></h2><p>Changes are saved only for this configuration area. Other ticket settings remain untouched.</p></div>
<?php if (!in_array($hck_settings_section, array('email','cloudflare'), true)): ?>
<div class="hck-admin-card">
    <div class="hck-admin-card-head"><h2><i class="fas fa-cog"></i> Settings</h2></div>
    <div class="hck-admin-card-body">
        <form id="hckSettingsForm">
            
<?php if ($hck_settings_section === 'categories'): ?>
	<div class="hck-admin-field-group" id="hck-setting-categories">
    <h3><i class="fas fa-tags"></i> Ticket Categories</h3>
    <p class="hck-muted" style="margin-bottom: 12px;">Enter a comma-separated list of categories customers can choose from.</p>
    
    <div class="hck-admin-field">
        <label>Categories List</label>
        <input type="text" 
               name="hck_ticket_categories" 
               class="hck-admin-input-full" 
               value="<?php echo esc_attr($categories_value); ?>" 
               placeholder="General, Order, Technical, Billing">
    </div>
</div>
<?php endif; ?>
<?php if ($hck_settings_section === 'identity'): ?>
<div class="hck-admin-field-group" id="hck-setting-identity">
    <h3><i class="fas fa-hashtag"></i> Ticket Numbering</h3>
    <p class="hck-muted" style="margin-bottom:12px">Ticket Center and HelpCenter use separate sequences. Changing these values updates the displayed numbers on existing tickets too.</p>
    <div class="hck-admin-field-row">
        <div class="hck-admin-field"><label>Global Prefix</label><input type="text" name="hck_ticket_prefix" maxlength="16" value="<?php echo esc_attr(hck_get_setting('hck_ticket_prefix','HCK')); ?>" class="hck-admin-input-full" placeholder="HCK"></div>
        <div class="hck-admin-field"><label>Ticket Center Suffix</label><input type="text" name="hck_ticket_suffix_tc" maxlength="12" value="<?php echo esc_attr(hck_get_setting('hck_ticket_suffix_tc','TC')); ?>" class="hck-admin-input-full" placeholder="TC"></div>
        <div class="hck-admin-field"><label>HelpCenter Suffix</label><input type="text" name="hck_ticket_suffix_hc" maxlength="12" value="<?php echo esc_attr(hck_get_setting('hck_ticket_suffix_hc','HC')); ?>" class="hck-admin-input-full" placeholder="HC"></div>
    </div>
    <div class="hck-admin-field"><label>HelpCenter Ticket Category</label><select name="hck_helpcenter_category" class="hck-admin-input-full">
        <?php foreach (hck_get_ticket_categories() as $slug=>$label): ?><option value="<?php echo esc_attr($slug); ?>" <?php selected(hck_get_setting('hck_helpcenter_category','helpcenter'),$slug); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?>
    </select><small class="hck-muted">Add a category named HelpCenter in the category list if it is not already available.</small></div>
    <div style="padding:12px;border-radius:9px;background:#F8FAFC;color:#475569;font-size:12px">Preview: <strong><?php echo esc_html(hck_format_ticket_number((int)wp_date('Y'),123,'tc')); ?></strong> &nbsp; <strong><?php echo esc_html(hck_format_ticket_number((int)wp_date('Y'),45,'hc')); ?></strong></div>
</div>

<?php endif; ?>
<?php if ($hck_settings_section === 'general'): ?>
            <div class="hck-admin-field-group" id="hck-setting-general">
                <h3>General</h3>
                <div class="hck-admin-field">
                    <label>Site Title</label>
                    <input type="text" name="hck_site_title" value="<?php echo esc_attr($s['hck_site_title'] ?? 'Support Center'); ?>" class="hck-admin-input-full">
                </div>
                <div class="hck-admin-field">
                    <label>Primary Color</label>
                    <input type="color" name="hck_primary_color" value="<?php echo esc_attr($s['hck_primary_color'] ?? '#6366F1'); ?>">
                </div>
            </div>
            
<?php endif; ?>
<?php if ($hck_settings_section === 'automation'): ?>
            <div class="hck-admin-field-group" id="hck-setting-automation">
                <h3>Automation</h3>
                <div class="hck-admin-field hck-admin-field-inline">
                    <label class="hck-admin-switch">
                        <input type="checkbox" name="hck_auto_close_enabled" value="1" <?php checked(($s['hck_auto_close_enabled'] ?? '1'), '1'); ?>>
                        <span></span>
                    </label>
                    <label>Auto-close inactive tickets</label>
                </div>
                <div class="hck-admin-field-row">
                    <div class="hck-admin-field">
                        <label>Auto-close after (days)</label>
                        <input type="number" name="hck_auto_close_days" value="<?php echo esc_attr($s['hck_auto_close_days'] ?? '7'); ?>" min="1" max="90" class="hck-admin-input-full">
                    </div>
                    <div class="hck-admin-field">
                        <label>Send reminder after (days)</label>
                        <input type="number" name="hck_reminder_days" value="<?php echo esc_attr($s['hck_reminder_days'] ?? '3'); ?>" min="1" max="30" class="hck-admin-input-full">
                    </div>
                </div>
                <div class="hck-admin-field" style="margin-top:12px;max-width:360px">
                    <label>Customer reopen request window (days)</label>
                    <input type="number" name="hck_reopen_window_days" value="<?php echo esc_attr((string)get_option('hck_reopen_window_days',14)); ?>" min="1" max="90" class="hck-admin-input-full">
                    <small class="hck-muted">Customers can request reopening of resolved or closed tickets within this period. Reopening requires agent or supervisor approval.</small>
                </div>
            </div>
            
<?php endif; ?>
<?php if ($hck_settings_section === 'attachments'): ?>
            <div class="hck-admin-field-group" id="hck-setting-attachments">
                <h3>Attachments</h3>
                <div class="hck-admin-field-row">
                    <div class="hck-admin-field">
                        <label>Max file size (MB)</label>
                        <input type="number" name="hck_max_attachment_size" value="<?php echo esc_attr($s['hck_max_attachment_size'] ?? '10'); ?>" min="1" max="100" class="hck-admin-input-full">
                    </div>
                    <div class="hck-admin-field">
                        <label>Allowed types</label>
                        <input type="text" name="hck_allowed_file_types" value="<?php echo esc_attr($s['hck_allowed_file_types'] ?? 'jpg,jpeg,png,webp,pdf,zip,doc,docx'); ?>" class="hck-admin-input-full">
                    </div>
                </div>
            </div>
            
<?php endif; ?>
            <div class="hck-admin-form-actions">
                <button type="submit" class="hck-admin-btn hck-admin-btn-primary">
                    <i class="fas fa-save"></i> Save Settings
                </button>
            </div>
            
        </form>
    </div>
</div>
<?php endif; ?>

<?php if ($hck_settings_section === 'attachments'): ?>
<div class="hck-admin-card" id="hck-setting-cleanup">
    <div class="hck-admin-card-head"><h2><i class="fas fa-broom"></i> Abandoned attachment cleanup</h2></div>
    <div class="hck-admin-card-body">
        <p class="hck-muted">Images and files uploaded before a customer sends a reply remain temporary. This tool removes only files that are still unattached (ticket ID and message ID are both zero) and at least 24 hours old. Files already linked to tickets are never removed.</p>
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
            <button type="button" class="hck-admin-btn" id="hckScanOrphanUploads"><i class="fas fa-search"></i> Check abandoned uploads</button>
            <button type="button" class="hck-admin-btn hck-admin-btn-primary" id="hckCleanupOrphanUploads" disabled><i class="fas fa-trash"></i> Clean up abandoned uploads</button>
            <span id="hckOrphanUploadStatus" class="hck-muted" aria-live="polite">No cleanup scan performed yet.</span>
        </div>
    </div>
</div>
<script id="hck-orphan-upload-cleanup">
(function(){var scan=document.getElementById('hckScanOrphanUploads'),clean=document.getElementById('hckCleanupOrphanUploads'),status=document.getElementById('hckOrphanUploadStatus');if(!scan||!clean||!status)return;var count=0,busy=false;function call(mode){if(busy)return;busy=true;scan.disabled=true;clean.disabled=true;status.textContent=mode==='cleanup'?'Cleaning abandoned uploads…':'Checking temporary uploads…';var fd=new FormData();fd.append('action','hck_cleanup_orphan_attachments');fd.append('nonce',window.hckData&&window.hckData.nonce?window.hckData.nonce:'');fd.append('mode',mode);fetch(window.hckData&&window.hckData.ajaxUrl?window.hckData.ajaxUrl:'/wp-admin/admin-ajax.php',{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json()}).then(function(r){if(!r||!r.success)throw new Error(r&&r.data&&r.data.message?r.data.message:'Cleanup request failed.');if(mode==='scan'){count=Number(r.data.count||0);status.textContent=r.data.message;clean.disabled=count===0;}else{count=Number(r.data.remaining||0);status.textContent=r.data.message;clean.disabled=count===0;}}).catch(function(e){status.textContent=e.message||'Cleanup request failed.';}).finally(function(){busy=false;scan.disabled=false;});}scan.addEventListener('click',function(){call('scan')});clean.addEventListener('click',function(){if(!count||!window.confirm('Permanently delete '+count+' abandoned upload record(s) and their unreferenced files?'))return;call('cleanup')});})();
</script>
<?php endif; ?>

<?php if ($hck_settings_section === 'email'): ?>
<!-- =============================================
     EMAIL NOTIFICATIONS
     ============================================= -->
<div class="hck-admin-card" id="hck-setting-email">
    <div class="hck-admin-card-head"><h2><i class="fas fa-envelope"></i> Email Notifications</h2></div>
    <div class="hck-admin-card-body">
        <form id="hckEmailSettingsForm">
            
            <div class="hck-admin-field-group">
                <h3>Delivery</h3>
                <div class="hck-admin-field hck-admin-field-inline">
                    <label class="hck-admin-switch">
                        <input type="checkbox" name="hck_email_notifications" value="1" <?php checked(($s['hck_email_notifications'] ?? '1'), '1'); ?>>
                        <span></span>
                    </label>
                    <label>Enable email notifications</label>
                </div>
                <div class="hck-admin-field">
                    <label>Support Email (From)</label>
                    <input type="email" name="hck_support_email" value="<?php echo esc_attr($s['hck_support_email'] ?? get_option('admin_email')); ?>" class="hck-admin-input-full">
                </div>
            </div>
            
            <div class="hck-admin-field-group">
                <h3>Email Templates</h3>
                <p class="hck-muted" style="margin-bottom:14px;font-size:12px;">
                    Edit each email's subject and HTML body. Available tags:
                    <code>{ticket_number}</code> <code>{ticket_subject}</code> <code>{customer_name}</code>
                    <code>{customer_email}</code> <code>{site_name}</code> <code>{status}</code>
                    <code>{priority}</code> <code>{ticket_url}</code> <code>{admin_url}</code>
                </p>
                
                <?php
                $templates = array(
                    'email_new_ticket_customer' => array('New Ticket — Customer', 'fa-ticket-alt', '#6366F1'),
                    'email_new_ticket_admin'    => array('New Ticket — Admin',    'fa-bell',       '#EF4444'),
                    'email_admin_reply'         => array('Admin Reply — Customer','fa-reply',      '#10B981'),
                    'email_customer_reply'      => array('Customer Reply — Admin','fa-user-edit',  '#8B5CF6'),
                    'email_ticket_resolved'     => array('Ticket Resolved',       'fa-check',      '#10B981'),
                    'email_ticket_closed'       => array('Ticket Closed',         'fa-lock',       '#64748B'),
                    'email_reminder'            => array('Inactivity Reminder',   'fa-clock',      '#F59E0B'),
                );
                foreach ($templates as $key => $meta):
                    $subject = hck_get_email_subject($key);
                    $body    = hck_get_setting($key, '');
                    if (trim($body) === '' && function_exists('hck_get_default_email_templates')) {
                        $defaults = hck_get_default_email_templates();
                        $body = isset($defaults[$key]) ? $defaults[$key] : '';
                    }
                ?>
                <details class="hck-email-template" style="margin-bottom:10px;border:1px solid #E2E8F0;border-radius:10px;overflow:hidden;background:#FFFFFF;">
                    <summary style="cursor:pointer;padding:14px 18px;background:#F8FAFC;list-style:none;display:flex;align-items:center;gap:10px;font-weight:600;font-size:13px;color:#0F172A;">
                        <span style="width:32px;height:32px;border-radius:8px;background:<?php echo $meta[2]; ?>;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:14px;">
                            <i class="fas <?php echo $meta[1]; ?>"></i>
                        </span>
                        <?php echo esc_html($meta[0]); ?>
                        <i class="fas fa-chevron-down" style="margin-left:auto;color:#94A3B8;font-size:12px;"></i>
                    </summary>
                    <div style="padding:18px;">
                        <div class="hck-admin-field">
                            <label>Subject Line</label>
                            <input type="text" name="<?php echo esc_attr($key); ?>_subject" value="<?php echo esc_attr($subject); ?>" class="hck-admin-input-full">
                        </div>
                        <div class="hck-admin-field">
    <label>Email Body (HTML)</label>
    <textarea name="<?php echo esc_attr($key); ?>" class="hck-admin-input-full hck-email-body" rows="12" style="font-family:'SF Mono',Monaco,monospace;font-size:12px;min-height:220px;"><?php echo esc_textarea($body); ?></textarea>
</div>

<div class="hck-email-actions" style="display:flex;gap:8px;flex-wrap:wrap;">
    <button type="button" class="hck-admin-btn hck-admin-btn-primary hck-admin-btn-sm hck-preview-btn" data-template="<?php echo esc_attr($key); ?>">
        <i class="fas fa-eye"></i> Preview
    </button>
    <button type="button" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm hck-reset-btn" data-template="<?php echo esc_attr($key); ?>">
        <i class="fas fa-undo"></i> Reset to Default
    </button>
</div>
                    </div>
                </details>
                <?php endforeach; ?>
            </div>
            
            <div class="hck-admin-form-actions">
                <button type="submit" class="hck-admin-btn hck-admin-btn-primary">
                    <i class="fas fa-save"></i> Save Email Settings
                </button>
            </div>
        </form>
    </div>
</div>

<script>
(function(){
    var form = document.getElementById('hckEmailSettingsForm');
    if (!form) return;
    
    form.addEventListener('submit', function(e){
        e.preventDefault();
        var btn = this.querySelector('button[type="submit"]');
        var orig = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        btn.disabled = true;
        
        var fd = new FormData(form);
        // Ensure unchecked checkbox is sent as 0
        if (!form.querySelector('input[name="hck_email_notifications"]').checked) {
            fd.set('hck_email_notifications', '0');
        }
        fd.append('action', 'hck_save_settings');
        fd.append('nonce', window.hckData.nonce);
        
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.hckData.ajaxUrl, true);
        xhr.onload = function(){
            btn.innerHTML = orig;
            btn.disabled = false;
            try {
                var res = JSON.parse(xhr.responseText);
                if (res.success) {
                    showToast('Email settings saved!', 'success');
                } else {
                    showToast((res.data && res.data.message) || 'Error', 'error');
                }
            } catch(err) { showToast('Server error', 'error'); }
        };
        xhr.onerror = function(){ btn.innerHTML = orig; btn.disabled = false; showToast('Network error', 'error'); };
        xhr.send(fd);
    });
    
    function showToast(msg, type) {
        var t = document.createElement('div');
        t.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);padding:12px 24px;border-radius:10px;font-size:14px;font-weight:600;z-index:9999;color:#fff;box-shadow:0 8px 24px rgba(0,0,0,0.2);background:' + (type === 'success' ? '#10B981' : '#EF4444') + ';';
        t.textContent = msg;
        document.body.appendChild(t);
        setTimeout(function(){ t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(function(){ t.remove(); }, 300); }, 2200);
    }
})();



    // ---------- PREVIEW ----------
    document.querySelectorAll('.hck-preview-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var templateKey = this.getAttribute('data-template');
            var details = this.closest('details');
            if (!details) return;
            var subject = details.querySelector('input[name="' + templateKey + '_subject"]');
            var body    = details.querySelector('textarea[name="' + templateKey + '"]');
            
            var fd = new FormData();
            fd.append('action', 'hck_preview_email');
            fd.append('nonce', window.hckData.nonce);
            fd.append('template', templateKey);
            fd.append('subject', subject ? subject.value : '');
            fd.append('body', body ? body.value : '');
            
            var xhr = new XMLHttpRequest();
            xhr.open('POST', window.hckData.ajaxUrl, true);
            xhr.onload = function() {
                try {
                    var res = JSON.parse(xhr.responseText);
                    if (res.success) {
                        openPreviewModal(templateKey, res.data.subject, res.data.body);
                    } else {
                        showToast('Preview failed', 'error');
                    }
                } catch(e) { showToast('Preview error', 'error'); }
            };
            xhr.send(fd);
        });
    });
    
    // ---------- RESET TO DEFAULT ----------
    document.querySelectorAll('.hck-reset-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            if (!confirm('Clear this template and restore system default?')) return;
            var templateKey = this.getAttribute('data-template');
            var details = this.closest('details');
            if (!details) return;
            var subject = details.querySelector('input[name="' + templateKey + '_subject"]');
            var body    = details.querySelector('textarea[name="' + templateKey + '"]');
            if (subject) subject.value = '';
            if (body) body.value = '';
            showToast('Cleared. Save to apply.', 'success');
        });
    });
    
    // ---------- PREVIEW MODAL ----------
    function openPreviewModal(key, subject, body) {
        var existing = document.getElementById('hckPreviewModal');
        if (existing) existing.remove();
        
        var modal = document.createElement('div');
        modal.id = 'hckPreviewModal';
        modal.innerHTML =
            '<div class="hck-preview-backdrop"></div>' +
            '<div class="hck-preview-container">' +
                '<div class="hck-preview-header">' +
                    '<div>' +
                        '<div class="hck-preview-label">Email Preview</div>' +
                        '<div class="hck-preview-subject">' + escapeHtml(subject) + '</div>' +
                    '</div>' +
                    '<button type="button" class="hck-preview-close" onclick="document.getElementById(\'hckPreviewModal\').remove()">&times;</button>' +
                '</div>' +
                '<div class="hck-preview-body">' +
                    '<iframe id="hckPreviewFrame" style="width:100%;height:100%;border:none;background:#F1F5F9;"></iframe>' +
                '</div>' +
            '</div>';
        document.body.appendChild(modal);
        
        setTimeout(function() {
            var frame = document.getElementById('hckPreviewFrame');
            if (frame) {
                var doc = frame.contentDocument || frame.contentWindow.document;
                doc.open();
                doc.write(body);
                doc.close();
            }
        }, 50);
        
        modal.querySelector('.hck-preview-backdrop').addEventListener('click', function() {
            modal.remove();
        });
        document.addEventListener('keydown', function esc(e) {
            if (e.key === 'Escape') {
                var m = document.getElementById('hckPreviewModal');
                if (m) m.remove();
                document.removeEventListener('keydown', esc);
            }
        });
    }
    
    function escapeHtml(str) {
        var d = document.createElement('div');
        d.textContent = str || '';
        return d.innerHTML;
    }
</script>

<div id="hckAdminToast" class="hck-admin-toast"></div>

<?php endif; ?>

<?php if ($hck_settings_section === 'cloudflare'): ?>
<?php $cf_cfg = get_option("hck_cf_resource_config", array()); if (!is_array($cf_cfg)) $cf_cfg = array(); ?>
<div class="hck-admin-card hck-cloudflare-integration-card" id="hck-setting-cloudflare-setup">
    <div class="hck-admin-card-head"><h2><i class="fas fa-wand-magic-sparkles"></i> Automatic Cloudflare setup</h2></div>
    <div class="hck-admin-card-body">
        <p class="hck-muted">Enter your Cloudflare Account ID and a scoped API token once. The site will verify access, find or create the configured D1 database, R2 bucket and Queue, apply the archive schema, deploy the bundled Worker only when its source/configuration changes, configure both the primary retry consumer and DLQ consumer, set its secret and run health checks. Synthetic admin tests verify both normal archive processing and retry exhaustion to the DLQ. Credentials remain server-side and encrypted.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" autocomplete="off">
            <input type="hidden" name="action" value="hck_cf_save_cloudflare_account">
            <?php wp_nonce_field('hck_cf_save_cloudflare_account'); ?>
            <div class="hck-admin-field-row">
                <div class="hck-admin-field"><label for="hckCfAccountId">Cloudflare Account ID</label><input id="hckCfAccountId" name="account_id" class="hck-admin-input-full" value="<?php echo esc_attr(get_option('hck_cf_account_id', '')); ?>" autocomplete="off" required></div>
                <div class="hck-admin-field"><label for="hckCfCloudflareToken">Cloudflare API Token</label><input id="hckCfCloudflareToken" type="password" name="cloudflare_token" class="hck-admin-input-full" value="" autocomplete="new-password" placeholder="<?php echo hck_cf_cf_token() ? 'Token already saved — paste only to replace it' : 'Paste scoped API token'; ?>"><small class="hck-muted">Required permissions: Account Read; D1 Read/Edit; Workers R2 Storage Read/Write; Queues Read/Write; Workers Scripts Read/Write.</small></div>
            </div>
            <div class="hck-admin-field-row">
                <div class="hck-admin-field"><label>D1 database name</label><input name="database_name" class="hck-admin-input-full" value="<?php echo esc_attr($cf_cfg['database_name'] ?? 'hck-support-data'); ?>"></div>
                <div class="hck-admin-field"><label>R2 bucket name</label><input name="bucket_name" class="hck-admin-input-full" value="<?php echo esc_attr($cf_cfg['bucket_name'] ?? 'hck-support-archive'); ?>"></div>
                <div class="hck-admin-field"><label>Queue name</label><input name="queue_name" class="hck-admin-input-full" value="<?php echo esc_attr($cf_cfg['queue_name'] ?? 'hck-support-archive-queue'); ?>"></div>
                <div class="hck-admin-field"><label>Dead-letter Queue</label><input name="dead_letter_queue_name" class="hck-admin-input-full" value="<?php echo esc_attr($cf_cfg['dead_letter_queue_name'] ?? 'hck-support-archive-dlq'); ?>"></div>
                <div class="hck-admin-field"><label>Worker name</label><input name="worker_name" class="hck-admin-input-full" value="<?php echo esc_attr($cf_cfg['worker_name'] ?? 'hck-support-storage'); ?>"></div>
            </div>
            <?php if (hck_cf_cf_token()): ?><label style="display:block;margin:10px 0"><input type="checkbox" name="clear_cloudflare_token" value="1"> Remove saved Cloudflare API token</label><?php endif; ?>
            <button type="submit" class="hck-admin-btn hck-admin-btn-primary"><i class="fas fa-lock"></i> Save Cloudflare account details</button>
            <?php if (!empty($_GET['hck_cf_notice']) && $_GET['hck_cf_notice'] === 'account_saved'): ?><span class="hck-muted" role="status">Cloudflare account details saved securely.</span><?php endif; ?>
        </form>
        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:16px">
            <button type="button" class="hck-admin-btn hck-admin-btn-primary" id="hckCfAutoProvision" <?php disabled(!hck_cf_cf_token() || !get_option('hck_cf_account_id')); ?>><i class="fas fa-cloud-arrow-up"></i> Verify and configure Cloudflare automatically</button>
            <button type="button" class="hck-admin-btn" id="hckCfDlqTest" <?php disabled(!hck_cf_is_configured()); ?>><i class="fas fa-rotate"></i> Test retries and dead-letter handling</button>
            <button type="button" class="hck-admin-btn" id="hckCfArchiveTest" <?php disabled(!hck_cf_is_configured()); ?>><i class="fas fa-box-archive"></i> Run archive processing verification</button>
            <span id="hckCfDlqResult" class="hck-muted" role="status" aria-live="polite"></span>
            <span id="hckCfArchiveResult" class="hck-muted" role="status" aria-live="polite"></span>
            <span id="hckCfAutoResult" class="hck-muted" role="status" aria-live="polite"></span>
        </div>
        <?php $cf_done = get_option('hck_cf_provision_status', array()); if (!empty($cf_done['completed_at'])): ?><p class="hck-muted">Last successful provisioning: <?php echo esc_html($cf_done['completed_at']); ?> · Worker: <?php echo esc_html($cf_done['worker'] ?? ''); ?> · D1: <?php echo esc_html($cf_done['database'] ?? ''); ?> · R2: <?php echo esc_html($cf_done['bucket'] ?? ''); ?> · Queue: <?php echo esc_html($cf_done['queue'] ?? ''); ?> · DLQ: <?php echo esc_html($cf_done['dead_letter_queue'] ?? ''); ?></p><?php endif; ?>
    </div>
</div>

<div class="hck-admin-card hck-cloudflare-integration-card" id="hck-setting-cloudflare">
    <div class="hck-admin-card-head"><h2><i class="fas fa-cloud"></i> Cloudflare Infrastructure</h2></div>
    <div class="hck-admin-card-body">
        <p class="hck-muted">Connect the support platform to Cloudflare Worker, D1, R2 and Queues. This connection is additive: WordPress remains the live system of record until a separately verified migration is completed. Ably message delivery is not routed through this service.</p>
        <div class="hck-admin-field-group">
            <h3>Connection status</h3>
            <p><?php if (hck_cf_is_configured()): ?><span class="hck-status-badge hck-status-active">Credentials configured</span><?php else: ?><span class="hck-status-badge hck-status-pending">Not configured</span><?php endif; ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="hck-cf-credentials-form" autocomplete="off">
                <input type="hidden" name="action" value="hck_cf_save_credentials">
                <?php wp_nonce_field('hck_cf_save_credentials'); ?>
                <div class="hck-admin-field"><label for="hckCfWorkerUrl">Cloudflare Worker URL</label><input id="hckCfWorkerUrl" type="url" name="worker_url" class="hck-admin-input-full" value="<?php echo esc_attr(hck_cf_get_worker_url()); ?>" placeholder="Automatically configured by the wizard"><small class="hck-muted">Normally populated automatically by the provisioning wizard. This advanced override is stored server-side and is not added to public frontend JavaScript.</small></div>
                <div class="hck-admin-field"><label for="hckCfApiSecret">Worker API secret</label><input id="hckCfApiSecret" type="password" name="api_secret" class="hck-admin-input-full" value="" placeholder="<?php echo hck_cf_get_api_secret() ? 'Secret already saved — paste only to replace it' : 'Paste your Worker API secret here'; ?>" autocomplete="new-password" spellcheck="false"><small class="hck-muted">Normally generated and configured automatically by the wizard. Only use this advanced override if you manage the Worker separately. It is encrypted and never returned to JavaScript.</small></div>
                <?php if (hck_cf_get_api_secret()): ?><label style="display:block;margin:10px 0"><input type="checkbox" name="clear_secret" value="1"> Remove saved API secret</label><?php endif; ?>
                <button type="submit" class="hck-admin-btn hck-admin-btn-primary"><i class="fas fa-save"></i> Save credentials securely</button>
            </form>
            <?php if (!empty($_GET['hck_cf_notice']) && $_GET['hck_cf_notice'] === 'saved'): ?><p class="hck-muted" role="status">Cloudflare credentials saved securely on the server.</p><?php elseif (!empty($_GET['hck_cf_notice']) && $_GET['hck_cf_notice'] === 'invalid_url'): ?><p role="alert">Enter a valid HTTPS Worker URL.</p><?php endif; ?>
            <button type="button" class="hck-admin-btn hck-admin-btn-primary" id="hckCfHealthCheck" <?php disabled(!hck_cf_is_configured()); ?>><i class="fas fa-plug"></i> Test Cloudflare connection</button>
            <span id="hckCfHealthResult" class="hck-muted" role="status" aria-live="polite" style="margin-left:10px"></span>
        </div>
        <div class="hck-admin-field-group">
            <h3>Services</h3>
            <div class="hck-admin-field-row">
                <div class="hck-admin-field"><strong>Workers</strong><p class="hck-muted">Secure API gateway</p></div>
                <div class="hck-admin-field"><strong>D1</strong><p class="hck-muted">Archive metadata and indexes</p></div>
                <div class="hck-admin-field"><strong>R2</strong><p class="hck-muted">Durable archive objects</p></div>
                <div class="hck-admin-field"><strong>Queues</strong><p class="hck-muted">Background archive processing</p></div>
            </div>
        </div>
        <p class="hck-muted"><strong>Important:</strong> the supplied Worker currently provides a verified archive API, not a full replacement for the existing ticket/message tables. Do not disable MySQL or switch live message writes until migration, parity, backup and restore tests have passed.</p>
    </div>
</div>
<?php endif; ?>

<style>.hck-settings-workspace-nav{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 18px}.hck-settings-workspace-nav a{display:inline-flex;padding:9px 13px;border:1px solid #e2e7f0;border-radius:9px;background:#fff;color:#475467;text-decoration:none;font-size:12px;font-weight:650}.hck-settings-workspace-nav a.is-active{background:#29265f;border-color:#29265f;color:#fff}.hck-settings-workspace-intro{margin:0 0 18px}.hck-settings-workspace-intro h2{margin:0 0 5px;font-size:21px}.hck-settings-workspace-intro p{margin:0;color:#778196;font-size:12px}</style>
