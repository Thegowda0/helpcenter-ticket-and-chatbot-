<?php
if (!defined('ABSPATH')) exit;

// This template is included from hck_template_router(), so import WPDB explicitly.
global $wpdb;

$ticket_id = get_query_var('hck_ticket');
$ticket = hck_get_ticket($ticket_id);

if (!$ticket) {
    echo '<div class="hck-admin-empty"><h2>Ticket not found</h2><a href="' . esc_url((!current_user_can('manage_options') && !current_user_can('manage_woocommerce') && !current_user_can('hc_manage_ai_escalations')) ? home_url('/ticket/agent/') : hck_admin_url('tickets/')) . '" class="hck-admin-btn hck-admin-btn-primary">Back to Tickets</a></div>';
    return;
}

// Do not load customer data or private notes until the current user passes
// the ticket visibility policy. Reply/assignment permissions are checked later.
if (!function_exists('hck_user_can_access_ticket') || !hck_user_can_access_ticket($ticket)) {
    status_header(403);
    echo '<div class="hck-admin-empty"><h2>Access denied</h2><p>You do not have permission to view this ticket.</p><a href="' . esc_url(home_url('/ticket/agent/')) . '" class="hck-admin-btn">Back to dashboard</a></div>';
    return;
}

$hck_message_page = function_exists('hck_get_messages_page') ? hck_get_messages_page($ticket_id, true, 0, 50) : array('messages' => hck_get_messages($ticket_id, true), 'has_more' => false, 'next_before_id' => 0);
$messages = $hck_message_page['messages'];
$hck_last_message_id = 0; foreach ((array)$messages as $loaded_message) $hck_last_message_id = max($hck_last_message_id, (int)$loaded_message->id);
$hck_attachments_by_message = function_exists('hck_get_attachments_for_messages') ? hck_get_attachments_for_messages(wp_list_pluck($messages, 'id')) : array();
$hck_ai_summary_record = get_option('hck_ticket_ai_summary_' . (int)$ticket_id, array());
$hck_ai_summary_text = is_array($hck_ai_summary_record) ? (string)($hck_ai_summary_record['summary'] ?? '') : '';
$hck_ai_summary_time = is_array($hck_ai_summary_record) ? (string)($hck_ai_summary_record['generated_at'] ?? '') : '';
$customer = get_userdata((int) hck_get_ticket_user_id($ticket));
$agent_id = hck_get_ticket_agent_id($ticket);
$agent    = $agent_id ? get_userdata($agent_id) : null;
$assignment_history = $wpdb->get_results($wpdb->prepare("SELECT user_id,action,details,created_at FROM {$wpdb->prefix}hck_ticket_logs WHERE ticket_id=%d AND action IN ('agent_transferred','agent_changed') ORDER BY id DESC LIMIT 8", $ticket_id));
$reopen_request = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}hck_ticket_reopen_requests WHERE ticket_id=%d AND status='pending' ORDER BY id DESC LIMIT 1", $ticket_id));
$merge_candidates = array();
if (function_exists('hck_phase2_is_supervisor') && hck_phase2_is_supervisor() && empty($ticket->merged_into)) {
    $merge_customer_id=hck_get_ticket_user_id($ticket);
    $merge_email=strtolower(trim((string)($ticket->customer_email ?? '')));
    if ($merge_customer_id>0 || is_email($merge_email)) {
        $merge_where = $merge_customer_id ? $wpdb->prepare('(user_id=%d OR customer_id=%d)', $merge_customer_id, $merge_customer_id) : $wpdb->prepare('customer_email=%s', $merge_email);
        $merge_candidates = $wpdb->get_results("SELECT id,ticket_number,subject,status FROM {$wpdb->prefix}hck_tickets WHERE {$merge_where} AND id<>".(int)$ticket_id." AND (merged_into IS NULL OR merged_into=0) ORDER BY updated_at DESC LIMIT 100");
    }
}
$can_handle = hck_user_can_handle_ticket($ticket);
$can_assign = $can_handle || current_user_can('manage_options') || current_user_can('manage_woocommerce') || current_user_can('hc_manage_ai_escalations');
$history_email = sanitize_email($ticket->customer_email ?: ($customer ? $customer->user_email : ''));
$history_where = hck_get_ticket_user_id($ticket) ? $wpdb->prepare('(user_id=%d OR customer_id=%d OR customer_email=%s)',hck_get_ticket_user_id($ticket),hck_get_ticket_user_id($ticket),$history_email) : (is_email($history_email) ? $wpdb->prepare('customer_email=%s',$history_email) : '1=0');
$customer_history_tickets = $wpdb->get_results($wpdb->prepare("SELECT id,ticket_number,subject,status,source,category,created_at,agent_id FROM {$wpdb->prefix}hck_tickets WHERE {$history_where} AND id<>%d ORDER BY created_at DESC,id DESC LIMIT 500",$ticket_id));
$customer_history_ticket_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hck_tickets WHERE {$history_where}");
$hc_history_table = $wpdb->prefix.'hc_ai_escalations';
$customer_history_chats = array();
$customer_history_chat_count = 0;
if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hc_history_table))===$hc_history_table) { $hc_where=hck_get_ticket_user_id($ticket)?$wpdb->prepare('(user_id=%d OR visitor_email=%s)',hck_get_ticket_user_id($ticket),$history_email):(is_email($history_email)?$wpdb->prepare('visitor_email=%s',$history_email):'1=0'); $customer_history_chats=$wpdb->get_results("SELECT id,issue,status,created_at,assigned_agent_name FROM {$hc_history_table} WHERE {$hc_where} ORDER BY created_at DESC,id DESC LIMIT 500"); $customer_history_chat_count=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$hc_history_table} WHERE {$hc_where}"); }
$admins   = get_users(array('role__in' => array('administrator','shop_manager','hc_support_agent'), 'orderby' => 'display_name', 'number' => 300));
$hc_agents = get_users(array('capability' => 'hc_manage_ai_escalations', 'orderby' => 'display_name', 'number' => 300));
$reply_agents = get_users(array('capability' => 'hck_reply_tickets', 'orderby' => 'display_name', 'number' => 300));
$admin_map = array(); foreach (array_merge((array)$admins,(array)$hc_agents,(array)$reply_agents) as $staff_user) $admin_map[(int)$staff_user->ID] = $staff_user; $admins = array_values($admin_map);
$order_details = array();
$related = json_decode($ticket->related_orders, true);
if (is_array($related) && function_exists('wc_get_order')) {
    foreach ($related as $oid) {
        $o = wc_get_order($oid);
        if (!$o) continue;
        
        $items = array();
        foreach ($o->get_items() as $item) {
            $product = $item->get_product();
            $items[] = array(
                'name'  => $item->get_name(),
                'qty'   => $item->get_quantity(),
                'total' => $o->get_formatted_line_subtotal($item),
                'thumb' => $product ? wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') : '',
            );
        }
        
        $order_details[] = array(
            'id'      => $o->get_id(),
            'status'  => wc_get_order_status_name($o->get_status()),
            'status_key' => $o->get_status(),
            'total'   => $o->get_formatted_order_total(),
            'date'    => $o->get_date_created() ? $o->get_date_created()->date('M j, Y') : '',
            'items'   => $items,
            'edit_url'=> admin_url('post.php?post=' . $o->get_id() . '&action=edit'),
        );
    }
}
?>

<div class="hck-admin-view-head">
    <a href="<?php echo esc_url((!current_user_can('manage_options') && !current_user_can('manage_woocommerce') && !current_user_can('hc_manage_ai_escalations')) ? home_url('/ticket/agent/') : hck_admin_url('tickets/')); ?>" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm">
        <i class="fas fa-arrow-left"></i> Back
    </a>
    <span class="hck-mono hck-admin-ticket-number-lg"><?php echo esc_html(hck_get_ticket_number($ticket)); ?></span>
    <span class="hck-badge hck-badge-<?php echo esc_attr($ticket->status); ?>"><?php echo esc_html(hck_get_status_label($ticket->status)); ?></span>
</div>

<?php if (!empty($ticket->merged_into)): $merged_target=hck_get_ticket((int)$ticket->merged_into); ?>
<div class="hck-admin-card" style="margin-bottom:16px;border-left:4px solid #64748b"><div class="hck-admin-card-body"><strong>This ticket has been merged.</strong> It is retained as a read-only record. The consolidated conversation is in <?php if($merged_target): ?><a href="<?php echo esc_url(hck_admin_url('view/'.(int)$merged_target->id.'/')); ?>"><?php echo esc_html(hck_get_ticket_number($merged_target)); ?></a><?php else: ?>the destination ticket<?php endif; ?>.</div></div>
<?php endif; ?>
<div class="hck-admin-view-grid">
    
    <!-- MAIN COLUMN -->
    <div class="hck-admin-view-main">
        
        <div class="hck-admin-card">
            <div class="hck-admin-card-head">
                <h2><?php echo esc_html($ticket->subject); ?></h2>
            </div>
            <div class="hck-admin-card-body">
                <div class="hck-admin-info-grid">
                    <div class="hck-admin-info"><small>Category</small><strong><?php $category_labels=hck_get_ticket_categories(); echo esc_html($category_labels[$ticket->category] ?? ucfirst($ticket->category)); ?></strong></div>
                    <div class="hck-admin-info"><small>Priority</small><strong style="color:<?php echo esc_attr(hck_get_priority_color($ticket->priority)); ?>;"><?php echo esc_html(hck_get_priority_label($ticket->priority)); ?></strong></div>
                    <div class="hck-admin-info"><small>Created</small><strong><?php echo esc_html(hck_format_date($ticket->created_at)); ?></strong></div>
                    <div class="hck-admin-info"><small>Updated</small><strong><?php echo esc_html(hck_time_ago($ticket->updated_at)); ?></strong></div>
                    <?php if (function_exists('hck_sla_initialize_ticket')) { hck_sla_initialize_ticket((int)$ticket->id); $ticket=hck_get_ticket((int)$ticket->id); } ?>
                    <div class="hck-admin-info"><small>First response SLA</small><strong><?php echo !empty($ticket->sla_first_responded_at) ? ('Responded '.esc_html(hck_format_date($ticket->sla_first_responded_at))) : (!empty($ticket->sla_first_response_breached) ? '<span style="color:#DC2626">Overdue</span>' : esc_html($ticket->sla_first_response_due_at ? hck_format_date($ticket->sla_first_response_due_at) : 'Not scheduled')); ?></strong></div>
                    <div class="hck-admin-info"><small>Resolution SLA</small><strong><?php echo in_array($ticket->status,array('resolved','closed'),true) ? (!empty($ticket->sla_resolution_breached) ? '<span style="color:#DC2626">Resolved after target</span>' : 'Completed') : (!empty($ticket->sla_resolution_breached) ? '<span style="color:#DC2626">Overdue</span>' : esc_html($ticket->sla_resolution_due_at ? hck_format_date($ticket->sla_resolution_due_at) : 'Not scheduled')); ?></strong></div>
                </div>
                
<?php if (!empty($order_details)): ?>
<div class="hck-admin-orders">
    <h3><i class="fas fa-shopping-cart"></i> Related Orders</h3>
    <?php foreach ($order_details as $order): ?>
    <div class="hck-admin-order-card">
        <div class="hck-admin-order-card-head">
            <a href="<?php echo esc_url($order['edit_url']); ?>" target="_blank" class="hck-admin-order-card-id">
                <i class="fas fa-hashtag"></i> Order #<?php echo (int) $order['id']; ?>
            </a>
            <span class="hck-admin-order-card-status hck-status-<?php echo esc_attr($order['status_key']); ?>">
                <?php echo esc_html($order['status']); ?>
            </span>
        </div>
        <div class="hck-admin-order-card-products">
            <?php foreach ($order['items'] as $item): ?>
            <div class="hck-admin-order-card-product">
                <?php if ($item['thumb']): ?>
                <img src="<?php echo esc_url($item['thumb']); ?>" alt="">
                <?php else: ?>
                <div class="hck-admin-order-card-noimg"><i class="fas fa-image"></i></div>
                <?php endif; ?>
                <div class="hck-admin-order-card-pinfo">
                    <div class="hck-admin-order-card-pname"><?php echo esc_html($item['name']); ?></div>
                    <div class="hck-admin-order-card-pmeta">Qty: <?php echo (int) $item['qty']; ?></div>
                </div>
                <div class="hck-admin-order-card-pprice"><?php echo $item['total']; ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="hck-admin-order-card-foot">
            <span><i class="far fa-calendar"></i> <?php echo esc_html($order['date']); ?></span>
            <span class="hck-admin-order-card-total">Total: <strong><?php echo $order['total']; ?></strong></span>
            <a href="<?php echo esc_url($order['edit_url']); ?>" target="_blank" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-xs">
                <i class="fas fa-external-link-alt"></i> Manage
            </a>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
            </div>
        </div>
        
        <?php if (function_exists('hck_is_agent') && hck_is_agent() && !current_user_can('manage_options') && !current_user_can('manage_woocommerce')): ?>
        <!-- AI TICKET HANDOVER SUMMARY -->
        <div class="hck-admin-card hck-ticket-ai-summary-card" id="hckTicketAiSummaryCard">
            <div class="hck-admin-card-head" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
                <h2><i class="fas fa-wand-magic-sparkles"></i> AI ticket summary</h2>
                <?php if ($can_handle || current_user_can('manage_options') || current_user_can('manage_woocommerce')): ?>
                <button type="button" class="hck-admin-btn hck-admin-btn-primary hck-admin-btn-sm" id="hckGenerateTicketSummary"><i class="fas fa-wand-magic-sparkles"></i> <?php echo $hck_ai_summary_text!==''?'Regenerate summary':'Generate summary'; ?></button>
                <?php endif; ?>
            </div>
            <div class="hck-admin-card-body">
                <div id="hckTicketAiSummaryContent" class="hck-ticket-ai-summary-content" aria-live="polite"><?php echo $hck_ai_summary_text!==''?esc_textarea($hck_ai_summary_text):'Generate an internal summary to understand the customer issue, verified facts, previous actions, outstanding questions and recommended next step.'; ?></div>
                <small class="hck-muted" id="hckTicketAiSummaryTime"><?php echo $hck_ai_summary_time!==''?'Last generated: '.esc_html(hck_format_date($hck_ai_summary_time)):'AI-generated internal notes are visible to support staff only.'; ?></small>
            </div>
        </div>

        <?php endif; ?>

        <!-- CONVERSATION -->
        <div class="hck-admin-card">
            <div class="hck-admin-card-head"><h2><i class="fas fa-comments"></i> Conversation</h2></div>
            <div class="hck-admin-card-body hck-admin-thread" id="hckAdminTicketThread" data-ticket-id="<?php echo (int) $ticket_id; ?>" data-before-id="<?php echo (int) $hck_message_page['next_before_id']; ?>" data-after-id="<?php echo (int) $hck_last_message_id; ?>">
                <?php if (!empty($hck_message_page['has_more'])): ?>
                <div class="hck-thread-older-wrap"><button type="button" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm" id="hckLoadOlderMessages"><i class="fas fa-chevron-up"></i> Load older messages</button><span class="hck-muted" id="hckOlderMessagesStatus">Showing the latest 50 messages</span></div>
                <?php endif; ?>
                <?php foreach ($messages as $msg):
                    $atts = $hck_attachments_by_message[(int) $msg->id] ?? (function_exists('hck_get_attachments') ? hck_get_attachments($msg->id) : array());
                    echo hck_render_admin_message_markup($msg, $atts);
                endforeach; ?>
            </div>
        </div>
        
        <!-- REPLY FORM -->
<?php if ($can_handle && !in_array($ticket->status,array('closed','resolved'),true)): ?>
<div class="hck-admin-card">
    <div class="hck-admin-card-head"><h2><i class="fas fa-reply"></i> Reply to Customer</h2></div>
    <div class="hck-admin-card-body">
        <form id="hckAdminReplyForm" enctype="multipart/form-data">
            <input type="hidden" name="ticket_id" value="<?php echo (int) $ticket_id; ?>">
            <textarea name="message" required rows="5" placeholder="Type your reply..." class="hck-admin-input-full"></textarea>
            
            <!-- File preview chips -->
            <div class="hck-admin-file-list" id="hckAdminReplyFiles"></div>
            
            <!-- Progress bar -->
            <div class="hck-upload-progress" id="hckAdminUploadProgress" style="display:none;">
                <div class="hck-upload-progress-bar"><div class="hck-upload-progress-fill" id="hckAdminUploadFill"></div></div>
                <div class="hck-upload-progress-text" id="hckAdminUploadText">Uploading...</div>
            </div>
            
            <div class="hck-admin-reply-controls">
                <label class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm hck-attach-label">
                    <i class="fas fa-paperclip"></i> Attach Files
                    <input type="file" name="attachments[]" id="hckAdminReplyInput" multiple style="display:none" onchange="hckAdminAddFiles(this)">
                </label>
                <label class="hck-admin-checkbox">
                    <input type="checkbox" name="internal" value="1">
                    <span>Internal note (not sent to customer)</span>
                </label>
            </div>
            
            <button type="submit" class="hck-admin-btn hck-admin-btn-primary" id="hckAdminReplyBtn">
                <i class="fas fa-paper-plane"></i> Send Reply
            </button>
        </form>
    </div>
</div>
<?php else: ?>
        <div class="hck-admin-card">
            <div class="hck-admin-card-body hck-admin-empty">
                <i class="fas fa-lock"></i>
                <p><?php echo in_array($ticket->status,array('closed','resolved'),true) ? 'This ticket is resolved or closed and is available for historical viewing.' : 'This ticket is assigned to another agent. You can view the complete conversation, but only the assigned agent can reply or update it.'; ?></p>
            </div>
        </div>
        <?php endif; ?>
        
    </div>
    
    <!-- SIDEBAR -->
    <div class="hck-admin-view-sidebar">
        
        <div class="hck-admin-card">
            <div class="hck-admin-card-head"><h3>Customer</h3></div>
            <div class="hck-admin-card-body">
                <div class="hck-admin-customer">
                    <img src="<?php echo esc_url(hck_get_avatar((int) hck_get_ticket_user_id($ticket), 48)); ?>" alt="">
                    <div>
                        <strong><?php echo esc_html(!empty($ticket->customer_name) ? $ticket->customer_name : ($customer ? hck_get_user_display($customer->ID) : 'Guest customer')); ?></strong>
                        <span class="hck-muted"><?php echo esc_html(!empty($ticket->customer_email) ? $ticket->customer_email : ($customer ? $customer->user_email : '')); ?></span>
                    </div>
                </div>
                <a href="<?php echo esc_url(hck_admin_url('customer/' . (int)$ticket_id . '/')); ?>" class="hck-admin-btn hck-admin-btn-primary hck-admin-btn-sm" style="margin-top:12px;width:100%;justify-content:center;">
                    <i class="fas fa-id-card"></i> Open Customer 360
                </a>
                <?php if ($customer): ?>
                <a href="<?php echo esc_url(admin_url('user-edit.php?user_id=' . $customer->ID)); ?>" target="_blank" rel="noopener" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm" style="margin-top:8px;width:100%;justify-content:center;">
                    <i class="fas fa-external-link-alt"></i> WordPress User Profile
                </a>
                <?php endif; ?>
                <?php if ($can_handle && !$customer && empty($ticket->user_id) && !empty($ticket->customer_email)): ?>
                <button type="button" id="hckResendGuestAccess" data-ticket-id="<?php echo (int)$ticket_id; ?>" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm" style="margin-top:12px;width:100%;justify-content:center;">
                    <i class="fas fa-paper-plane"></i> Resend secure guest access link
                </button>
                <small class="hck-muted">Customer must open the email link and sign in or register with this same email before replying in the portal.</small>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="hck-admin-card">
            <div class="hck-admin-card-head"><h3>Customer Support History</h3></div>
            <div class="hck-admin-card-body hck-customer-history-body">
                <div class="hck-muted" style="font-size:12px;margin-bottom:10px"><?php echo (int)$customer_history_ticket_count; ?> tickets · <?php echo (int)$customer_history_chat_count; ?> HelpCenter conversations</div>
                <?php if ($customer_history_tickets): ?><div class="hck-history-group" data-hck-history-group="tickets"><?php foreach($customer_history_tickets as $history_ticket): $history_agent=$history_ticket->agent_id?get_userdata((int)$history_ticket->agent_id):false; ?>
                <a data-hck-history-item href="<?php echo esc_url(hck_admin_url('view/'.(int)$history_ticket->id.'/')); ?>" class="hck-customer-history-item"><strong><?php echo esc_html($history_ticket->ticket_number ?: ('#'.$history_ticket->id)); ?></strong><span><?php echo esc_html($history_ticket->subject); ?></span><small><?php echo esc_html(hck_get_status_label($history_ticket->status)); ?> · <?php echo esc_html(strpos((string)$history_ticket->source,'helpcenter')===0?'HelpCenter':'Ticket Center'); ?> · <?php echo esc_html($history_agent?($history_agent->display_name?:$history_agent->user_login):'Unassigned'); ?></small></a>
                <?php endforeach; ?></div><?php else: ?><small class="hck-muted">No previous HCK tickets.</small><?php endif; ?>
                <?php if ($customer_history_chats): ?><h4 style="margin:14px 0 6px">HelpCenter conversations</h4><div class="hck-history-group" data-hck-history-group="conversations"><?php foreach($customer_history_chats as $history_chat): ?><a data-hck-history-item href="<?php echo esc_url(add_query_arg(array('tab'=>'all','ticket'=>(int)$history_chat->id),home_url('/support-agent/'))); ?>" target="_blank" rel="noopener" class="hck-customer-history-item"><strong>Conversation #<?php echo (int)$history_chat->id; ?></strong><span><?php echo esc_html(wp_trim_words(wp_strip_all_tags((string)$history_chat->issue),16,'…')); ?></span><small><?php echo esc_html(hck_get_status_label($history_chat->status)); ?> · <?php echo esc_html($history_chat->assigned_agent_name ?: 'Unassigned'); ?></small></a><?php endforeach; ?></div><?php endif; ?>
            </div>
        </div>

        <div class="hck-admin-card">
            <div class="hck-admin-card-head"><h3>Status</h3></div>
            <div class="hck-admin-card-body">
                <?php if ($can_handle): ?><select id="hckStatusSelect" class="hck-admin-input-full" onchange="hckAdminChangeStatus(this.value)">
                    <?php foreach (array('open','in_progress','awaiting_reply','resolved','closed') as $s): ?>
                    <option value="<?php echo esc_attr($s); ?>" <?php selected($ticket->status, $s); ?>><?php echo esc_html(hck_get_status_label($s)); ?></option>
                    <?php endforeach; ?>
                </select><?php else: ?><p class="hck-muted"><?php echo in_array($ticket->status,array('closed','resolved'),true)?'This ticket is closed/resolved and read-only.':'View-only: this ticket is assigned to another agent.'; ?></p><?php endif; ?>
            </div>
        </div>
        
        <div class="hck-admin-card">
            <div class="hck-admin-card-head"><h3>Priority</h3></div>
            <div class="hck-admin-card-body">
                <?php if ($can_handle): ?><select id="hckPrioritySelect" class="hck-admin-input-full" onchange="hckAdminChangePriority(this.value)">
                    <?php foreach (array('low','normal','high','urgent') as $p): ?>
                    <option value="<?php echo esc_attr($p); ?>" <?php selected($ticket->priority, $p); ?>><?php echo esc_html(ucfirst($p)); ?></option>
                    <?php endforeach; ?>
                </select><?php else: ?><p class="hck-muted">View-only ticket.</p><?php endif; ?>
            </div>
        </div>
        
        <div class="hck-admin-card">
            <div class="hck-admin-card-head"><h3>Assigned Agent</h3></div>
            <div class="hck-admin-card-body">
                <?php if ($can_assign && !in_array((string)$ticket->status,array('resolved','closed'),true)): ?><select id="hckAgentSelect" class="hck-admin-input-full" onchange="hckAdminChangeAgent(this.value)">
                    <option value="">Unassigned</option>
                    <?php foreach ($admins as $a): ?>
                    <option value="<?php echo (int) $a->ID; ?>" <?php selected($agent_id, $a->ID); ?>><?php echo esc_html($a->display_name); ?></option>
                    <?php endforeach; ?>
                </select><?php else: ?><p class="hck-muted">Assignment is read-only for this ticket.</p><?php endif; ?>
            </div>
        </div>
        <?php if ($assignment_history): ?>
        <div class="hck-admin-card">
            <div class="hck-admin-card-head"><h3>Assignment history</h3></div>
            <div class="hck-admin-card-body"><div class="hck-assignment-history">
                <?php foreach ($assignment_history as $event): $event_user=$event->user_id?get_userdata((int)$event->user_id):false; ?>
                <div class="hck-assignment-event"><i class="fas fa-right-left"></i><span><strong><?php echo esc_html($event_user?$event_user->display_name:'System'); ?></strong><small><?php echo esc_html($event->details); ?></small><time><?php echo esc_html(hck_format_date($event->created_at)); ?></time></span></div>
                <?php endforeach; ?>
            </div></div>
        </div>
        <?php endif; ?>

        <?php if ($reopen_request && (hck_phase2_is_supervisor() || hck_get_ticket_agent_id($ticket)===(int)get_current_user_id())): ?>
        <div class="hck-admin-card"><div class="hck-admin-card-head"><h3>Customer reopen request</h3></div><div class="hck-admin-card-body"><p><?php echo esc_html($reopen_request->reason ?: 'No reason provided.'); ?></p><small class="hck-muted">Requested <?php echo esc_html(hck_format_date($reopen_request->created_at)); ?></small><textarea id="hckReopenReviewNote" class="hck-admin-input-full" rows="2" placeholder="Optional note to record"></textarea><div style="display:flex;gap:8px;margin-top:10px"><button type="button" class="hck-admin-btn hck-admin-btn-primary" onclick="hckReviewReopen(<?php echo (int)$reopen_request->id; ?>,'approve')">Approve & reopen</button><button type="button" class="hck-admin-btn hck-admin-btn-outline" onclick="hckReviewReopen(<?php echo (int)$reopen_request->id; ?>,'reject')">Reject</button></div></div></div>
        <?php endif; ?>

        <?php if (hck_phase2_is_supervisor() && empty($ticket->merged_into) && $merge_candidates): ?>
        <div class="hck-admin-card"><div class="hck-admin-card-head"><h3>Merge duplicate ticket</h3></div><div class="hck-admin-card-body"><p class="hck-muted">Copy this ticket's messages, attachments and audit history into another ticket belonging to the same customer. The original remains read-only.</p><label class="hck-admin-label" for="hckMergeTarget">Destination ticket</label><select id="hckMergeTarget" class="hck-admin-input-full"><option value="">Select destination…</option><?php foreach($merge_candidates as $candidate): ?><option value="<?php echo (int)$candidate->id; ?>"><?php echo esc_html(($candidate->ticket_number ?: '#'.$candidate->id).' — '.wp_trim_words($candidate->subject,10,'…').' ('.hck_get_status_label($candidate->status).')'); ?></option><?php endforeach; ?></select><button type="button" class="hck-admin-btn hck-admin-btn-primary" style="margin-top:10px;width:100%" onclick="hckMergeTicket(<?php echo (int)$ticket_id; ?>)"><i class="fas fa-code-merge"></i> Merge into selected ticket</button></div></div>
        <?php endif; ?>
        
    </div>

</div>

<div id="hckAdminToast" class="hck-admin-toast"></div>

<style>
.hck-customer-history-item{display:flex;flex-direction:column;gap:4px;padding:10px;border:1px solid #e8edf4;border-radius:10px;margin:0 0 7px;text-decoration:none;color:inherit;font-size:12px;min-width:0;max-width:100%;background:#fff;white-space:normal}.hck-customer-history-item strong,.hck-customer-history-item span,.hck-customer-history-item small{display:block;min-width:0;max-width:100%;white-space:normal;overflow-wrap:anywhere;word-break:break-word;line-height:1.45}.hck-customer-history-item small{color:#748094}.hck-history-group{min-width:0}.hck-customer-history-body{max-height:min(62vh,620px);overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin}.hck-history-group [data-hck-history-item][hidden]{display:none!important}.hck-history-more{width:100%;padding:9px 10px;margin:3px 0 10px;border:1px solid #dcd9f5;border-radius:9px;background:#f5f4ff;color:#5146bd;font-size:11px;font-weight:700;cursor:pointer}.hck-admin-view-sidebar,.hck-admin-view-sidebar .hck-admin-card,.hck-admin-view-sidebar .hck-admin-card-body{min-width:0}.hck-admin-view-main .hck-admin-card-head h2{min-width:0;max-width:100%;white-space:normal;overflow-wrap:anywhere;word-break:break-word;line-height:1.35}.hck-admin-view-grid{min-width:0}.hck-admin-view-main{min-width:0;overflow-wrap:anywhere}.hck-assignment-history{display:grid;gap:10px}.hck-assignment-event{display:flex;gap:10px;align-items:flex-start;font-size:12px}.hck-assignment-event>i{color:#6366f1;margin-top:3px}.hck-assignment-event span,.hck-assignment-event small,.hck-assignment-event time{display:block;min-width:0;overflow-wrap:anywhere}.hck-assignment-event small{color:#64748b;line-height:1.4;margin:3px 0}.hck-assignment-event time{font-size:10px;color:#94a3b8}
</style>
<script>(function(){
 function initHistory(){document.querySelectorAll('[data-hck-history-group]').forEach(function(group){var cards=Array.prototype.slice.call(group.querySelectorAll('[data-hck-history-item]'));cards.forEach(function(card,i){card.hidden=i>=10;});if(cards.length<=10)return;var btn=document.createElement('button');btn.type='button';btn.className='hck-history-more';btn.textContent='Load 10 more ('+Math.min(10,cards.length-10)+' available)';btn.dataset.shown='10';btn.addEventListener('click',function(){var shown=parseInt(btn.dataset.shown||'10',10),next=shown+10;cards.forEach(function(card,i){if(i<next)card.hidden=false;});btn.dataset.shown=String(next);var left=Math.max(0,cards.length-next);if(!left)btn.remove();else btn.textContent='Load 10 more ('+Math.min(10,left)+' available)';});group.appendChild(btn);});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initHistory,{once:true});else initHistory();
})();</script>
<style id="hck-ticket-ai-summary-style">
.hck-ticket-ai-summary-content.hck-summary-working{position:relative;min-height:118px;padding:24px 14px!important;border:1px solid #dce5f2;border-radius:9px;background:linear-gradient(100deg,#f3f6fb 20%,#fff 38%,#f3f6fb 58%);background-size:220% 100%;animation:hck-summary-shimmer 1.35s ease-in-out infinite;color:#64748b;text-align:center}.hck-ticket-ai-summary-content.hck-summary-working:before{content:'';display:block;width:27px;height:27px;margin:0 auto 12px;border:3px solid #dbe3f5;border-top-color:#5968bd;border-radius:50%;animation:hck-summary-spin .75s linear infinite}.hck-ticket-ai-summary-content.hck-summary-working:after{content:'Reviewing the customer issue, agent actions and final outcome…';display:block;font-size:12px;font-weight:650;color:#65739a}@keyframes hck-summary-spin{to{transform:rotate(360deg)}}@keyframes hck-summary-shimmer{to{background-position:-220% 0}}
.hck-ticket-ai-summary-content{font-size:13px;line-height:1.7;color:#334155;overflow-wrap:anywhere;white-space:normal}.hck-ticket-ai-summary-content h1,.hck-ticket-ai-summary-content h2,.hck-ticket-ai-summary-content h3{font-size:14px;margin:12px 0 6px;color:#1e293b}.hck-ticket-ai-summary-content p{margin:6px 0}.hck-ticket-ai-summary-content ul,.hck-ticket-ai-summary-content ol{padding-left:22px;margin:6px 0}.hck-ticket-ai-summary-content li{margin:3px 0}.hck-ticket-ai-summary-content code{padding:2px 5px;border-radius:5px;background:#eef2f7}.hck-ticket-ai-summary-content pre{padding:10px;border-radius:8px;background:#f1f5f9;overflow:auto}.hck-ticket-ai-summary-content blockquote{margin:8px 0;padding:7px 12px;border-left:3px solid #8b83dc;background:#f7f6ff}.hck-ticket-ai-summary-content table{width:100%;border-collapse:collapse}.hck-ticket-ai-summary-content th,.hck-ticket-ai-summary-content td{border:1px solid #e2e8f0;padding:6px;text-align:left}
</style>
<script id="hck-ticket-ai-summary-script">
(function(){var btn=document.getElementById('hckGenerateTicketSummary'),box=document.getElementById('hckTicketAiSummaryContent'),time=document.getElementById('hckTicketAiSummaryTime');if(!btn||!box)return;var ticketId=<?php echo (int)$ticket_id; ?>;function esc(s){return String(s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}function md(s){var x=esc(s);x=x.replace(/```([\s\S]*?)```/g,'<pre><code>$1</code></pre>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/^###\s+(.+)$/gm,'<h3>$1</h3>').replace(/^##\s+(.+)$/gm,'<h2>$1</h2>').replace(/^#\s+(.+)$/gm,'<h1>$1</h1>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/\*([^*]+)\*/g,'<em>$1</em>').replace(/^[-*+]\s+(.+)$/gm,'<li>$1</li>').replace(/(?:<li>.*<\/li>\n?)+/g,function(m){return '<ul>'+m+'</ul>';}).replace(/\n/g,'<br>');return x;}if(box.textContent.trim()&&box.textContent.indexOf('Generate an internal summary')!==0)box.innerHTML=md(box.textContent);if(!btn)return;btn.addEventListener('click',function(){btn.disabled=true;btn.innerHTML='<i class="fas fa-circle-notch fa-spin"></i> Generating…';btn.setAttribute('aria-busy','true');box.classList.add('hck-summary-working');box.textContent='';var fd=new FormData();fd.append('action','hck_generate_ticket_ai_summary');fd.append('nonce',window.hckData&&window.hckData.nonce?window.hckData.nonce:'');fd.append('ticket_id',ticketId);fetch(window.hckData.ajaxUrl,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(function(r){if(!r||!r.success)throw new Error(r&&r.data&&r.data.message?r.data.message:'AI summary could not be generated.');box.classList.remove('hck-summary-working');box.innerHTML=md(r.data.summary||'No summary returned.');time.textContent='Last generated: '+(r.data.generated_at||'just now')+' · Internal staff summary';btn.innerHTML='<i class="fas fa-rotate"></i> Regenerate summary';}).catch(function(e){box.classList.remove('hck-summary-working');box.textContent=e.message||'AI summary could not be generated.';btn.innerHTML='<i class="fas fa-rotate"></i> Try again';}).finally(function(){btn.disabled=false;btn.removeAttribute('aria-busy');});});})();
</script>
<script>(function(){
 function bottom(el){if(!el)return;el.scrollTop=el.scrollHeight;var last=el.lastElementChild;if(last&&last.scrollIntoView)last.scrollIntoView({block:'end',behavior:'auto'});el.scrollTop=el.scrollHeight;}
 function run(){document.querySelectorAll('.hck-admin-thread').forEach(function(el){bottom(el);requestAnimationFrame(function(){bottom(el);requestAnimationFrame(function(){bottom(el);});});setTimeout(function(){bottom(el);},180);setTimeout(function(){bottom(el);},500);el.querySelectorAll('img').forEach(function(img){if(!img.complete)img.addEventListener('load',function(){bottom(el);},{once:true});});if(window.ResizeObserver&&!el._hckBottomObserver){el._hckBottomObserver=new ResizeObserver(function(){var nearBottom=el.scrollHeight-el.scrollTop-el.clientHeight<120;if(nearBottom)bottom(el);});el._hckBottomObserver.observe(el);}});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();window.addEventListener('load',function(){setTimeout(run,80);},{once:true});
})();</script>
<script id="hck-scroll-boundary-guard-v104">
(function(){
  if(window.__hckScrollBoundaryGuardV104)return;
  window.__hckScrollBoundaryGuardV104=true;
  var selector=[
    '.hck-admin-thread','.hck-customer-history-body','.hc-history-list','.hc-history-items',
    '#messages','.chatbody','.hc-support-transcript','.hc-support-ticket-list',
    '.hc-support-visitor-pane','.hc-support-context-body','.hc-support-history',
    '.hc-support-history-list','.hc-support-customer-history','.hc-ai-conversation-detail',
    '.hc-ai-conversation-messages','.hc-chat-messages','.hc-chat-body',
    '.hc-widget-messages','.hc-bot-messages','#hc-chat-messages','#hcMessages'
  ].join(',');
  function scrollBox(target){
    var node=target&&target.nodeType===1?target:target&&target.parentElement;
    while(node&&node!==document.body&&node!==document.documentElement){
      if(node.matches&&node.matches(selector)){
        var cs=window.getComputedStyle(node);
        var oy=cs.overflowY;
        if((oy==='auto'||oy==='scroll'||node.scrollHeight>node.clientHeight+1)&&node.scrollHeight>node.clientHeight+1)return node;
      }
      node=node.parentElement;
    }
    return null;
  }
  function atTop(el){return el.scrollTop<=1;}
  function atBottom(el){return el.scrollTop+el.clientHeight>=el.scrollHeight-2;}
  document.addEventListener('wheel',function(e){
    if(!e||!e.cancelable||!e.deltaY)return;
    var el=scrollBox(e.target);if(!el)return;
    if((e.deltaY<0&&atTop(el))||(e.deltaY>0&&atBottom(el)))e.preventDefault();
  },{capture:true,passive:false});
  var lastTouchY=null;
  document.addEventListener('touchstart',function(e){
    if(e.touches&&e.touches.length)lastTouchY=e.touches[0].clientY;
  },{capture:true,passive:true});
  document.addEventListener('touchmove',function(e){
    if(!e||!e.cancelable||!e.touches||!e.touches.length||lastTouchY===null)return;
    var y=e.touches[0].clientY,dy=y-lastTouchY;lastTouchY=y;
    if(Math.abs(dy)<0.5)return;
    var el=scrollBox(e.target);if(!el)return;
    /* Finger moving down requests scroll-up; finger moving up requests scroll-down. */
    if((dy>0&&atTop(el))||(dy<0&&atBottom(el)))e.preventDefault();
  },{capture:true,passive:false});
  document.addEventListener('touchend',function(){lastTouchY=null;},{capture:true,passive:true});
  document.addEventListener('touchcancel',function(){lastTouchY=null;},{capture:true,passive:true});
  function apply(){document.querySelectorAll(selector).forEach(function(el){
    if(el.scrollHeight>el.clientHeight+1){
      el.style.overscrollBehaviorY='none';
      el.style.overscrollBehaviorX='none';
      el.style.webkitOverflowScrolling='touch';
    }
  });}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply,{once:true});else apply();
  window.addEventListener('load',apply,{once:true});
})();
</script>

<script>
function hckPhase2Post(action,data){var fd=new FormData();fd.append('action',action);fd.append('nonce',window.hckData.nonce);Object.keys(data).forEach(function(k){fd.append(k,data[k]);});return fetch(window.hckData.ajaxUrl,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();});}
function hckReviewReopen(id,decision){var note=document.getElementById('hckReopenReviewNote');hckPhase2Post('hck_phase2_review_reopen',{request_id:id,decision:decision,note:note?note.value:''}).then(function(r){if(!r.success)throw new Error((r.data&&r.data.message)||'Could not review request');alert(r.data.message);location.reload();}).catch(function(e){alert(e.message);});}
function hckMergeTicket(source){var select=document.getElementById('hckMergeTarget');if(!select||!select.value){alert('Please select the destination ticket.');return;}if(!confirm('Merge this ticket into the selected destination? Messages, attachments and history will be copied. The original ticket will become read-only.'))return;hckPhase2Post('hck_phase2_merge_ticket',{source_ticket_id:source,target_ticket_id:select.value}).then(function(r){if(!r.success)throw new Error((r.data&&r.data.message)||'Merge failed');window.location.href=r.data.redirect;}).catch(function(e){alert(e.message);});}
</script>
