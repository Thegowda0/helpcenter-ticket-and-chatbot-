<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$t = $wpdb->prefix . 'hck_tickets';

$status   = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$priority = isset($_GET['priority']) ? sanitize_text_field($_GET['priority']) : '';
$agent    = isset($_GET['agent']) ? intval($_GET['agent']) : -1;
$search   = isset($_GET['q']) ? sanitize_text_field($_GET['q']) : '';
$paged    = isset($_GET['pg']) ? max(1, intval($_GET['pg'])) : 1;
$per_page = 25;
$offset   = ($paged - 1) * $per_page;

$where = array('1=1');
if ($status)   $where[] = $wpdb->prepare("status = %s", $status);
if ($priority) $where[] = $wpdb->prepare("priority = %s", $priority);
if ($agent >= 0) {
    if ($agent === 0) $where[] = "agent_id IS NULL";
    else $where[] = $wpdb->prepare("agent_id = %d", $agent);
}
if ($search) {
    $like = '%' . $wpdb->esc_like($search) . '%';
    $where[] = $wpdb->prepare("(ticket_number LIKE %s OR subject LIKE %s OR customer_email LIKE %s OR customer_name LIKE %s)", $like, $like, $like, $like);
}
$where_sql = implode(' AND ', $where);

$total   = (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE $where_sql");
$tickets = $wpdb->get_results("SELECT * FROM $t WHERE $where_sql ORDER BY 
    CASE priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 WHEN 'low' THEN 4 END,
    updated_at DESC 
    LIMIT $offset, $per_page");
$pages = ceil($total / $per_page);

$admins = get_users(array('role__in' => array('administrator','shop_manager'), 'orderby' => 'display_name', 'number' => 300));
$hc_agents = get_users(array('capability' => 'hc_manage_ai_escalations', 'orderby' => 'display_name', 'number' => 300));
$admin_map = array(); foreach (array_merge((array)$admins,(array)$hc_agents) as $staff_user) $admin_map[(int)$staff_user->ID] = $staff_user; $admins = array_values($admin_map);
$stats = hck_get_admin_stats();
?>

<div class="hck-admin-toolbar">
    <form method="get" class="hck-admin-filters">
        <input type="text" name="q" value="<?php echo esc_attr($search); ?>" placeholder="Search tickets..." class="hck-admin-input">
        <select name="status" class="hck-admin-select">
            <option value="">All Status</option>
            <?php foreach (array('open','in_progress','awaiting_reply','resolved','closed') as $s): ?>
            <option value="<?php echo esc_attr($s); ?>" <?php selected($status, $s); ?>><?php echo esc_html(hck_get_status_label($s)); ?></option>
            <?php endforeach; ?>
        </select>
        <select name="priority" class="hck-admin-select">
            <option value="">All Priority</option>
            <?php foreach (array('urgent','high','normal','low') as $p): ?>
            <option value="<?php echo esc_attr($p); ?>" <?php selected($priority, $p); ?>><?php echo esc_html(ucfirst($p)); ?></option>
            <?php endforeach; ?>
        </select>
        <select name="agent" class="hck-admin-select">
            <option value="-1">All Agents</option>
            <option value="0" <?php selected($agent, 0); ?>>Unassigned</option>
            <?php foreach ($admins as $a): ?>
            <option value="<?php echo (int) $a->ID; ?>" <?php selected($agent, $a->ID); ?>><?php echo esc_html($a->display_name); ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="hck-admin-btn hck-admin-btn-primary hck-admin-btn-sm"><i class="fas fa-filter"></i> Filter</button>
        <?php if ($search || $status || $priority || $agent >= 0): ?>
        <a href="<?php echo esc_url(hck_admin_url('tickets/')); ?>" class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm">Clear</a>
        <?php endif; ?>
    </form>
</div>

<div class="hck-admin-tabs">
    <?php
    $tabs = array(
        ''               => array('All', $stats['total']),
        'open'           => array('Open', $stats['open']),
        'awaiting_reply' => array('Awaiting', 0),
        'resolved'       => array('Resolved', $stats['resolved']),
        'closed'         => array('Closed', $stats['closed']),
    );
    foreach ($tabs as $key => $data):
        $url = hck_admin_url('tickets/');
        if ($key) $url = add_query_arg('status', $key, $url);
    ?>
    <a href="<?php echo esc_url($url); ?>" class="hck-admin-tab <?php echo $status === $key ? 'active' : ''; ?>">
        <?php echo esc_html($data[0]); ?>
        <?php if ($data[1]): ?><span class="hck-admin-tab-count"><?php echo $data[1]; ?></span><?php endif; ?>
    </a>
    <?php endforeach; ?>
</div>

<div class="hck-admin-card">
    <div class="hck-admin-card-body hck-admin-card-body-flush">
        <?php if ($tickets): ?>
        <table class="hck-admin-table hck-admin-table-hover">
            <thead>
    <tr>
        <th>Ticket</th>
        <th>Subject</th>
        <th>Customer</th>
        <th>Category</th>
        <th>Status</th>
        <th>Priority</th>
        <th>Agent</th>
        <th>Updated</th>
        <th></th>
    </tr>
</thead>
            <tbody>
                <?php foreach ($tickets as $ticket):
                    $agent_user = hck_get_ticket_agent_id($ticket) ? get_userdata(hck_get_ticket_agent_id($ticket)) : null;
                ?>
                <tr onclick="window.location='<?php echo esc_url(hck_admin_url('view/' . $ticket->id . '/')); ?>'" style="cursor:pointer">
                    <td class="hck-mono"><?php echo esc_html(hck_get_ticket_number($ticket)); ?><br><small class="hck-muted" style="font-size:10px"><?php echo esc_html(strpos((string)($ticket->source??''),'helpcenter')===0?'HelpCenter':'Ticket Center'); ?></small></td> <td title="<?php echo esc_attr($ticket->subject); ?>"><?php echo esc_html(hck_ticket_subject_short($ticket->subject,50)); ?></td> <td>
                        <div class="hck-admin-user">
                            <img src="<?php echo esc_url(hck_get_avatar(hck_get_ticket_user_id($ticket), 28)); ?>" alt="">
                            <span><?php echo esc_html(!empty($ticket->customer_name) ? $ticket->customer_name : hck_get_user_name(hck_get_ticket_user_id($ticket))); ?></span>
                        </div>
                    </td> <td><span class="hck-category-chip"><?php $category_labels=hck_get_ticket_categories(); echo esc_html($category_labels[$ticket->category] ?? ucfirst($ticket->category)); ?></span></td>
<td><span class="hck-badge hck-badge-<?php echo esc_attr($ticket->status); ?>"><?php echo esc_html(hck_get_status_label($ticket->status)); ?></span></td>
                    <td style="color:<?php echo esc_attr(hck_get_priority_color($ticket->priority)); ?>;font-weight:600;"><?php echo esc_html(hck_get_priority_label($ticket->priority)); ?></td>
                    <td>
                        <?php if ($agent_user): ?>
                        <span class="hck-admin-agent"><i class="fas fa-user-tie"></i> <?php echo esc_html($agent_user->display_name); ?></span>
                        <?php else: ?>
                        <span class="hck-muted"><i class="fas fa-user-slash"></i> Unassigned</span>
                        <?php endif; ?>
                    </td>
                    <td class="hck-muted"><?php echo esc_html(hck_time_ago($ticket->updated_at)); ?></td>
                    <td><i class="fas fa-chevron-right hck-muted"></i></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="hck-admin-empty">
            <i class="fas fa-inbox"></i>
            <p>No tickets found</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($pages > 1): ?>
<div class="hck-admin-pagination">
    <?php for ($i = 1; $i <= $pages; $i++):
        $url = add_query_arg(array_filter(array(
            'q' => $search ?: null, 'status' => $status ?: null,
            'priority' => $priority ?: null, 'agent' => $agent >= 0 ? $agent : null,
            'pg' => $i > 1 ? $i : null,
        )), hck_admin_url('tickets/'));
    ?>
    <a href="<?php echo esc_url($url); ?>" class="hck-admin-page <?php echo $i === $paged ? 'active' : ''; ?>"><?php echo $i; ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>
