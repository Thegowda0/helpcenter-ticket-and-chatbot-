<?php
/** HCK Phase 2 — Customer directory. */
if (!defined('ABSPATH')) exit;
if (!hck_is_agent()) { echo '<div class="hck-admin-empty">Access denied.</div>'; return; }
global $wpdb;
$t = $wpdb->prefix.'hck_tickets';
$q = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
$page = max(1, absint($_GET['paged'] ?? 1));
$per_page = 30;
$where = '1=1'; $args = array();
if ($q !== '') {
    $like = '%'.$wpdb->esc_like($q).'%';
    $where = '(customer_name LIKE %s OR customer_email LIKE %s OR subject LIKE %s OR ticket_number LIKE %s)';
    $args = array($like,$like,$like,$like);
}
$key_expr = "CASE WHEN COALESCE(user_id,0)>0 THEN CONCAT('u:',user_id) WHEN COALESCE(customer_id,0)>0 THEN CONCAT('u:',customer_id) WHEN customer_email<>'' THEN CONCAT('g:',LOWER(customer_email)) ELSE CONCAT('g:id:',id) END";
$count_sql = "SELECT COUNT(*) FROM (SELECT {$key_expr} AS customer_key FROM {$t} WHERE {$where} GROUP BY customer_key) c";
$total = (int)($args ? $wpdb->get_var($wpdb->prepare($count_sql,$args)) : $wpdb->get_var($count_sql));
$offset = ($page-1)*$per_page;
$sql = "SELECT {$key_expr} AS customer_key, MAX(NULLIF(customer_name,'')) AS customer_name, MAX(NULLIF(customer_email,'')) AS customer_email, MAX(COALESCE(NULLIF(user_id,0),NULLIF(customer_id,0),0)) AS customer_user_id, COUNT(*) AS ticket_count, SUM(CASE WHEN status NOT IN ('closed','resolved') THEN 1 ELSE 0 END) AS active_count, MAX(updated_at) AS last_activity, MAX(id) AS reference_ticket_id FROM {$t} WHERE {$where} GROUP BY customer_key ORDER BY last_activity DESC LIMIT %d OFFSET %d";
$query_args = $args; $query_args[]=$per_page; $query_args[]=$offset;
$rows = $wpdb->get_results($wpdb->prepare($sql,$query_args));
$pages = max(1,(int)ceil($total/$per_page));
?>
<div class="hck-admin-page-head"><div><h1>Customers</h1><p class="hck-muted">Customer records are grouped by WordPress user ID or, for unclaimed guest tickets, exact email address.</p></div><span class="hck-badge"><?php echo (int)$total; ?> customers</span></div>
<div class="hck-admin-card"><div class="hck-admin-card-body"><form method="get" action="<?php echo esc_url(hck_admin_url('customers/')); ?>" class="hck-customer-search"><input class="hck-admin-input" type="search" name="q" value="<?php echo esc_attr($q); ?>" placeholder="Search customer name, email, ticket number or subject"><button class="hck-admin-btn hck-admin-btn-primary" type="submit"><i class="fas fa-search"></i> Search</button><?php if($q!==''): ?><a class="hck-admin-btn hck-admin-btn-outline" href="<?php echo esc_url(hck_admin_url('customers/')); ?>">Clear</a><?php endif; ?></form></div></div>
<div class="hck-admin-card"><div class="hck-admin-card-body hck-admin-card-body-flush"><div class="hck-customer-table-wrap"><table class="hck-admin-table"><thead><tr><th>Customer</th><th>Email</th><th>Total tickets</th><th>Active tickets</th><th>Last activity</th><th></th></tr></thead><tbody>
<?php if($rows): foreach($rows as $r): $display=$r->customer_name ?: ($r->customer_user_id ? hck_get_user_display((int)$r->customer_user_id) : 'Guest customer'); ?>
<tr><td><div class="hck-admin-user"><img src="<?php echo esc_url(hck_get_avatar((int)$r->customer_user_id,32)); ?>" alt=""><strong><?php echo esc_html($display); ?></strong></div></td><td><?php echo esc_html($r->customer_email ?: '—'); ?></td><td><?php echo (int)$r->ticket_count; ?></td><td><?php echo (int)$r->active_count; ?></td><td><?php echo esc_html(hck_time_ago($r->last_activity)); ?></td><td><a class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-xs" href="<?php echo esc_url(hck_admin_url('customer/'.(int)$r->reference_ticket_id.'/')); ?>">View 360</a></td></tr>
<?php endforeach; else: ?><tr><td colspan="6" class="hck-admin-empty">No customers found.</td></tr><?php endif; ?>
</tbody></table></div></div></div>
<?php if($pages>1): ?><div class="hck-customer-pagination"><span>Page <?php echo (int)$page; ?> of <?php echo (int)$pages; ?></span><?php if($page>1): ?><a class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm" href="<?php echo esc_url(add_query_arg(array('paged'=>$page-1,'q'=>$q),hck_admin_url('customers/'))); ?>">Previous</a><?php endif; ?><?php if($page<$pages): ?><a class="hck-admin-btn hck-admin-btn-outline hck-admin-btn-sm" href="<?php echo esc_url(add_query_arg(array('paged'=>$page+1,'q'=>$q),hck_admin_url('customers/'))); ?>">Next</a><?php endif; ?></div><?php endif; ?>
<style>.hck-admin-page-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 16px}.hck-admin-page-head h1{margin:0 0 5px}.hck-customer-search{display:flex;gap:9px;align-items:center}.hck-customer-search .hck-admin-input{flex:1;min-width:120px}.hck-customer-table-wrap{overflow-x:auto}.hck-customer-table-wrap table{min-width:760px}.hck-customer-pagination{display:flex;align-items:center;justify-content:flex-end;gap:9px;margin-top:14px;color:#7b8495;font-size:12px}@media(max-width:640px){.hck-admin-page-head{align-items:flex-start;flex-direction:column}.hck-customer-search{flex-wrap:wrap}.hck-customer-search .hck-admin-input{flex-basis:100%}}</style>
