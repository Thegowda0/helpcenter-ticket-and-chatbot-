<?php
/**
 * HCK Ticket System - Agent Workspace (v114)
 * A single, useful workspace with distinct queues, filters and SLA visibility.
 */
if (!defined('ABSPATH')) exit;
if (!function_exists('hck_is_agent') || !hck_is_agent()) { echo '<div class="hck-admin-empty">Agent access required.</div>'; return; }
if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
nocache_headers();

global $wpdb;
$table = $wpdb->prefix . 'hck_tickets';
$user_id = get_current_user_id();
$now = current_time('mysql');
$soon = date('Y-m-d H:i:s', current_time('timestamp') + HOUR_IN_SECONDS);
$owner = $wpdb->prepare('(agent_id=%d OR ((agent_id IS NULL OR agent_id=0) AND assigned_to=%d))', $user_id, $user_id);
$not_merged = '(merged_into IS NULL OR merged_into=0)';
$active_sql = "status IN ('open','in_progress','awaiting_reply')";

// Summary counts are calculated from the agent's current assignment, never from all staff tickets.
$active_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$owner} AND {$not_merged} AND {$active_sql}");
$action_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$owner} AND {$not_merged} AND status IN ('open','in_progress')");
$waiting_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$owner} AND {$not_merged} AND status='awaiting_reply'");
$completed_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$owner} AND {$not_merged} AND status IN ('resolved','closed')");
$overdue_sql = "((sla_first_responded_at IS NULL AND sla_first_response_due_at IS NOT NULL AND sla_first_response_due_at < %s) OR (sla_resolution_due_at IS NOT NULL AND sla_resolution_due_at < %s))";
$overdue_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$owner} AND {$not_merged} AND {$active_sql} AND {$overdue_sql}", $now, $now));
$due_soon_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$owner} AND {$not_merged} AND {$active_sql} AND NOT {$overdue_sql} AND ((sla_first_responded_at IS NULL AND sla_first_response_due_at BETWEEN %s AND %s) OR (sla_resolution_due_at BETWEEN %s AND %s))", $now, $now, $now, $soon, $now, $soon));

$view = sanitize_key(wp_unslash($_GET['view'] ?? 'active'));
$allowed_views = array('active','action','waiting','overdue','due-soon','completed','all');
if (!in_array($view, $allowed_views, true)) $view = 'active';
$search = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
$priority = sanitize_key(wp_unslash($_GET['priority'] ?? ''));
if (!in_array($priority, array('','urgent','high','normal','low'), true)) $priority = '';
$source = sanitize_key(wp_unslash($_GET['source'] ?? ''));
if (!in_array($source, array('','helpcenter','ticket-center'), true)) $source = '';
$sort = sanitize_key(wp_unslash($_GET['sort'] ?? 'priority'));
$sorts = array(
    'priority' => "CASE priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 ELSE 4 END ASC, updated_at DESC",
    'sla' => "CASE WHEN sla_first_responded_at IS NULL THEN COALESCE(sla_first_response_due_at,sla_resolution_due_at) ELSE sla_resolution_due_at END ASC, updated_at DESC",
    'recent' => 'updated_at DESC, id DESC',
    'oldest' => 'created_at ASC, id ASC',
);
if (!isset($sorts[$sort])) $sort = 'priority';

$where = $owner . ' AND ' . $not_merged;
if ($view === 'active') $where .= " AND {$active_sql}";
elseif ($view === 'action') $where .= " AND status IN ('open','in_progress')";
elseif ($view === 'waiting') $where .= " AND status='awaiting_reply'";
elseif ($view === 'completed') $where .= " AND status IN ('resolved','closed')";
elseif ($view === 'overdue') $where .= " AND {$active_sql} AND {$overdue_sql}";
elseif ($view === 'due-soon') $where .= " AND {$active_sql} AND NOT {$overdue_sql} AND ((sla_first_responded_at IS NULL AND sla_first_response_due_at BETWEEN %s AND %s) OR (sla_resolution_due_at BETWEEN %s AND %s))";

$args = array();
if ($view === 'overdue') { $args[] = $now; $args[] = $now; }
if ($view === 'due-soon') { $args[] = $now; $args[] = $now; $args[] = $now; $args[] = $soon; $args[] = $now; $args[] = $soon; }
if ($priority !== '') { $where .= ' AND priority=%s'; $args[] = $priority; }
if ($source === 'helpcenter') $where .= " AND source LIKE 'helpcenter%'";
elseif ($source === 'ticket-center') $where .= " AND (source IS NULL OR source NOT LIKE 'helpcenter%')";
if ($search !== '') {
    $like = '%' . $wpdb->esc_like($search) . '%';
    $where .= ' AND (ticket_number LIKE %s OR subject LIKE %s OR customer_name LIKE %s OR customer_email LIKE %s)';
    array_push($args, $like, $like, $like, $like);
}
$per_page = 20;
$paged = max(1, absint($_GET['pg'] ?? 1));
$offset = ($paged - 1) * $per_page;
$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
$total = (int) ($args ? $wpdb->get_var($wpdb->prepare($count_sql, $args)) : $wpdb->get_var($count_sql));
$list_sql = "SELECT * FROM {$table} WHERE {$where} ORDER BY {$sorts[$sort]} LIMIT %d OFFSET %d";
$list_args = $args;
$list_args[] = $per_page;
$list_args[] = $offset;
$rows = $wpdb->get_results($wpdb->prepare($list_sql, $list_args));
$pages = (int) ceil($total / $per_page);
$base_url = home_url('/ticket/agent/');
$build_url = function($new = array()) use ($base_url, $view, $search, $priority, $source, $sort) {
    $params = array('view'=>$view, 'q'=>$search, 'priority'=>$priority, 'source'=>$source, 'sort'=>$sort);
    foreach ($new as $key=>$value) $params[$key] = $value;
    foreach ($params as $key=>$value) if ($value === '' || $value === null || $value === false || ($key==='pg' && (int)$value <= 1)) unset($params[$key]);
    return add_query_arg($params, $base_url);
};
$views = array(
    'active' => array('All active', $active_count),
    'action' => array('Needs action', $action_count),
    'waiting' => array('Waiting for customer', $waiting_count),
    'overdue' => array('Overdue', $overdue_count),
    'due-soon' => array('Due soon', $due_soon_count),
    'completed' => array('Completed', $completed_count),
    'all' => array('All assigned', $active_count + $completed_count),
);
$capacity = (int) get_user_meta($user_id, 'hck_agent_capacity', true);
if ($capacity < 1) $capacity = 15;
$load_pct = min(100, (int) round(($active_count / $capacity) * 100));
$categories = function_exists('hck_get_ticket_categories') ? hck_get_ticket_categories() : array();
?>
<style>
.hck-aw{--aw-ink:#182338;--aw-muted:#738096;--aw-line:#e7ebf2;--aw-soft:#f6f8fb;max-width:1600px;margin:0 auto;color:var(--aw-ink)}
.hck-aw-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;flex-wrap:wrap;margin:2px 0 22px}.hck-aw-head h1{font-size:26px;line-height:1.2;margin:0 0 7px;font-weight:750;letter-spacing:-.5px}.hck-aw-head p{margin:0;color:var(--aw-muted);font-size:13px}.hck-aw-head-actions{display:flex;gap:9px;flex-wrap:wrap}.hck-aw-head-actions .hck-admin-btn{display:inline-flex;align-items:center;gap:8px}
.hck-aw-kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin-bottom:18px}.hck-aw-kpi{display:block;text-decoration:none!important;background:#fff;border:1px solid var(--aw-line);border-radius:13px;padding:15px 16px;min-width:0;transition:border-color .15s,transform .15s}.hck-aw-kpi:hover{border-color:#aeb8ce;transform:translateY(-1px)}.hck-aw-kpi-top{display:flex;justify-content:space-between;align-items:center;gap:8px;color:var(--aw-muted);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.45px}.hck-aw-kpi-icon{width:30px;height:30px;border-radius:9px;display:grid;place-items:center;background:#f0f3fa;color:#586781}.hck-aw-kpi strong{display:block;font-size:27px;line-height:1.2;margin-top:9px;font-weight:760;color:var(--aw-ink)}.hck-aw-kpi small{display:block;margin-top:3px;color:#8b96a9;font-size:11px}.hck-aw-kpi.is-danger .hck-aw-kpi-icon{background:#fff0f0;color:#d33d48}.hck-aw-kpi.is-warning .hck-aw-kpi-icon{background:#fff7e8;color:#b97713}
.hck-aw-load{display:flex;align-items:center;gap:13px;padding:13px 16px;background:#fff;border:1px solid var(--aw-line);border-radius:12px;margin-bottom:18px}.hck-aw-load-copy{min-width:120px}.hck-aw-load-copy strong{display:block;font-size:12px}.hck-aw-load-copy span{font-size:11px;color:var(--aw-muted)}.hck-aw-load-track{height:7px;background:#edf0f5;border-radius:20px;overflow:hidden;flex:1}.hck-aw-load-track i{height:100%;display:block;background:#6475dc;border-radius:20px}.hck-aw-load-value{font-size:12px;font-weight:750;white-space:nowrap;color:#4b5871}
.hck-aw-panel{background:#fff;border:1px solid var(--aw-line);border-radius:14px;overflow:hidden}.hck-aw-panel-head{padding:17px 18px 0}.hck-aw-panel-head h2{font-size:16px;margin:0 0 4px}.hck-aw-panel-head p{font-size:12px;color:var(--aw-muted);margin:0}.hck-aw-tabs{display:flex;gap:5px;padding:15px 18px 0;overflow-x:auto;border-bottom:1px solid var(--aw-line);scrollbar-width:thin}.hck-aw-tabs a{display:flex;align-items:center;gap:7px;white-space:nowrap;padding:11px 10px 12px;color:#66748b;text-decoration:none!important;font-size:12px;font-weight:650;border-bottom:2px solid transparent}.hck-aw-tabs a.active{color:#4f46bd;border-color:#6259d9}.hck-aw-tabs em{font-style:normal;background:#f0f2f7;border-radius:20px;padding:2px 6px;font-size:10px;color:#67738a}.hck-aw-tabs a.active em{background:#efedff;color:#5146bd}
.hck-aw-filters{display:flex;align-items:end;gap:10px;flex-wrap:wrap;padding:15px 18px;border-bottom:1px solid var(--aw-line);background:#fcfdff}.hck-aw-field{display:grid;gap:5px;min-width:130px}.hck-aw-field label{font-size:10px;text-transform:uppercase;letter-spacing:.45px;font-weight:750;color:#78859a}.hck-aw-field input,.hck-aw-field select{height:38px;min-width:0;width:100%;padding:0 10px;border:1px solid #dfe4ec;border-radius:8px;background:#fff;color:#253149;font-size:12px}.hck-aw-field-search{flex:1;min-width:220px}.hck-aw-filter-actions{display:flex;gap:7px}.hck-aw-filter-actions .hck-admin-btn{height:38px;display:inline-flex;align-items:center;gap:7px}.hck-aw-results-meta{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 18px;color:var(--aw-muted);font-size:11px}.hck-aw-table-wrap{overflow-x:auto}.hck-aw-table{width:100%;border-collapse:collapse;min-width:900px}.hck-aw-table th{padding:10px 13px;text-align:left;background:#fafbfe;border-top:1px solid #f0f2f6;border-bottom:1px solid var(--aw-line);font-size:10px;text-transform:uppercase;letter-spacing:.45px;color:#8792a5;white-space:nowrap}.hck-aw-table td{padding:13px;border-bottom:1px solid #f0f2f6;vertical-align:middle;font-size:12px}.hck-aw-table tr:last-child td{border-bottom:0}.hck-aw-table tbody tr:hover{background:#fbfcff}.hck-aw-ticket-id{font-weight:750;color:#5362c9;white-space:nowrap}.hck-aw-ticket-id-link{display:inline-flex;align-items:center;gap:5px;color:#4e5bc5!important;text-decoration:none!important;border-radius:5px;padding:2px 4px;margin:-2px -4px;transition:background .15s,color .15s}.hck-aw-ticket-id-link:hover,.hck-aw-ticket-id-link:focus-visible{background:#eef0ff;color:#343eaa!important;text-decoration:underline!important;outline:none}.hck-aw-ticket-id-link:focus-visible{box-shadow:0 0 0 2px #aeb4ff}.hck-aw-ticket-subject{display:block;font-weight:700;color:#26334a;max-width:340px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.hck-aw-ticket-meta{display:block;color:#8a95a8;font-size:10px;margin-top:4px}.hck-aw-customer{font-weight:650;color:#344158}.hck-aw-customer small{display:block;color:#8a95a8;font-size:10px;margin-top:3px}.hck-aw-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 8px;border-radius:20px;font-size:10px;font-weight:750;white-space:nowrap;background:#f1f4f8;color:#58657a}.hck-aw-badge:before{content:'';width:5px;height:5px;border-radius:50%;background:currentColor}.hck-aw-status-open,.hck-aw-status-in_progress{background:#eef2ff;color:#4f46bd}.hck-aw-status-awaiting_reply{background:#f3eefe;color:#7b42ad}.hck-aw-status-resolved,.hck-aw-status-closed{background:#eaf8f0;color:#26824e}.hck-aw-priority{font-size:11px;font-weight:750}.hck-aw-sla{font-size:10px;font-weight:700;white-space:nowrap}.hck-aw-sla.overdue{color:#cf3542}.hck-aw-sla.soon{color:#b97713}.hck-aw-sla.ok{color:#748198}.hck-aw-open{display:inline-flex;align-items:center;gap:6px;padding:7px 10px;border:1px solid #dfe4ec;border-radius:7px;color:#4655b9!important;font-size:11px;font-weight:750;text-decoration:none!important;white-space:nowrap}.hck-aw-open:hover{background:#f3f4ff;border-color:#c9cafa}.hck-aw-empty{padding:50px 20px;text-align:center}.hck-aw-empty-icon{width:48px;height:48px;border-radius:14px;background:#f2f4f8;color:#8490a5;display:grid;place-items:center;margin:0 auto 12px;font-size:20px}.hck-aw-empty strong{display:block;font-size:14px}.hck-aw-empty p{font-size:12px;color:var(--aw-muted);margin:5px 0 0}.hck-aw-pager{display:flex;align-items:center;justify-content:flex-end;gap:6px;padding:14px 18px;border-top:1px solid #f0f2f6}.hck-aw-pager a,.hck-aw-pager span{min-width:31px;text-align:center;padding:7px 9px;border:1px solid #e1e6ef;border-radius:7px;text-decoration:none!important;color:#5b6780;font-size:11px}.hck-aw-pager .current{background:#5556c9;border-color:#5556c9;color:#fff}.hck-aw-mobile-cards{display:none}
@media(max-width:1100px){.hck-aw-kpis{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:700px){.hck-aw-head h1{font-size:22px}.hck-aw-kpis{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.hck-aw-kpi{padding:12px}.hck-aw-kpi strong{font-size:23px}.hck-aw-load{gap:9px}.hck-aw-load-copy{min-width:95px}.hck-aw-filters{display:grid;grid-template-columns:1fr 1fr;gap:9px}.hck-aw-field-search{grid-column:1/-1;min-width:0}.hck-aw-filter-actions{grid-column:1/-1}.hck-aw-filter-actions .hck-admin-btn{flex:1;justify-content:center}.hck-aw-table-wrap{display:none}.hck-aw-mobile-cards{display:grid;gap:0}.hck-aw-mobile-ticket{display:block;padding:14px 15px;border-bottom:1px solid #edf0f5;text-decoration:none!important}.hck-aw-mobile-ticket:last-child{border-bottom:0}.hck-aw-mobile-top{display:flex;justify-content:space-between;gap:8px;align-items:center}.hck-aw-mobile-subject{font-size:13px;font-weight:750;color:#26334a;margin:8px 0 5px;line-height:1.4}.hck-aw-mobile-customer{font-size:11px;color:#758197}.hck-aw-mobile-bottom{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:10px}.hck-aw-mobile-tags{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.hck-aw-mobile-open{font-size:11px;font-weight:750;color:#5158bd}.hck-aw-results-meta{padding:10px 14px}.hck-aw-tabs{padding-left:12px;padding-right:12px}.hck-aw-panel-head{padding:15px 14px 0}}

/* v114 visual hierarchy: separated overview, queue and focus rail */
.hck-aw{max-width:1680px}
.hck-aw-hero{position:relative;isolation:isolate;display:flex;align-items:center;justify-content:space-between;gap:24px;padding:25px 28px;margin:2px 0 18px;border-radius:18px;overflow:hidden;background:linear-gradient(115deg,#182746 0%,#293c70 54%,#514f9d 100%);color:#fff;box-shadow:0 12px 30px rgba(31,48,91,.13)}
.hck-aw-hero:before,.hck-aw-hero:after{content:"";position:absolute;z-index:-1;border-radius:50%;pointer-events:none}.hck-aw-hero:before{width:280px;height:280px;right:8%;top:-190px;background:rgba(255,255,255,.09)}.hck-aw-hero:after{width:190px;height:190px;right:25%;bottom:-150px;border:1px solid rgba(255,255,255,.15)}
.hck-aw-hero-copy{min-width:0}.hck-aw-eyebrow{display:flex;align-items:center;gap:8px;margin-bottom:9px;color:#cbd5f4;font-size:10px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase}.hck-aw-eyebrow i{color:#a8f0d0}.hck-aw-hero h1{margin:0 0 7px;color:#fff;font-size:27px;line-height:1.2;font-weight:780;letter-spacing:-.6px}.hck-aw-hero p{margin:0;color:#d4dcf2;font-size:13px;line-height:1.55}.hck-aw-hero-actions{display:flex;gap:9px;flex-wrap:wrap;flex-shrink:0}.hck-aw-hero-actions a{display:inline-flex;align-items:center;gap:8px;padding:10px 14px;border-radius:9px;text-decoration:none!important;font-size:12px;font-weight:750;transition:transform .15s,background .15s}.hck-aw-hero-actions a:hover{transform:translateY(-1px)}.hck-aw-hero-primary{background:#fff;color:#26386b!important}.hck-aw-hero-secondary{border:1px solid rgba(255,255,255,.3);color:#fff!important;background:rgba(255,255,255,.08)}
.hck-aw-kpis{grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin-bottom:20px}.hck-aw-kpi{position:relative;border-radius:14px;padding:16px 17px 15px;box-shadow:0 3px 12px rgba(29,43,73,.035)}.hck-aw-kpi:after{content:"";position:absolute;left:17px;right:17px;bottom:0;height:3px;border-radius:3px 3px 0 0;background:#dfe5f1}.hck-aw-kpi:nth-child(1):after{background:#6878df}.hck-aw-kpi:nth-child(2):after{background:#e4a64b}.hck-aw-kpi:nth-child(3):after{background:#9b79d4}.hck-aw-kpi:nth-child(4):after{background:#df6874}.hck-aw-kpi:nth-child(5):after{background:#39a987}.hck-aw-kpi strong{font-size:29px}.hck-aw-kpi-icon{width:34px;height:34px;border-radius:11px}
.hck-aw-main-grid{display:grid;grid-template-columns:minmax(0,1fr) 285px;gap:17px;align-items:start}.hck-aw-main{min-width:0}.hck-aw-rail{display:grid;gap:14px;min-width:0}.hck-aw-side-card{background:#fff;border:1px solid var(--aw-line);border-radius:15px;padding:17px;box-shadow:0 3px 12px rgba(29,43,73,.035)}.hck-aw-side-title{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:13px}.hck-aw-side-title h2{margin:0;font-size:14px;font-weight:780;color:#26334a}.hck-aw-side-title span{font-size:10px;color:#8a95a8}.hck-aw-load-ring{display:flex;align-items:center;gap:13px}.hck-aw-ring{--load:0;width:72px;height:72px;border-radius:50%;display:grid;place-items:center;flex-shrink:0;background:conic-gradient(#6372d8 var(--load),#edf0f6 0);position:relative}.hck-aw-ring:before{content:"";position:absolute;inset:7px;background:#fff;border-radius:50%}.hck-aw-ring strong{position:relative;font-size:16px;color:#26334a}.hck-aw-ring-copy strong{display:block;font-size:12px;color:#29364d}.hck-aw-ring-copy span{display:block;margin-top:4px;font-size:11px;color:#8994a7;line-height:1.4}.hck-aw-side-divider{height:1px;background:#eef1f5;margin:15px 0}.hck-aw-focus-list{display:grid;gap:8px}.hck-aw-focus-link{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 11px;border:1px solid #edf0f5;border-radius:10px;text-decoration:none!important;transition:background .15s,border-color .15s}.hck-aw-focus-link:hover{background:#fafbff;border-color:#dce2f0}.hck-aw-focus-left{display:flex;align-items:center;gap:9px;min-width:0}.hck-aw-focus-icon{width:29px;height:29px;display:grid;place-items:center;border-radius:9px;background:#f1f3fa;color:#69768f;flex-shrink:0}.hck-aw-focus-link.is-red .hck-aw-focus-icon{background:#fff0f1;color:#d14d59}.hck-aw-focus-link.is-amber .hck-aw-focus-icon{background:#fff6e8;color:#bd8127}.hck-aw-focus-link.is-green .hck-aw-focus-icon{background:#eaf8f1;color:#299264}.hck-aw-focus-copy strong{display:block;color:#344158;font-size:11px}.hck-aw-focus-copy small{display:block;margin-top:2px;color:#929caf;font-size:10px}.hck-aw-focus-count{font-size:15px;font-weight:800;color:#344158}.hck-aw-shortcut{display:flex;align-items:center;gap:10px;padding:11px 0;border-top:1px solid #f0f2f6;text-decoration:none!important}.hck-aw-shortcut:first-of-type{border-top:0}.hck-aw-shortcut-icon{width:32px;height:32px;border-radius:10px;background:#f0f2ff;color:#5a62c7;display:grid;place-items:center;flex-shrink:0}.hck-aw-shortcut strong{display:block;font-size:11px;color:#344158}.hck-aw-shortcut small{display:block;font-size:10px;color:#929caf;margin-top:3px}.hck-aw-shortcut>i{margin-left:auto;color:#a3adbd;font-size:10px}.hck-aw-panel{box-shadow:0 4px 16px rgba(29,43,73,.035);border-radius:15px}.hck-aw-panel-head{padding:19px 19px 0}.hck-aw-tabs{padding-top:13px}.hck-aw-tabs a{padding-left:11px;padding-right:11px}.hck-aw-filters{background:#f9faff}.hck-aw-table th{background:#f8f9fc}.hck-aw-empty{padding:64px 20px}
@media(max-width:1200px){.hck-aw-main-grid{grid-template-columns:minmax(0,1fr) 250px}.hck-aw-kpis{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:900px){.hck-aw-main-grid{grid-template-columns:1fr}.hck-aw-rail{grid-template-columns:repeat(2,minmax(0,1fr));align-items:start}.hck-aw-rail .hck-aw-side-card:first-child{grid-row:span 2}}
@media(max-width:700px){.hck-aw-hero{padding:20px 18px;border-radius:14px;display:block}.hck-aw-hero h1{font-size:23px}.hck-aw-hero-actions{margin-top:16px}.hck-aw-hero-actions a{flex:1;justify-content:center}.hck-aw-kpis{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-bottom:13px}.hck-aw-kpi{padding:12px 13px 14px}.hck-aw-kpi:after{left:13px;right:13px}.hck-aw-kpi strong{font-size:24px}.hck-aw-kpi-top{font-size:9px}.hck-aw-kpi-icon{width:29px;height:29px}.hck-aw-rail{grid-template-columns:1fr}.hck-aw-rail .hck-aw-side-card:first-child{grid-row:auto}.hck-aw-panel-head{padding:15px 14px 0}}

</style>
<div class="hck-aw">
    <header class="hck-aw-hero">
        <div class="hck-aw-hero-copy">
            <div class="hck-aw-eyebrow"><i class="fas fa-circle-check"></i> Agent command center</div>
            <h1>Good <?php echo esc_html((int)current_time('H') < 12 ? 'morning' : ((int)current_time('H') < 17 ? 'afternoon' : 'evening')); ?>, <?php echo esc_html(wp_get_current_user()->display_name); ?></h1>
            <p>Your ticket workspace, priorities and response deadlines — organized in one clear view.</p>
        </div>
        <div class="hck-aw-hero-actions">
            <a class="hck-aw-hero-primary" href="<?php echo esc_url($build_url(array('view'=>'action','pg'=>false))); ?>"><i class="fas fa-bolt"></i> Work on tickets</a>
            <a class="hck-aw-hero-secondary" href="<?php echo esc_url(home_url('/support-agent/')); ?>"><i class="fas fa-comments"></i> HelpCenter Desk</a>
        </div>
    </header>
    <div class="hck-aw-kpis">
        <a class="hck-aw-kpi" href="<?php echo esc_url($build_url(array('view'=>'active','pg'=>false))); ?>"><div class="hck-aw-kpi-top">Active tickets <span class="hck-aw-kpi-icon"><i class="fas fa-inbox"></i></span></div><strong><?php echo number_format_i18n($active_count); ?></strong><small>Currently assigned to you</small></a>
        <a class="hck-aw-kpi" href="<?php echo esc_url($build_url(array('view'=>'action','pg'=>false))); ?>"><div class="hck-aw-kpi-top">Needs action <span class="hck-aw-kpi-icon"><i class="fas fa-reply"></i></span></div><strong><?php echo number_format_i18n($action_count); ?></strong><small>Open or in progress</small></a>
        <a class="hck-aw-kpi" href="<?php echo esc_url($build_url(array('view'=>'waiting','pg'=>false))); ?>"><div class="hck-aw-kpi-top">Waiting for customer <span class="hck-aw-kpi-icon"><i class="fas fa-hourglass-half"></i></span></div><strong><?php echo number_format_i18n($waiting_count); ?></strong><small>Awaiting customer reply</small></a>
        <a class="hck-aw-kpi is-danger" href="<?php echo esc_url($build_url(array('view'=>'overdue','pg'=>false))); ?>"><div class="hck-aw-kpi-top">Overdue <span class="hck-aw-kpi-icon"><i class="fas fa-triangle-exclamation"></i></span></div><strong><?php echo number_format_i18n($overdue_count); ?></strong><small>Past an SLA deadline</small></a>
        <a class="hck-aw-kpi is-warning" href="<?php echo esc_url($build_url(array('view'=>'due-soon','pg'=>false))); ?>"><div class="hck-aw-kpi-top">Due in 1 hour <span class="hck-aw-kpi-icon"><i class="fas fa-stopwatch"></i></span></div><strong><?php echo number_format_i18n($due_soon_count); ?></strong><small>Upcoming SLA deadlines</small></a>
    </div>
    <div class="hck-aw-main-grid">
      <div class="hck-aw-main">
    <section class="hck-aw-panel">
        <div class="hck-aw-panel-head"><h2>Ticket queue</h2><p>Choose a queue, narrow the results and open a ticket to continue working.</p></div>
        <nav class="hck-aw-tabs" aria-label="Ticket queues">
            <?php foreach ($views as $key=>$meta): ?><a class="<?php echo $view===$key?'active':''; ?>" href="<?php echo esc_url($build_url(array('view'=>$key,'pg'=>false))); ?>"><?php echo esc_html($meta[0]); ?><em><?php echo number_format_i18n($meta[1]); ?></em></a><?php endforeach; ?>
        </nav>
        <form class="hck-aw-filters" method="get" action="<?php echo esc_url($base_url); ?>">
            <input type="hidden" name="view" value="<?php echo esc_attr($view); ?>">
            <div class="hck-aw-field hck-aw-field-search"><label for="hck-aw-q">Search tickets</label><input id="hck-aw-q" type="search" name="q" value="<?php echo esc_attr($search); ?>" placeholder="Ticket number, subject, customer or email"></div>
            <div class="hck-aw-field"><label for="hck-aw-priority">Priority</label><select id="hck-aw-priority" name="priority"><option value="">All priorities</option><?php foreach(array('urgent'=>'Urgent','high'=>'High','normal'=>'Normal','low'=>'Low') as $k=>$v): ?><option value="<?php echo esc_attr($k); ?>" <?php selected($priority,$k); ?>><?php echo esc_html($v); ?></option><?php endforeach; ?></select></div>
            <div class="hck-aw-field"><label for="hck-aw-source">Ticket source</label><select id="hck-aw-source" name="source"><option value="">All sources</option><option value="helpcenter" <?php selected($source,'helpcenter'); ?>>HelpCenter</option><option value="ticket-center" <?php selected($source,'ticket-center'); ?>>Ticket Center</option></select></div>
            <div class="hck-aw-field"><label for="hck-aw-sort">Sort by</label><select id="hck-aw-sort" name="sort"><option value="priority" <?php selected($sort,'priority'); ?>>Priority</option><option value="sla" <?php selected($sort,'sla'); ?>>SLA deadline</option><option value="recent" <?php selected($sort,'recent'); ?>>Recently updated</option><option value="oldest" <?php selected($sort,'oldest'); ?>>Oldest first</option></select></div>
            <div class="hck-aw-filter-actions"><button type="submit" class="hck-admin-btn hck-admin-btn-primary"><i class="fas fa-filter"></i> Apply</button><a class="hck-admin-btn hck-admin-btn-outline" href="<?php echo esc_url($build_url(array('q'=>'','priority'=>'','source'=>'','sort'=>'priority','pg'=>false))); ?>">Reset</a></div>
        </form>
        <div class="hck-aw-results-meta"><span><strong><?php echo number_format_i18n($total); ?></strong> ticket<?php echo $total===1?'':'s'; ?> found<?php echo $search!==''?' for “'.esc_html($search).'”':''; ?></span><span>Page <?php echo number_format_i18n($paged); ?> of <?php echo number_format_i18n(max(1,$pages)); ?></span></div>
        <?php if ($rows): ?>
        <div class="hck-aw-table-wrap"><table class="hck-aw-table"><thead><tr><th>Ticket</th><th>Subject</th><th>Customer</th><th>Status</th><th>Priority</th><th>SLA</th><th>Last activity</th><th></th></tr></thead><tbody>
        <?php foreach($rows as $ticket):
            $due = (!empty($ticket->sla_first_responded_at) ? $ticket->sla_resolution_due_at : ($ticket->sla_first_response_due_at ?: $ticket->sla_resolution_due_at));
            $sla_class='ok'; $sla_label='No deadline';
            if ($due) { $due_ts=strtotime($due); $now_ts=current_time('timestamp'); if ($due_ts < $now_ts) { $sla_class='overdue'; $sla_label='Overdue'; } elseif ($due_ts <= $now_ts+HOUR_IN_SECONDS) { $sla_class='soon'; $sla_label='Due '.human_time_diff($now_ts,$due_ts); } else { $sla_label='Due '.mysql2date('M j, g:i a',$due); } }
            $source_label = strpos((string)($ticket->source??''),'helpcenter')===0 ? 'HelpCenter' : 'Ticket Center';
            $customer_name = $ticket->customer_name ?: hck_get_user_name(hck_get_ticket_user_id($ticket));
            $open_url = hck_admin_url('view/'.(int)$ticket->id.'/');
        ?>
        <tr><td><a class="hck-aw-ticket-id hck-aw-ticket-id-link" href="<?php echo esc_url($open_url); ?>" aria-label="Open ticket <?php echo esc_attr(hck_get_ticket_number($ticket)); ?>"><?php echo esc_html(hck_get_ticket_number($ticket)); ?> <i class="fas fa-arrow-up-right-from-square" aria-hidden="true" style="font-size:9px;opacity:.65"></i></a><span class="hck-aw-ticket-meta"><?php echo esc_html($source_label); ?></span></td><td><span class="hck-aw-ticket-subject" title="<?php echo esc_attr($ticket->subject); ?>"><?php echo esc_html(hck_ticket_subject_short($ticket->subject,50)); ?></span><span class="hck-aw-ticket-meta"><?php echo esc_html(isset($categories[$ticket->category])?$categories[$ticket->category]:ucfirst(str_replace('-',' ',(string)$ticket->category))); ?></span></td><td><span class="hck-aw-customer"><?php echo esc_html($customer_name); ?></span><small><?php echo esc_html($ticket->customer_email); ?></small></td><td><span class="hck-aw-badge hck-aw-status-<?php echo esc_attr($ticket->status); ?>"><?php echo esc_html(hck_get_status_label($ticket->status)); ?></span></td><td><span class="hck-aw-priority" style="color:<?php echo esc_attr(hck_get_priority_color($ticket->priority)); ?>"><?php echo esc_html(hck_get_priority_label($ticket->priority)); ?></span></td><td><span class="hck-aw-sla <?php echo esc_attr($sla_class); ?>"><?php echo esc_html($sla_label); ?></span></td><td><span class="hck-aw-ticket-meta"><?php echo esc_html(hck_time_ago($ticket->updated_at)); ?></span></td><td><a class="hck-aw-open" href="<?php echo esc_url($open_url); ?>">Open <i class="fas fa-arrow-up-right-from-square"></i></a></td></tr>
        <?php endforeach; ?></tbody></table></div>
        <div class="hck-aw-mobile-cards">
        <?php foreach($rows as $ticket):
            $due = (!empty($ticket->sla_first_responded_at) ? $ticket->sla_resolution_due_at : ($ticket->sla_first_response_due_at ?: $ticket->sla_resolution_due_at));
            $sla_class='ok'; $sla_label='No SLA deadline'; if($due){$due_ts=strtotime($due);$now_ts=current_time('timestamp');if($due_ts<$now_ts){$sla_class='overdue';$sla_label='SLA overdue';}elseif($due_ts<=$now_ts+HOUR_IN_SECONDS){$sla_class='soon';$sla_label='Due '.human_time_diff($now_ts,$due_ts);}}
            $source_label = strpos((string)($ticket->source??''),'helpcenter')===0 ? 'HelpCenter' : 'Ticket Center';
            $customer_name = $ticket->customer_name ?: hck_get_user_name(hck_get_ticket_user_id($ticket));
        ?><a class="hck-aw-mobile-ticket" href="<?php echo esc_url(hck_admin_url('view/'.(int)$ticket->id.'/')); ?>"><div class="hck-aw-mobile-top"><span class="hck-aw-ticket-id hck-aw-ticket-id-link" aria-hidden="true"><?php echo esc_html(hck_get_ticket_number($ticket)); ?> <i class="fas fa-arrow-up-right-from-square" aria-hidden="true" style="font-size:9px;opacity:.65"></i></span><span class="hck-aw-badge hck-aw-status-<?php echo esc_attr($ticket->status); ?>"><?php echo esc_html(hck_get_status_label($ticket->status)); ?></span></div><div class="hck-aw-mobile-subject"><?php echo esc_html(hck_ticket_subject_short($ticket->subject,80)); ?></div><div class="hck-aw-mobile-customer"><?php echo esc_html($customer_name); ?> · <?php echo esc_html($source_label); ?></div><div class="hck-aw-mobile-bottom"><div class="hck-aw-mobile-tags"><span class="hck-aw-priority" style="color:<?php echo esc_attr(hck_get_priority_color($ticket->priority)); ?>"><?php echo esc_html(hck_get_priority_label($ticket->priority)); ?></span><span class="hck-aw-sla <?php echo esc_attr($sla_class); ?>"><?php echo esc_html($sla_label); ?></span></div><span class="hck-aw-mobile-open">Open ticket <i class="fas fa-arrow-right"></i></span></div></a><?php endforeach; ?>
        </div>
        <?php else: ?><div class="hck-aw-empty"><div class="hck-aw-empty-icon"><i class="fas fa-inbox"></i></div><strong><?php echo $search!==''?'No matching tickets':'No tickets in this queue'; ?></strong><p><?php echo $search!==''?'Try a different search term or clear your filters.':'You are all caught up for this queue.'; ?></p></div><?php endif; ?>
        <?php if($pages>1): ?><div class="hck-aw-pager"><?php if($paged>1): ?><a href="<?php echo esc_url($build_url(array('pg'=>$paged-1))); ?>"><i class="fas fa-chevron-left"></i></a><?php endif; ?><?php for($i=max(1,$paged-2);$i<=min($pages,$paged+2);$i++): ?><?php if($i===$paged): ?><span class="current"><?php echo (int)$i; ?></span><?php else: ?><a href="<?php echo esc_url($build_url(array('pg'=>$i))); ?>"><?php echo (int)$i; ?></a><?php endif; ?><?php endfor; ?><?php if($paged<$pages): ?><a href="<?php echo esc_url($build_url(array('pg'=>$paged+1))); ?>"><i class="fas fa-chevron-right"></i></a><?php endif; ?></div><?php endif; ?>
    </section>
      </div>
      <aside class="hck-aw-rail" aria-label="Agent overview">
        <section class="hck-aw-side-card">
          <div class="hck-aw-side-title"><h2>Workload balance</h2><span>Current load</span></div>
          <div class="hck-aw-load-ring">
            <div class="hck-aw-ring" style="--load:<?php echo (int)$load_pct; ?>%"><strong><?php echo (int)$load_pct; ?>%</strong></div>
            <div class="hck-aw-ring-copy"><strong><?php echo number_format_i18n($active_count); ?> active tickets</strong><span>Capacity: <?php echo number_format_i18n($capacity); ?> tickets<br><?php echo esc_html($active_count >= $capacity ? 'You are at or above your configured capacity.' : number_format_i18n(max(0,$capacity-$active_count)).' available capacity remaining.'); ?></span></div>
          </div>
          <div class="hck-aw-side-divider"></div>
          <div class="hck-aw-side-title"><h2>Priority focus</h2><span>Live counts</span></div>
          <div class="hck-aw-focus-list">
            <a class="hck-aw-focus-link is-red" href="<?php echo esc_url($build_url(array('view'=>'overdue','pg'=>false))); ?>"><span class="hck-aw-focus-left"><span class="hck-aw-focus-icon"><i class="fas fa-triangle-exclamation"></i></span><span class="hck-aw-focus-copy"><strong>Past SLA deadline</strong><small>Needs immediate attention</small></span></span><span class="hck-aw-focus-count"><?php echo number_format_i18n($overdue_count); ?></span></a>
            <a class="hck-aw-focus-link is-amber" href="<?php echo esc_url($build_url(array('view'=>'due-soon','pg'=>false))); ?>"><span class="hck-aw-focus-left"><span class="hck-aw-focus-icon"><i class="fas fa-stopwatch"></i></span><span class="hck-aw-focus-copy"><strong>Due within one hour</strong><small>Upcoming SLA deadlines</small></span></span><span class="hck-aw-focus-count"><?php echo number_format_i18n($due_soon_count); ?></span></a>
            <a class="hck-aw-focus-link is-green" href="<?php echo esc_url($build_url(array('view'=>'completed','pg'=>false))); ?>"><span class="hck-aw-focus-left"><span class="hck-aw-focus-icon"><i class="fas fa-check"></i></span><span class="hck-aw-focus-copy"><strong>Completed tickets</strong><small>Resolved or closed</small></span></span><span class="hck-aw-focus-count"><?php echo number_format_i18n($completed_count); ?></span></a>
          </div>
        </section>
        <section class="hck-aw-side-card">
          <div class="hck-aw-side-title"><h2>Quick access</h2><span>Shortcuts</span></div>
          <a class="hck-aw-shortcut" href="<?php echo esc_url($build_url(array('view'=>'action','pg'=>false))); ?>"><span class="hck-aw-shortcut-icon"><i class="fas fa-reply"></i></span><span><strong>Tickets needing action</strong><small>Continue pending conversations</small></span><i class="fas fa-arrow-right"></i></a>
          <a class="hck-aw-shortcut" href="<?php echo esc_url($build_url(array('view'=>'waiting','pg'=>false))); ?>"><span class="hck-aw-shortcut-icon"><i class="fas fa-hourglass-half"></i></span><span><strong>Waiting for customer</strong><small>Review pending customer replies</small></span><i class="fas fa-arrow-right"></i></a>
          <a class="hck-aw-shortcut" href="<?php echo esc_url(home_url('/support-agent/')); ?>"><span class="hck-aw-shortcut-icon"><i class="fas fa-headset"></i></span><span><strong>HelpCenter live support</strong><small>Open your live-chat desk</small></span><i class="fas fa-arrow-right"></i></a>
        </section>
      </aside>
    </div>
</div>
