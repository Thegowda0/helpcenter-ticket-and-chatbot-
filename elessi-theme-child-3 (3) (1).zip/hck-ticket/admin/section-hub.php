<?php
/** HCK admin workspace directory. Existing ticket, customer, team, SLA and CSAT routes are preserved. */
if (!defined('ABSPATH')) exit;
$hub = sanitize_key(get_query_var('hck_hub'));
$base = home_url('/ticket/admin/');
$u = function($path='') use ($base) { return $base . ltrim($path, '/'); };
if (in_array($hub, array('sla','settings'), true) && !current_user_can('manage_options')) { wp_safe_redirect($base); exit; }
$hubs=array(
 'tickets'=>array('title'=>'Ticket Management','eyebrow'=>'SUPPORT OPERATIONS','description'=>'Work the ticket queue, create requests and manage ticket ownership from one workspace.','cards'=>array(
  array('title'=>'Ticket Queue','desc'=>'Search, filter, review, update and respond to customer tickets.','icon'=>'fa-ticket','meta'=>'ALL TICKETS','url'=>$u('tickets/'),'links'=>array(array('label'=>'Open ticket queue','url'=>$u('tickets/')))),
  array('title'=>'Create Ticket','desc'=>'Create a ticket for a customer request received outside the usual ticket flow.','icon'=>'fa-plus-circle','meta'=>'NEW REQUEST','url'=>home_url('/ticket/create/'),'links'=>array(array('label'=>'Create a ticket','url'=>home_url('/ticket/create/')))),
  array('title'=>'Assignments & Routing','desc'=>'Review ticket ownership and move to the queue to reassign work.','icon'=>'fa-diagram-project','meta'=>'WORK DISTRIBUTION','url'=>$u('tickets/'),'links'=>array(array('label'=>'Manage assignments','url'=>$u('tickets/')))),
 ),'actions'=>array(array('label'=>'Open ticket queue','url'=>$u('tickets/')),array('label'=>'Create ticket','url'=>home_url('/ticket/create/')))),
 'customers'=>array('title'=>'Customers','eyebrow'=>'CUSTOMER RELATIONSHIPS','description'=>'Find customer records and understand their ticket history and support context.','cards'=>array(
  array('title'=>'Customer Directory','desc'=>'Search customers, open customer profiles and review their ticket history.','icon'=>'fa-users','meta'=>'CUSTOMER RECORDS','url'=>$u('customers/'),'links'=>array(array('label'=>'Browse customers','url'=>$u('customers/')))),
 ),'actions'=>array(array('label'=>'Browse customers','url'=>$u('customers/')))),
 'agents-team'=>array('title'=>'Agents & Team','eyebrow'=>'PEOPLE AND PERFORMANCE','description'=>'Manage team access, understand workload and review customer feedback.','cards'=>array(
  array('title'=>'Team Management','desc'=>'Add agents and manage team membership, roles and access.','icon'=>'fa-user-group','meta'=>'PEOPLE & ACCESS','url'=>$u('team/'),'links'=>array(array('label'=>'Manage team','url'=>$u('team/')))),
  array('title'=>'Workload & Assignments','desc'=>'Review ticket ownership and distribute work across available agents.','icon'=>'fa-diagram-project','meta'=>'OPERATIONS','url'=>$u('tickets/'),'links'=>array(array('label'=>'Review assignments','url'=>$u('tickets/')))),
  array('title'=>'Customer Satisfaction','desc'=>'Review customer ratings, feedback and tickets that need further help.','icon'=>'fa-star','meta'=>'QUALITY','url'=>$u('csat/'),'links'=>array(array('label'=>'Open CSAT reports','url'=>$u('csat/')))),
 ),'actions'=>array(array('label'=>'Manage team','url'=>$u('team/')),array('label'=>'Review CSAT','url'=>$u('csat/')))),
 'sla'=>array('title'=>'SLA Management','eyebrow'=>'SERVICE LEVELS','description'=>'Configure response and resolution targets and monitor service commitments.','cards'=>array(
  array('title'=>'SLA Policies & Monitoring','desc'=>'Configure service targets and review response and resolution performance.','icon'=>'fa-stopwatch','meta'=>'SERVICE POLICIES','url'=>$u('sla/'),'links'=>array(array('label'=>'Open SLA workspace','url'=>$u('sla/')))),
 ),'actions'=>array(array('label'=>'Configure SLA','url'=>$u('sla/')))),
 'settings'=>array('title'=>'Settings','eyebrow'=>'SYSTEM CONFIGURATION','description'=>'Choose a focused area of ticket configuration. Each area opens a dedicated configuration page and uses its existing secure save handler.','cards'=>array(
  array('title'=>'General & Branding','desc'=>'Support centre title and primary colour.','icon'=>'fa-sliders','meta'=>'SYSTEM IDENTITY','url'=>$u('settings/general/'),'links'=>array(array('label'=>'Configure general settings','url'=>$u('settings/general/')))),
  array('title'=>'Ticket Categories','desc'=>'Manage customer-facing ticket categories and their labels.','icon'=>'fa-tags','meta'=>'TICKET STRUCTURE','url'=>$u('settings/categories/'),'links'=>array(array('label'=>'Manage categories','url'=>$u('settings/categories/')))),
  array('title'=>'Ticket Identity','desc'=>'Configure the global prefix and separate Ticket Center and HelpCenter sequences.','icon'=>'fa-hashtag','meta'=>'NUMBERING','url'=>$u('settings/identity/'),'links'=>array(array('label'=>'Configure numbering','url'=>$u('settings/identity/')))),
  array('title'=>'Email & Notifications','desc'=>'Control notification delivery and edit customer and agent email templates.','icon'=>'fa-envelope','meta'=>'COMMUNICATION','url'=>$u('settings/email/'),'links'=>array(array('label'=>'Manage email settings','url'=>$u('settings/email/')))),
  array('title'=>'Automation & Lifecycle','desc'=>'Set inactivity reminders, automatic closure and customer reopen windows.','icon'=>'fa-gears','meta'=>'TICKET LIFECYCLE','url'=>$u('settings/automation/'),'links'=>array(array('label'=>'Configure automation','url'=>$u('settings/automation/')))),
  array('title'=>'Attachments & Cleanup','desc'=>'Set upload limits and safely inspect abandoned temporary uploads.','icon'=>'fa-paperclip','meta'=>'FILE MANAGEMENT','url'=>$u('settings/attachments/'),'links'=>array(array('label'=>'Configure attachments','url'=>$u('settings/attachments/')),array('label'=>'Review cleanup','url'=>$u('settings/attachments/')))),
  array('title'=>'Cloudflare Infrastructure','desc'=>'Manage the existing Cloudflare connection, provisioning and archive configuration.','icon'=>'fa-cloud','meta'=>'INFRASTRUCTURE','url'=>$u('settings/cloudflare/'),'links'=>array(array('label'=>'Open infrastructure settings','url'=>$u('settings/cloudflare/')))),
 ),'actions'=>array(array('label'=>'Open general settings','url'=>$u('settings/general/')))),
);
if (!isset($hubs[$hub])) { echo '<div class="hck-saas-empty">Workspace not found. <a href="'.esc_url($base).'">Return to dashboard</a>.</div>'; return; }
$data=$hubs[$hub];
?>
<div class="hck-saas-hub">
 <div class="hck-saas-breadcrumb"><a href="<?php echo esc_url($base); ?>">Dashboard</a><span>/</span><span><?php echo esc_html($data['title']); ?></span></div>
 <header class="hck-saas-hero"><div><div class="hck-saas-eyebrow"><?php echo esc_html($data['eyebrow']); ?></div><h2><?php echo esc_html($data['title']); ?></h2><p><?php echo esc_html($data['description']); ?></p></div><a class="hck-saas-back" href="<?php echo esc_url($base); ?>"><i class="fas fa-arrow-left"></i> Dashboard</a></header>
 <?php if(!empty($data['actions'])): ?><nav class="hck-saas-actions" aria-label="Quick actions"><span>QUICK ACTIONS</span><?php foreach($data['actions'] as $action): ?><a href="<?php echo esc_url($action['url']); ?>"><?php echo esc_html($action['label']); ?><b aria-hidden="true">↗</b></a><?php endforeach; ?></nav><?php endif; ?>
 <div class="hck-saas-grid"><?php foreach($data['cards'] as $card): ?><article class="hck-saas-card"><a class="hck-saas-card-main" href="<?php echo esc_url($card['url']); ?>"><span class="hck-saas-icon"><i class="fas <?php echo esc_attr($card['icon']); ?>" aria-hidden="true"></i></span><span class="hck-saas-card-meta"><?php echo esc_html($card['meta']); ?></span><strong><?php echo esc_html($card['title']); ?></strong><span class="hck-saas-card-desc"><?php echo esc_html($card['desc']); ?></span><span class="hck-saas-card-link">Open workspace <b aria-hidden="true">→</b></span></a><?php if (!empty($card['links'])): ?><nav class="hck-saas-card-links" aria-label="<?php echo esc_attr($card['title']); ?> links"><?php foreach($card['links'] as $link): ?><a href="<?php echo esc_url($link['url']); ?>"><?php echo esc_html($link['label']); ?><span aria-hidden="true">→</span></a><?php endforeach; ?></nav><?php endif; ?></article><?php endforeach; ?></div>
</div>
