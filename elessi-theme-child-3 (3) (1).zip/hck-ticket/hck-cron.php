<?php
/**
 * HCK Ticket System - Scheduled maintenance
 *
 * Makes the Settings page real:
 *   - "Send reminder after (days)": emails the customer when staff replied and nothing came back.
 *   - "Auto-close inactive tickets" / "Auto-close after (days)": closes tickets waiting on the
 *     customer, and resolved tickets nobody rated or reopened.
 * Also removes uploads that were never attached to a message (older than 24 hours).
 */

if (!defined('ABSPATH')) exit;

add_action('hck_daily_maintenance', 'hck_run_maintenance');

function hck_schedule_cron() {
    if (!wp_next_scheduled('hck_daily_maintenance')) {
        wp_schedule_event(time() + 300, 'daily', 'hck_daily_maintenance');
    }
}

function hck_unschedule_cron() {
    wp_clear_scheduled_hook('hck_daily_maintenance');
}
add_action('switch_theme', 'hck_unschedule_cron');

function hck_run_maintenance() {
    global $wpdb;
    $t = $wpdb->prefix . 'hck_tickets';

    $enabled     = (hck_get_setting('hck_auto_close_enabled', '1') === '1');
    $close_days  = max(1, (int) hck_get_setting('hck_auto_close_days', '7'));
    $remind_days = max(1, (int) hck_get_setting('hck_reminder_days', '3'));
    $now_ts      = current_time('timestamp');

    if ($enabled) {
        // ---- 1. Reminders (staff replied, customer silent) ----
        if ($remind_days < $close_days) {
            $cut = date('Y-m-d H:i:s', $now_ts - ($remind_days * DAY_IN_SECONDS));
            $ids = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$t}
                 WHERE status = 'awaiting_reply' AND reminder_sent_at IS NULL AND updated_at <= %s",
                $cut
            ));
            foreach ((array) $ids as $tid) {
                $tid = (int) $tid;
                $sent = function_exists('hck_notify_reminder') ? hck_notify_reminder($tid, $remind_days, $close_days - $remind_days) : false;
                if ($sent === true) {
                    $wpdb->update($t, array('reminder_sent_at' => current_time('mysql')), array('id' => $tid));
                    hck_add_log($tid, 0, 'reminder_sent', 'Reminder accepted by the configured mail transport after ' . $remind_days . ' day(s) without a reply');
                } else {
                    hck_add_log($tid, 0, 'reminder_failed', 'Reminder was not confirmed by the configured mail transport; it remains eligible for retry.');
                }
            }
        }

        // ---- 2. Auto-close ----
        $cut = date('Y-m-d H:i:s', $now_ts - ($close_days * DAY_IN_SECONDS));
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$t}
             WHERE status IN ('awaiting_reply', 'resolved') AND updated_at <= %s",
            $cut
        ));
        foreach ((array) $ids as $tid) {
            $tid = (int) $tid;
            $now = current_time('mysql');
            $wpdb->update($t, array(
                'status' => 'closed', 'closed_at' => $now, 'updated_at' => $now,
            ), array('id' => $tid));
            $wpdb->insert($wpdb->prefix . 'hck_ticket_messages', array(
                'ticket_id' => $tid, 'user_id' => 0,
                'message'   => 'Ticket closed automatically after ' . $close_days . ' days of inactivity.',
                'is_admin'  => 0, 'is_system' => 1, 'created_at' => $now,
            ));
            hck_add_log($tid, 0, 'auto_closed', 'Closed after ' . $close_days . ' days of inactivity');
            if (function_exists('hck_notify_ticket_closed')) hck_notify_ticket_closed($tid);
            if (class_exists('HCK_HelpCenter_Integration')) HCK_HelpCenter_Integration::sync_helpcenter_status($tid,'closed');
        }
    }

    // ---- 3. Orphan uploads (never attached to a message) ----
    $cut = date('Y-m-d H:i:s', $now_ts - DAY_IN_SECONDS);
    $orphans = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}hck_ticket_attachments WHERE ticket_id = 0 AND created_at <= %s", $cut
    ));
    foreach ((array) $orphans as $att) {
        $path = hck_attachment_path($att);
        if ($path !== '' && file_exists($path)) @unlink($path);
        $wpdb->delete($wpdb->prefix . 'hck_ticket_attachments', array('id' => (int) $att->id), array('%d'));
    }
}
