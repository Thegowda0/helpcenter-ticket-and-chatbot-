<?php
/**
 * HCK Ticket System - Database Schema
 * Runs on init, creates/updates all tables.
 */

if (!defined('ABSPATH')) exit;

function hck_install_database() {
    // Only run if schema version changed
    $installed = get_option('hck_db_version', '0');
    if (version_compare($installed, HCK_VERSION, '>=')) return;
    
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    
    $charset = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;
    
    // =============================================
    // TICKETS TABLE
    // =============================================
    $sql = "CREATE TABLE {$p}hck_tickets (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        ticket_number VARCHAR(64) DEFAULT NULL,
        ticket_type VARCHAR(8) NOT NULL DEFAULT 'tc',
        ticket_sequence BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        customer_id BIGINT(20) UNSIGNED DEFAULT NULL,
        subject VARCHAR(255) NOT NULL,
        category VARCHAR(50) NOT NULL DEFAULT 'order',
        priority VARCHAR(20) NOT NULL DEFAULT 'normal',
        status VARCHAR(30) NOT NULL DEFAULT 'open',
        order_id BIGINT(20) UNSIGNED DEFAULT NULL,
        product_id BIGINT(20) UNSIGNED DEFAULT NULL,
        related_orders TEXT DEFAULT NULL,
        agent_id BIGINT(20) UNSIGNED DEFAULT NULL,
        assigned_to BIGINT(20) UNSIGNED DEFAULT NULL,
        rating TINYINT(1) DEFAULT NULL,
        rating_comment TEXT DEFAULT NULL,
        rated_at DATETIME DEFAULT NULL,
        resolved_at DATETIME DEFAULT NULL,
        closed_at DATETIME DEFAULT NULL,
        last_reply_by_admin TINYINT(1) DEFAULT 0,
        reminder_sent_at DATETIME DEFAULT NULL,
        sla_first_response_due_at DATETIME DEFAULT NULL,
        sla_resolution_due_at DATETIME DEFAULT NULL,
        sla_first_responded_at DATETIME DEFAULT NULL,
        sla_first_response_breached TINYINT(1) NOT NULL DEFAULT 0,
        sla_resolution_breached TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY ticket_number (ticket_number),
        KEY user_id (user_id),
        KEY status (status),
        KEY priority (priority),
        KEY agent_id (agent_id)
    ) $charset;";
    dbDelta($sql);
    
    // Independent yearly sequences for Ticket Center and HelpCenter.
    $sql = "CREATE TABLE {$p}hck_ticket_sequences_v2 (
        year SMALLINT(4) UNSIGNED NOT NULL,
        ticket_type VARCHAR(8) NOT NULL,
        last_number BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY  (year,ticket_type)
    ) $charset;";
    dbDelta($sql);

    // =============================================
    // MESSAGES TABLE
    // =============================================
    $sql = "CREATE TABLE {$p}hck_ticket_messages (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        ticket_id BIGINT(20) UNSIGNED NOT NULL,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        message LONGTEXT NOT NULL,
        is_admin TINYINT(1) DEFAULT 0,
        is_internal TINYINT(1) DEFAULT 0,
        is_system TINYINT(1) DEFAULT 0,
        client_message_id VARCHAR(64) NULL DEFAULT NULL,
        edited_at DATETIME NULL,
        edited_by BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        is_deleted TINYINT(1) NOT NULL DEFAULT 0,
        deleted_at DATETIME NULL,
        deleted_by BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY ticket_id (ticket_id),
        KEY ticket_after_id (ticket_id,id),
        KEY user_id (user_id),
        UNIQUE KEY ticket_client_message (ticket_id,client_message_id)
    ) $charset;";
    dbDelta($sql);
    
    // =============================================
    // ATTACHMENTS TABLE
    // =============================================
    $sql = "CREATE TABLE {$p}hck_ticket_attachments (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        ticket_id BIGINT(20) UNSIGNED NOT NULL,
        message_id BIGINT(20) UNSIGNED NOT NULL,
        filename VARCHAR(255) NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        file_size BIGINT(20) DEFAULT 0,
        file_type VARCHAR(100) DEFAULT NULL,
        uploaded_by BIGINT(20) UNSIGNED NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY ticket_id (ticket_id),
        KEY message_id (message_id)
    ) $charset;";
    dbDelta($sql);
    
    // =============================================
    // LOGS TABLE
    // =============================================
    $sql = "CREATE TABLE {$p}hck_ticket_logs (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        ticket_id BIGINT(20) UNSIGNED NOT NULL,
        user_id BIGINT(20) UNSIGNED DEFAULT NULL,
        action VARCHAR(50) NOT NULL,
        details TEXT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY ticket_id (ticket_id)
    ) $charset;";
    dbDelta($sql);
    
    // =============================================
    // RATINGS TABLE
    // =============================================
    $sql = "CREATE TABLE {$p}hck_ticket_ratings (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        ticket_id BIGINT(20) UNSIGNED NOT NULL,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        rating TINYINT(1) NOT NULL,
        resolved VARCHAR(5) DEFAULT NULL,
        comment TEXT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY ticket_id (ticket_id),
        KEY user_id (user_id)
    ) $charset;";
    dbDelta($sql);
    
    // =============================================
    // CUSTOMER-LEVEL INTERNAL NOTES (Phase 2)
    // =============================================
    $sql = "CREATE TABLE {$p}hck_customer_notes (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        customer_user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        customer_email VARCHAR(190) NOT NULL DEFAULT '',
        note LONGTEXT NOT NULL,
        created_by BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        KEY customer_user (customer_user_id,created_at),
        KEY customer_email (customer_email,created_at),
        KEY created_at (created_at)
    ) $charset;";
    dbDelta($sql);

    // =============================================
    // SETTINGS TABLE
    // =============================================
    $sql = "CREATE TABLE {$p}hck_ticket_settings (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        setting_key VARCHAR(100) NOT NULL,
        setting_value LONGTEXT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY setting_key (setting_key)
    ) $charset;";
    dbDelta($sql);
    
    // =============================================
    // ENSURE MISSING COLUMNS EXIST (for existing installs)
    // =============================================
    hck_ensure_columns($p);
    
    // =============================================
    // SEED DEFAULT SETTINGS
    // =============================================
    hck_seed_settings($p);
    
    // Store version
    $wpdb->query("ALTER TABLE {$p}hck_tickets MODIFY ticket_number VARCHAR(64) DEFAULT NULL");
    if (!$wpdb->get_var("SHOW COLUMNS FROM {$p}hck_tickets LIKE 'ticket_type'")) $wpdb->query("ALTER TABLE {$p}hck_tickets ADD ticket_type VARCHAR(8) NOT NULL DEFAULT 'tc'");
    if (!$wpdb->get_var("SHOW COLUMNS FROM {$p}hck_tickets LIKE 'ticket_sequence'")) $wpdb->query("ALTER TABLE {$p}hck_tickets ADD ticket_sequence BIGINT(20) UNSIGNED NOT NULL DEFAULT 0");
    update_option('hck_db_version', HCK_VERSION);
}

/**
 * Add missing columns to existing tables
 */
function hck_ensure_columns($p) {
    global $wpdb;
    
    $columns = array(
        "{$p}hck_tickets" => array(
            'ticket_number'       => "VARCHAR(32) DEFAULT NULL",
            'user_id'             => "BIGINT(20) UNSIGNED NOT NULL DEFAULT 0",
            'priority'            => "VARCHAR(20) NOT NULL DEFAULT 'normal'",
            'related_orders'      => "TEXT DEFAULT NULL",
            'agent_id'            => "BIGINT(20) UNSIGNED DEFAULT NULL",
            'rated_at'            => "DATETIME DEFAULT NULL",
            'resolved_at'         => "DATETIME DEFAULT NULL",
            'last_reply_by_admin' => "TINYINT(1) DEFAULT 0",
            'reminder_sent_at'    => "DATETIME DEFAULT NULL",
            'sla_first_response_due_at' => "DATETIME DEFAULT NULL",
            'sla_resolution_due_at' => "DATETIME DEFAULT NULL",
            'sla_first_responded_at' => "DATETIME DEFAULT NULL",
            'sla_first_response_breached' => "TINYINT(1) NOT NULL DEFAULT 0",
            'sla_resolution_breached' => "TINYINT(1) NOT NULL DEFAULT 0",
            'customer_email'      => "VARCHAR(190) NOT NULL DEFAULT ''",
            'customer_name'       => "VARCHAR(120) NOT NULL DEFAULT ''",
            'source'              => "VARCHAR(32) NOT NULL DEFAULT 'portal'",
            'hc_ticket_id'        => "BIGINT(20) UNSIGNED DEFAULT NULL",
        ),
        "{$p}hck_ticket_messages" => array(
            'is_system' => "TINYINT(1) DEFAULT 0",
            'sender_name' => "VARCHAR(120) NOT NULL DEFAULT ''",
            'sender_type' => "VARCHAR(20) NOT NULL DEFAULT ''",
            'source_message_id' => "VARCHAR(80) DEFAULT NULL",
        ),
        "{$p}hck_ticket_attachments" => array(
            'ticket_id'   => "BIGINT(20) UNSIGNED NOT NULL DEFAULT 0",
            'filename'    => "VARCHAR(255) DEFAULT NULL",
            'file_size'   => "BIGINT(20) DEFAULT 0",
            'file_type'   => "VARCHAR(100) DEFAULT NULL",
            'uploaded_by' => "BIGINT(20) UNSIGNED NOT NULL DEFAULT 0",
        ),
    );
    
    foreach ($columns as $table => $cols) {
        // Skip if table doesn't exist
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) continue;
        
        $existing = $wpdb->get_col("DESCRIBE $table", 0);
        foreach ($cols as $col => $def) {
            if (!in_array($col, $existing, true)) {
                $wpdb->query("ALTER TABLE $table ADD COLUMN $col $def");
            }
        }
    }
}

/**
 * Seed default settings
 */
function hck_seed_settings($p) {
    global $wpdb;
    $table = "{$p}hck_ticket_settings";
    
    $defaults = array(
        'hck_site_title'            => 'Support Center',
        'hck_support_email'         => get_option('admin_email'),
        'hck_email_notifications'   => '1',
        'hck_auto_close_enabled'    => '1',
        'hck_auto_close_days'       => '7',
        'hck_reminder_days'         => '3',
        'hck_max_attachment_size'   => '10',
        'hck_allowed_file_types'    => 'jpg,jpeg,png,webp,pdf,zip,doc,docx',
        'hck_primary_color'         => '#6366F1',
    );
    
    foreach ($defaults as $key => $value) {
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE setting_key = %s", $key));
        if (!$exists) {
            $wpdb->insert($table, array(
                'setting_key'   => $key,
                'setting_value' => $value,
            ));
        }
    }
}
