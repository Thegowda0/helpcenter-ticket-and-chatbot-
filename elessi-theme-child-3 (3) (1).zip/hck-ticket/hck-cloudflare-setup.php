<?php
/**
 * HCK Cloudflare self-service provisioning. This provisions infrastructure only;
 * it deliberately does not migrate or reroute live ticket/chat traffic.
 */
if (!defined('ABSPATH')) exit;

function hck_cf_cf_token() {
    $enc = (string) get_option('hck_cf_cf_token_enc', '');
    return $enc ? hck_cf_get_decrypted_value($enc) : '';
}

function hck_cf_get_decrypted_value($value) {
    if (!$value || strpos($value, 'gcm2:') !== 0 || !function_exists('openssl_decrypt')) return '';
    $raw = base64_decode(substr($value, 5), true);
    if ($raw === false || strlen($raw) < 29) return '';
    $plain = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', hck_cf_secret_key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return is_string($plain) ? $plain : '';
}

function hck_cf_cf_api($method, $path, $body = null, $headers = array()) {
    $token = hck_cf_cf_token();
    if (!$token) return new WP_Error('hck_cf_no_cf_token', 'Save a Cloudflare API token first.');
    $args = array(
        'method' => strtoupper($method), 'timeout' => 35, 'redirection' => 0,
        'headers' => array_merge(array('Authorization' => 'Bearer ' . $token, 'Accept' => 'application/json'), $headers),
    );
    if ($body !== null) {
        if (is_array($body)) { $args['body'] = wp_json_encode($body); $args['headers']['Content-Type'] = 'application/json'; }
        else $args['body'] = $body;
    }
    $response = wp_remote_request('https://api.cloudflare.com/client/v4' . $path, $args);
    if (is_wp_error($response)) return $response;
    $status = (int) wp_remote_retrieve_response_code($response);
    $json = json_decode(wp_remote_retrieve_body($response), true);
    if ($status < 200 || $status >= 300 || !is_array($json) || empty($json['success'])) {
        $messages = array();
        foreach ((array) ($json['errors'] ?? array()) as $error) if (!empty($error['message'])) $messages[] = sanitize_text_field($error['message']);
        return new WP_Error('hck_cf_api_error', $messages ? implode('; ', $messages) : 'Cloudflare API request failed (HTTP ' . $status . ').', array('status' => $status));
    }
    return $json['result'] ?? array();
}

function hck_cf_cf_list_items($result, $key = '') {
    if (is_array($result) && isset($result[$key]) && is_array($result[$key])) return $result[$key];
    if ($key === '' && is_array($result) && isset($result['queues']) && is_array($result['queues'])) return $result['queues'];
    if ($key === '' && is_array($result) && isset($result['consumers']) && is_array($result['consumers'])) return $result['consumers'];
    return is_array($result) ? $result : array();
}

function hck_cf_cf_verify() {
    $result = hck_cf_cf_api('GET', '/user/tokens/verify');
    if (is_wp_error($result)) return $result;
    if (!is_array($result) || empty($result['status']) || $result['status'] !== 'active') return new WP_Error('hck_cf_token_inactive', 'Cloudflare API token is not active.');
    $account = preg_replace('/[^a-f0-9]/i', '', (string) get_option('hck_cf_account_id', ''));
    if (strlen($account) < 20 || strlen($account) > 32) return new WP_Error('hck_cf_account_id', 'Enter the Cloudflare Account ID (usually 32 characters).');
    $account_result = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account));
    if (is_wp_error($account_result)) return $account_result;
    return array('status' => 'active', 'account_id' => $account, 'account_name' => sanitize_text_field($account_result['name'] ?? 'Cloudflare account'));
}

function hck_cf_cf_find_or_create_d1($account, $name) {
    $list = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account) . '/d1/database?per_page=100');
    if (is_wp_error($list)) return $list;
    $items = hck_cf_cf_list_items($list);
    foreach ($items as $item) if (($item['name'] ?? '') === $name && !empty($item['uuid'])) return $item;
    if (count($items) === 1 && !empty($items[0]['uuid'])) return $items[0];
    if (count($items) > 1) return new WP_Error('hck_cf_d1_ambiguous', 'Multiple D1 databases exist. Set the exact database name in Cloudflare settings before provisioning.');
    return hck_cf_cf_api('POST', '/accounts/' . rawurlencode($account) . '/d1/database', array('name' => $name));
}

function hck_cf_cf_find_or_create_r2($account, $name) {
    $list = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account) . '/r2/buckets?per_page=100');
    if (is_wp_error($list)) return $list;
    $items = hck_cf_cf_list_items($list, 'buckets');
    foreach ($items as $item) if (($item['name'] ?? '') === $name) return $item;
    if (count($items) === 1) return $items[0];
    if (count($items) > 1) return new WP_Error('hck_cf_r2_ambiguous', 'Multiple R2 buckets exist. Set the exact bucket name in Cloudflare settings before provisioning.');
    return hck_cf_cf_api('POST', '/accounts/' . rawurlencode($account) . '/r2/buckets', array('name' => $name, 'locationHint' => 'apac')); 
}

function hck_cf_cf_find_or_create_queue($account, $name) {
    $list = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account) . '/queues?per_page=100');
    if (is_wp_error($list)) return $list;
    $items = hck_cf_cf_list_items($list);
    foreach ($items as $item) if (($item['queue_name'] ?? '') === $name && (!empty($item['queue_id']) || !empty($item['id']))) { $item['queue_id'] = $item['queue_id'] ?? $item['id']; return $item; }
    if (count($items) === 1 && (!empty($items[0]['queue_id']) || !empty($items[0]['id']))) { $items[0]['queue_id'] = $items[0]['queue_id'] ?? $items[0]['id']; return $items[0]; }
    if (count($items) > 1) return new WP_Error('hck_cf_queue_ambiguous', 'Multiple Queues exist. Set the exact Queue name in Cloudflare settings before provisioning.');
    $created = hck_cf_cf_api('POST', '/accounts/' . rawurlencode($account) . '/queues', array('queue_name' => $name));
    if (!is_wp_error($created) && empty($created['queue_id']) && !empty($created['id'])) $created['queue_id'] = $created['id'];
    return $created;
}

function hck_cf_cf_find_or_create_dlq($account, $name) {
    $list = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account) . '/queues?per_page=100');
    if (is_wp_error($list)) return $list;
    foreach (hck_cf_cf_list_items($list) as $item) {
        if (($item['queue_name'] ?? '') === $name) {
            if (empty($item['queue_id']) && !empty($item['id'])) $item['queue_id'] = $item['id'];
            return $item;
        }
    }
    // A dedicated DLQ is safe to create even when unrelated queues already exist.
    $created = hck_cf_cf_api('POST', '/accounts/' . rawurlencode($account) . '/queues', array('queue_name' => $name));
    if (!is_wp_error($created) && empty($created['queue_id']) && !empty($created['id'])) $created['queue_id'] = $created['id'];
    return $created;
}

function hck_cf_cf_apply_schema($account, $database_id) {
    $statements = array(
        "CREATE TABLE IF NOT EXISTS archive_objects (id TEXT PRIMARY KEY, object_key TEXT NOT NULL UNIQUE, record_type TEXT NOT NULL, source_id TEXT NOT NULL, content_type TEXT NOT NULL DEFAULT 'application/json', byte_size INTEGER NOT NULL DEFAULT 0, checksum_sha256 TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), metadata_json TEXT NOT NULL DEFAULT '{}')",
        'CREATE INDEX IF NOT EXISTS idx_archive_type_source ON archive_objects(record_type, source_id)',
        'CREATE INDEX IF NOT EXISTS idx_archive_created ON archive_objects(created_at)',
        "CREATE TABLE IF NOT EXISTS migration_runs (id TEXT PRIMARY KEY, source TEXT NOT NULL, status TEXT NOT NULL, started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), completed_at TEXT, records_seen INTEGER NOT NULL DEFAULT 0, records_written INTEGER NOT NULL DEFAULT 0, error_text TEXT)",
        "CREATE TABLE IF NOT EXISTS archive_jobs (id TEXT PRIMARY KEY, record_type TEXT NOT NULL, source_id TEXT NOT NULL, stage_key TEXT NOT NULL, metadata_json TEXT NOT NULL DEFAULT '{}', checksum_sha256 TEXT NOT NULL, byte_size INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'queued', object_key TEXT, error_text TEXT, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), completed_at TEXT)",
        'CREATE INDEX IF NOT EXISTS idx_archive_jobs_status_created ON archive_jobs(status, created_at)',
        "CREATE TABLE IF NOT EXISTS queue_probes (id TEXT PRIMARY KEY, status TEXT NOT NULL DEFAULT 'queued', created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), consumed_at TEXT)",
        "CREATE TABLE IF NOT EXISTS queue_failures (message_id TEXT PRIMARY KEY, queue_name TEXT NOT NULL, message_type TEXT NOT NULL, job_id TEXT, dlq_attempts INTEGER NOT NULL DEFAULT 1, body_json TEXT NOT NULL DEFAULT '{}', error_text TEXT, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')))",
        "CREATE INDEX IF NOT EXISTS idx_queue_failures_created ON queue_failures(created_at)",
        "CREATE TABLE IF NOT EXISTS queue_dlq_probes (id TEXT PRIMARY KEY, status TEXT NOT NULL DEFAULT 'queued', created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), dead_lettered_at TEXT, source_message_id TEXT, dlq_attempts INTEGER, error_text TEXT)",
    );
    foreach ($statements as $sql) {
        $result = hck_cf_cf_api('POST', '/accounts/' . rawurlencode($account) . '/d1/database/' . rawurlencode($database_id) . '/query', array('sql' => $sql));
        if (is_wp_error($result)) return $result;
        if (is_array($result)) {
            foreach ($result as $statement_result) {
                if (is_array($statement_result) && array_key_exists('success', $statement_result) && !$statement_result['success']) {
                    return new WP_Error('hck_cf_d1_sql', 'D1 rejected a setup statement. Check the database permissions and existing schema.');
                }
            }
        }
    }
    return true;
}

function hck_cf_cf_upload_worker($account, $script, $database_id, $bucket_name, $queue_name, $dlq_name) {
    $source = dirname(HCK_PATH) . '/cloudflare-worker/src/index.js';
    if (!is_readable($source)) return new WP_Error('hck_cf_worker_source_missing', 'Worker source file is missing from the installed theme package.');
    $code = file_get_contents($source);
    if (!is_string($code) || $code === '') return new WP_Error('hck_cf_worker_source_empty', 'Worker source file is empty.');
    $metadata = array(
        'main_module' => 'index.js', 'compatibility_date' => '2026-11-01', 'workers_dev' => true,
        'bindings' => array(
            array('type' => 'd1', 'name' => 'DB', 'id' => $database_id),
            array('type' => 'r2_bucket', 'name' => 'BUCKET', 'bucket_name' => $bucket_name),
            array('type' => 'queue', 'name' => 'ARCHIVE_QUEUE', 'queue_name' => $queue_name),
            array('type' => 'plain_text', 'name' => 'MAX_ARCHIVE_BYTES', 'text' => '10485760'),
            array('type' => 'plain_text', 'name' => 'HCK_PRIMARY_QUEUE_NAME', 'text' => $queue_name),
            array('type' => 'plain_text', 'name' => 'HCK_DLQ_QUEUE_NAME', 'text' => $dlq_name),
        ),
    );
    $boundary = '----HCKCloudflare' . wp_generate_password(24, false, false);
    $body = '--' . $boundary . "\r\nContent-Disposition: form-data; name=\"metadata\"; filename=\"metadata.json\"\r\nContent-Type: application/json\r\n\r\n" . wp_json_encode($metadata) . "\r\n";
    $body .= '--' . $boundary . "\r\nContent-Disposition: form-data; name=\"index.js\"; filename=\"index.js\"\r\nContent-Type: application/javascript+module\r\n\r\n" . $code . "\r\n--" . $boundary . "--\r\n";
    return hck_cf_cf_api('PUT', '/accounts/' . rawurlencode($account) . '/workers/scripts/' . rawurlencode($script), $body, array('Content-Type' => 'multipart/form-data; boundary=' . $boundary));
}

function hck_cf_cf_deploy_worker_if_changed($account, $script, $database_id, $bucket_name, $queue_name, $dlq_name) {
    $source = dirname(HCK_PATH) . '/cloudflare-worker/src/index.js';
    if (!is_readable($source)) return new WP_Error('hck_cf_worker_source_missing', 'Worker source file is missing from the installed theme package.');
    $code = file_get_contents($source);
    if (!is_string($code) || $code === '') return new WP_Error('hck_cf_worker_source_empty', 'Worker source file is empty.');
    $fingerprint = hash('sha256', $code . "\n" . wp_json_encode(array($script, $database_id, $bucket_name, $queue_name, $dlq_name, 'MAX_ARCHIVE_BYTES' => 10485760, 'compatibility_date' => '2026-11-01')));
    $previous = (string) get_option('hck_cf_worker_deployment_fingerprint', '');
    $script_settings = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account) . '/workers/scripts/' . rawurlencode($script) . '/settings');
    $script_exists = !is_wp_error($script_settings);
    if (is_wp_error($script_settings)) {
        $api_data = $script_settings->get_error_data();
        $http_status = is_array($api_data) ? (int) ($api_data['status'] ?? 0) : 0;
        if ($http_status !== 404) return $script_settings;
    }
    if ($script_exists && $previous !== '' && hash_equals($previous, $fingerprint)) return array('deployed' => false, 'fingerprint' => $fingerprint);
    $uploaded = hck_cf_cf_upload_worker($account, $script, $database_id, $bucket_name, $queue_name, $dlq_name);
    if (is_wp_error($uploaded)) return $uploaded;
    update_option('hck_cf_worker_deployment_fingerprint', $fingerprint, false);
    return array('deployed' => true, 'fingerprint' => $fingerprint);
}

function hck_cf_cf_set_worker_secret($account, $script, $secret) {
    return hck_cf_cf_api('PUT', '/accounts/' . rawurlencode($account) . '/workers/scripts/' . rawurlencode($script) . '/secrets', array('name' => 'HCK_API_SECRET', 'text' => $secret, 'type' => 'secret_text'));
}

function hck_cf_cf_ensure_queue_consumer($account, $queue_id, $script, $settings, $dead_letter_queue = null) {
    $listed = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account) . '/queues/' . rawurlencode($queue_id) . '/consumers');
    if (is_wp_error($listed)) return $listed;
    $consumers = hck_cf_cf_list_items($listed, 'consumers');
    $matching = null;
    foreach ($consumers as $consumer) {
        $consumer_script = (string) ($consumer['script_name'] ?? $consumer['script'] ?? '');
        if (strtolower($consumer_script) === strtolower($script) && ($consumer['type'] ?? 'worker') === 'worker') {
            if ($matching !== null) return new WP_Error('hck_cf_queue_ambiguous', 'More than one matching consumer was returned for this Queue. No consumer was changed.');
            $matching = $consumer;
        } else {
            return new WP_Error('hck_cf_queue_in_use', 'The selected Queue already has a different consumer. Setup stopped without replacing it.');
        }
    }
    if ($matching && empty($matching['consumer_id'])) return new WP_Error('hck_cf_queue_consumer_id', 'Cloudflare did not return the existing consumer ID, so it cannot be safely updated.');
    $body = array('script_name' => $script, 'type' => 'worker', 'settings' => $settings);
    // Empty string explicitly clears any accidental DLQ chaining on the DLQ consumer.
    if ($dead_letter_queue !== null) $body['dead_letter_queue'] = $dead_letter_queue;
    if ($matching && !empty($matching['consumer_id'])) {
        $saved = hck_cf_cf_api('PUT', '/accounts/' . rawurlencode($account) . '/queues/' . rawurlencode($queue_id) . '/consumers/' . rawurlencode($matching['consumer_id']), $body);
    } else {
        $saved = hck_cf_cf_api('POST', '/accounts/' . rawurlencode($account) . '/queues/' . rawurlencode($queue_id) . '/consumers', $body);
    }
    if (is_wp_error($saved)) return $saved;
    // Read-after-write verification: do not report success merely because the mutation endpoint returned 2xx.
    $verify = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account) . '/queues/' . rawurlencode($queue_id) . '/consumers');
    if (is_wp_error($verify)) return $verify;
    $verified_consumer = null;
    foreach (hck_cf_cf_list_items($verify, 'consumers') as $consumer) {
        $consumer_script = (string) ($consumer['script_name'] ?? $consumer['script'] ?? '');
        if (strtolower($consumer_script) === strtolower($script) && ($consumer['type'] ?? 'worker') === 'worker') { $verified_consumer = $consumer; break; }
    }
    if (!$verified_consumer) return new WP_Error('hck_cf_queue_verify', 'Cloudflare did not return the configured Worker consumer after saving it.');
    $actual = (array) ($verified_consumer['settings'] ?? array());
    foreach (array('batch_size', 'max_retries', 'max_wait_time_ms', 'retry_delay') as $setting) {
        if (isset($settings[$setting]) && (int) ($actual[$setting] ?? -1) !== (int) $settings[$setting]) {
            return new WP_Error('hck_cf_queue_verify', 'Cloudflare Queue consumer settings did not match the requested retry configuration (' . $setting . ').');
        }
    }
    if ($dead_letter_queue !== null && (string) ($verified_consumer['dead_letter_queue'] ?? '') !== (string) $dead_letter_queue) {
        return new WP_Error('hck_cf_queue_verify', 'Cloudflare did not confirm the expected dead-letter Queue connection.');
    }
    return $verified_consumer;
}

function hck_cf_cf_attach_consumers($account, $primary_queue_id, $dlq_queue_id, $script, $dlq_name) {
    $primary = hck_cf_cf_ensure_queue_consumer($account, $primary_queue_id, $script,
        array('batch_size' => 10, 'max_retries' => 3, 'max_wait_time_ms' => 5000, 'retry_delay' => 5), $dlq_name);
    if (is_wp_error($primary)) return $primary;
    $dead = hck_cf_cf_ensure_queue_consumer($account, $dlq_queue_id, $script,
        array('batch_size' => 10, 'max_retries' => 100, 'max_wait_time_ms' => 1000, 'retry_delay' => 60), '');
    if (is_wp_error($dead)) return $dead;
    return array('primary' => 'verified', 'dead_letter' => 'verified');
}

function hck_cf_cf_queue_smoke_test() {
    $probe = 'cfprobe-' . wp_generate_password(18, false, false);
    $headers = array('Authorization' => 'Bearer ' . hck_cf_get_api_secret(), 'Idempotency-Key' => $probe);
    $sent = wp_remote_post(hck_cf_worker_url('v1/queue/probe'), array('timeout' => 8, 'redirection' => 0, 'headers' => $headers, 'body' => ''));
    if (is_wp_error($sent)) return $sent;
    if ((int) wp_remote_retrieve_response_code($sent) !== 202) return new WP_Error('hck_cf_queue_probe_send', 'Worker accepted no queue verification message.');
    // Queue delivery is asynchronous; allow time for Cloudflare batch delivery.
    $deadline = microtime(true) + 30.0;
    $last_status = 'queued';
    while (microtime(true) < $deadline) {
        $check = wp_remote_get(hck_cf_worker_url('v1/queue/probe/' . rawurlencode($probe)), array('timeout' => 3, 'redirection' => 0, 'headers' => array('Authorization' => 'Bearer ' . hck_cf_get_api_secret())));
        if (!is_wp_error($check)) {
            $http = (int) wp_remote_retrieve_response_code($check);
            $body = json_decode(wp_remote_retrieve_body($check), true);
            if ($http === 200 && !empty($body['ok']) && !empty($body['probe']['status'])) {
                $last_status = sanitize_key($body['probe']['status']);
                if ($last_status === 'consumed') return true;
                if (in_array($last_status, array('failed', 'dead_lettered'), true)) {
                    return new WP_Error('hck_cf_queue_probe_failed', 'The Queue consumer received the verification message but reported a processing failure. Check Worker Queue logs.');
                }
            }
        }
        usleep(500000);
    }
    return new WP_Error('hck_cf_queue_probe_timeout', 'The Queue producer accepted the verification message, but no consumer acknowledgement was recorded within 30 seconds. Check Worker Queue event logs. Last reported status: ' . $last_status . '.');
}

function hck_cf_cf_dlq_smoke_test() {
    $probe = 'cf-dlq-' . wp_generate_password(18, false, false);
    $headers = array('Authorization' => 'Bearer ' . hck_cf_get_api_secret(), 'Content-Type' => 'application/json', 'Idempotency-Key' => $probe);
    $sent = wp_remote_post(hck_cf_worker_url('v1/queue/dlq-probe'), array('timeout' => 10, 'redirection' => 0, 'headers' => $headers, 'body' => '{}'));
    if (is_wp_error($sent)) return $sent;
    $http = (int) wp_remote_retrieve_response_code($sent);
    $body = json_decode(wp_remote_retrieve_body($sent), true);
    if ($http !== 202 || empty($body['ok']) || empty($body['probe_id'])) return new WP_Error('hck_cf_dlq_probe_send', 'Worker did not accept the synthetic DLQ verification message.');
    $deadline = microtime(true) + 100;
    $last = 'queued';
    while (microtime(true) < $deadline) {
        $check = wp_remote_get(hck_cf_worker_url('v1/queue/dlq-probe/' . rawurlencode($probe)), array('timeout' => 5, 'redirection' => 0, 'headers' => array('Authorization' => 'Bearer ' . hck_cf_get_api_secret())));
        if (!is_wp_error($check) && (int) wp_remote_retrieve_response_code($check) === 200) {
            $data = json_decode(wp_remote_retrieve_body($check), true);
            $last = sanitize_key($data['probe']['status'] ?? 'unknown');
            if ($last === 'dead_lettered') return true;
            if ($last === 'failed') return new WP_Error('hck_cf_dlq_probe_failed', 'The synthetic message failed before reaching the dead-letter consumer.');
        }
        usleep(1000000);
    }
    return new WP_Error('hck_cf_dlq_probe_timeout', 'The synthetic message did not reach the DLQ consumer within 100 seconds. Last status: ' . $last . '. Check Queue consumer settings and Worker logs.');
}

/** Run an isolated end-to-end archive test. The synthetic object is retained for audit and never references a real ticket. */
function hck_cf_cf_archive_regression_test() {
    if (!hck_cf_is_configured()) return new WP_Error('hck_cf_not_configured', 'Run automatic Cloudflare setup first.');
    $nonce = strtolower(wp_generate_password(20, false, false));
    $source_id = 'archive-regression-' . $nonce;
    $job_id = 'hck-archive-test-' . $nonce;
    $payload = array(
        'test' => 'hck_archive_regression',
        'synthetic' => true,
        'source_id' => $source_id,
        'created_at' => gmdate('c'),
        'message' => 'Synthetic archive regression verification; contains no customer or ticket data.'
    );
    $headers = array('Authorization' => 'Bearer ' . hck_cf_get_api_secret(), 'Content-Type' => 'application/json', 'Idempotency-Key' => $job_id);
    $sent = wp_remote_post(hck_cf_worker_url('v1/archive/async'), array('timeout' => 12, 'redirection' => 0, 'headers' => $headers, 'body' => wp_json_encode(array('record_type' => 'synthetic_archive_test', 'source_id' => $source_id, 'payload' => $payload, 'metadata' => array('purpose' => 'admin_regression_test')))));
    if (is_wp_error($sent)) return $sent;
    $http = (int) wp_remote_retrieve_response_code($sent);
    $body = json_decode(wp_remote_retrieve_body($sent), true);
    if ($http !== 202 || empty($body['ok']) || empty($body['id'])) return new WP_Error('hck_cf_archive_test_enqueue', 'Worker did not accept the synthetic archive test job. HTTP ' . $http . '.');
    $job_id = sanitize_text_field($body['id']);
    $deadline = microtime(true) + 90;
    $last_status = 'queued';
    while (microtime(true) < $deadline) {
        $check = wp_remote_get(hck_cf_worker_url('v1/archive/jobs/' . rawurlencode($job_id)), array('timeout' => 5, 'redirection' => 0, 'headers' => array('Authorization' => 'Bearer ' . hck_cf_get_api_secret())));
        if (!is_wp_error($check) && (int) wp_remote_retrieve_response_code($check) === 200) {
            $data = json_decode(wp_remote_retrieve_body($check), true);
            $last_status = sanitize_key($data['job']['status'] ?? 'unknown');
            if ($last_status === 'complete') break;
            if (in_array($last_status, array('dead_lettered', 'failed'), true)) return new WP_Error('hck_cf_archive_test_failed', 'Synthetic archive job ended with status ' . $last_status . '.');
        }
        usleep(1000000);
    }
    if ($last_status !== 'complete') return new WP_Error('hck_cf_archive_test_timeout', 'Synthetic archive job did not complete within 90 seconds. Last status: ' . $last_status . '.');
    $verify = wp_remote_get(hck_cf_worker_url('v1/archive/verify/' . rawurlencode($job_id)), array('timeout' => 8, 'redirection' => 0, 'headers' => array('Authorization' => 'Bearer ' . hck_cf_get_api_secret())));
    if (is_wp_error($verify)) return $verify;
    $verify_http = (int) wp_remote_retrieve_response_code($verify);
    $result = json_decode(wp_remote_retrieve_body($verify), true);
    if ($verify_http !== 200 || empty($result['ok'])) return new WP_Error('hck_cf_archive_test_verify', 'Worker could not verify the synthetic archive object in D1 and R2.');
    if (($result['job_status'] ?? '') !== 'complete' || (int) ($result['archive_object_count'] ?? 0) !== 1 || empty($result['matching_archive_object']) || empty($result['r2_readback_matches']) || (int) ($result['dlq_failure_count'] ?? -1) !== 0) {
        return new WP_Error('hck_cf_archive_test_assertions', 'Archive verification did not pass all checks. Job: ' . sanitize_key($result['job_status'] ?? 'unknown') . '; D1 objects: ' . (int) ($result['archive_object_count'] ?? -1) . '; R2 checksum match: ' . (!empty($result['r2_readback_matches']) ? 'yes' : 'no') . '; DLQ failure records: ' . (int) ($result['dlq_failure_count'] ?? -1) . '.');
    }
    return array('job_id' => $job_id, 'source_id' => $source_id, 'checks' => $result);
}

function hck_cf_auto_provision() {
    $verified = hck_cf_cf_verify();
    if (is_wp_error($verified)) return $verified;
    $account = $verified['account_id'];
    $config = get_option('hck_cf_resource_config', array());
    if (!is_array($config)) $config = array();
    $db_name = sanitize_key($config['database_name'] ?? 'hck-support-data');
    $bucket_name = sanitize_key($config['bucket_name'] ?? 'hck-support-archive');
    $queue_name = sanitize_key($config['queue_name'] ?? 'hck-support-archive-queue');
    $dlq_name = sanitize_key($config['dead_letter_queue_name'] ?? 'hck-support-archive-dlq');
    $script = sanitize_key($config['worker_name'] ?? 'hck-support-storage');
    if (strlen($db_name) < 3 || strlen($bucket_name) < 3 || strlen($queue_name) < 3 || strlen($dlq_name) < 3 || strlen($script) < 3) return new WP_Error('hck_cf_names', 'Resource names must contain at least 3 valid characters.');

    $db = hck_cf_cf_find_or_create_d1($account, $db_name);
    if (is_wp_error($db) || empty($db['uuid'])) return is_wp_error($db) ? $db : new WP_Error('hck_cf_d1_create', 'Cloudflare did not return the D1 database ID.');
    $r2 = hck_cf_cf_find_or_create_r2($account, $bucket_name);
    if (is_wp_error($r2)) return $r2;
    $queue = hck_cf_cf_find_or_create_queue($account, $queue_name);
    if (is_wp_error($queue) || empty($queue['queue_id'])) return is_wp_error($queue) ? $queue : new WP_Error('hck_cf_queue_create', 'Cloudflare did not return the Queue ID.');
    $dlq = hck_cf_cf_find_or_create_dlq($account, $dlq_name);
    if (is_wp_error($dlq) || empty($dlq['queue_id'])) return is_wp_error($dlq) ? $dlq : new WP_Error('hck_cf_dlq_create', 'Cloudflare did not return the dead-letter Queue ID.');
    $dlq_name = sanitize_key($dlq['queue_name'] ?? $dlq_name);
    $db_name = sanitize_key($db['name'] ?? $db_name);
    $bucket_name = sanitize_key($r2['name'] ?? $bucket_name);
    $queue_name = sanitize_key($queue['queue_name'] ?? $queue_name);
    update_option('hck_cf_resource_config', array('database_name' => $db_name, 'bucket_name' => $bucket_name, 'queue_name' => $queue_name, 'dead_letter_queue_name' => $dlq_name, 'worker_name' => $script), false);

    $schema = hck_cf_cf_apply_schema($account, $db['uuid']);
    if (is_wp_error($schema)) return $schema;
    $uploaded = hck_cf_cf_deploy_worker_if_changed($account, $script, $db['uuid'], $bucket_name, $queue_name, $dlq_name);
    if (is_wp_error($uploaded)) return $uploaded;
    $secret = hck_cf_get_api_secret();
    if (!$secret) {
        try { $secret = rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'), '='); }
        catch (Exception $e) { return new WP_Error('hck_cf_secret_random', 'Secure random generation failed.'); }
    }
    $secret_result = hck_cf_cf_set_worker_secret($account, $script, $secret);
    if (is_wp_error($secret_result)) return $secret_result;
    $consumers = hck_cf_cf_attach_consumers($account, $queue['queue_id'], $dlq['queue_id'], $script, $dlq_name);
    if (is_wp_error($consumers)) return $consumers;

    $worker_url = hck_cf_get_worker_url();
    if (!$worker_url || strpos(parse_url($worker_url, PHP_URL_HOST) ?: '', $script . '.') !== 0) {
        $subdomain = hck_cf_cf_api('GET', '/accounts/' . rawurlencode($account) . '/workers/subdomain');
        if (is_wp_error($subdomain) || empty($subdomain['subdomain'])) return new WP_Error('hck_cf_subdomain', 'Resources and Worker were provisioned, but the account workers.dev subdomain could not be read. Enable workers.dev in Cloudflare and run setup again.');
        $worker_url = 'https://' . $script . '.' . $subdomain['subdomain'] . '.workers.dev';
    }
    $encrypted = hck_cf_encrypt_api_secret($secret);
    if (is_wp_error($encrypted)) return $encrypted;
    update_option('hck_cf_worker_url', esc_url_raw($worker_url), false);
    update_option('hck_cf_api_secret_enc', $encrypted, false);
    $health = hck_cf_health_check();
    if (is_wp_error($health)) return new WP_Error('hck_cf_post_deploy_health', 'Infrastructure and Worker deployment completed, but the final Worker health check failed: ' . $health->get_error_message());
    $queue_test = hck_cf_cf_queue_smoke_test();
    if (is_wp_error($queue_test)) return $queue_test;
    // Mark provisioning successful only after all verification steps pass.
    update_option('hck_cf_provision_status', array('completed_at' => current_time('mysql'), 'worker' => $script, 'database' => $db_name, 'bucket' => $bucket_name, 'queue' => $queue_name, 'dead_letter_queue' => $dlq_name, 'queue_consumer' => 'verified', 'dlq_consumer' => 'verified', 'worker_deployed' => !empty($uploaded['deployed'])), false);
    return array('worker_url' => $worker_url, 'database' => $db_name, 'bucket' => $bucket_name, 'queue' => $queue_name, 'dead_letter_queue' => $dlq_name, 'health' => $health, 'queue_consumer' => 'verified', 'dlq_consumer' => 'verified', 'worker_deployed' => !empty($uploaded['deployed']));
}

add_action('admin_post_hck_cf_save_cloudflare_account', function () {
    if (!current_user_can('manage_options')) wp_die('Unauthorized.', 403);
    check_admin_referer('hck_cf_save_cloudflare_account');
    $account = isset($_POST['account_id']) ? preg_replace('/[^a-f0-9]/i', '', (string) wp_unslash($_POST['account_id'])) : '';
    if ($account && (strlen($account) < 20 || strlen($account) > 32)) wp_die('Invalid Cloudflare Account ID.');
    update_option('hck_cf_account_id', $account, false);
    $token = isset($_POST['cloudflare_token']) ? trim((string) wp_unslash($_POST['cloudflare_token'])) : '';
    if (!empty($_POST['clear_cloudflare_token'])) delete_option('hck_cf_cf_token_enc');
    elseif ($token !== '') {
        $encrypted = hck_cf_encrypt_api_secret($token);
        if (is_wp_error($encrypted)) wp_die(esc_html($encrypted->get_error_message()));
        update_option('hck_cf_cf_token_enc', $encrypted, false);
    }
    $names = array(
        'database_name' => sanitize_key($_POST['database_name'] ?? 'hck-support-data'),
        'bucket_name' => sanitize_key($_POST['bucket_name'] ?? 'hck-support-archive'),
        'queue_name' => sanitize_key($_POST['queue_name'] ?? 'hck-support-archive-queue'),
        'dead_letter_queue_name' => sanitize_key($_POST['dead_letter_queue_name'] ?? 'hck-support-archive-dlq'),
        'worker_name' => sanitize_key($_POST['worker_name'] ?? 'hck-support-storage'),
    );
    update_option('hck_cf_resource_config', $names, false);
    wp_safe_redirect(add_query_arg('hck_cf_notice', 'account_saved', wp_get_referer() ?: admin_url())); exit;
});

add_action('wp_ajax_hck_cf_auto_provision', function () {
    if (function_exists('set_time_limit')) @set_time_limit(120);
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Unauthorized.'), 403);
    check_ajax_referer('hck_nonce', 'nonce');
    if (!hck_cf_cf_token()) wp_send_json_error(array('message' => 'Save the Cloudflare API token and Account ID first.'), 400);
    $result = hck_cf_auto_provision();
    if (is_wp_error($result)) wp_send_json_error(array('message' => $result->get_error_message()), 503);
    wp_send_json_success(array('message' => 'Cloudflare resources, Worker deployment, queue consumer and health verification completed.', 'details' => $result));
});


add_action('wp_ajax_hck_cf_dlq_test', function () {
    if (function_exists('set_time_limit')) @set_time_limit(120);
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Unauthorized.'), 403);
    check_ajax_referer('hck_nonce', 'nonce');
    if (!hck_cf_is_configured()) wp_send_json_error(array('message' => 'Run automatic Cloudflare setup first.'), 400);
    $result = hck_cf_cf_dlq_smoke_test();
    if (is_wp_error($result)) wp_send_json_error(array('message' => $result->get_error_message()), 503);
    wp_send_json_success(array('message' => 'Retry and dead-letter verification passed. The synthetic message reached the DLQ and was recorded in D1.'));
});


add_action('wp_ajax_hck_cf_archive_regression_test', function () {
    if (function_exists('set_time_limit')) @set_time_limit(120);
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Unauthorized.'), 403);
    check_ajax_referer('hck_nonce', 'nonce');
    if (!hck_cf_is_configured()) wp_send_json_error(array('message' => 'Run automatic Cloudflare setup first.'), 400);
    $result = hck_cf_cf_archive_regression_test();
    if (is_wp_error($result)) wp_send_json_error(array('message' => $result->get_error_message()), 503);
    wp_send_json_success(array('message' => 'Archive regression verification passed. Synthetic job completed, exactly one matching D1 object exists, R2 readback checksum matches, and no DLQ failure was recorded.', 'details' => $result));
});
