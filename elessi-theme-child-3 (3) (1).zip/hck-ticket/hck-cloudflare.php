<?php
/**
 * HCK Cloudflare archive bridge.
 * Optional, additive archive API. It never blocks or replaces Ably delivery.
 */
if (!defined('ABSPATH')) exit;

/** Resolve credentials from WordPress admin options first. No credential is localized to frontend JavaScript. */
function hck_cf_get_worker_url() {
    $saved = (string) get_option('hck_cf_worker_url', '');
    if ($saved !== '') return esc_url_raw($saved);
    // Legacy fallback only; the admin editor can override it by saving an option.
    if (defined('HCK_CF_WORKER_URL') && HCK_CF_WORKER_URL) return esc_url_raw(HCK_CF_WORKER_URL);
    return '';
}

function hck_cf_secret_key() {
    return hash('sha256', wp_salt('auth') . '|' . wp_salt('secure_auth'), true);
}

function hck_cf_get_api_secret() {
    $stored = (string) get_option('hck_cf_api_secret_enc', '');
    if (!$stored || !function_exists('openssl_decrypt')) return '';
    if (strpos($stored, 'gcm2:') !== 0) return '';
    $raw = base64_decode(substr($stored, 5), true);
    if ($raw === false || strlen($raw) < 29) return '';
    $iv = substr($raw, 0, 12);
    $tag = substr($raw, 12, 16);
    $cipher = substr($raw, 28);
    $plain = openssl_decrypt($cipher, 'aes-256-gcm', hck_cf_secret_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if (is_string($plain) && $plain !== '') return $plain;
    // Legacy fallback only when no admin-saved secret exists.
    return (defined('HCK_CF_API_SECRET') && HCK_CF_API_SECRET) ? (string) HCK_CF_API_SECRET : '';
}

function hck_cf_encrypt_api_secret($secret) {
    if (!function_exists('openssl_encrypt')) return new WP_Error('hck_cf_crypto_unavailable', 'OpenSSL is required to securely save the Cloudflare secret.');
    try { $iv = random_bytes(12); } catch (Exception $e) { return new WP_Error('hck_cf_random_unavailable', 'Secure random generation is unavailable.'); }
    $tag = '';
    $cipher = openssl_encrypt((string) $secret, 'aes-256-gcm', hck_cf_secret_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false || strlen($tag) !== 16) return new WP_Error('hck_cf_encrypt_failed', 'Could not encrypt the Cloudflare secret.');
    return 'gcm2:' . base64_encode($iv . $tag . $cipher);
}

function hck_cf_is_configured() {
    return (bool) (hck_cf_get_worker_url() && hck_cf_get_api_secret());
}

function hck_cf_worker_url($path = '') {
    $base = hck_cf_get_worker_url();
    return $base ? rtrim($base, '/') . '/' . ltrim($path, '/') : '';
}

/** Save credentials from the admin screen. The secret is encrypted before storage and never re-displayed. */
add_action('admin_post_hck_cf_save_credentials', function () {
    if (!current_user_can('manage_options')) wp_die('Unauthorized.', 403);
    check_admin_referer('hck_cf_save_credentials');
    $url = isset($_POST['worker_url']) ? esc_url_raw(trim(wp_unslash($_POST['worker_url']))) : '';
    if ($url && (!wp_http_validate_url($url) || !preg_match('#^https://#i', $url))) {
        wp_safe_redirect(add_query_arg('hck_cf_notice', 'invalid_url', wp_get_referer() ?: admin_url())); exit;
    }
    update_option('hck_cf_worker_url', $url, false);
    $secret = isset($_POST['api_secret']) ? trim((string) wp_unslash($_POST['api_secret'])) : '';
    if (!empty($_POST['clear_secret'])) {
        delete_option('hck_cf_api_secret_enc');
    } elseif ($secret !== '') {
        $encrypted = hck_cf_encrypt_api_secret($secret);
        if (is_wp_error($encrypted)) wp_die(esc_html($encrypted->get_error_message()));
        update_option('hck_cf_api_secret_enc', $encrypted, false);
    }
    $referer = wp_get_referer() ?: admin_url();
    wp_safe_redirect(add_query_arg('hck_cf_notice', 'saved', $referer)); exit;
});

/** Authenticated connectivity test. Never returns or logs the secret. */
function hck_cf_health_check() {
    if (!hck_cf_is_configured()) return new WP_Error('hck_cf_not_configured', 'Cloudflare Worker URL and API secret are not configured.');
    $result = wp_remote_get(hck_cf_worker_url('health'), array(
        'timeout' => 8, 'redirection' => 0,
        'headers' => array('Authorization' => 'Bearer ' . hck_cf_get_api_secret()),
    ));
    if (is_wp_error($result)) return $result;
    $code = wp_remote_retrieve_response_code($result);
    $body = json_decode(wp_remote_retrieve_body($result), true);
    if ($code !== 200 || empty($body['ok']) || empty($body['d1']) || empty($body['r2']) || empty($body['queue_binding'])) {
        return new WP_Error('hck_cf_health_failed', 'Worker responded, but D1, R2 or Queue binding verification did not pass.');
    }
    return $body;
}

/**
 * Explicit archive helper for background/admin jobs only.
 * Callers must enqueue/defer this; never call inline in customer or agent message requests.
 */
function hck_cf_archive_record($record_type, $source_id, $payload, $idempotency_key, $metadata = array()) {
    if (!hck_cf_is_configured()) return new WP_Error('hck_cf_not_configured', 'Cloudflare archive is not configured.');
    $record_type = sanitize_key($record_type);
    $source_id = (string) $source_id;
    if (!$record_type || !preg_match('/^[a-zA-Z0-9._:-]{1,160}$/', $source_id) || !preg_match('/^[a-zA-Z0-9._:-]{1,160}$/', (string) $idempotency_key)) {
        return new WP_Error('hck_cf_invalid_record', 'Invalid archive record identifiers.');
    }
    $response = wp_remote_post(hck_cf_worker_url('v1/archive'), array(
        'timeout' => 12,
        'redirection' => 0,
        'headers' => array(
            'Authorization' => 'Bearer ' . hck_cf_get_api_secret(),
            'Content-Type' => 'application/json',
            'Idempotency-Key' => (string) $idempotency_key,
        ),
        'body' => wp_json_encode(array(
            'record_type' => $record_type,
            'source_id' => $source_id,
            'payload' => $payload,
            'metadata' => is_array($metadata) ? $metadata : array(),
        )),
    ));
    if (is_wp_error($response)) return $response;
    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if ($code < 200 || $code >= 300 || empty($body['ok'])) return new WP_Error('hck_cf_archive_failed', 'Cloudflare archive request failed.', array('status' => $code));
    return $body;
}


/** Queue an archive job for background processing. Use from deferred jobs, never inline in message requests. */
function hck_cf_enqueue_archive_record($record_type, $source_id, $payload, $idempotency_key, $metadata = array()) {
    if (!hck_cf_is_configured()) return new WP_Error('hck_cf_not_configured', 'Cloudflare archive is not configured.');
    $record_type = sanitize_key($record_type);
    $source_id = (string) $source_id;
    $idempotency_key = (string) $idempotency_key;
    if (!preg_match('/^[a-z][a-z0-9_-]{1,40}$/', $record_type) || !preg_match('/^[a-zA-Z0-9._:-]{1,160}$/', $source_id) || !preg_match('/^[a-zA-Z0-9._:-]{1,160}$/', $idempotency_key)) {
        return new WP_Error('hck_cf_invalid_record', 'Invalid archive record identifiers.');
    }
    $result = wp_remote_post(hck_cf_worker_url('v1/archive/async'), array(
        'timeout' => 8, 'redirection' => 0,
        'headers' => array('Authorization' => 'Bearer ' . hck_cf_get_api_secret(), 'Content-Type' => 'application/json', 'Idempotency-Key' => $idempotency_key),
        'body' => wp_json_encode(array('record_type' => $record_type, 'source_id' => $source_id, 'payload' => $payload, 'metadata' => is_array($metadata) ? $metadata : array())),
    ));
    if (is_wp_error($result)) return $result;
    $code = wp_remote_retrieve_response_code($result);
    $body = json_decode(wp_remote_retrieve_body($result), true);
    if ($code !== 202 || empty($body['ok'])) return new WP_Error('hck_cf_enqueue_failed', 'Cloudflare did not accept the archive job.', array('status' => $code));
    return $body;
}


add_action('wp_ajax_hck_cf_health_check', function () {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Unauthorized.'), 403);
    }

    check_ajax_referer('hck_nonce', 'nonce');

    $result = hck_cf_health_check();

    if (is_wp_error($result)) {
        wp_send_json_error(array(
            'message' => $result->get_error_message()
        ), 503);
    }

    wp_send_json_success(array(
        'message' => 'Cloudflare health checks passed.',
        'details' => array(
            'worker' => 'Responding',
            'd1' => sanitize_text_field($result['d1']),
            'r2' => sanitize_text_field($result['r2']),
            'queue_binding' => !empty($result['queue_binding'])
                ? 'Available'
                : 'Missing'
        )
    ));
});
