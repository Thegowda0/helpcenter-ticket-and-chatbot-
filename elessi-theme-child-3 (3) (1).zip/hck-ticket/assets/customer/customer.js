/**
 * HCK Ticket System - Customer JS v5.0
 */
(function() {
    'use strict';

    var data = window.hckData || {};
    var hckRealtimeConnection = null, hckRealtimeConnectPromise = null, hckRealtimeConnected = false;
    var hckCustomerThread = document.querySelector('.hck-admin-thread');
    var hckCustomerAfterId = hckCustomerThread ? Number(hckCustomerThread.getAttribute('data-after-id') || 0) : 0;
    var hckCustomerPollBusy = false, hckCustomerPollTimer = null;
    function hckCustomerRenderIncoming(message) {
        if (!hckCustomerThread || !message || message.is_internal || message.sender_type !== 'agent') return;
        var clientId = String(message.client_message_id || ''), id = Number(message.id) || 0;
        var existing = clientId ? hckCustomerThread.querySelector('[data-client-message-id="' + CSS.escape(clientId) + '"]') : null;
        if (existing) { if (id) { existing.id='msg-'+id; existing.setAttribute('data-message-id',String(id)); } hckCustomerAfterId=Math.max(hckCustomerAfterId,id); return; }
        if (id && document.getElementById('msg-' + id)) return;
        var empty = hckCustomerThread.querySelector('.hck-empty-mini'); if (empty) empty.remove();
        var row = document.createElement('div'); row.className = 'hck-admin-msg hck-admin-msg-admin';
        if (id) { row.id = 'msg-' + id; row.setAttribute('data-message-id', String(id)); }
        if (clientId) row.setAttribute('data-client-message-id', clientId);
        var avatar = document.createElement('div'); avatar.className = 'hck-admin-msg-avatar';
        var icon = document.createElement('i'); icon.className = 'fas fa-headset'; avatar.appendChild(icon);
        var content = document.createElement('div'); content.className = 'hck-admin-msg-content';
        var head = document.createElement('div'); head.className = 'hck-admin-msg-head';
        var name = document.createElement('strong'); name.textContent = message.sender_name || 'Support';
        var time = document.createElement('span'); time.className = 'hck-msg-time'; time.textContent = message.created_at || 'Just now';
        head.appendChild(name); head.appendChild(time);
        var body = document.createElement('div'); body.className = 'hck-admin-msg-body';
        var text = document.createElement('div'); text.className = 'hck-msg-text'; text.textContent = message.content || ''; body.appendChild(text);
        (message.attachments || []).forEach(function (att) { if (!att.url) return; var link = document.createElement('a'); link.className = 'hck-file-link'; link.href = att.url; link.target = '_blank'; link.rel = 'noopener'; link.textContent = att.name || 'Attachment'; body.appendChild(link); });
        content.appendChild(head); content.appendChild(body); row.appendChild(avatar); row.appendChild(content); hckCustomerThread.appendChild(row);
        hckCustomerAfterId = Math.max(hckCustomerAfterId, id); hckCustomerThread.scrollTop = hckCustomerThread.scrollHeight;
    }
    function hckCustomerReceive(event, eventName, channelName) {
        if (eventName !== 'hck.message' || channelName !== 'hck-agent-' + Number(data.ticketId || 0)) return;
        hckCustomerRenderIncoming(event && event.message);
    }
    if (data.ticketId && data.realtimeEnabled && window.HCRealtimeClient && window.Ably) {
        hckRealtimeConnectPromise = window.HCRealtimeClient.connect({ajaxUrl:data.ajaxUrl,nonce:data.nonce,channelType:'hck_ticket',ticketId:Number(data.ticketId)},hckCustomerReceive,function(state){
            hckRealtimeConnected = state === 'connected';
            hckCustomerConfigurePolling();
            if (window.console && console.debug) console.debug('[HCK Ably] Customer ticket realtime:', state);
        }).then(function(connection){ hckRealtimeConnection=connection; hckRealtimeConnected=true; hckCustomerConfigurePolling(); return connection; }).catch(function(error){ hckRealtimeConnected=false; console.warn('[HCK Ably] Customer ticket realtime unavailable; using save fallback/recovery.',error); return null; });
    }
    function hckCustomerPublish(message) {
        if (!hckRealtimeConnectPromise) return Promise.resolve(false);
        return hckRealtimeConnectPromise.then(function(connection){
            if (!connection || message._hcPublishCancelled) return false;
            var publicMessage = Object.assign({}, message); delete publicMessage._hcPublishCancelled;
            return connection.publishTo('hck-customer-' + Number(data.ticketId), 'hck.message', {ticket_id:Number(data.ticketId),message:publicMessage}).then(function(){ return true; }).catch(function(error){ console.warn('[HCK Ably] Customer direct publish failed.',error); return false; });
        }).catch(function(){ return false; });
    }
    function hckCustomerServerRelay(message) {
        var fd = new FormData(); fd.append('action','hck_publish_realtime_message'); fd.append('nonce',data.nonce || '');
        fd.append('ticket_id',String(data.ticketId)); fd.append('client_message_id',String(message.client_message_id)); fd.append('message',String(message.content || ''));
        return fetch(data.ajaxUrl,{method:'POST',body:fd,credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json();}).then(function(r){if(!r || !r.success) throw new Error(r && r.data && r.data.message || 'Realtime server relay failed.'); console.info('[HCK Realtime] Customer pre-save relay acknowledged.',{ticket_id:data.ticketId,client_message_id:message.client_message_id}); return true;}).catch(function(error){console.warn('[HCK Realtime] Customer relay failed; database recovery remains available.',error); return false;});
    }
    function hckCustomerDeliver(message) {
        // Do not race/cancel the browser publish after 650ms. On a page refresh,
        // Ably may still be completing its token/connection handshake. Keep that
        // publish alive while the permanent transcript save proceeds independently.
        return hckCustomerPublish(message).then(function(delivered){
            if (delivered) {
                if (window.console && console.info) console.info('[HCK Ably] Customer message delivered directly.', {ticket_id:data.ticketId,client_message_id:message.client_message_id});
                return true;
            }
            // Only use the server relay after the direct browser path has actually
            // failed. This fallback also runs independently of the DB save request.
            return hckCustomerServerRelay(message);
        }).catch(function(error){
            console.warn('[HCK Ably] Customer direct delivery failed; trying server relay.', error);
            return hckCustomerServerRelay(message);
        });
    }
    function hckCustomerConfigurePolling() {
        if (hckCustomerPollTimer) window.clearInterval(hckCustomerPollTimer);
        hckCustomerPollTimer = null;
        if (!hckCustomerThread || !data.ticketId) return;
        hckCustomerPollTimer = window.setInterval(hckCustomerPoll, hckRealtimeConnected ? 30000 : 1800);
    }
    function hckCustomerPoll() {
        if (!hckCustomerThread || hckCustomerPollBusy || document.hidden || !data.ticketId) return;
        hckCustomerPollBusy = true;
        var fd = new FormData(); fd.append('action','hck_poll_new_messages'); fd.append('nonce',data.nonce || ''); fd.append('ticket_id',String(data.ticketId)); fd.append('after_id',String(hckCustomerAfterId));
        fetch(data.ajaxUrl,{method:'POST',body:fd,credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json();}).then(function(r){ if(!r || !r.success || !r.data) return; (r.data.messages||[]).forEach(hckCustomerRenderIncoming); hckCustomerAfterId=Math.max(hckCustomerAfterId,Number(r.data.last_id)||0); }).catch(function(){}).finally(function(){hckCustomerPollBusy=false;});
    }
    if (hckCustomerThread && data.ticketId) hckCustomerConfigurePolling();
    document.addEventListener('visibilitychange',function(){if(!document.hidden)hckCustomerPoll();});

    // =============================================
    // TOAST
    // =============================================
    function toast(msg, type) {
        type = type || 'success';
        var colors = { success: '#10B981', error: '#EF4444', info: '#3B82F6' };
        var icons  = { success: 'check-circle', error: 'exclamation-circle', info: 'info-circle' };
        var el = document.createElement('div');
        el.style.cssText = 'position:fixed;bottom:100px;left:50%;transform:translateX(-50%);padding:14px 24px;background:' + (colors[type] || colors.info) + ';color:#fff;border-radius:12px;font-size:14px;font-weight:600;z-index:99999;box-shadow:0 10px 30px rgba(0,0,0,0.25);display:flex;gap:8px;align-items:center;max-width:90%;';
        el.innerHTML = '<i class="fas fa-' + (icons[type] || 'info-circle') + '"></i> ' + msg;
        document.body.appendChild(el);
        setTimeout(function() {
            el.style.transition = 'opacity 0.3s';
            el.style.opacity = '0';
            setTimeout(function() { el.remove(); }, 300);
        }, 3000);
    }

    // =============================================
    // AJAX HELPER
    // =============================================
    function ajax(action, formData, onSuccess, onError) {
        formData = formData || new FormData();
        formData.append('action', action);
        formData.append('nonce', data.nonce);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', data.ajaxUrl, true);
        xhr.onload = function() {
            try {
                var res = JSON.parse(xhr.responseText);
                if (res.success) {
                    if (onSuccess) onSuccess(res.data);
                } else {
                    var err = res.data || { message: 'Error' };
                    if (onError) onError(err);
                    else toast(err.message || 'Error', 'error');
                }
            } catch (e) {
                if (onError) onError({ message: 'Invalid server response' });
                else toast('Server error', 'error');
            }
        };
        xhr.onerror = function() {
            if (onError) onError({ message: 'Network error' });
            else toast('Network error', 'error');
        };
        xhr.send(formData);
    }

    // =============================================
    // REPLY FORM — pre-upload files
    // =============================================
    var replyFiles = [];

    window.hckAddReplyFiles = function(input) {
        if (!input || !input.files) return;
        for (var i = 0; i < input.files.length; i++) {
            var f = input.files[i];
            if (f.size > 10485760) { toast('File "' + f.name + '" exceeds 10MB', 'error'); continue; }
            var dup = false;
            for (var j = 0; j < replyFiles.length; j++) {
                if (replyFiles[j].name === f.name && replyFiles[j].size === f.size) { dup = true; break; }
            }
            if (dup) continue;
            var item = { id: null, name: f.name, size: f.size, status: 'uploading', pct: 0, file: f };
            replyFiles.push(item);
            startUpload(item, 'reply');
        }
        renderFiles('reply');
        input.value = '';
    };

    function startUpload(item, context) {
        var fd = new FormData();
        fd.append('action', 'hck_upload_temp');
        fd.append('nonce', data.nonce);
        fd.append('ticket_id', data.ticketId || 0);
        fd.append('file', item.file);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', data.ajaxUrl, true);
        xhr.upload.addEventListener('progress', function(ev) {
            if (ev.lengthComputable && ev.total > 0) {
                item.pct = Math.min(99, Math.round((ev.loaded / ev.total) * 100));
            } else {
                item.pct = Math.max(item.pct, 20);
            }
            renderFiles(context);
        });
        xhr.onload = function() {
            try {
                var res = JSON.parse(xhr.responseText);
                if (res.success && res.data && res.data.attachment_id) {
                    item.id = res.data.attachment_id;
                    item.status = 'done';
                    item.pct = 100;
                } else {
                    item.status = 'error';
                    item.errorMessage = (res.data && res.data.message) || 'Upload failed';
                }
            } catch (e) {
                item.status = 'error';
                item.errorMessage = 'Server error';
            }
            renderFiles(context);
        };
        xhr.onerror = function() {
            item.status = 'error';
            item.errorMessage = 'Network error';
            renderFiles(context);
        };
        xhr.send(fd);
    }

    function renderFiles(context) {
        var list, items;
        if (context === 'reply') {
            list = document.getElementById('hckReplyFiles');
            items = replyFiles;
        } else {
            list = document.getElementById('hckFileList');
            items = createFiles;
        }
        if (!list) return;
        list.innerHTML = '';
        for (var i = 0; i < items.length; i++) {
            (function(idx) {
                var item = items[idx];
                var row = document.createElement('div');
                row.className = 'hck-reply-file-chip' + (item.status === 'error' ? ' is-error' : '');
                var statusHtml = '';
                if (item.status === 'uploading') {
                    statusHtml = '<div class="hck-chip-progress"><div class="hck-chip-progress-fill" style="width:' + item.pct + '%"></div></div>';
                } else if (item.status === 'done') {
                    statusHtml = '<i class="fas fa-check-circle hck-chip-done"></i>';
                } else if (item.status === 'error') {
                    statusHtml = '<i class="fas fa-exclamation-circle hck-chip-error" title="' + (item.errorMessage || 'Error') + '"></i>';
                }
                row.innerHTML =
                    '<i class="fas fa-paperclip"></i>' +
                    '<span class="hck-reply-file-chip-name">' + item.name + ' (' + (item.size / 1048576).toFixed(2) + ' MB)</span>' +
                    statusHtml +
                    '<button type="button" class="hck-reply-file-chip-remove" title="Remove">&times;</button>';
                row.querySelector('.hck-reply-file-chip-remove').addEventListener('click', function(e) {
                    e.preventDefault();
                    items.splice(idx, 1);
                    renderFiles(context);
                });
                list.appendChild(row);
            })(i);
        }
    }

    // Reply form: each text message gets its own request and idempotency key.
    // A slow save never disables the composer for the next message.
    var replyForm = document.getElementById('hckReplyForm');
    if (replyForm) {
        var replyTextarea = document.getElementById('hckReplyText');
        var replyButton = document.getElementById('hckReplyBtn');
        var hckPendingReplies = Object.create(null);
        var hckReplyPersistenceQueue = Promise.resolve();
        var replyThread = document.querySelector('.hck-admin-thread');
        window.addEventListener('beforeunload', function (e) {
            if (Object.keys(hckPendingReplies).length) { e.preventDefault(); e.returnValue = ''; }
        });
        function newReplyId() {
            if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
            return 'hck-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
        }
        function addPendingReply(entry) {
            if (!replyThread) return null;
            var empty = replyThread.querySelector('.hck-empty-mini');
            if (empty) empty.remove();
            var row = document.createElement('div');
            row.className = 'hck-admin-msg hck-admin-msg-customer hck-pending-reply';
            row.setAttribute('data-client-message-id', entry.clientId);
            var avatar = document.createElement('div');
            avatar.className = 'hck-admin-msg-avatar';
            avatar.textContent = 'Y';
            var content = document.createElement('div');
            content.className = 'hck-admin-msg-content';
            var head = document.createElement('div');
            head.className = 'hck-admin-msg-head';
            var who = document.createElement('strong');
            who.textContent = 'You';
            var time = document.createElement('span');
            time.className = 'hck-msg-time hck-reply-save-state';
            time.textContent = 'Sending…';
            head.appendChild(who);
            head.appendChild(time);
            var body = document.createElement('div');
            body.className = 'hck-admin-msg-body';
            var text = document.createElement('div');
            text.className = 'hck-msg-text';
            text.textContent = entry.message;
            body.appendChild(text);
            content.appendChild(head);
            content.appendChild(body);
            row.appendChild(avatar);
            row.appendChild(content);
            replyThread.appendChild(row);
            row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
            return row;
        }
        function setReplyState(entry, label, failed) {
            var row = entry.node || (replyThread && replyThread.querySelector('[data-client-message-id="' + CSS.escape(entry.clientId) + '"]'));
            if (!row) return;
            var status = row.querySelector('.hck-reply-save-state');
            if (status) status.textContent = label;
            row.classList.toggle('hck-reply-save-failed', !!failed);
            var retry = row.querySelector('.hck-reply-retry');
            if (failed && !retry) {
                retry = document.createElement('button');
                retry.type = 'button';
                retry.className = 'hck-reply-retry';
                retry.textContent = 'Retry saving';
                retry.addEventListener('click', function () { sendHckReply(entry); });
                row.querySelector('.hck-admin-msg-body').appendChild(retry);
            } else if (!failed && retry) retry.remove();
        }
        function sendHckReply(entry) {
            if (!entry || entry.saving) return;
            entry.saving = true;
            setReplyState(entry, 'Saving…', false);
            var formData = new FormData();
            formData.append('action', 'hck_send_reply');
            formData.append('nonce', data.nonce);
            formData.append('ticket_id', String(data.ticketId || replyForm.querySelector('[name="ticket_id"]').value));
            formData.append('message', entry.message);
            formData.append('client_message_id', entry.clientId);
            formData.append('uploaded_file_ids', JSON.stringify(entry.fileIds || []));
            var xhr = new XMLHttpRequest();
            xhr.open('POST', data.ajaxUrl, true);
            xhr.timeout = 60000;
            xhr.onload = function () {
                var res = null;
                try { res = JSON.parse(xhr.responseText); } catch (e) {}
                entry.saving = false;
                if (xhr.status >= 200 && xhr.status < 300 && res && res.success) {
                    var messageId = Number(res.data && res.data.message_id) || 0;
                    if (messageId && entry.node) entry.node.id = 'msg-' + messageId;
                    setReplyState(entry, 'Saved', false);
                    delete hckPendingReplies[entry.clientId];
                } else {
                    setReplyState(entry, (res && res.data && res.data.message) || 'Save failed · retry', true);
                    console.warn('[HCK] Customer reply save failed; retry is available.', {
                        ticket_id: data.ticketId || 0,
                        client_message_id: entry.clientId,
                        http_status: xhr.status
                    });
                }
            };
            xhr.onerror = function () {
                entry.saving = false;
                setReplyState(entry, 'Network error · retry', true);
            };
            xhr.ontimeout = function () {
                entry.saving = false;
                setReplyState(entry, 'Timed out · retry', true);
            };
            // Persist immediately and independently. The Ably publish started
            // above continues in parallel; never make the customer wait for the
            // token handshake or publish acknowledgement before saving the row.
            // Mark that realtime was attempted so PHP does not issue a duplicate
            // post-save event. hckCustomerDeliver performs its own server-relay
            // fallback if the direct browser publish fails.
            var queuedRequest = hckReplyPersistenceQueue.catch(function () {}).then(function () {
                formData.append('realtime_attempted', entry.fileIds.length ? '0' : '1');
                formData.append('realtime_delivered', '0');
                return new Promise(function (resolve) {
                    ['onload', 'onerror', 'ontimeout', 'onabort'].forEach(function (name) {
                        var handler = xhr[name];
                        xhr[name] = function (event) {
                            try { if (typeof handler === 'function') handler.call(xhr, event); }
                            finally { resolve(); }
                        };
                    });
                    try { xhr.send(formData); }
                    catch (error) {
                        entry.saving = false;
                        setReplyState(entry, 'Could not send · retry', true);
                        resolve();
                    }
                });
            });
            hckReplyPersistenceQueue = queuedRequest.catch(function () {});
        }
        replyForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var message = (replyTextarea && replyTextarea.value || '').trim();
            if (!message) { if (replyTextarea) replyTextarea.focus(); return; }
            var uploading = replyFiles.filter(function (f) { return f.status === 'uploading'; });
            if (uploading.length > 0) { toast('Please wait for files to finish uploading', 'info'); return; }
            var failedFiles = replyFiles.filter(function (f) { return f.status === 'error'; });
            if (failedFiles.length > 0) { toast('Remove failed attachments or upload them again.', 'error'); return; }
            var fileIds = replyFiles.filter(function (f) { return f.status === 'done' && f.id; }).map(function (f) { return f.id; });
            var entry = { clientId: newReplyId(), message: message, fileIds: fileIds, saving: false, node: null };
            entry.directPromise = fileIds.length ? Promise.resolve(false) : hckCustomerDeliver({client_message_id:entry.clientId,sender_type:'customer',sender_name:'You',content:message,created_at:new Date().toISOString(),attachments:[]});
            entry.node = addPendingReply(entry);
            hckPendingReplies[entry.clientId] = entry;
            if (replyTextarea) { replyTextarea.value = ''; replyTextarea.style.height = 'auto'; }
            // Detach the files from this message so the next text reply can be sent
            // while this one is being saved. Files are never shared between messages.
            replyFiles = [];
            renderFiles('reply');
            if (replyButton) {
                replyButton.disabled = false;
                replyButton.innerHTML = '<i class="fas fa-paper-plane"></i> Send Reply';
            }
            sendHckReply(entry);
        });
    }

    // Scroll to reply after reload
    (function() {
        try {
            if (sessionStorage.getItem('hck_scroll_to_reply') === '1') {
                sessionStorage.removeItem('hck_scroll_to_reply');
                var el = document.getElementById('hckReplyForm');
                if (el) setTimeout(function() {
                    var y = el.getBoundingClientRect().top + window.pageYOffset - 80;
                    window.scrollTo({ top: y, behavior: 'instant' });
                }, 80);
            }
        } catch (e) {}
    })();

    // =============================================
    // CREATE TICKET FORM
    // =============================================
    var createFiles = [];
    var createForm = document.getElementById('hckCreateForm');
    if (createForm) {
        var selectedOrders = [];
        var fileInput = document.getElementById('hckFileInput');
        var fileList  = document.getElementById('hckFileList');
        var dropzone  = document.getElementById('hckDropzone');

        // File input change
        if (fileInput) {
            fileInput.addEventListener('change', function() {
                if (!this.files) return;
                for (var i = 0; i < this.files.length; i++) {
                    var f = this.files[i];
                    if (f.size > 10485760) { toast('File "' + f.name + '" exceeds 10MB', 'error'); continue; }
                    var dup = false;
                    for (var j = 0; j < createFiles.length; j++) {
                        if (createFiles[j].name === f.name && createFiles[j].size === f.size) { dup = true; break; }
                    }
                    if (dup) continue;
                    var item = { id: null, name: f.name, size: f.size, status: 'uploading', pct: 0, file: f };
                    createFiles.push(item);
                    startUpload(item, 'create');
                }
                renderFiles('create');
                this.value = '';
            });
        }

        // Drag & drop
        if (dropzone) {
            ['dragenter', 'dragover'].forEach(function(evt) {
                dropzone.addEventListener(evt, function(e) { e.preventDefault(); dropzone.classList.add('dragover'); });
            });
            ['dragleave', 'drop'].forEach(function(evt) {
                dropzone.addEventListener(evt, function(e) { e.preventDefault(); dropzone.classList.remove('dragover'); });
            });
            dropzone.addEventListener('drop', function(e) {
                if (!e.dataTransfer.files.length || !fileInput) return;
                var dt = new DataTransfer();
                for (var i = 0; i < e.dataTransfer.files.length; i++) dt.items.add(e.dataTransfer.files[i]);
                fileInput.files = dt.files;
                fileInput.dispatchEvent(new Event('change'));
            });
        }

        // Order selection
        window.hckToggleOrder = function(orderId, el) {
            var idx = selectedOrders.indexOf(orderId);
            if (idx === -1) { selectedOrders.push(orderId); el.classList.add('selected'); }
            else { selectedOrders.splice(idx, 1); el.classList.remove('selected'); }
            renderSelectedOrderTags();
            var inp = document.getElementById('hckOrdersInput');
            if (inp) inp.value = JSON.stringify(selectedOrders);
        };

        window.hckRemoveOrder = function(orderId) {
            var idx = selectedOrders.indexOf(orderId);
            if (idx > -1) selectedOrders.splice(idx, 1);
            var card = document.querySelector('.hck-order-card[data-order-id="' + orderId + '"]');
            if (card) card.classList.remove('selected');
            renderSelectedOrderTags();
            var inp = document.getElementById('hckOrdersInput');
            if (inp) inp.value = JSON.stringify(selectedOrders);
        };

        function renderSelectedOrderTags() {
            var container = document.getElementById('hckSelectedOrders');
            var counter = document.getElementById('hckOrderCount');
            if (!container) return;
            if (selectedOrders.length === 0) {
                container.innerHTML = '';
                if (counter) { counter.textContent = '0 selected'; counter.classList.remove('has-selection'); }
                return;
            }
            var html = '<span class="hck-selected-orders-label">Selected:</span>';
            selectedOrders.forEach(function(id) {
                html += '<span class="hck-selected-order-tag">Order #' + id + ' <button type="button" onclick="event.stopPropagation();hckRemoveOrder(' + id + ')">&times;</button></span>';
            });
            container.innerHTML = html;
            if (counter) { counter.textContent = selectedOrders.length + ' selected'; counter.classList.add('has-selection'); }
        }

        // Submit
        createForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var uploading = createFiles.filter(function(f) { return f.status === 'uploading'; });
            if (uploading.length > 0) { toast('Please wait for files to finish uploading', 'info'); return; }

            var btn = document.getElementById('hckSubmitBtn');
            if (!btn) return;
            var orig = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            btn.disabled = true;

            var fileIds = createFiles.filter(function(f) { return f.status === 'done' && f.id; }).map(function(f) { return f.id; });
            var formData = new FormData(createForm);
            formData.set('orders', JSON.stringify(selectedOrders));
            formData.append('uploaded_file_ids', JSON.stringify(fileIds));

            ajax('hck_create_ticket', formData, function(res) {
                toast('Ticket created!');
                setTimeout(function() { window.location.href = res.redirect; }, 500);
            }, function(err) {
                toast(err.message || 'Error', 'error');
                btn.innerHTML = orig;
                btn.disabled = false;
            });
        });
    }

    // =============================================
    // RATE FORM
    // =============================================
    var stars = document.querySelectorAll('.hck-star');
    if (stars.length) {
        stars.forEach(function(s) {
            s.addEventListener('click', function() {
                var rating = parseInt(this.getAttribute('data-rating'));
                var inp = document.getElementById('hckRatingValue');
                if (inp) inp.value = rating;
                stars.forEach(function(st) {
                    st.classList.toggle('active', parseInt(st.getAttribute('data-rating')) <= rating);
                });
            });
        });
    }

    var rateForm = document.getElementById('hckRateForm');
    if (rateForm) {
        rateForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var ratingEl = document.getElementById('hckRatingValue');
            var rating = ratingEl ? ratingEl.value : 0;
            if (!rating || rating === '0') { toast('Please select a rating', 'error'); return; }
            var btn = this.querySelector('button[type="submit"]');
            if (!btn) return;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            btn.disabled = true;
            var formData = new FormData(rateForm);
            ajax('hck_rate_ticket', formData, function() {
                toast('Thank you!');
                setTimeout(function() { location.reload(); }, 800);
            }, function(err) {
                toast(err.message || 'Error', 'error');
                btn.disabled = false;
            });
        });
    }

})();
