/**
 * HCK Ticket System - Admin JS
 */
(function() {
    'use strict';
    
    var data = window.hckData || {};
    var hckAdminRealtimeConnection = null, hckAdminRealtimeConnectPromise = null, hckAdminRealtimeConnected = false;
    var hckAdminThread = document.getElementById('hckAdminTicketThread');
    var hckAdminAfterId = hckAdminThread ? Number(hckAdminThread.getAttribute('data-after-id') || 0) : 0;
    var hckAdminPollBusy = false, hckAdminPollTimer = null;
    function hckAdminEscape(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]); }); }
    var hckAgentAlertMuted = false, hckAgentAlertVolume = Math.max(0, Math.min(1, Number(data.alertVolume) || 0.9));
    var hckAgentAlertUnlocked = false, hckAgentAudio = null;
    var hckAgentMutedKey = 'hc_agent_alert_muted_' + String(data.userId || 'agent');
    var hckAgentVolumeKey = 'hc_agent_alert_volume_' + String(data.userId || 'agent');
    try { hckAgentAlertMuted = localStorage.getItem(hckAgentMutedKey) === '1'; var savedVolume = localStorage.getItem(hckAgentVolumeKey); if (savedVolume !== null) hckAgentAlertVolume = Math.max(0, Math.min(1, Number(savedVolume) || 0)); } catch (e) {}
    function hckAgentUnlockAudio() { hckAgentAlertUnlocked = true; try { var C=window.AudioContext||window.webkitAudioContext; if(C&&!hckAgentAudio)hckAgentAudio=new C(); if(hckAgentAudio&&hckAgentAudio.state==='suspended')hckAgentAudio.resume(); } catch(e) {} }
    function hckAgentPlayAlert() {
        if (data.alertsEnabled === false || hckAgentAlertMuted || !hckAgentAlertUnlocked || hckAgentAlertVolume <= 0) return;
        try { var C=window.AudioContext||window.webkitAudioContext; if(!C)return; if(!hckAgentAudio)hckAgentAudio=new C(); var c=hckAgentAudio; if(c.state==='suspended')c.resume();
            var sounds={urgent:[1046,1318,1568,1318,1046],bell:[660,990,1320,990],classic:[988,784,988,784,1318],digital:[784,784,1174,784],chime:[880,1174,1568],soft:[523,659,784]}; var name=String(data.alertSound||'urgent'),notes=sounds[name]||sounds.urgent,base=c.currentTime;
            notes.forEach(function(hz,i){var o=c.createOscillator(),g=c.createGain(),at=base+i*.16;o.type=name==='digital'?'square':'sine';o.frequency.setValueAtTime(hz,at);g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(Math.max(.01,hckAgentAlertVolume)*.85,at+.018);g.gain.exponentialRampToValueAtTime(.0001,at+.24);o.connect(g);g.connect(c.destination);o.start(at);o.stop(at+.26);});
        } catch(e) { /* Browser audio is optional; transcript remains authoritative. */ }
    }
    function hckInitHeaderAlerts() {
        var host=document.getElementById('hckHeaderAlertControl'),toggle=document.getElementById('hckHeaderAlertToggle'),panel=document.getElementById('hckHeaderAlertPanel'); if(!host||!toggle||!panel)return;
        var enabled=document.getElementById('hckHeaderAlertEnabled'),volume=document.getElementById('hckHeaderAlertVolume'),output=document.getElementById('hckHeaderAlertVolumeValue'),status=document.getElementById('hckHeaderAlertStatus');
        enabled.checked=!hckAgentAlertMuted; enabled.disabled=data.alertsEnabled===false; volume.value=String(hckAgentAlertVolume); output.value=Math.round(hckAgentAlertVolume*100)+'%';
        status.textContent=data.alertsEnabled===false?'Sound alerts are disabled by the site administrator.':'Administrator sound: '+String(data.alertSound||'urgent')+'. Your mute and volume preference applies to this agent in this browser.';
        toggle.addEventListener('click',function(){hckAgentUnlockAudio();panel.hidden=!panel.hidden;toggle.setAttribute('aria-expanded',panel.hidden?'false':'true');});
        enabled.addEventListener('change',function(){hckAgentAlertMuted=!enabled.checked;try{localStorage.setItem(hckAgentMutedKey,hckAgentAlertMuted?'1':'0')}catch(e){}});
        volume.addEventListener('input',function(){hckAgentAlertVolume=Math.max(0,Math.min(1,Number(volume.value)||0));output.value=Math.round(hckAgentAlertVolume*100)+'%';try{localStorage.setItem(hckAgentVolumeKey,String(hckAgentAlertVolume))}catch(e){}});
        document.getElementById('hckHeaderAlertTest').addEventListener('click',function(){hckAgentUnlockAudio();if(data.alertsEnabled!==false&&!hckAgentAlertMuted)hckAgentPlayAlert();});
        document.getElementById('hckHeaderAlertClose').addEventListener('click',function(){panel.hidden=true;toggle.setAttribute('aria-expanded','false');});
        document.addEventListener('click',hckAgentUnlockAudio,{once:true});
        function moveFloatingAlerts(){var moved=false;document.querySelectorAll('button,a,[role="button"],[onclick]').forEach(function(el){if(el===toggle||host.contains(el)||el.classList.contains('hck-alerts-moved-to-header'))return;var label=String(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim();if(!/^(?:🔔\s*)?Alerts$/i.test(label))return;if(window.getComputedStyle(el).position!=='fixed')return;el.classList.add('hck-alerts-moved-to-header');['position','right','left','top','bottom','inset','z-index','transform','margin','box-shadow'].forEach(function(k){el.style.removeProperty(k)});el.style.setProperty('position','static','important');el.style.setProperty('inset','auto','important');el.style.setProperty('margin','0 8px 0 0','important');el.style.setProperty('z-index','auto','important');host.parentNode.insertBefore(el,host);moved=true;});return moved;}
        if(!moveFloatingAlerts()&&!window.__hckAlertsObserver){var observer=new MutationObserver(function(){if(moveFloatingAlerts()){observer.disconnect();window.__hckAlertsObserver=null;}});window.__hckAlertsObserver=observer;observer.observe(document.body,{childList:true,subtree:true});window.setTimeout(function(){if(window.__hckAlertsObserver===observer){observer.disconnect();window.__hckAlertsObserver=null;}},10000);}
    }
    hckInitHeaderAlerts();
    function hckAdminEnhanceHandoff(card) {
        if (!card || card.dataset.rendered === '1') return;
        var rawNode = card.querySelector('.hck-handoff-brief-raw');
        var target = card.querySelector('.hck-handoff-brief-rendered');
        if (!rawNode || !target) return;
        var raw = String(rawNode.textContent || '').replace(/\r/g, '').trim();
        var lines = raw.split('\n'), meta = {}, sections = {}, current = '';
        var headings = {
            'CUSTOMER’S ORIGINAL CONCERN':'concern', "CUSTOMER'S ORIGINAL CONCERN":'concern',
            'CONVERSATION BACKGROUND':'background','LATEST CUSTOMER UPDATE':'customer',
            'LATEST HUMAN-AGENT UPDATE':'agent','EXISTING AI CONVERSATION SUMMARY':'ai'
        };
        lines.forEach(function(line,index){
            var t=String(line||'').trim(), upper=t.toUpperCase();
            if (index===0 && /HELPCENTER HANDOFF BRIEF/i.test(t)) return;
            if (!current) {
                var m=t.match(/^(Source conversation|Customer|Transferred by|Transferred at|Handoff reason):\s*(.*)$/i);
                if(m){meta[m[1].toLowerCase()]=m[2];return;}
            }
            if (headings[upper]) { current=headings[upper]; sections[current]=[]; return; }
            if(current) sections[current].push(t);
        });
        Object.keys(sections).forEach(function(k){sections[k]=sections[k].join('\n').trim();});
        var bg=sections.background||'', statLine=(bg.match(/Customer messages:\s*\d+[^\n]*/i)||[])[0]||'';
        var statsMatch=statLine.match(/Customer messages:\s*(\d+)\s*·\s*AI replies:\s*(\d+)\s*·\s*Human-agent replies:\s*(\d+)\s*·\s*Private notes:\s*(\d+)\s*·\s*System events:\s*(\d+)/i);
        var stats=statsMatch?[['Customer',statsMatch[1]],['AI replies',statsMatch[2]],['Agent replies',statsMatch[3]],['Private notes',statsMatch[4]],['System events',statsMatch[5]]]:[];
        bg=bg.replace(/^Customer messages:.*\n?/i,'').replace(/The complete imported AI and human-support transcript[\s\S]*$/i,'').trim();
        function section(title,icon,body,extra){if(!body)return '';return '<section class="hck-handoff-section '+(extra||'')+'"><h4><i class="fas '+icon+'"></i>'+hckAdminEscape(title)+'</h4><p>'+hckAdminEscape(body)+'</p></section>';}
        function formatHandoffSummary(value){
            var lines=String(value||'').replace(/\r/g,'').split('\n'),out=[],listOpen=false;
            function inline(text){return hckAdminEscape(text).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/(^|[^*])\*([^*]+)\*($|[^*])/g,'$1<em>$2</em>').replace(/`([^`]+)`/g,'<code>$1</code>');}
            function closeList(){if(listOpen){out.push('</ul>');listOpen=false;}}
            lines.forEach(function(line){var t=String(line||'').trim();if(!t){closeList();return;}var h=t.match(/^(#{1,4})\s+(.+)$/);if(h){closeList();out.push('<h'+Math.min(4,h[1].length+1)+'>'+inline(h[2])+'</h'+Math.min(4,h[1].length+1)+'>');return;}var li=t.match(/^(?:[-*•])\s+(.+)$/);if(li){if(!listOpen){out.push('<ul>');listOpen=true;}out.push('<li>'+inline(li[1])+'</li>');return;}closeList();out.push('<p>'+inline(t)+'</p>');});closeList();return out.join('');
        }
        function metaItem(label,value,icon){if(!value)return '';return '<div class="hck-handoff-meta"><small><i class="fas '+icon+'"></i>'+hckAdminEscape(label)+'</small><strong>'+hckAdminEscape(value)+'</strong></div>';}
        var metaHtml=[metaItem('Source conversation',meta['source conversation'],'fa-comments'),metaItem('Customer',meta.customer,'fa-user'),metaItem('Transferred by',meta['transferred by'],'fa-user-check'),metaItem('Transferred at',meta['transferred at'],'fa-clock'),metaItem('Handoff reason',meta['handoff reason'],'fa-arrow-right-arrow-left')].join('');
        var statsHtml=stats.map(function(x){return '<div class="hck-handoff-stat"><strong>'+hckAdminEscape(x[1])+'</strong><small>'+hckAdminEscape(x[0])+'</small></div>';}).join('');
        var ai=sections.ai||'';var privacy='Private internal context for authorized support agents. This summary is not sent to the customer. The original message timeline remains preserved below.';
        target.innerHTML='<div class="hck-handoff-card"><header><div><strong><i class="fas fa-clipboard-check"></i> HelpCenter follow-up summary</strong><small>Context transferred from the original conversation</small></div><span>PRIVATE · AGENTS ONLY</span></header><div class="hck-handoff-meta-grid">'+metaHtml+'</div>'+section('Customer’s original concern','fa-circle-exclamation',sections.concern||'No separate detailed concern was recorded.','is-concern')+'<section class="hck-handoff-section"><h4><i class="fas fa-chart-simple"></i>Conversation background</h4>'+(statsHtml?'<div class="hck-handoff-stats">'+statsHtml+'</div>':'')+'<p>'+hckAdminEscape(bg||'The complete original conversation is preserved in the ticket history.')+'</p></section><div class="hck-handoff-grid">'+section('Latest customer update','fa-user',sections.customer||'No separate customer message was found.')+section('Latest human-agent update','fa-headset',sections.agent||'No human-agent reply was recorded before handoff.')+'</div>'+(ai?'<section class="hck-handoff-section is-ai-summary"><h4><i class="fas fa-wand-magic-sparkles"></i>Existing AI conversation summary</h4><div class="hck-handoff-richtext">'+formatHandoffSummary(ai)+'</div></section>':'')+'<div class="hck-handoff-private"><i class="fas fa-lock"></i>'+hckAdminEscape(privacy)+'</div></div>';
        card.dataset.rendered = '1';
    }
    function hckAdminReflowGroups() {
        if (!hckAdminThread) return;
        var previous = null;
        Array.prototype.forEach.call(hckAdminThread.querySelectorAll('.hck-admin-msg'), function (row) {
            var key = row.getAttribute('data-sender-key') || '', at = Date.parse(String(row.getAttribute('data-created-at') || '').replace(' ','T'));
            var grouped = false;
            if (previous && key && previous.key === key && Number.isFinite(at) && Number.isFinite(previous.at) && at >= previous.at && at - previous.at <= 300000) grouped = true;
            row.classList.toggle('is-grouped', grouped);
            previous = {key:key,at:at};
        });
    }
    function hckAdminEnhanceThread() {
        if (!hckAdminThread) return;
        hckAdminThread.querySelectorAll('[data-hck-handoff-brief]').forEach(hckAdminEnhanceHandoff);
        hckAdminReflowGroups();
    }
    function hckAdminAppendMessage(message) {
        if (!hckAdminThread || !message || message.is_internal) return;
        var clientId=String(message.client_message_id||''),id=Number(message.id)||0;
        var existing=clientId?hckAdminThread.querySelector('[data-client-message-id="'+CSS.escape(clientId)+'"]'):null;
        if(existing){if(id){existing.id='msg-'+id;existing.setAttribute('data-message-id',String(id));}if(message.created_at)existing.setAttribute('data-created-at',String(message.created_at).replace(' ','T'));if(message.user_id){existing.setAttribute('data-user-id',String(message.user_id));existing.setAttribute('data-sender-key',(String(message.sender_type||'customer')==='agent'?'agent':'customer')+':'+String(message.user_id));}hckAdminAfterId=Math.max(hckAdminAfterId,id);hckAdminReflowGroups();return;}
        if(id&&document.getElementById('msg-'+id))return;
        var row=document.createElement('div'), sender=String(message.sender_type||'customer'), name=message.sender_name||(sender==='agent'?'Support':'Customer'), internal=!!message.is_internal;
        if(!internal && !(Number(message.user_id||0) && Number(message.user_id)===Number(data.userId||0))) hckAgentPlayAlert();
        row.className='hck-admin-msg '+(internal?'hck-admin-msg-internal':(sender==='agent'?'hck-admin-msg-admin':'hck-admin-msg-customer'));
        var userKey=String(message.user_id||name).toLowerCase();row.setAttribute('data-sender-key',(internal?'internal':sender==='agent'?'agent':'customer')+':'+userKey);row.setAttribute('data-user-id',String(message.user_id||''));row.setAttribute('data-created-at',message.created_at||new Date().toISOString());row.setAttribute('data-sender-name',name);
        if(id){row.id='msg-'+id;row.setAttribute('data-message-id',String(id));} if(clientId)row.setAttribute('data-client-message-id',clientId);
        var author=document.createElement('div');author.className='hck-admin-msg-author';var avatar=document.createElement('span');avatar.className='hck-chat-avatar';avatar.textContent=String(name).trim().charAt(0).toUpperCase()||'?';var copy=document.createElement('div');copy.className='hck-chat-author-copy';var strong=document.createElement('strong');strong.textContent=name;var role=document.createElement('em');role.className='hck-chat-role';role.textContent=sender==='agent'?'Agent':'Customer';copy.appendChild(strong);copy.appendChild(role);author.appendChild(avatar);author.appendChild(copy);
        var body=document.createElement('div');body.className='hck-admin-msg-body';body.textContent=message.content||'';
        var footer=document.createElement('div');footer.className='hck-admin-msg-footer';var stamp=document.createElement('span');stamp.innerHTML='<i class="far fa-clock"></i> ';var time=document.createElement('time');time.textContent=message.created_at||'Just now';stamp.appendChild(time);footer.appendChild(stamp);
        row.appendChild(author);row.appendChild(body);
        (message.attachments||[]).forEach(function(att){if(!att.url)return;var link=document.createElement('a');link.className='hck-file-link';link.href=att.url;link.target='_blank';link.rel='noopener';link.textContent=att.name||'Attachment';row.appendChild(link);});
        row.appendChild(footer);hckAdminThread.appendChild(row);hckAdminAfterId=Math.max(hckAdminAfterId,id);hckAdminEnhanceThread();hckAdminThread.scrollTop=hckAdminThread.scrollHeight;
    }
    function hckAdminReceive(event,eventName,channelName){if(eventName!=='hck.message'||channelName!=='hck-customer-'+Number(data.ticketId||0))return;hckAdminAppendMessage(event&&event.message);}
    if(data.ticketId&&data.realtimeEnabled&&window.HCRealtimeClient&&window.Ably){
        hckAdminRealtimeConnectPromise=window.HCRealtimeClient.connect({ajaxUrl:data.ajaxUrl,nonce:data.nonce,channelType:'hck_ticket',ticketId:Number(data.ticketId)},hckAdminReceive,function(state){hckAdminRealtimeConnected=state==='connected';hckAdminConfigurePolling();if(window.console&&console.debug)console.debug('[HCK Ably] Admin ticket realtime:',state);}).then(function(c){hckAdminRealtimeConnection=c;hckAdminRealtimeConnected=true;hckAdminConfigurePolling();return c;}).catch(function(e){hckAdminRealtimeConnected=false;console.warn('[HCK Ably] Admin ticket realtime unavailable; fallback active.',e);return null;});
    }
    function hckAdminPublish(message){if(!hckAdminRealtimeConnectPromise)return Promise.resolve(false);return hckAdminRealtimeConnectPromise.then(function(c){if(!c||message._hcPublishCancelled)return false;var publicMessage=Object.assign({},message);delete publicMessage._hcPublishCancelled;return c.publishTo('hck-agent-'+Number(data.ticketId),'hck.message',{ticket_id:Number(data.ticketId),message:publicMessage}).then(function(){return true;}).catch(function(e){console.warn('[HCK Ably] Agent direct publish failed.',e);return false;});}).catch(function(){return false;});}
    function hckAdminServerRelay(message){var fd=new FormData();fd.append('action','hck_publish_realtime_message');fd.append('nonce',data.nonce||'');fd.append('ticket_id',String(data.ticketId));fd.append('client_message_id',String(message.client_message_id));fd.append('message',String(message.content||''));return fetch(data.ajaxUrl,{method:'POST',body:fd,credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json();}).then(function(r){if(!r||!r.success)throw new Error(r&&r.data&&r.data.message||'Realtime server relay failed.');console.info('[HCK Realtime] Admin pre-save relay acknowledged.',{ticket_id:data.ticketId,client_message_id:message.client_message_id});return true;}).catch(function(e){console.warn('[HCK Realtime] Admin relay failed; database recovery remains available.',e);return false;});}
    function hckAdminDeliver(message){var timer,direct=hckAdminPublish(message);return Promise.race([direct,new Promise(function(resolve){timer=window.setTimeout(function(){resolve(false);},650);})]).then(function(ok){window.clearTimeout(timer);if(ok)return true;message._hcPublishCancelled=true;return hckAdminServerRelay(message);});}
    function hckAdminPoll(){if(!hckAdminThread||hckAdminPollBusy||document.hidden||!data.ticketId)return;hckAdminPollBusy=true;var fd=new FormData();fd.append('action','hck_poll_new_messages');fd.append('nonce',data.nonce||'');fd.append('ticket_id',String(data.ticketId));fd.append('after_id',String(hckAdminAfterId));fetch(data.ajaxUrl,{method:'POST',body:fd,credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json();}).then(function(r){if(!r||!r.success||!r.data)return;(r.data.messages||[]).forEach(hckAdminAppendMessage);hckAdminAfterId=Math.max(hckAdminAfterId,Number(r.data.last_id)||0);}).catch(function(){}).finally(function(){hckAdminPollBusy=false;});}
    function hckAdminConfigurePolling(){if(hckAdminPollTimer)window.clearInterval(hckAdminPollTimer);hckAdminPollTimer=null;if(hckAdminThread&&data.ticketId)hckAdminPollTimer=window.setInterval(hckAdminPoll,hckAdminRealtimeConnected?30000:1800);}
    if(hckAdminThread&&data.ticketId){hckAdminEnhanceThread();hckAdminConfigurePolling();}
    document.addEventListener('visibilitychange',function(){if(!document.hidden)hckAdminPoll();});
    
    // =============================================
    // TOAST
    // =============================================
    function toast(msg, type) {
        type = type || 'success';
        var el = document.getElementById('hckAdminToast');
        if (!el) return;
        el.className = 'hck-admin-toast hck-admin-toast-' + type + ' show';
        el.innerHTML = '<i class="fas fa-' + (type === 'success' ? 'check-circle' : 'exclamation-circle') + '"></i> ' + msg;
        setTimeout(function() {
            el.classList.remove('show');
        }, 2500);
    }
    
    // =============================================
    // AJAX
    // =============================================
    function ajax(action, payload, onSuccess, onError) {
        var fd = payload instanceof FormData ? payload : new FormData();
        if (!(payload instanceof FormData)) {
            Object.keys(payload || {}).forEach(function(k) {
                fd.append(k, payload[k]);
            });
        }
        fd.append('action', action);
        fd.append('nonce', data.nonce);
        
        var xhr = new XMLHttpRequest();
        xhr.open('POST', data.ajaxUrl, true);
        if (action === 'hck_cf_dlq_test') { xhr.timeout = 120000; xhr.ontimeout = function() { toast('Retry/DLQ test timed out. Check Cloudflare Queue logs and D1 probe status.', 'error'); if (onError) onError(new Error('Retry/DLQ test timed out.')); }; }
        if (action === 'hck_cf_archive_regression_test') { xhr.timeout = 120000; xhr.ontimeout = function() { toast('Archive verification timed out. Check Worker logs and the synthetic archive job in D1.', 'error'); if (onError) onError(new Error('Archive verification timed out.')); }; }
        xhr.onload = function() {
            try {
                var res = JSON.parse(xhr.responseText);
                if (res.success) {
                    if (onSuccess) onSuccess(res.data);
                    if (res.data && res.data.message) toast(res.data.message, 'success');
                } else {
                    var err = res.data || { message: 'Error' };
                    toast(err.message, 'error');
                    if (onError) onError(err);
                }
            } catch (e) {
                toast('Invalid response', 'error');
                if (onError) onError(e);
            }
        };
        xhr.onerror = function() { toast('Network error', 'error'); if (onError) onError(new Error('Network error')); };
        xhr.send(fd);
    }
    
    // Resend the single-use secure claim link for an unclaimed guest ticket.
    document.addEventListener('click', function(event) {
        var button = event.target.closest('#hckResendGuestAccess');
        if (!button || button.disabled) return;
        if (!window.confirm('Send a new secure ticket access link to the customer email saved on this ticket? The previous link will stop working.')) return;
        button.disabled = true;
        ajax('hck_resend_guest_access', { ticket_id: button.getAttribute('data-ticket-id') }, function() {
            button.innerHTML = '<i class="fas fa-check"></i> Access link sent';
        }, function() { button.disabled = false; });
    });

    // =============================================
    // CHANGE STATUS
    // =============================================
    window.hckAdminChangeStatus = function(status) {
        var ticketId = getTicketId();
        if (!ticketId) return;
        ajax('hck_admin_change_status', { ticket_id: ticketId, status: status }, function() {
            setTimeout(function() { location.reload(); }, 800);
        });
    };
    
    // =============================================
    // CHANGE PRIORITY
    // =============================================
    window.hckAdminChangePriority = function(priority) {
        var ticketId = getTicketId();
        if (!ticketId) return;
        ajax('hck_admin_change_priority', { ticket_id: ticketId, priority: priority });
    };
    
    // =============================================
    // CHANGE AGENT
    // =============================================
    window.hckAdminChangeAgent = function(agentId) {
        var ticketId = getTicketId();
        if (!ticketId) return;
        ajax('hck_admin_change_agent', { ticket_id: ticketId, agent_id: agentId });
    };
    
    function getTicketId() {
        var url = window.location.pathname;
        var match = url.match(/view\/(\d+)/);
        return match ? match[1] : null;
    }
    
    // =============================================
    // FILE PREVIEW
    // =============================================
    window.hckAdminPreviewFiles = function(input) {
        var container = document.getElementById('hckAdminReplyFiles');
        if (!container) return;
        container.innerHTML = '';
        for (var i = 0; i < input.files.length; i++) {
            var f = input.files[i];
            var row = document.createElement('div');
            row.className = 'hck-admin-file-item';
            row.innerHTML = '<i class="fas fa-paperclip"></i> ' + f.name + ' (' + (f.size/1048576).toFixed(2) + ' MB)';
            container.appendChild(row);
        }
    };
    
    // =============================================
    // ADMIN FILE HANDLING
    // =============================================
    var adminFileData = new DataTransfer();

    window.hckAdminAddFiles = function(input) {
        for (var i = 0; i < input.files.length; i++) {
            var f = input.files[i];
            if (f.size > 10485760) {
                toast('File "' + f.name + '" exceeds 10MB', 'error');
                continue;
            }
            var dup = false;
            for (var j = 0; j < adminFileData.files.length; j++) {
                if (adminFileData.files[j].name === f.name && adminFileData.files[j].size === f.size) {
                    dup = true; break;
                }
            }
            if (!dup) adminFileData.items.add(f);
        }
        input.files = adminFileData.files;
        renderAdminFiles();
    };

    function renderAdminFiles() {
        var container = document.getElementById('hckAdminReplyFiles');
        if (!container) return;
        container.innerHTML = '';
        for (var i = 0; i < adminFileData.files.length; i++) {
            (function(idx) {
                var f = adminFileData.files[idx];
                var row = document.createElement('div');
                row.className = 'hck-admin-file-chip';
                row.innerHTML =
                    '<div class="hck-admin-file-chip-icon"><i class="fas fa-paperclip"></i></div>' +
                    '<div class="hck-admin-file-chip-info">' +
                        '<div class="hck-admin-file-chip-name">' + f.name + '</div>' +
                        '<div class="hck-admin-file-chip-size">' + (f.size / 1048576).toFixed(2) + ' MB</div>' +
                    '</div>' +
                    '<button type="button" class="hck-admin-file-chip-remove" title="Remove">&times;</button>';
                row.querySelector('.hck-admin-file-chip-remove').addEventListener('click', function(e) {
                    e.preventDefault();
                    var dt = new DataTransfer();
                    for (var k = 0; k < adminFileData.files.length; k++) {
                        if (k !== idx) dt.items.add(adminFileData.files[k]);
                    }
                    adminFileData = dt;
                    var inp = document.getElementById('hckAdminReplyInput');
                    if (inp) inp.files = adminFileData.files;
                    renderAdminFiles();
                });
                container.appendChild(row);
            })(i);
        }
    }

    // =============================================
    // PAGINATED TICKET TRANSCRIPT — load older messages without reloading
    // =============================================
    var olderMessagesBtn = document.getElementById('hckLoadOlderMessages');
    if (olderMessagesBtn) {
        olderMessagesBtn.addEventListener('click', function() {
            var thread = document.getElementById('hckAdminTicketThread');
            if (!thread || olderMessagesBtn.disabled) return;
            var beforeId = parseInt(thread.getAttribute('data-before-id') || '0', 10);
            var ticketId = parseInt(thread.getAttribute('data-ticket-id') || '0', 10);
            if (!beforeId || !ticketId) return;
            var oldHeight = thread.scrollHeight;
            var oldTop = thread.scrollTop;
            olderMessagesBtn.disabled = true;
            olderMessagesBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            ajax('hck_load_older_messages', {ticket_id: ticketId, before_id: beforeId}, function(result) {
                if (result.html) {
                    var marker = thread.querySelector('.hck-thread-older-wrap');
                    if (marker) marker.insertAdjacentHTML('afterend', result.html);
                    hckAdminEnhanceThread();
                    thread.scrollTop = thread.scrollHeight - oldHeight + oldTop;
                }
                thread.setAttribute('data-before-id', String(result.next_before_id || ''));
                if (!result.has_more || !result.next_before_id) {
                    var wrap = thread.querySelector('.hck-thread-older-wrap');
                    if (wrap) wrap.remove();
                } else {
                    olderMessagesBtn.disabled = false;
                    olderMessagesBtn.innerHTML = '<i class="fas fa-chevron-up"></i> Load older messages';
                }
                var status = document.getElementById('hckOlderMessagesStatus');
                if (status) status.textContent = result.has_more ? 'Loaded ' + (result.loaded || 0) + ' older messages' : 'All messages loaded';
            }, function(error) {
                olderMessagesBtn.disabled = false;
                olderMessagesBtn.innerHTML = '<i class="fas fa-chevron-up"></i> Try again';
                // ajax() already displays the server error toast.
            });
        });
    }

    if (hckAdminThread) {
        hckAdminThread.addEventListener('click', function (event) {
            var edit = event.target.closest('[data-hck-edit-note]'), del = event.target.closest('[data-hck-delete-note]');
            if (!edit && !del) return;
            var button = edit || del, messageId = Number(button.getAttribute(edit ? 'data-hck-edit-note' : 'data-hck-delete-note'));
            var row = button.closest('.hck-admin-msg'); if (!messageId || !row) return;
            if (edit) {
                var body = row.querySelector('.hck-admin-msg-body');
                var next = window.prompt('Edit this private note:', body ? body.textContent : '');
                if (next === null) return;
                ajax('hck_edit_internal_note', {ticket_id:Number(data.ticketId), message_id:messageId, message:next}, function (result) {
                    if (body) body.textContent = result.message_text || next;
                    var audit = row.querySelector('.hck-note-edited');
                    if (!audit) { audit=document.createElement('div'); audit.className='hck-note-edited'; row.insertBefore(audit,row.querySelector('.hck-admin-msg-footer')); }
                    audit.innerHTML='<i class="fas fa-pen"></i> Edited by '+hckAdminEscape(result.edited_by_name||'you')+' · '+hckAdminEscape(result.edited_at||'');
                });
            } else if (window.confirm('Delete this private note? The text will be removed, and a deletion record will remain.')) {
                ajax('hck_delete_internal_note', {ticket_id:Number(data.ticketId), message_id:messageId}, function (result) {
                    row.classList.add('is-deleted');
                    row.innerHTML='<div class="hck-note-action-marker"><i class="fas fa-trash"></i><span>Private note deleted by '+hckAdminEscape(result.deleted_by_name||'you')+' · '+hckAdminEscape(result.deleted_at||'')+'</span></div>';
                });
            }
        });
    }

    // =============================================
    // ADMIN REPLY FORM — with progress
    // =============================================
    var replyForm = document.getElementById('hckAdminReplyForm');
    var hckAdminPersistenceQueue = Promise.resolve();
    if (replyForm) {
        replyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var btn = document.getElementById('hckAdminReplyBtn');
            if (!btn) return;
            var orig = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
            btn.disabled = true;

            var formData = new FormData(replyForm);
            formData.append('action', 'hck_send_reply');
            formData.append('nonce', data.nonce);
            var clientId = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : ('hck-admin-' + Date.now() + '-' + Math.random().toString(16).slice(2));
            formData.append('client_message_id', clientId);
            var msgText = String(formData.get('message') || '').trim();
            var internalNote = !!formData.get('internal');
            var fileField = replyForm.querySelector('input[type=file]');
            var hasFiles = !!(fileField && fileField.files && fileField.files.length);
            var isIndependentText = !!(msgText && !internalNote && !hasFiles);
            var pendingRow = null;
            if (msgText && !internalNote && !hasFiles && hckAdminThread) {
                pendingRow = document.createElement('div'); pendingRow.className='hck-admin-msg hck-admin-msg-admin'; pendingRow.setAttribute('data-client-message-id',clientId);
                pendingRow.setAttribute('data-sender-key','agent:'+String(data.userId||'you'));pendingRow.setAttribute('data-user-id',String(data.userId||''));pendingRow.setAttribute('data-created-at',new Date().toISOString());var ph=document.createElement('div');ph.className='hck-admin-msg-author';var av=document.createElement('span');av.className='hck-chat-avatar';av.textContent='Y';var ac=document.createElement('div');ac.className='hck-chat-author-copy';var pn=document.createElement('strong');pn.textContent='You';var pr=document.createElement('em');pr.className='hck-chat-role';pr.textContent='Agent';ac.appendChild(pn);ac.appendChild(pr);ph.appendChild(av);ph.appendChild(ac);
                var pb=document.createElement('div');pb.className='hck-admin-msg-body';pb.textContent=msgText;var pf=document.createElement('div');pf.className='hck-admin-msg-footer';pf.innerHTML='<span><i class="far fa-clock"></i> <time>Sending…</time></span>';pendingRow.appendChild(ph);pendingRow.appendChild(pb);pendingRow.appendChild(pf);hckAdminThread.appendChild(pendingRow);hckAdminEnhanceThread();hckAdminThread.scrollTop=hckAdminThread.scrollHeight;
            }
            var directPromise = (!internalNote && !hasFiles && msgText) ? hckAdminDeliver({client_message_id:clientId,sender_type:'agent',sender_name:'Support',content:msgText,created_at:new Date().toISOString(),attachments:[]}) : Promise.resolve(false);
            // Make sure it's tagged as admin (from admin view URL)

            var progress = document.getElementById('hckAdminUploadProgress');
            var fill = document.getElementById('hckAdminUploadFill');
            var text = document.getElementById('hckAdminUploadText');
            if (progress && adminFileData.files.length > 0) {
                progress.style.display = 'block';
            }

            var xhr = new XMLHttpRequest();
            xhr.open('POST', data.ajaxUrl, true);
            xhr.upload.addEventListener('progress', function(ev) {
                if (ev.lengthComputable && fill) {
                    var pct = Math.round((ev.loaded / ev.total) * 100);
                    fill.style.width = pct + '%';
                    if (text) text.textContent = 'Uploading... ' + pct + '%';
                }
            });
            xhr.onload = function() {
                if (progress) progress.style.display = 'none';
                try {
                    var res = JSON.parse(xhr.responseText);
                    if (res.success) {
                        toast('Reply sent!');
                        var savedId = Number(res.data && res.data.message_id) || 0;
                        if (pendingRow) { if (savedId) { pendingRow.id='msg-'+savedId; pendingRow.setAttribute('data-message-id',String(savedId)); } var stamp=pendingRow.querySelector('.hck-admin-msg-footer time'); if(stamp)stamp.textContent=(res.data && res.data.created_at) || new Date().toLocaleString();if(res.data&&res.data.created_at)pendingRow.setAttribute('data-created-at',String(res.data.created_at).replace(' ','T'));hckAdminReflowGroups(); }
                        if (!isIndependentText) { var messageField=replyForm.querySelector('[name=message]');if(messageField)messageField.value=''; if (fileField) fileField.value=''; btn.innerHTML=orig;btn.disabled=false; }
                    } else {
                        toast((res.data && res.data.message) || 'Error', 'error');
                        if (pendingRow) { var failedStamp=pendingRow.querySelector('.hck-admin-msg-footer time'); if(failedStamp)failedStamp.textContent='Save failed · retry'; pendingRow.classList.add('hck-reply-save-failed'); }
                        if (!isIndependentText) { btn.innerHTML = orig; btn.disabled = false; }
                    }
                } catch (err) {
                    toast('Server error', 'error');
                    if (pendingRow) { var errorStamp=pendingRow.querySelector('.hck-admin-msg-footer time'); if(errorStamp)errorStamp.textContent='Save failed'; pendingRow.classList.add('hck-reply-save-failed'); }
                    if (!isIndependentText) { btn.innerHTML = orig; btn.disabled = false; }
                }
            };
            xhr.onerror = function() {
                if (progress) progress.style.display = 'none';
                toast('Network error', 'error');
                if (pendingRow) { var networkStamp=pendingRow.querySelector('.hck-msg-time'); if(networkStamp)networkStamp.textContent='Network error · save pending'; pendingRow.classList.add('hck-reply-save-failed'); }
                if (!isIndependentText) { btn.innerHTML = orig; btn.disabled = false; }
            };
            if (isIndependentText) {
                var messageFieldNow = replyForm.querySelector('[name=message]');
                if (messageFieldNow) messageFieldNow.value = '';
                btn.innerHTML = orig; btn.disabled = false;
            }
            var persistAdminReply = function() {
                return Promise.resolve(directPromise).then(function(delivered){
                    formData.append('realtime_delivered', delivered ? '1' : '0');
                    return new Promise(function(resolve){
                        var done = false;
                        var finish = function(){ if(done)return; done=true; resolve(); };
                        var oldLoad=xhr.onload, oldError=xhr.onerror, oldTimeout=xhr.ontimeout;
                        xhr.onload=function(ev){try{if(typeof oldLoad==='function')oldLoad.call(xhr,ev);}finally{finish();}};
                        xhr.onerror=function(ev){try{if(typeof oldError==='function')oldError.call(xhr,ev);}finally{finish();}};
                        xhr.ontimeout=function(ev){try{if(typeof oldTimeout==='function')oldTimeout.call(xhr,ev);}finally{finish();}};
                        try{xhr.send(formData);}catch(error){finish();if(!isIndependentText){btn.innerHTML=orig;btn.disabled=false;}toast('Could not send reply.','error');}
                    });
                });
            };
            if (isIndependentText) {
                var queuedAdminSave = hckAdminPersistenceQueue.catch(function(){}).then(persistAdminReply);
                hckAdminPersistenceQueue = queuedAdminSave.catch(function(){});
            } else {
                persistAdminReply();
            }
        });
    }
    
    // =============================================
    // SETTINGS FORM
    // =============================================
    var settingsForm = document.getElementById('hckSettingsForm');
    if (settingsForm) {
        settingsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var btn = this.querySelector('button[type="submit"]');
            var orig = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            btn.disabled = true;
            
            var payload = {};
            new FormData(settingsForm).forEach(function(v, k) { payload[k] = v; });
            // Ensure checkboxes that are unchecked are sent as '0'
            settingsForm.querySelectorAll('input[type="checkbox"]').forEach(function(cb) {
                if (!cb.checked) payload[cb.name] = '0';
            });
            
            ajax('hck_save_settings', payload, function() {
                btn.innerHTML = orig;
                btn.disabled = false;
            }, function() {
                btn.innerHTML = orig;
                btn.disabled = false;
            });
        });
    }

    // Cloudflare provisioning runs server-side; API tokens are never sent to JavaScript.
    var cfProvisionButton = document.getElementById('hckCfAutoProvision');
    if (cfProvisionButton) {
        cfProvisionButton.addEventListener('click', function() {
            var result = document.getElementById('hckCfAutoResult');
            var original = cfProvisionButton.innerHTML;
            if (!window.confirm('The site will create missing Cloudflare resources and deploy/update the configured Worker. Existing live WordPress chat and ticket storage will NOT be switched. Continue?')) return;
            cfProvisionButton.disabled = true;
            cfProvisionButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying and configuring...';
            if (result) result.textContent = 'Checking account permissions, resources, deployment and health...';
            ajax('hck_cf_auto_provision', {}, function(res) {
                var d = res && res.details ? res.details : {};
                if (result) result.textContent = 'Ready · Worker: ' + (d.worker_url || 'deployed') + ' · D1: ' + (d.database || '') + ' · R2: ' + (d.bucket || '') + ' · Primary Queue consumer: ' + (d.queue_consumer || 'verified') + ' · DLQ consumer: ' + (d.dlq_consumer || 'verified') + ' · Worker source: ' + (d.worker_deployed ? 'updated' : 'unchanged');
                cfProvisionButton.innerHTML = original;
                cfProvisionButton.disabled = false;
            }, function(err) {
                if (result) result.textContent = err && err.message ? err.message : 'Provisioning failed. Review the error and permissions, then retry.';
                cfProvisionButton.innerHTML = original;
                cfProvisionButton.disabled = false;
            });
        });
    }

    // Cloudflare connection diagnostics (admin-only; never sends credentials to the browser).
    var cfTestButton = document.getElementById('hckCfHealthCheck');
    if (cfTestButton) {
        cfTestButton.addEventListener('click', function() {
            var result = document.getElementById('hckCfHealthResult');
            var original = cfTestButton.innerHTML;
            cfTestButton.disabled = true;
            cfTestButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking...';
            if (result) result.textContent = '';
            ajax('hck_cf_health_check', {}, function(res) {
    var details = res && res.details ? res.details : {};

    if (result) {
        result.textContent = [
            'Worker: ' + (details.worker || 'Unknown'),
            'D1: ' + (details.d1 || 'Unknown'),
            'R2: ' + (details.r2 || 'Unknown'),
            'Queue binding: ' + (details.queue_binding || 'Unknown')
        ].join(' | ');
    }

    cfTestButton.innerHTML = original;
    cfTestButton.disabled = false;
            });
        });
    }


    // Synthetic end-to-end archive regression test; creates one isolated test object, no ticket data.
    var cfArchiveTestButton = document.getElementById('hckCfArchiveTest');
    if (cfArchiveTestButton) {
        cfArchiveTestButton.addEventListener('click', function() {
            var result = document.getElementById('hckCfArchiveResult');
            var original = cfArchiveTestButton.innerHTML;
            if (!window.confirm('This creates one synthetic archive job and object, verifies D1 metadata and R2 readback, and checks that no DLQ failure was recorded. It does not use customer or ticket data. The synthetic archive object is retained for audit. Continue?')) return;
            cfArchiveTestButton.disabled = true;
            cfArchiveTestButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying archive...';
            if (result) result.textContent = 'Waiting for the synthetic archive job to complete and verifying D1, R2 and DLQ status (up to 90 seconds)...';
            ajax('hck_cf_archive_regression_test', {}, function(res) {
                if (result) result.textContent = res && res.message ? res.message : 'Archive regression verification passed.';
                cfArchiveTestButton.innerHTML = original;
                cfArchiveTestButton.disabled = false;
            }, function(err) {
                if (result) result.textContent = err && err.message ? err.message : 'Archive regression verification failed. Check Worker and Queue logs.';
                cfArchiveTestButton.innerHTML = original;
                cfArchiveTestButton.disabled = false;
            });
        });
    }

    // Explicit synthetic retry/DLQ verification. It does not touch ticket or archive records.
    var cfDlqTestButton = document.getElementById('hckCfDlqTest');
    if (cfDlqTestButton) {
        cfDlqTestButton.addEventListener('click', function() {
            var result = document.getElementById('hckCfDlqResult');
            var original = cfDlqTestButton.innerHTML;
            if (!window.confirm('This sends one synthetic test message, intentionally fails it until Cloudflare moves it to the DLQ, and verifies that the Worker records it in D1. No customer tickets or archive objects are changed. Continue?')) return;
            cfDlqTestButton.disabled = true;
            cfDlqTestButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Testing retries and DLQ...';
            if (result) result.textContent = 'Waiting for the synthetic message to exhaust retries and reach the DLQ (up to 100 seconds)...';
            ajax('hck_cf_dlq_test', {}, function(res) {
                if (result) result.textContent = res && res.message ? res.message : 'Retry and DLQ verification passed.';
                cfDlqTestButton.innerHTML = original;
                cfDlqTestButton.disabled = false;
            }, function(err) {
                if (result) result.textContent = err && err.message ? err.message : 'Retry/DLQ verification failed. Check Worker and Queue logs.';
                cfDlqTestButton.innerHTML = original;
                cfDlqTestButton.disabled = false;
            });
        });
    }

})();
