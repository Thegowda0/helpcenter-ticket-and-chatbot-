<?php
/**
 * HCK Ticket System - Email Notifications
 * Editable subjects + bodies via admin settings.
 */

if (!defined('ABSPATH')) exit;

/**
 * Check if emails are enabled
 */
function hck_emails_enabled() {
    return hck_get_setting('hck_email_notifications', '1') === '1';
}

/**
 * Send an email
 */
function hck_send_mail($to, $subject, $body) {
    $site_name  = hck_get_setting('hck_site_title', get_bloginfo('name'));
    $from_email = hck_get_setting('hck_support_email', get_option('admin_email'));

    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $from_email . '>',
    );

    error_log('[HCK EMAIL] Sending to: ' . $to . ' | Subject: ' . $subject);
    $result = wp_mail($to, $subject, $body, $headers);
    error_log('[HCK EMAIL] Result: ' . ($result ? 'SENT' : 'FAILED'));
    return $result;
}

/**
 * Base HTML email template (fallback wrapper for legacy use)
 */
function hck_email_template($heading, $heading_color, $content_html) {
    $site_name = hck_get_setting('hck_site_title', get_bloginfo('name'));
    $year = date('Y');

    return '<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#F1F5F9;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#F1F5F9;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);">
<tr><td style="background:' . $heading_color . ';padding:30px;text-align:center;">
<h1 style="color:#fff;margin:0;font-size:22px;font-weight:700;">' . esc_html($heading) . '</h1>
</td></tr>
<tr><td style="padding:32px 28px;">
' . $content_html . '
</td></tr>
<tr><td style="padding:20px 28px;text-align:center;border-top:1px solid #E2E8F0;">
<p style="margin:0;font-size:12px;color:#94A3B8;">' . esc_html($site_name) . ' &copy; ' . $year . '</p>
</td></tr>
</table>
</td></tr>
</table>
</body></html>';
}

/**
 * Info table helper
 */
function hck_email_info_table($rows) {
    $html = '<table width="100%" cellpadding="0" cellspacing="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;margin:16px 0;border-collapse:collapse;">';
    foreach ($rows as $label => $value) {
        $html .= '<tr>';
        $html .= '<td style="padding:12px 16px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#475569;font-size:13px;width:40%;">' . esc_html($label) . '</td>';
        $html .= '<td style="padding:12px 16px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:13px;">' . wp_kses_post($value) . '</td>';
        $html .= '</tr>';
    }
    $html .= '</table>';
    return $html;
}

/**
 * Button helper
 */
function hck_email_button($text, $url) {
    return '<p style="text-align:center;margin:24px 0;"><a href="' . esc_url($url) . '" style="display:inline-block;background:#6366F1;color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;">' . esc_html($text) . '</a></p>';
}

// =============================================
// DEFAULT TEMPLATES
// =============================================
function hck_get_default_email_templates() {
    $brand      = '#6366F1';
    $brand_dark = '#4F46E5';
    $site_name  = '{site_name}';

    // ------------------------------------------------------------
    // Shared wrapper: header + body + footer
    // ------------------------------------------------------------
    $wrap = function($heading, $color, $body) {
        return '<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $heading . '</title></head>
<body style="margin:0;padding:0;background:#F1F5F9;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;-webkit-font-smoothing:antialiased;">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F1F5F9;padding:40px 16px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;background:#FFFFFF;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);">
  <tr><td style="background:linear-gradient(135deg,' . $color . ' 0%,' . $color . 'CC 100%);padding:32px 28px;text-align:center;">
    <h1 style="color:#FFFFFF;margin:0;font-size:22px;font-weight:700;letter-spacing:-0.3px;">' . $heading . '</h1>
  </td></tr>
  <tr><td style="padding:36px 32px;">
    ' . $body . '
  </td></tr>
  <tr><td style="padding:20px 32px 24px;text-align:center;border-top:1px solid #F1F5F9;">
    <p style="margin:0 0 6px;font-size:12px;color:#94A3B8;line-height:1.5;">This email was sent by <strong style="color:#64748B;">' . $site_name . '</strong>. If you didn\'t request this, you can safely ignore it.</p>
    <p style="margin:0;font-size:11px;color:#CBD5E1;">&copy; ' . date('Y') . ' ' . $site_name . '. All rights reserved.</p>
  </td></tr>
</table>
</td></tr>
</table>
</body></html>';
    };

    return array(

        // =========================================================
        // 1. NEW TICKET — CUSTOMER
        // =========================================================
        'email_new_ticket_customer' => $wrap('Ticket Received', $brand, '
<p style="font-size:16px;color:#0F172A;margin:0 0 8px;font-weight:600;">Hi {customer_name},</p>
<p style="font-size:14px;color:#475569;line-height:1.6;margin:0 0 24px;">Thanks for reaching out. We\'ve received your ticket and our team will get back to you as soon as possible.</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;margin:0 0 28px;border-collapse:separate;overflow:hidden;">
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%;">Ticket Number</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;font-weight:600;">{ticket_number}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Subject</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;">{ticket_subject}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Priority</td>
    <td style="padding:14px 18px;color:#0F172A;font-size:14px;">{priority}</td>
  </tr>
</table>

<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
  <tr><td style="border-radius:10px;background:' . $brand . ';">
    <a href="{ticket_url}" style="display:inline-block;color:#FFFFFF;padding:14px 36px;text-decoration:none;font-weight:600;font-size:14px;border-radius:10px;">View Your Ticket</a>
  </td></tr>
</table>

<p style="font-size:12px;color:#94A3B8;text-align:center;margin:28px 0 0;line-height:1.6;">Tip: you can reply directly from the ticket page to add more details or attach files.</p>
'),

        // =========================================================
        // 2. NEW TICKET — ADMIN
        // =========================================================
        'email_new_ticket_admin' => $wrap('New Support Ticket', '#EF4444', '
<p style="font-size:15px;color:#0F172A;margin:0 0 20px;font-weight:600;">A new ticket has been submitted.</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;margin:0 0 28px;border-collapse:separate;overflow:hidden;">
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%;">Ticket</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;font-weight:600;">{ticket_number}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Customer</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;">{customer_name}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Subject</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;">{ticket_subject}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Category</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;">{category}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Priority</td>
    <td style="padding:14px 18px;color:#0F172A;font-size:14px;font-weight:600;">{priority}</td>
  </tr>
</table>

<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
  <tr><td style="border-radius:10px;background:' . $brand . ';">
    <a href="{admin_url}" style="display:inline-block;color:#FFFFFF;padding:14px 36px;text-decoration:none;font-weight:600;font-size:14px;border-radius:10px;">Open in Admin Panel</a>
  </td></tr>
</table>
'),

        // =========================================================
        // 3. ADMIN REPLY — CUSTOMER
        // =========================================================
        'email_admin_reply' => $wrap('New Reply on Your Ticket', '#10B981', '
<p style="font-size:16px;color:#0F172A;margin:0 0 8px;font-weight:600;">Hi {customer_name},</p>
<p style="font-size:14px;color:#475569;line-height:1.6;margin:0 0 24px;">Our support team has responded to your ticket. You can read the reply and continue the conversation from the link below.</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;margin:0 0 28px;border-collapse:separate;overflow:hidden;">
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%;">Ticket</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;font-weight:600;">{ticket_number}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Subject</td>
    <td style="padding:14px 18px;color:#0F172A;font-size:14px;">{ticket_subject}</td>
  </tr>
</table>

<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
  <tr><td style="border-radius:10px;background:' . $brand . ';">
    <a href="{ticket_url}" style="display:inline-block;color:#FFFFFF;padding:14px 36px;text-decoration:none;font-weight:600;font-size:14px;border-radius:10px;">View Reply</a>
  </td></tr>
</table>
'),

        // =========================================================
        // 4. CUSTOMER REPLY — ADMIN
        // =========================================================
        'email_customer_reply' => $wrap('Customer Replied', '#8B5CF6', '
<p style="font-size:15px;color:#0F172A;margin:0 0 20px;font-weight:600;">The customer has added a new reply to their ticket.</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;margin:0 0 28px;border-collapse:separate;overflow:hidden;">
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%;">Ticket</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;font-weight:600;">{ticket_number}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Customer</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;">{customer_name}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Subject</td>
    <td style="padding:14px 18px;color:#0F172A;font-size:14px;">{ticket_subject}</td>
  </tr>
</table>

<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
  <tr><td style="border-radius:10px;background:' . $brand . ';">
    <a href="{admin_url}" style="display:inline-block;color:#FFFFFF;padding:14px 36px;text-decoration:none;font-weight:600;font-size:14px;border-radius:10px;">Open Ticket</a>
  </td></tr>
</table>
'),

        // =========================================================
        // 5. TICKET RESOLVED
        // =========================================================
        'email_ticket_resolved' => $wrap('Ticket Resolved', '#10B981', '
<p style="font-size:16px;color:#0F172A;margin:0 0 8px;font-weight:600;">Hi {customer_name},</p>
<p style="font-size:14px;color:#475569;line-height:1.6;margin:0 0 24px;">Great news — your support ticket has been resolved. If the issue is fully taken care of, feel free to rate your experience.</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;margin:0 0 28px;border-collapse:separate;overflow:hidden;">
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%;">Ticket</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;font-weight:600;">{ticket_number}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Subject</td>
    <td style="padding:14px 18px;color:#0F172A;font-size:14px;">{ticket_subject}</td>
  </tr>
</table>

<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto 24px;">
  <tr><td style="border-radius:10px;background:#F59E0B;">
    <a href="{ticket_url}" style="display:inline-block;color:#FFFFFF;padding:14px 36px;text-decoration:none;font-weight:600;font-size:14px;border-radius:10px;">Rate Your Experience</a>
  </td></tr>
</table>

<p style="font-size:13px;color:#64748B;text-align:center;margin:0;">If you need more help, simply reply to reopen the ticket.</p>
'),

        // =========================================================
        // 6. TICKET CLOSED
        // =========================================================
        'email_ticket_closed' => $wrap('Ticket Closed', '#64748B', '
<p style="font-size:16px;color:#0F172A;margin:0 0 8px;font-weight:600;">Hi {customer_name},</p>
<p style="font-size:14px;color:#475569;line-height:1.6;margin:0 0 24px;">Your ticket has been closed. Thanks for contacting us — if you need anything else, feel free to open a new ticket anytime.</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;margin:0 0 28px;border-collapse:separate;overflow:hidden;">
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%;">Ticket</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;font-weight:600;">{ticket_number}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Subject</td>
    <td style="padding:14px 18px;color:#0F172A;font-size:14px;">{ticket_subject}</td>
  </tr>
</table>

<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
  <tr><td style="border-radius:10px;background:' . $brand . ';">
    <a href="{create_url}" style="display:inline-block;color:#FFFFFF;padding:14px 36px;text-decoration:none;font-weight:600;font-size:14px;border-radius:10px;">Create New Ticket</a>
  </td></tr>
</table>
'),

        // =========================================================
        // 7. INACTIVITY REMINDER
        // =========================================================
        'email_reminder' => $wrap('We\'re Waiting for Your Reply', '#F59E0B', '
<p style="font-size:16px;color:#0F172A;margin:0 0 8px;font-weight:600;">Hi {customer_name},</p>
<p style="font-size:14px;color:#475569;line-height:1.6;margin:0 0 24px;">We replied to your ticket <strong>{days_inactive} days ago</strong> and haven\'t heard back yet. If we don\'t hear from you within <strong>{days_remaining} days</strong>, this ticket will be closed automatically.</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:12px;margin:0 0 28px;border-collapse:separate;overflow:hidden;">
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #FDE68A;font-weight:600;color:#92400E;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%;">Ticket</td>
    <td style="padding:14px 18px;border-bottom:1px solid #FDE68A;color:#0F172A;font-size:14px;font-weight:600;">{ticket_number}</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;font-weight:600;color:#92400E;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Subject</td>
    <td style="padding:14px 18px;color:#0F172A;font-size:14px;">{ticket_subject}</td>
  </tr>
</table>

<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
  <tr><td style="border-radius:10px;background:#F59E0B;">
    <a href="{ticket_url}" style="display:inline-block;color:#FFFFFF;padding:14px 36px;text-decoration:none;font-weight:600;font-size:14px;border-radius:10px;">Reply Now</a>
  </td></tr>
</table>
'),
    );
}

/**
 * Default subjects
 */
function hck_get_default_email_subjects() {
    return array(
        'email_new_ticket_customer' => '[{ticket_number}] Ticket Created - {site_name}',
        'email_new_ticket_admin'    => '[NEW TICKET] {ticket_number} - {ticket_subject}',
        'email_admin_reply'         => '[{ticket_number}] New Reply - {site_name}',
        'email_customer_reply'      => '[{ticket_number}] Customer Reply - {site_name}',
        'email_ticket_resolved'     => '[{ticket_number}] Ticket Resolved - {site_name}',
        'email_ticket_closed'       => '[{ticket_number}] Ticket Closed - {site_name}',
        'email_reminder'            => '[{ticket_number}] Reminder - {site_name}',
    );
}

/**
 * Get a template body (saved or default)
 */
function hck_get_email_template($key) {
    $saved = hck_get_setting($key, '');
    if (trim($saved) !== '') return $saved;
    $defaults = hck_get_default_email_templates();
    return isset($defaults[$key]) ? $defaults[$key] : '';
}

/**
 * Get a template subject (saved or default)
 */
function hck_get_email_subject($key) {
    $saved = hck_get_setting($key . '_subject', '');
    if (trim($saved) !== '') return $saved;
    $defaults = hck_get_default_email_subjects();
    return isset($defaults[$key]) ? $defaults[$key] : '';
}

/**
 * Replace template tags with values
 */
function hck_replace_email_tags($text, $data = array()) {
    $defaults = array(
        '{ticket_number}'  => '',
        '{ticket_subject}' => '',
        '{ticket_id}'      => '',
        '{customer_name}'  => '',
        '{customer_email}' => '',
        '{site_name}'      => hck_get_setting('hck_site_title', get_bloginfo('name')),
        '{status}'         => '',
        '{priority}'       => '',
        '{category}'       => '',
        '{admin_name}'     => '',
        '{reply}'          => '',
        '{ticket_url}'     => '',
        '{admin_url}'      => '',
        '{create_url}'     => home_url('/ticket/create/'),
        '{order_id}'       => '',
        '{order_details}'  => '',
        '{rating}'         => '',
        '{current_date}'   => date('F j, Y'),
        '{current_time}'   => date('g:i A'),
        '{days_inactive}'  => '',
        '{days_remaining}' => '',
    );
    $data = array_merge($defaults, $data);
    foreach ($data as $tag => $value) {
        $text = str_replace($tag, $value, $text);
    }
    return $text;
}

/**
 * Resolve customer contact details for both registered and unclaimed guest tickets.
 */
function hck_ticket_notification_email($ticket, $user = null) {
    if ($user && !empty($user->user_email) && is_email($user->user_email)) return $user->user_email;
    $email = isset($ticket->customer_email) ? sanitize_email($ticket->customer_email) : '';
    return is_email($email) ? $email : '';
}


/** Build tag map for a ticket. */
function hck_email_build_tags($ticket, $user) {
    $ticket_id  = (int) $ticket->id;
    $ticket_num = hck_get_ticket_number($ticket);
    $customer_name = !empty($ticket->customer_name) ? $ticket->customer_name : ($user ? hck_get_user_display($user->ID) : hck_get_user_display(hck_get_ticket_user_id($ticket)));
    return array(
        '{ticket_number}'  => $ticket_num,
        '{ticket_subject}' => $ticket->subject,
        '{ticket_id}'      => $ticket_id,
        '{customer_name}'  => $customer_name,
        '{customer_email}' => hck_ticket_notification_email($ticket, $user),
        '{status}'         => hck_get_status_label($ticket->status),
        '{priority}'       => hck_get_priority_label($ticket->priority),
        '{category}'       => ucfirst($ticket->category),
        '{ticket_url}'     => hck_customer_url('view/' . $ticket_id . '/'),
        '{admin_url}'      => hck_admin_url('view/' . $ticket_id . '/'),
    );
}

// =============================================
// NOTIFICATION: NEW TICKET (CUSTOMER)
// =============================================
function hck_notify_new_ticket_customer($ticket_id) {
    if (!hck_emails_enabled()) return false;
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) return false;
    $user = get_userdata(hck_get_ticket_user_id($ticket));
    $email = hck_ticket_notification_email($ticket, $user);
    if (!$email) return false;
    $tags = hck_email_build_tags($ticket, $user);
    if (!$user && class_exists('HCK_HelpCenter_Integration')) {
        $guest_url = HCK_HelpCenter_Integration::create_guest_access_link($ticket_id, $email, $ticket->customer_name ?: 'Customer');
        if (!$guest_url) return false;
        $tags['{ticket_url}'] = $guest_url;
        $tags['{customer_name}'] = $ticket->customer_name ?: 'Customer';
    }
    $body = hck_replace_email_tags(hck_get_email_template('email_new_ticket_customer'), $tags);
    if (!$user) { if (strpos($body, esc_url($guest_url)) === false) $body .= hck_email_button('Open your support ticket',$guest_url); $body .= '<p style="font-size:12px;color:#64748B;line-height:1.6">For guest access, open this unique link and enter the one-time code sent to this email address. You can choose to create a website account or continue without one. Please send all replies through the ticket portal; email replies are not added to the ticket.</p>'; }
    $subject = hck_replace_email_tags(hck_get_email_subject('email_new_ticket_customer'), $tags);
    return hck_send_mail($email, $subject, $body);
}

// =============================================
// NOTIFICATION: NEW TICKET (ADMIN)
// =============================================
function hck_notify_new_ticket_admin($ticket_id) {
    if (!hck_emails_enabled()) return false;
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) return false;
    $user = get_userdata(hck_get_ticket_user_id($ticket));
    $admin_email = hck_get_setting('hck_support_email', get_option('admin_email'));
    if (!is_email($admin_email)) return false;
    $tags = hck_email_build_tags($ticket, $user);
    $body = hck_replace_email_tags(hck_get_email_template('email_new_ticket_admin'), $tags);
    $subject = hck_replace_email_tags(hck_get_email_subject('email_new_ticket_admin'), $tags);
    return hck_send_mail($admin_email, $subject, $body);
}

// =============================================
// NOTIFICATION: ADMIN REPLY (CUSTOMER)
// =============================================
function hck_notify_customer_on_reply($ticket_id) {
    if (!hck_emails_enabled()) return false;
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) return false;
    $user = get_userdata(hck_get_ticket_user_id($ticket));
    $email = hck_ticket_notification_email($ticket, $user);
    if (!$email) return false;
    $tags = hck_email_build_tags($ticket, $user);
    if (!$user && class_exists('HCK_HelpCenter_Integration')) {
        $guest_url = HCK_HelpCenter_Integration::create_guest_access_link($ticket_id, $email, $ticket->customer_name ?: 'Customer');
        if (!$guest_url) return false;
        $tags['{ticket_url}'] = $guest_url;
        $tags['{customer_name}'] = $ticket->customer_name ?: 'Customer';
    }
    $body = hck_replace_email_tags(hck_get_email_template('email_admin_reply'), $tags);
    if (!$user) { if (strpos($body, esc_url($guest_url)) === false) $body .= hck_email_button('View and reply to your ticket',$guest_url); $body .= '<p style="font-size:12px;color:#64748B;line-height:1.6">Open this unique ticket link and enter the one-time code sent to this email address to view and reply. Email replies are not added to the ticket.</p>'; }
    $subject = hck_replace_email_tags(hck_get_email_subject('email_admin_reply'), $tags);
    return hck_send_mail($email, $subject, $body);
}

// =============================================
// NOTIFICATION: CUSTOMER REPLY (ADMIN)
// =============================================
function hck_notify_admin_on_reply($ticket_id) {
    if (!hck_emails_enabled()) return false;
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) return false;
    $user = get_userdata(hck_get_ticket_user_id($ticket));
    $admin_email = hck_get_setting('hck_support_email', get_option('admin_email'));
    if (!is_email($admin_email)) return false;
    $tags = hck_email_build_tags($ticket, $user);
    $body = hck_replace_email_tags(hck_get_email_template('email_customer_reply'), $tags);
    $subject = hck_replace_email_tags(hck_get_email_subject('email_customer_reply'), $tags);
    return hck_send_mail($admin_email, $subject, $body);
}

// =============================================
// NOTIFICATION: TICKET RESOLVED
// =============================================
function hck_notify_ticket_resolved($ticket_id) {
    if (!hck_emails_enabled()) return false;
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) return false;
    $user = get_userdata(hck_get_ticket_user_id($ticket));
    if (!$user) return false;
    $email = hck_ticket_notification_email($ticket, $user);
    if (!$email) return false;
    $tags = hck_email_build_tags($ticket, $user);
    $body = hck_replace_email_tags(hck_get_email_template('email_ticket_resolved'), $tags);
    $subject = hck_replace_email_tags(hck_get_email_subject('email_ticket_resolved'), $tags);
    return hck_send_mail($email, $subject, $body);
}

// =============================================
// NOTIFICATION: TICKET CLOSED
// =============================================
function hck_notify_ticket_closed($ticket_id) {
    if (!hck_emails_enabled()) return false;
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) return false;
    $user = get_userdata(hck_get_ticket_user_id($ticket));
    if (!$user) return false;
    $email = hck_ticket_notification_email($ticket, $user);
    if (!$email) return false;
    $tags = hck_email_build_tags($ticket, $user);
    $body = hck_replace_email_tags(hck_get_email_template('email_ticket_closed'), $tags);
    $subject = hck_replace_email_tags(hck_get_email_subject('email_ticket_closed'), $tags);
    return hck_send_mail($email, $subject, $body);
}

// =============================================
// NOTIFICATION: REMINDER (waiting on customer)
// =============================================
function hck_notify_reminder($ticket_id, $days_inactive, $days_remaining) {
    if (!hck_emails_enabled()) return false;
    $ticket = hck_get_ticket($ticket_id);
    if (!$ticket) return false;
    $user = get_userdata(hck_get_ticket_user_id($ticket));
    if (!$user) return false;
    $email = hck_ticket_notification_email($ticket, $user);
    if (!$email) return false;

    $tags = hck_email_build_tags($ticket, $user);
    $tags['{days_inactive}']  = (string) (int) $days_inactive;
    $tags['{days_remaining}'] = (string) (int) $days_remaining;

    $body    = hck_replace_email_tags(hck_get_email_template('email_reminder'), $tags);
    $subject = hck_replace_email_tags(hck_get_email_subject('email_reminder'), $tags);

    return hck_send_mail($email, $subject, $body);
}
