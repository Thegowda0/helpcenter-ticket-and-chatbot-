<?php
/**
 * HelpCenter -> HCK Ticket System integration.
 * HCK remains the authoritative ticket store after an agent conversion.
 */
if (!defined('ABSPATH')) exit;

class HCK_HelpCenter_Integration {
    const VERSION = '1.6.1';

    public static function register() {
        add_action('init', array(__CLASS__, 'install'), 7);
        add_action('wp_ajax_hc_ai_escalation_convert_hck', array(__CLASS__, 'ajax_convert'));
        add_action('wp_ajax_hck_resend_guest_access', array(__CLASS__, 'ajax_resend_guest_access'));
        add_action('template_redirect', array(__CLASS__, 'claim_route'), 0);
        add_action('init', array(__CLASS__, 'register_rewrite'), 4);
        add_filter('query_vars', array(__CLASS__, 'query_vars'));
    }

    public static function install() {
        if (get_option('hck_hc_integration_version') === self::VERSION) return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix;
        dbDelta("CREATE TABLE {$p}hck_hc_links (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            hc_ticket_id bigint(20) unsigned NOT NULL,
            hck_ticket_id bigint(20) unsigned NOT NULL,
            conversation_id bigint(20) unsigned NOT NULL DEFAULT 0,
            idempotency_key varchar(80) NOT NULL,
            converted_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY hc_ticket_id (hc_ticket_id),
            KEY hck_ticket_id (hck_ticket_id),
            UNIQUE KEY idempotency_key (idempotency_key)
        ) {$charset};");
        dbDelta("CREATE TABLE {$p}hck_ticket_sequences (
            year smallint(4) unsigned NOT NULL,
            last_number bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (year)
        ) {$charset};");
        dbDelta("CREATE TABLE {$p}hck_guest_claims (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            email varchar(190) NOT NULL,
            token_hash char(64) NOT NULL,
            expires_at datetime NOT NULL,
            claimed_at datetime NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY ticket_id (ticket_id),
            UNIQUE KEY token_hash (token_hash),
            KEY email (email)
        ) {$charset};");
        dbDelta("CREATE TABLE {$p}hck_guest_access_tokens (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            email varchar(190) NOT NULL,
            token_hash char(64) NOT NULL,
            otp_hash varchar(255) NOT NULL DEFAULT '',
            otp_expires_at datetime NULL,
            otp_attempts smallint(5) unsigned NOT NULL DEFAULT 0,
            otp_sent_at datetime NULL,
            expires_at datetime NOT NULL,
            used_at datetime NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY token_hash (token_hash),
            KEY ticket_id (ticket_id),
            KEY email (email)
        ) {$charset};");
        dbDelta("CREATE TABLE {$p}hck_guest_sessions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            email varchar(190) NOT NULL,
            token_hash char(64) NOT NULL,
            expires_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY token_hash (token_hash),
            KEY ticket_id (ticket_id)
        ) {$charset};");
        $tickets = $p . 'hck_tickets';
        $messages = $p . 'hck_ticket_messages';
        self::ensure_column($tickets, 'customer_email', "VARCHAR(190) NOT NULL DEFAULT ''");
        self::ensure_column($tickets, 'customer_name', "VARCHAR(120) NOT NULL DEFAULT ''");
        self::ensure_column($tickets, 'source', "VARCHAR(32) NOT NULL DEFAULT 'portal'");
        self::ensure_column($tickets, 'hc_ticket_id', "BIGINT(20) UNSIGNED DEFAULT NULL");
        self::ensure_column($tickets, 'ticket_type', "VARCHAR(8) NOT NULL DEFAULT 'tc'");
        self::ensure_column($tickets, 'ticket_sequence', "BIGINT(20) UNSIGNED NOT NULL DEFAULT 0");
        $seq_v2=$p.'hck_ticket_sequences_v2';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$seq_v2))!==$seq_v2) $wpdb->query("CREATE TABLE `{$seq_v2}` (year smallint(4) unsigned NOT NULL,ticket_type varchar(8) NOT NULL,last_number bigint(20) unsigned NOT NULL DEFAULT 0,PRIMARY KEY (year,ticket_type)) {$charset}");
        $wpdb->query("UPDATE {$tickets} SET ticket_type=CASE WHEN source LIKE 'helpcenter%' THEN 'hc' ELSE 'tc' END WHERE ticket_sequence=0");
        $legacy=$wpdb->get_results("SELECT id,created_at,ticket_number,ticket_type FROM {$tickets} WHERE ticket_sequence=0");
        foreach ((array)$legacy as $legacy_row) { $seq=0; if (preg_match('/-(\\d{6,})/',(string)$legacy_row->ticket_number,$mm)) $seq=(int)$mm[1]; if($seq<1)$seq=(int)$legacy_row->id; $wpdb->update($tickets,array('ticket_sequence'=>$seq),array('id'=>(int)$legacy_row->id)); }
        $wpdb->query("INSERT INTO {$p}hck_ticket_sequences_v2 (year,ticket_type,last_number) SELECT COALESCE(YEAR(created_at),YEAR(CURRENT_DATE())),ticket_type,MAX(ticket_sequence) FROM {$tickets} GROUP BY COALESCE(YEAR(created_at),YEAR(CURRENT_DATE())),ticket_type ON DUPLICATE KEY UPDATE last_number=GREATEST(last_number,VALUES(last_number))");
        self::ensure_column($messages, 'sender_name', "VARCHAR(120) NOT NULL DEFAULT ''");
        self::ensure_column($messages, 'sender_type', "VARCHAR(20) NOT NULL DEFAULT ''");
        self::ensure_column($messages, 'source_message_id', "VARCHAR(80) DEFAULT NULL");
        self::ensure_column($messages, 'is_system', "TINYINT(1) NOT NULL DEFAULT 0");
        $indexes=$wpdb->get_results("SHOW INDEX FROM {$p}hck_hc_links");
        $legacy_unique_hck_link=false;
        foreach ((array)$indexes as $idx) if ($idx->Key_name==='hck_ticket_id' && (int)$idx->Non_unique===0) { $wpdb->query("ALTER TABLE {$p}hck_hc_links DROP INDEX hck_ticket_id"); $legacy_unique_hck_link=true; break; }
        if ($legacy_unique_hck_link) $wpdb->query("ALTER TABLE {$p}hck_hc_links ADD KEY hck_ticket_id (hck_ticket_id)");
        // Backfill HelpCenter closure state for tickets that were already resolved
        // or closed before this integration version was installed.
        $hc_table=$p.'hc_ai_escalations';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hc_table))===$hc_table) {
            $closed_rows=$wpdb->get_results("SELECT DISTINCT t.id,t.status FROM {$tickets} t INNER JOIN {$p}hck_hc_links l ON l.hck_ticket_id=t.id WHERE t.status IN ('resolved','closed')");
            foreach((array)$closed_rows as $closed_row) self::sync_helpcenter_status((int)$closed_row->id,(string)$closed_row->status);
        }
        update_option('hck_hc_integration_version', self::VERSION, false);
    }

    private static function ensure_column($table, $column, $definition) {
        global $wpdb;
        $found = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$table}` LIKE %s", $column));
        if (!$found) $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
    }

    /** Ensure the extension columns exist even on sites upgraded from an older HCK schema. */
    private static function ensure_ticket_schema() {
        global $wpdb;
        $p=$wpdb->prefix;
        $tickets=$p.'hck_tickets';
        $messages=$p.'hck_ticket_messages';
        foreach (array($tickets,$messages) as $table) {
            $exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table));
            if ($exists!==$table) {
                if (function_exists('hck_install_database')) hck_install_database();
                $exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table));
            }
            if ($exists!==$table) throw new Exception('Required HCK table is missing: '.$table);
        }
        self::ensure_column($tickets,'customer_email',"VARCHAR(190) NOT NULL DEFAULT ''");
        self::ensure_column($tickets,'customer_name',"VARCHAR(120) NOT NULL DEFAULT ''");
        self::ensure_column($tickets,'source',"VARCHAR(32) NOT NULL DEFAULT 'portal'");
        self::ensure_column($tickets,'hc_ticket_id',"BIGINT(20) UNSIGNED DEFAULT NULL");
        self::ensure_column($tickets,'ticket_type',"VARCHAR(8) NOT NULL DEFAULT 'tc'");
        self::ensure_column($tickets,'ticket_sequence',"BIGINT(20) UNSIGNED NOT NULL DEFAULT 0");
        $number_col=$wpdb->get_row("SHOW COLUMNS FROM `{$tickets}` LIKE 'ticket_number'");
        if ($number_col && strtolower((string)$number_col->Type)!=='varchar(64)') $wpdb->query("ALTER TABLE `{$tickets}` MODIFY ticket_number VARCHAR(64) DEFAULT NULL");
        $seq_v2=$p.'hck_ticket_sequences_v2';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$seq_v2))!==$seq_v2) $wpdb->query("CREATE TABLE `{$seq_v2}` (year smallint(4) unsigned NOT NULL,ticket_type varchar(8) NOT NULL,last_number bigint(20) unsigned NOT NULL DEFAULT 0,PRIMARY KEY (year,ticket_type)) {$wpdb->get_charset_collate()}");
        $legacy_count=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$tickets} WHERE ticket_sequence=0");
        if($legacy_count){
            $wpdb->query("UPDATE {$tickets} SET ticket_type=CASE WHEN source LIKE 'helpcenter%' THEN 'hc' ELSE 'tc' END WHERE ticket_sequence=0");
            $legacy=$wpdb->get_results("SELECT id,created_at,ticket_number FROM {$tickets} WHERE ticket_sequence=0");
            foreach((array)$legacy as $legacy_row){$seq=0;if(preg_match('/-(\\d{6,})/',(string)$legacy_row->ticket_number,$mm))$seq=(int)$mm[1];if($seq<1)$seq=(int)$legacy_row->id;$wpdb->update($tickets,array('ticket_sequence'=>$seq),array('id'=>(int)$legacy_row->id));}
            $wpdb->query("INSERT INTO {$seq_v2} (year,ticket_type,last_number) SELECT COALESCE(YEAR(created_at),YEAR(CURRENT_DATE())),ticket_type,MAX(ticket_sequence) FROM {$tickets} GROUP BY COALESCE(YEAR(created_at),YEAR(CURRENT_DATE())),ticket_type ON DUPLICATE KEY UPDATE last_number=GREATEST(last_number,VALUES(last_number))");
        }
        self::ensure_column($messages,'sender_name',"VARCHAR(120) NOT NULL DEFAULT ''");
        self::ensure_column($messages,'sender_type',"VARCHAR(20) NOT NULL DEFAULT ''");
        self::ensure_column($messages,'source_message_id',"VARCHAR(80) DEFAULT NULL");
        self::ensure_column($messages,'is_system',"TINYINT(1) NOT NULL DEFAULT 0");
        if ($wpdb->last_error) throw new Exception('Could not prepare the HCK ticket sequence table: '.$wpdb->last_error);
        foreach (array('customer_email','customer_name','source','hc_ticket_id','ticket_type','ticket_sequence') as $col) {
            if (!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$tickets}` LIKE %s",$col))) throw new Exception('HCK ticket schema is missing column '.$col);
        }
        foreach (array('sender_name','sender_type','source_message_id','is_system') as $col) {
            if (!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$messages}` LIKE %s",$col))) throw new Exception('HCK message schema is missing column '.$col);
        }
    }

    public static function register_rewrite() { add_rewrite_rule('^ticket/claim/([A-Za-z0-9]{48,96})/?$', 'index.php?hck_page=claim&hck_claim_token=$matches[1]', 'top'); }
    public static function query_vars($vars) { $vars[] = 'hck_claim_token'; return $vars; }

    /** Create a unique, expiring link for each guest ticket email. */
    public static function create_guest_access_link($ticket_id,$email,$name='Customer') {
        global $wpdb;
        $email=sanitize_email($email); $ticket_id=absint($ticket_id);
        if (!$ticket_id || !is_email($email)) return false;
        $token=bin2hex(random_bytes(32)); $now=current_time('mysql');
        $expires=wp_date('Y-m-d H:i:s',time()+7*DAY_IN_SECONDS);
        $ok=$wpdb->insert($wpdb->prefix.'hck_guest_access_tokens',array('ticket_id'=>$ticket_id,'email'=>$email,'token_hash'=>hash('sha256',$token),'expires_at'=>$expires,'created_at'=>$now));
        return $ok ? home_url('/ticket/claim/'.$token.'/') : false;
    }

    private static function create_guest_claim($ticket_id,$email,$name) {
        return self::create_guest_access_link($ticket_id,$email,$name);
    }

    /** Return a reusable chatbot CTA only while its one-time token is still unused. */
    public static function guest_link_for_chat($hc_id,$ticket_id,$email,$name='Customer') {
        global $wpdb;
        $key='hc_hck_guest_url_'.absint($hc_id); $url=(string)get_transient($key);
        if ($url) {
            $token=basename((string)wp_parse_url($url,PHP_URL_PATH));
            $valid=preg_match('/^[A-Fa-f0-9]{64}$/',$token) ? $wpdb->get_var($wpdb->prepare('SELECT id FROM '.$wpdb->prefix.'hck_guest_access_tokens WHERE token_hash=%s AND used_at IS NULL AND expires_at>%s',hash('sha256',$token),current_time('mysql'))) : 0;
            if ($valid) return $url;
        }
        $url=self::create_guest_access_link($ticket_id,$email,$name);
        if ($url) set_transient($key,$url,DAY_IN_SECONDS);
        return $url;
    }

    public static function claim_route() {
        if (get_query_var('hck_page')!=='claim') return;
        global $wpdb;
        $token=(string)get_query_var('hck_claim_token');
        if (!preg_match('/^[A-Fa-f0-9]{64}$/',$token)) wp_die('This secure ticket link is invalid. Please request a new link.', 'Ticket access unavailable', array('response'=>410));
        $hash=hash('sha256',$token); $table=$wpdb->prefix.'hck_guest_access_tokens';
        $claim=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE token_hash=%s AND used_at IS NULL AND expires_at>%s",$hash,current_time('mysql')));
        if (!$claim) wp_die('This secure ticket link has expired or has already been used. Please request a new ticket access email.', 'Ticket access unavailable', array('response'=>410));
        $message='';
        if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['hck_guest_otp'])) {
            if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce']??'')),'hck_guest_access_'.$claim->id)) wp_die('Security check failed. Refresh the page and try again.','Ticket access unavailable',array('response'=>403));
            $otp=preg_replace('/\D+/','',(string)wp_unslash($_POST['hck_guest_otp']));
            $fresh=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND used_at IS NULL",(int)$claim->id));
            if (!$fresh || (int)$fresh->otp_attempts>=5 || empty($fresh->otp_hash) || empty($fresh->otp_expires_at) || $fresh->otp_expires_at<current_time('mysql') || !password_verify($otp,(string)$fresh->otp_hash)) {
                if ($fresh) $wpdb->update($table,array('otp_attempts'=>(int)$fresh->otp_attempts+1),array('id'=>(int)$fresh->id));
                $message='The code is incorrect or expired. You can request a new ticket access email.';
            } else {
                $create=!empty($_POST['hck_create_account']);
                $user=get_user_by('email',$fresh->email);
                if ($create && !$user) {
                    $login=sanitize_user(current(explode('@',$fresh->email)),true); if (!$login) $login='customer';
                    $base=$login; $n=1; while(username_exists($login)){$login=$base.$n++;}
                    $claim_ticket=hck_get_ticket((int)$fresh->ticket_id); $display_name=$claim_ticket && !empty($claim_ticket->customer_name)?$claim_ticket->customer_name:'Customer';
                    $new_id=wp_insert_user(array('user_login'=>$login,'user_email'=>$fresh->email,'user_pass'=>wp_generate_password(32,true,true),'display_name'=>sanitize_text_field($display_name),'role'=>get_role('customer')?'customer':'subscriber'));
                    if (is_wp_error($new_id)) { $message='We verified your email, but could not create your account. Please try again without selecting account creation.'; }
                    else { $user=get_user_by('id',$new_id); $key=get_password_reset_key($user); if (!is_wp_error($key)) { $reset=network_site_url('wp-login.php?action=rp&key='.rawurlencode($key).'&login='.rawurlencode($user->user_login),'login'); wp_mail($fresh->email,'Set your support account password','Your support account has been created. Set a password here: '.$reset); } }
                }
                if ($message==='') {
                    $wpdb->query('START TRANSACTION');
                    $ticket_id=(int)$fresh->ticket_id;
                    if ($user) {
                        if (strtolower($user->user_email)!==strtolower($fresh->email)) { $wpdb->query('ROLLBACK'); wp_die('The account email does not match the ticket email.','Email mismatch',array('response'=>403)); }
                        $ticket_update=$wpdb->update($wpdb->prefix.'hck_tickets',array('user_id'=>(int)$user->ID,'customer_id'=>(int)$user->ID,'updated_at'=>current_time('mysql')),array('id'=>$ticket_id));
                        $hc_links=$wpdb->get_col($wpdb->prepare('SELECT hc_ticket_id FROM '.$wpdb->prefix.'hck_hc_links WHERE hck_ticket_id=%d',$ticket_id));
                        $hc_update=1; foreach((array)$hc_links as $linked_hc_id){$updated=$wpdb->update($wpdb->prefix.'hc_ai_escalations',array('user_id'=>(int)$user->ID),array('id'=>(int)$linked_hc_id));if($updated===false){$hc_update=false;break;}}
                        $claim_update=$wpdb->update($table,array('used_at'=>current_time('mysql')),array('id'=>(int)$fresh->id));
                        if ($ticket_update===false || $hc_update===false || $claim_update===false) { $wpdb->query('ROLLBACK'); $message='We verified your email but could not link the ticket to your account. Please try again.'; }
                        else { $wpdb->query('COMMIT'); wp_set_current_user((int)$user->ID); wp_set_auth_cookie((int)$user->ID,true,is_ssl()); hck_add_log($ticket_id,(int)$user->ID,'guest_ticket_claimed','Ticket linked to account after email OTP verification'); }
                    } else {
                        $session=bin2hex(random_bytes(32));
                        $session_insert=$wpdb->insert($wpdb->prefix.'hck_guest_sessions',array('ticket_id'=>$ticket_id,'email'=>$fresh->email,'token_hash'=>hash('sha256',$session),'expires_at'=>wp_date('Y-m-d H:i:s',time()+14*DAY_IN_SECONDS),'created_at'=>current_time('mysql')));
                        $claim_update=$session_insert?$wpdb->update($table,array('used_at'=>current_time('mysql')),array('id'=>(int)$fresh->id)):false;
                        if (!$session_insert || $claim_update===false) { $wpdb->query('ROLLBACK'); $message='We verified your email but could not open the ticket session. Please try again.'; }
                        else { $wpdb->query('COMMIT'); setcookie('hck_guest_ticket_'.$ticket_id,$session,array('expires'=>time()+14*DAY_IN_SECONDS,'path'=>'/','secure'=>is_ssl(),'httponly'=>true,'samesite'=>'Lax')); hck_add_log($ticket_id,0,'guest_ticket_accessed','Guest ticket accessed after email OTP verification'); }
                    }
                    if ($message==='') { wp_safe_redirect(hck_customer_url('view/'.$ticket_id.'/')); exit; }
                }
            }
        }
        // OTP send is throttled to one request per minute and expires after ten minutes.
        $claim=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",(int)$claim->id));
        $last_sent_gmt = !empty($claim->otp_sent_at) ? get_gmt_from_date($claim->otp_sent_at) : '';
        $last_sent_ts = $last_sent_gmt ? strtotime($last_sent_gmt . ' UTC') : 0;
        if (!$last_sent_ts || (time()-$last_sent_ts)>60) {
            $otp=(string)random_int(100000,999999);
            $wpdb->update($table,array('otp_hash'=>password_hash($otp,PASSWORD_DEFAULT),'otp_expires_at'=>wp_date('Y-m-d H:i:s',time()+10*MINUTE_IN_SECONDS),'otp_attempts'=>0,'otp_sent_at'=>current_time('mysql')),array('id'=>(int)$claim->id));
            $ticket=hck_get_ticket((int)$claim->ticket_id); $number=$ticket?hck_get_ticket_number($ticket):('Ticket #'.(int)$claim->ticket_id);
            $body='<p>Your one-time verification code for support ticket <strong>'.esc_html($number).'</strong> is:</p><p style="font-size:28px;font-weight:700;letter-spacing:6px">'.esc_html($otp).'</p><p>This code expires in 10 minutes. Do not share it with anyone.</p>';
            $sent=function_exists('hck_send_mail')?hck_send_mail($claim->email,'Your support ticket verification code',hck_email_template('Ticket email verification','#4F46E5',$body)):false;
            if (!$sent) $sent=wp_mail($claim->email,'Your support ticket verification code',wp_strip_all_tags($body));
            if (!$sent) $message='We could not send the verification code. Please try again later or contact support.';
        }
        status_header(200); nocache_headers();
        $ticket=hck_get_ticket((int)$claim->ticket_id); $number=$ticket?hck_get_ticket_number($ticket):'Support ticket';
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Verify ticket access</title><style>body{font:16px/1.5 system-ui;background:#f5f7fb;margin:0;padding:28px;color:#172033}.card{max-width:460px;margin:7vh auto;background:#fff;padding:30px;border-radius:18px;box-shadow:0 10px 35px #10204012}h1{font-size:24px;margin:0 0 8px}p{color:#596579}.email{background:#f1f4f9;padding:12px;border-radius:9px;font-weight:600;overflow-wrap:anywhere}input[type=text]{width:100%;box-sizing:border-box;padding:14px;border:1px solid #ccd4e0;border-radius:9px;font-size:22px;letter-spacing:5px;text-align:center;margin:14px 0}label{display:flex;gap:9px;align-items:flex-start;margin:14px 0;color:#39465a}button{width:100%;border:0;border-radius:9px;background:#4f46e5;color:#fff;padding:14px;font-weight:700;font-size:16px;cursor:pointer}.error{color:#b42318;background:#fff1f0;padding:10px;border-radius:8px}</style></head><body><main class="card"><h1>Access your support ticket</h1><p>'.esc_html($number).'</p><p>We sent a one-time code to this email address. The address is fixed to protect your ticket.</p><div class="email">'.esc_html($claim->email).'</div>'.($message?'<p class="error">'.esc_html($message).'</p>':'').'<form method="post">'; wp_nonce_field('hck_guest_access_'.$claim->id); echo '<label for="hck_guest_otp">Enter your 6-digit email code</label><input id="hck_guest_otp" name="hck_guest_otp" type="text" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required>'; if (get_user_by('email',$claim->email)) echo '<p>An account already exists for this email address. Verifying the code will sign you into that account.</p>'; else echo '<label><input type="checkbox" name="hck_create_account" value="1"> Create a website account for me so I can access my tickets more easily in the future.</label>'; echo '<button type="submit">Verify and open ticket</button></form><p style="font-size:13px">If you leave account creation unchecked, you can still reply to this ticket as a guest. New ticket email links will be unique and require email verification. If the code does not arrive, refresh this page after one minute to request another code.</p></main></body></html>';
        exit;
    }

    public static function ajax_convert() {
        if (!class_exists('HC_Live_Support') || !HC_Live_Support::can_manage()) wp_send_json_error(array('message'=>'You are not authorized to convert this conversation.'),403);
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'hc_nonce')) wp_send_json_error(array('message'=>'Please refresh the Agent Desk and try again.'),403);
        $hc_id = absint($_POST['ticket_id'] ?? 0);
        if (!$hc_id) wp_send_json_error(array('message'=>'Invalid conversation reference.'),400);
        $result = self::convert_conversation($hc_id, get_current_user_id(), 'agent');
        if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()), 500);
        wp_send_json_success($result);
    }

    /** Convert an assigned HelpCenter live conversation from the isolated Agent Desk. */
    public static function agent_convert($hc_id, $actor_id) {
        $hc_id = absint($hc_id); $actor_id = absint($actor_id);
        if (!$hc_id || !$actor_id || !user_can($actor_id, 'hc_manage_ai_escalations')) return new WP_Error('forbidden','You are not allowed to convert this live conversation.');
        global $wpdb;
        $hc = $wpdb->get_row($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'hc_ai_escalations WHERE id=%d',$hc_id));
        if (!$hc) return new WP_Error('missing_conversation','The live conversation no longer exists.');
        if ((int)$hc->assigned_agent_id !== $actor_id && !user_can($actor_id,'manage_options')) return new WP_Error('not_assigned','Only the assigned agent can convert this live conversation.');
        return self::convert_conversation($hc_id,$actor_id,'agent');
    }

    /** Shared, idempotent conversion used by an agent and the five-minute timeout. */
    public static function auto_convert($hc_id) {
        $hc_id = absint($hc_id);
        if (!$hc_id) return new WP_Error('invalid_conversation', 'Invalid HelpCenter conversation.');
        global $wpdb;
        $hc = $wpdb->get_row($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'hc_ai_escalations WHERE id=%d', $hc_id));
        if (!$hc) return new WP_Error('missing_conversation', 'The HelpCenter conversation no longer exists.');
        if ($hc->status === 'converted') {
            $link = self::linked($hc_id);
            return $link ? self::response_for_link($link) : new WP_Error('missing_link','The conversation is marked converted but its ticket link is missing.');
        }
        // Assignment is the cutoff for automatic conversion. Once any agent owns the
        // conversation, only an explicit agent conversion may create the HCK ticket.
        $legacy = $hc->status === 'pending_email';
        if (!empty($hc->assigned_agent_id) || !empty($hc->accepted_at) || !empty($hc->agent_connected_at)) return new WP_Error('agent_assigned','A support agent has already been assigned to this conversation.');
        if (!in_array($hc->status, array('queued','active','waiting_agent','waiting_customer','pending_email'), true)) return new WP_Error('not_eligible','This conversation is not eligible for automatic follow-up.');
        $legacy_agent_id=(int)$hc->assigned_agent_id; $legacy_agent=$legacy_agent_id?get_userdata($legacy_agent_id):false;
        if (!$legacy_agent || !(user_can($legacy_agent,'hck_reply_tickets') || user_can($legacy_agent,'hc_manage_ai_escalations') || user_can($legacy_agent,'manage_options'))) $legacy_agent_id=0;
        return self::convert_conversation($hc_id, $legacy ? $legacy_agent_id : 0, $legacy ? 'legacy' : 'timeout');
    }

    private static function convert_conversation($hc_id, $actor_id, $mode) {
        global $wpdb;
        $hc_table = $wpdb->prefix.'hc_ai_escalations';
        $hc = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$hc_table} WHERE id=%d", (int)$hc_id));
        if (!$hc) return new WP_Error('missing_conversation','The HelpCenter conversation no longer exists.');
        $existing = self::linked($hc_id);
        if ($existing) return self::response_for_link($existing);
        if (!in_array($hc->status, array('active','waiting_agent','waiting_customer','pending_email','queued'), true)) return new WP_Error('not_eligible','This conversation is not eligible for conversion.');
        if ($mode === 'agent' && (int)$hc->assigned_agent_id !== (int)$actor_id && !user_can($actor_id,'manage_options')) return new WP_Error('not_assigned','Only the assigned agent or a supervisor can convert this conversation.');
        try { self::ensure_ticket_schema(); }
        catch (Throwable $schema_error) {
            error_log('[HCK integration] Ticket schema preparation failed for HC ticket '.$hc_id.': '.$schema_error->getMessage());
            return new WP_Error('hck_schema_unavailable','The ticket system database is not ready. No conversation data was changed. Please contact support.');
        }
        $email = sanitize_email($hc->visitor_email);
        if (!is_email($email)) return new WP_Error('missing_email','A valid customer email is required before this conversation can become a ticket.');
        $name = sanitize_text_field($hc->visitor_name ?: 'Customer');
        $wp_user_id = (int)$hc->user_id;
        $user = $wp_user_id ? get_userdata($wp_user_id) : false;
        if (!$user || strtolower($user->user_email) !== strtolower($email)) $wp_user_id = 0;
        $idempotency = 'hc-'.$hc_id;
        $wpdb->query('START TRANSACTION');
        $copied_files = array();
        $guest_access_url = '';
        try {
            // Serialize conversion against agent connection and duplicate conversion requests.
            $locked_hc=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$hc_table} WHERE id=%d FOR UPDATE",(int)$hc_id));
            if (!$locked_hc) throw new Exception('The HelpCenter conversation no longer exists.');
            $hc=$locked_hc;
            $existing = self::linked($hc_id, true);
            if ($existing) { $wpdb->query('COMMIT'); return self::response_for_link($existing); }
            if (!in_array($hc->status,array('active','waiting_agent','waiting_customer','pending_email','queued'),true)) throw new Exception('This conversation is no longer eligible for conversion.');
            if (in_array($mode,array('timeout','legacy'),true) && (!empty($hc->assigned_agent_id) || !empty($hc->accepted_at) || !empty($hc->agent_connected_at))) { $wpdb->query('ROLLBACK'); return new WP_Error('agent_assigned','A support agent was assigned before automatic conversion completed.'); }
            if ($mode==='agent' && (int)$hc->assigned_agent_id !== (int)$actor_id && !user_can($actor_id,'manage_options')) throw new Exception('Only the assigned agent or a supervisor can convert this conversation.');
            $email=sanitize_email($hc->visitor_email);
            if (!is_email($email)) throw new Exception('A valid customer email is required before this conversation can become a ticket.');
            $name=sanitize_text_field($hc->visitor_name ?: 'Customer');
            $wp_user_id=(int)$hc->user_id; $user=$wp_user_id?get_userdata($wp_user_id):false;
            if (!$user || strtolower($user->user_email)!==strtolower($email)) $wp_user_id=0;
            $category_map = function_exists('hck_get_ticket_categories') ? hck_get_ticket_categories() : array();
            $configured_hc_category = sanitize_title((string)hck_get_setting('hck_helpcenter_category', 'helpcenter'));
            $category = isset($category_map[$configured_hc_category]) ? $configured_hc_category : ($category_map ? (string)array_key_first($category_map) : 'helpcenter');
            $issue = self::original_issue_text($hc);
            $subject_issue = $issue !== '' ? $issue : 'Customer support request';
            $stable_title = !empty($hc->ai_title) ? (string)$hc->ai_title : $subject_issue;
            $subject = sanitize_text_field('HelpCenter follow-up: '.mb_substr($stable_title,0,220));
            if (mb_strlen($subject)<5) $subject='HelpCenter support follow-up';
            $now=current_time('mysql');
            $ticket_sequence=0; $ticket_year=0; $ticket_number=hck_generate_ticket_number('hc',$ticket_sequence,$ticket_year);
            // Agent-initiated follow-up tickets are assigned to the exact agent who
            // moved the HelpCenter conversation. Timeout conversions have actor_id=0
            // and therefore remain unassigned; legacy migrations retain their verified actor.
            $default_agent_id = ($mode === 'agent' && $actor_id > 0 && (user_can($actor_id,'hck_reply_tickets') || user_can($actor_id,'hc_manage_ai_escalations') || user_can($actor_id,'manage_options'))) ? (int)$actor_id : (($mode === 'legacy' && $actor_id > 0) ? (int)$actor_id : 0);
            $ticket_row=array(
                'ticket_number'=>$ticket_number, 'ticket_type'=>'hc', 'ticket_sequence'=>$ticket_sequence, 'user_id'=>$wp_user_id, 'customer_id'=>$wp_user_id ?: 0,
                'subject'=>$subject, 'category'=>$category,
                'priority'=>in_array($hc->priority,array('low','normal','high','urgent'),true)?$hc->priority:'normal',
                'status'=>'open','agent_id'=>$default_agent_id,'assigned_to'=>$default_agent_id,'created_at'=>$now,'updated_at'=>$now,
                'customer_email'=>$email,'customer_name'=>$name,'source'=>($mode==='timeout'?'helpcenter_timeout':($mode==='legacy'?'helpcenter_legacy_followup':'helpcenter_chat')),'hc_ticket_id'=>(int)$hc_id
            );
            if (!$wpdb->insert($wpdb->prefix.'hck_tickets',$ticket_row)) throw new Exception('Could not create the HCK ticket: '.$wpdb->last_error);
            $hck_id=(int)$wpdb->insert_id;
            if (function_exists('hck_sla_initialize_ticket')) hck_sla_initialize_ticket($hck_id);
            $timeline=self::build_timeline($hc);
            // Ensure the customer's complete, detailed concern is always present as a distinct first-class ticket entry.
            $issue_found=false;
            foreach ($timeline as $entry) if (($entry['source_id']??'')==='hcissue:'.(int)$hc_id || trim(wp_strip_all_tags((string)($entry['message']??'')))===trim(wp_strip_all_tags($issue))) {$issue_found=true;break;}
            if (!$issue_found && $issue!=='') {
                $timeline[]=array('time'=>$hc->created_at,'created_at'=>$hc->created_at,'type'=>'visitor','name'=>$name,'user_id'=>(int)$hc->user_id,'message'=>$issue,'source_id'=>'hcissue:'.(int)$hc_id,'internal'=>false);
                usort($timeline,function($a,$b){$ta=(string)($a['time']??$a['created_at']??'');$tb=(string)($b['time']??$b['created_at']??'');$cmp=strcmp($ta,$tb);return $cmp?:strcmp((string)($a['source_id']??''),(string)($b['source_id']??''));});
            }
            foreach ($timeline as $entry) {
                $row=array('ticket_id'=>$hck_id,'user_id'=>(int)($entry['user_id']??0),'message'=>(string)$entry['message'],
                    'is_admin'=>in_array($entry['type'],array('agent','ai','internal_note','system'),true)?1:0,
                    'is_internal'=>!empty($entry['internal'])?1:0,'is_system'=>$entry['type']==='system'?1:0,
                    'sender_name'=>sanitize_text_field($entry['name']),'sender_type'=>$entry['type'],
                    'source_message_id'=>$entry['source_id'],'created_at'=>$entry['created_at']?:$now);
                if (!$wpdb->insert($wpdb->prefix.'hck_ticket_messages',$row)) throw new Exception('Could not transfer the conversation transcript: '.$wpdb->last_error);
                $msg_id=(int)$wpdb->insert_id;
                if (!empty($entry['attachment'])) {
                    $copied=self::copy_attachment($entry['attachment'],$hck_id,$msg_id,(int)($entry['user_id']??0));
                    if ($copied) $copied_files[]=$copied;
                    else throw new Exception('An attachment could not be securely transferred. The original conversation remains available; retry conversion after resolving the attachment.');
                }
            }
            // A private, structured handoff brief makes the background and latest state easy for the next assigned agent to understand.
            $handoff_brief=self::build_handoff_brief($hc,$timeline,$actor_id,$mode);
            $brief_saved=$wpdb->insert($wpdb->prefix.'hck_ticket_messages',array(
                'ticket_id'=>$hck_id,'user_id'=>(int)$actor_id,'message'=>$handoff_brief,
                'is_admin'=>1,'is_internal'=>1,'is_system'=>0,
                'sender_name'=>'HelpCenter Handoff Brief','sender_type'=>'internal_note','created_at'=>$now
            ));
            if (!$brief_saved) throw new Exception('Could not save the private HelpCenter handoff brief: '.$wpdb->last_error);
            $link_inserted=$wpdb->insert($wpdb->prefix.'hck_hc_links',array('hc_ticket_id'=>(int)$hc_id,'hck_ticket_id'=>$hck_id,'conversation_id'=>(int)$hc->conversation_id,'idempotency_key'=>$idempotency,'converted_by'=>(int)$actor_id,'created_at'=>$now));
            if (!$link_inserted) throw new Exception('Could not save the HelpCenter ticket link: '.$wpdb->last_error);
            $hc_updated=$wpdb->update($hc_table,array('status'=>'converted','closed_at'=>$now,'last_activity'=>$now),array('id'=>(int)$hc_id));
            if ($hc_updated===false) throw new Exception('Could not lock the original HelpCenter conversation as read-only: '.$wpdb->last_error);
            $wpdb->query($wpdb->prepare("UPDATE ".$wpdb->prefix."hc_ai_escalation_messages SET email_status='cancelled',email_error='Migrated to HCK ticket portal; customer replies are portal-only.' WHERE ticket_id=%d AND sender_type='agent' AND email_status IN ('pending','failed','sending')",(int)$hc_id));
            $conversion_note = $mode==='timeout'
                ? 'No support agent joined within five minutes. This concern has automatically become HCK follow-up ticket '.hck_get_ticket_number(hck_get_ticket($hck_id)).'. Please use the ticket portal for all further replies.'
                : ($mode==='legacy'?'This existing email follow-up was migrated to HCK ticket '.hck_get_ticket_number(hck_get_ticket($hck_id)).'. The original chat is now read-only. Continue all replies in the ticket portal.':'This conversation was converted by a support agent into HCK follow-up ticket '.hck_get_ticket_number(hck_get_ticket($hck_id)).'. The original chat is now read-only. Continue all replies in the ticket portal.');
            $wpdb->insert($wpdb->prefix.'hc_ai_escalation_messages',array('ticket_id'=>(int)$hc_id,'conversation_id'=>(int)$hc->conversation_id,'sender_type'=>'system','sender_user_id'=>(int)$actor_id,'sender_name'=>'System','content'=>$conversion_note,'created_at'=>$now));
            hck_add_log($hck_id,(int)$actor_id,$mode==='timeout'?'auto_created_from_helpcenter':'created_from_helpcenter','Converted from HelpCenter conversation #'.$hc_id.' ('.$mode.')');
            if (!$wp_user_id) { $guest_access_url=self::guest_link_for_chat((int)$hc_id,$hck_id,$email,$name); if (!$guest_access_url) throw new Exception('Could not create secure guest ticket access.'); }
            $wpdb->query('COMMIT');
        } catch (Throwable $e) {
            $db_error=(string)$wpdb->last_error;
            $wpdb->query('ROLLBACK');
            foreach ($copied_files as $file) if (is_string($file) && is_file($file)) @unlink($file);
            error_log('[HCK integration] Conversion failed for HC ticket '.$hc_id.'; actor='.$actor_id.'; mode='.$mode.'; error='.$e->getMessage().($db_error!==''?'; db='.$db_error:''));
            return new WP_Error('conversion_failed','Ticket conversion could not be completed. Your original conversation is preserved. Please retry; if it fails again, share the matching [HCK integration] error from the server log.');
        }
        $ticket=hck_get_ticket($hck_id);
        if (function_exists('hck_notify_new_ticket_admin')) hck_notify_new_ticket_admin($hck_id);
        $portal_url=$wp_user_id?hck_customer_url('view/'.$hck_id.'/'):$guest_access_url;
        if (!$wp_user_id && $guest_access_url) set_transient('hc_hck_guest_url_'.(int)$hc_id,$guest_access_url,DAY_IN_SECONDS);
        $customer_message='Your concern has been moved to follow-up ticket '.hck_get_ticket_number($ticket).'. The original chatbot conversation is now read-only. Please use your secure ticket link for all further replies.';
        $system_saved=$wpdb->insert($wpdb->prefix.'hck_ticket_messages',array('ticket_id'=>$hck_id,'user_id'=>(int)$actor_id,'message'=>$customer_message,'is_admin'=>1,'is_system'=>1,'sender_name'=>'Support','sender_type'=>'system','created_at'=>current_time('mysql')));
        if (!$system_saved) error_log('[HCK integration] Could not add post-conversion system message for HCK ticket '.$hck_id.': '.$wpdb->last_error);
        // HCK's ticket-created notification and HelpCenter's follow-up notification are deliberately separate.
        // HCK's configured new-ticket email template is used for both account and guest customers.
        // Guest tickets receive a unique OTP access link through the template's {ticket_url} tag.
        $hck_customer_sent = function_exists('hck_notify_new_ticket_customer') ? hck_notify_new_ticket_customer($hck_id) : false;
        if (!$hck_customer_sent) {
            $fallback_ticket_link=$wp_user_id?$portal_url:self::create_guest_access_link($hck_id,$email,$name);
            $fallback_body='<p>Hello '.esc_html($name).',</p><p>Your HCK support ticket has been created.</p><p><strong>Ticket: '.esc_html(hck_get_ticket_number($ticket)).'</strong></p><p>Open this secure link. If you do not have a website account, enter the one-time code sent to this email and choose whether to create an account or continue as a guest.</p>'.hck_email_button('Open your support ticket',$fallback_ticket_link?:$portal_url);
            $hck_customer_sent=wp_mail($email,'['.hck_get_ticket_number($ticket).'] Ticket created',hck_email_template('Support ticket created','#4F46E5',$fallback_body),array('Content-Type: text/html; charset=UTF-8'));
        }
        $followup_link=$wp_user_id?$portal_url:self::create_guest_access_link($hck_id,$email,$name);
        $followup_reason=$mode==='timeout'?'No support agent connected within five minutes, so your concern has become a follow-up ticket.':($mode==='legacy'?'Your existing email follow-up has been moved into the HCK ticket system.':'Our support agent has moved your conversation to follow-up.');
        $followup_body='<p>Hello '.esc_html($name).',</p><p>'.esc_html($followup_reason).'</p><p>We have recorded your detailed concern and transferred your conversation to our ticket system.</p><p><strong>Your ticket reference: '.esc_html(hck_get_ticket_number($ticket)).'</strong></p><p>From now on, please use the ticket portal for all replies. Replies to this email will not be added to your ticket. The original chatbot conversation is retained as read-only history.</p>'.hck_email_button('View and reply to your ticket',$followup_link?:$portal_url);
        $followup_sent=wp_mail($email,'Follow-up created · '.hck_get_ticket_number($ticket),$followup_body,array('Content-Type: text/html; charset=UTF-8'));
        if (!$hck_customer_sent || !$followup_sent) error_log('[HCK integration] Customer notification transport issue for ticket '.$hck_id.'; email='.$email.'; HCK-created='.($hck_customer_sent?'accepted':'failed').'; HC-followup='.($followup_sent?'accepted':'failed').'; mail_error='.(isset($GLOBALS['phpmailer']) && is_object($GLOBALS['phpmailer']) ? 'check SMTP provider log' : 'wp_mail did not confirm acceptance'));
        if ($mode==='timeout' && HC_Core::get_setting('hc_ai_escalation_offline_email','1')!=='0') {
            $raw=(string)HC_Core::get_setting('hc_ai_escalation_recipients',get_option('admin_email'));
            $recipients=array_values(array_unique(array_filter(array_map('sanitize_email',preg_split('/[,;\s]+/',$raw)))));
            $internal='A HelpCenter human-support request was automatically converted after five minutes without an agent connecting.\n\nTicket: '.hck_get_ticket_number($ticket).'\nCustomer: '.$name.' <'.$email.'>\nConcern: '.wp_strip_all_tags((string)$hc->issue).'\n\nOpen ticket: '.hck_admin_url('view/'.$hck_id.'/');
            foreach($recipients as $recipient) if(is_email($recipient)) wp_mail($recipient,'Automatic HelpCenter follow-up created · '.hck_get_ticket_number($ticket),$internal);
        }
        return array('ticket_id'=>$hck_id,'ticket_number'=>hck_get_ticket_number($ticket),'url'=>$wp_user_id?$portal_url:'','admin_url'=>hck_admin_url('view/'.$hck_id.'/'),'guest'=>!$wp_user_id,'guest_access_url'=>$wp_user_id?'':$guest_access_url,'email_sent'=>(bool)$hck_customer_sent,'followup_email_sent'=>(bool)$followup_sent,'auto_created'=>$mode==='timeout','message'=>$mode==='timeout'?'No agent joined within five minutes. Your concern has been recorded as a follow-up ticket. Please continue in the ticket portal.':'Conversation converted to a follow-up ticket. The original chat is now read-only.');
    }

    /** Keep the original HelpCenter conversation closed when its HCK ticket is resolved/closed. */
    public static function sync_helpcenter_status($hck_ticket_id, $status, $actor_id = 0) {
        global $wpdb;
        $hck_ticket_id=absint($hck_ticket_id);
        if (!$hck_ticket_id || !in_array($status,array('resolved','closed'),true)) return;
        $links=$wpdb->prefix.'hck_hc_links'; $hc=$wpdb->prefix.'hc_ai_escalations';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links))!==$links) return;
        $ticket=hck_get_ticket($hck_ticket_id);
        $closed_by=absint($actor_id) ?: ($ticket && function_exists('hck_get_ticket_agent_id') ? hck_get_ticket_agent_id($ticket) : 0);
        $closed_at=$ticket ? ((string)($ticket->closed_at ?: ($ticket->resolved_at ?: current_time('mysql')))) : current_time('mysql');
        $ids=$wpdb->get_col($wpdb->prepare("SELECT hc_ticket_id FROM {$links} WHERE hck_ticket_id=%d",$hck_ticket_id));
        foreach ((array)$ids as $hc_id) {
            $now=current_time('mysql');
            // A converted HelpCenter chat becomes formally closed when its HCK source
            // ticket is resolved/closed. The link keeps it identifiable as migrated.
            $wpdb->update($hc,array('status'=>'closed','closed_at'=>$closed_at,'closed_by_agent_id'=>$closed_by,'last_activity'=>$now),array('id'=>(int)$hc_id));
            $note='The linked HCK ticket has been '.$status.'. This HelpCenter conversation remains closed and read-only. Start a new conversation for a new concern.';
            $already=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}hc_ai_escalation_messages WHERE ticket_id=%d AND sender_type='system' AND content=%s",(int)$hc_id,$note));
            if(!$already)$wpdb->insert($wpdb->prefix.'hc_ai_escalation_messages',array('ticket_id'=>(int)$hc_id,'sender_type'=>'system','sender_user_id'=>0,'sender_name'=>'System','content'=>$note,'created_at'=>$now));
        }
    }

    /** Block a new human handoff while an earlier HelpCenter follow-up has no public agent response. */
    public static function blocking_followup($user_id,$email,$visitor_hash = '') {
        global $wpdb;
        $tickets=$wpdb->prefix.'hck_tickets'; $links=$wpdb->prefix.'hck_hc_links'; $messages=$wpdb->prefix.'hck_ticket_messages'; $hc_table=$wpdb->prefix.'hc_ai_escalations';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links))!==$links) return null;
        $email=sanitize_email($email); $user_id=absint($user_id);
        if (!$user_id && !is_email($email) && !preg_match('/^[a-f0-9]{64}$/',(string)$visitor_hash)) return null;
        $identity=$user_id ? $wpdb->prepare('(t.user_id=%d OR (t.user_id=0 AND t.customer_email=%s))',$user_id,$email) : (is_email($email) ? $wpdb->prepare('t.customer_email=%s',$email) : '1=0');
        $visitor_hash=sanitize_text_field($visitor_hash);
        if (preg_match('/^[a-f0-9]{64}$/',$visitor_hash)) $identity='('.$identity.' OR hc.visitor_hash='.$wpdb->prepare('%s',$visitor_hash).')';
        $row=$wpdb->get_row("SELECT t.*,l.hc_ticket_id FROM {$tickets} t INNER JOIN {$links} l ON l.hck_ticket_id=t.id INNER JOIN {$hc_table} hc ON hc.id=l.hc_ticket_id WHERE {$identity} AND t.status NOT IN ('closed','resolved') AND NOT EXISTS (SELECT 1 FROM {$messages} m WHERE m.ticket_id=t.id AND m.is_internal=0 AND m.is_system=0 AND (m.sender_type='agent' OR (m.is_admin=1 AND m.sender_type<>'ai')) AND (m.source_message_id IS NULL OR m.source_message_id='')) ORDER BY t.created_at DESC LIMIT 1");
        if (!$row) return null;
        $row->portal_url=(int)$row->user_id>0 ? hck_customer_url('view/'.(int)$row->id.'/') : '';
        if (!(int)$row->user_id) {
            $guest_url=self::guest_link_for_chat((int)$row->hc_ticket_id,(int)$row->id,(string)$row->customer_email,(string)$row->customer_name);
            if ($guest_url) $row->portal_url=$guest_url;
        }
        return $row;
    }

    public static function ajax_resend_guest_access() {
        if (!function_exists('hck_is_agent') || !hck_is_agent()) wp_send_json_error(array('message'=>'You are not authorized to resend guest ticket access.'),403);
        check_ajax_referer('hck_nonce','nonce');
        $ticket_id=absint($_POST['ticket_id']??0); $ticket=hck_get_ticket($ticket_id);
        if (!$ticket || (int)$ticket->user_id>0) wp_send_json_error(array('message'=>'This ticket is already linked to a customer account or no longer exists.'),404);
        if (function_exists('hck_user_can_handle_ticket') && !hck_user_can_handle_ticket($ticket)) wp_send_json_error(array('message'=>'Only the assigned agent can resend guest access for this ticket.'),403);
        $email=sanitize_email($ticket->customer_email??'');
        if (!is_email($email)) wp_send_json_error(array('message'=>'The ticket does not have a valid customer email address.'),400);
        $claim_url=self::create_guest_access_link($ticket_id,$email,$ticket->customer_name?:'Customer');
        if (!$claim_url) wp_send_json_error(array('message'=>'Could not create a secure access link. Please try again.'),500);
        $body='<p>Hello '.esc_html($ticket->customer_name?:'there').',</p><p>Here is a new secure access link for your support ticket.</p><p><strong>Ticket: '.esc_html(hck_get_ticket_number($ticket)).'</strong></p><p>Open this unique link, enter the one-time code sent to this email, and choose whether to create a website account. You can reply in the ticket portal without creating an account. Replies to email notifications are not added to your ticket.</p>'.hck_email_button('Access your support ticket',$claim_url);
        $sent=hck_send_mail($email,'['.hck_get_ticket_number($ticket).'] Secure ticket access link',hck_email_template('Support ticket access','#4F46E5',$body));
        if (!$sent) $sent=wp_mail($email,'['.hck_get_ticket_number($ticket).'] Secure ticket access link',hck_email_template('Support ticket access','#4F46E5',$body),array('Content-Type: text/html; charset=UTF-8'));
        if (!$sent) wp_send_json_error(array('message'=>'The secure link was generated, but the mail transport did not confirm delivery. Check SMTP/provider logs.'),502);
        hck_add_log($ticket_id,get_current_user_id(),'guest_access_resent','Secure guest ticket access link resent to the stored customer email.');
        wp_send_json_success(array('message'=>'A new unique secure access link was sent to '.$email.'. Older unused links remain valid until they expire or are used.'));
    }

    private static function linked($hc_id,$lock=false) { global $wpdb; return $wpdb->get_row($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'hck_hc_links WHERE hc_ticket_id=%d'.($lock?' FOR UPDATE':''),(int)$hc_id)); }
    private static function response_for_link($link) {
        $t=hck_get_ticket($link->hck_ticket_id); $guest=!$t || !(int)$t->user_id;
        $url=$guest?self::guest_link_for_chat((int)$link->hc_ticket_id,(int)$link->hck_ticket_id,(string)($t->customer_email??''),(string)($t->customer_name??'Customer')):hck_customer_url('view/'.(int)$link->hck_ticket_id.'/');
        return array('ticket_id'=>(int)$link->hck_ticket_id,'ticket_number'=>$t?hck_get_ticket_number($t):'','url'=>$url,'admin_url'=>hck_admin_url('view/'.(int)$link->hck_ticket_id.'/'),'guest'=>$guest,'already_converted'=>true);
    }

    /**
     * Resolve the original handoff concern from the first visitor handoff message.
     * The dedicated issue column is a fallback because older records may have no
     * message row. Strip known timeout UI text if an older record contains it.
     */
    private static function original_issue_text($hc) {
        global $wpdb;
        $clean = function($value) {
            $value = trim(wp_strip_all_tags((string) $value));
            $value = preg_replace('/(?:\\s*Five minutes have passed\\.?\\s*Preparing your secure follow-up ticket(?:\\.{1,3}|…)?\\s*)+/iu', ' ', $value);
            $value = preg_replace('/(?:\\s*Five minutes have passed\\.?\\s*)+/iu', ' ', (string) $value);
            $value = preg_replace('/(?:\\s*Preparing your secure follow-up ticket(?:\\.{1,3}|…)?\\s*)+/iu', ' ', (string) $value);
            $value = preg_replace('/[ \\t]+/u', ' ', (string) $value);
            $value = preg_replace('/\\n{3,}/u', "\\n\\n", (string) $value);
            return trim((string) $value);
        };

        // The issue column is the authoritative value submitted by the handoff form.
        $issue = $hc ? $clean($hc->issue ?? '') : '';
        if (mb_strlen($issue) >= 100 || !$hc || empty($hc->id)) return $issue;

        // Older/broken records may have a status message in issue or no issue at all.
        // Recover the first detailed visitor handoff message as a fallback.
        $table = $wpdb->prefix . 'hc_ai_escalation_messages';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($exists === $table) {
            $message_issue = (string) $wpdb->get_var($wpdb->prepare(
                "SELECT content FROM {$table} WHERE ticket_id=%d AND sender_type='visitor' AND CHAR_LENGTH(TRIM(content))>=100 ORDER BY id ASC LIMIT 1",
                (int) $hc->id
            ));
            $message_issue = $clean($message_issue);
            if ($message_issue !== '') return $message_issue;
        }
        return $issue;
    }

    /** Build a concise internal handoff note; the full source timeline remains separately preserved. */
    private static function build_handoff_brief($hc, $timeline, $actor_id, $mode) {
        $clean = static function($value, $limit = 900) {
            $value = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string)$value)));
            if (function_exists('mb_strlen') && mb_strlen($value) > $limit) $value = mb_substr($value, 0, $limit) . '…';
            elseif (strlen($value) > $limit) $value = substr($value, 0, $limit) . '…';
            return $value;
        };
        $counts = array('visitor'=>0, 'ai'=>0, 'agent'=>0, 'internal_note'=>0, 'system'=>0);
        $last_customer = ''; $last_agent = '';
        foreach ((array)$timeline as $entry) {
            $type = (string)($entry['type'] ?? '');
            if (isset($counts[$type])) $counts[$type]++;
            $message = $clean($entry['message'] ?? '', 900);
            if ($type === 'visitor' && $message !== '') $last_customer = $message;
            if ($type === 'agent' && $message !== '') $last_agent = $message;
        }
        $agent = $actor_id ? get_userdata((int)$actor_id) : false;
        $agent_name = $agent ? ($agent->display_name ?: $agent->user_login) : 'Automatic HelpCenter follow-up';
        $reason = $mode === 'timeout' ? 'No human agent connected within the five-minute waiting window.' : ($mode === 'legacy' ? 'An existing HelpCenter email follow-up was migrated into HCK.' : 'The assigned support agent moved this conversation into HCK follow-up.');
        $issue = self::original_issue_text($hc);
        $lines = array(
            'HELPCENTER HANDOFF BRIEF — INTERNAL / AGENTS ONLY',
            'Source conversation: #'.(int)$hc->id,
            'Customer: '.sanitize_text_field((string)($hc->visitor_name ?: 'Customer')).' <'.sanitize_email((string)$hc->visitor_email).'>',
            'Transferred by: '.$clean($agent_name, 160),
            'Transferred at: '.current_time('mysql'),
            'Handoff reason: '.$reason,
            '',
            'CUSTOMER’S ORIGINAL CONCERN',
            $issue !== '' ? $clean($issue, 1800) : 'No separate detailed concern was recorded.',
            '',
            'CONVERSATION BACKGROUND',
            'Customer messages: '.$counts['visitor'].' · AI replies: '.$counts['ai'].' · Human-agent replies: '.$counts['agent'].' · Private notes: '.$counts['internal_note'].' · System events: '.$counts['system'],
            'The complete imported AI and human-support transcript, including transferred attachments where available, is preserved in this ticket history.',
            '',
            'LATEST CUSTOMER UPDATE',
            $last_customer !== '' ? $last_customer : 'No separate customer message was found in the source transcript.',
            '',
            'LATEST HUMAN-AGENT UPDATE',
            $last_agent !== '' ? $last_agent : 'No human-agent reply was recorded before the handoff.'
        );
        if (!empty($hc->ai_summary)) {
            $lines[] = '';
            $lines[] = 'EXISTING AI CONVERSATION SUMMARY';
            $lines[] = $clean($hc->ai_summary, 1400);
        }
        $lines[] = '';
        $lines[] = 'This note is private to authorized support agents. It is not sent to the customer. Use the original messages below for the exact wording and chronology.';
        return implode("\n", $lines);
    }

    private static function build_timeline($hc) {
        global $wpdb; $out=array();
        // Transfer only the AI conversation explicitly linked to this support ticket.
        // Do not merge unrelated conversations merely because they share a browser session.
        if (!empty($hc->conversation_id)) {
            $ai = $wpdb->get_results($wpdb->prepare("SELECT id,role,content,created_at FROM {$wpdb->prefix}hc_ai_messages WHERE conversation_id=%d AND role IN ('user','assistant') ORDER BY id ASC",(int)$hc->conversation_id), ARRAY_A);
            foreach ((array)$ai as $m) $out[]=array('time'=>$m['created_at'],'created_at'=>$m['created_at'],'type'=>$m['role']==='user'?'visitor':'ai','name'=>$m['role']==='user'?$hc->visitor_name:'AI Assistant','user_id'=>$m['role']==='user'?(int)$hc->user_id:0,'message'=>(string)$m['content'],'source_id'=>'ai:'.(int)$m['id'],'internal'=>false);
        }
        $ai_user_texts = array();
        foreach ($out as $prior) if ($prior['type'] === 'visitor') $ai_user_texts[hash('sha256',trim(wp_strip_all_tags($prior['message'])))] = true;
        $msgs=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'hc_ai_escalation_messages WHERE ticket_id=%d ORDER BY id ASC',(int)$hc->id));
        foreach ((array)$msgs as $m) {
            if ($m->sender_type === 'visitor' && isset($ai_user_texts[hash('sha256',trim(wp_strip_all_tags((string)$m->content)))])) continue;
            $att=null; $message_content=(string)$m->content;
            if (!empty($m->attachment_path)) {
                if (self::attachment_source($m)) $att=$m;
                else $message_content .= ($message_content!==''?"\n\n":'').'[Attachment could not be transferred because the original file is no longer available: '.sanitize_text_field($m->attachment_name ?: basename((string)$m->attachment_path)).']';
            } elseif (!empty($m->attachment_name) && !empty($m->attachment_deleted_at)) {
                $message_content .= ($message_content!==''?"\n\n":'').'[Attachment expired in HelpCenter storage: '.sanitize_text_field($m->attachment_name).']';
            }
            $is_internal = $m->sender_type === 'internal_note';
            $source_message_id='hcmsg:'.(int)$m->id;
            // A previously delivered agent email in a legacy pending_email conversation counts as an agent response for the re-escalation gate.
            if ($hc->status==='pending_email' && $m->sender_type==='agent' && ($m->email_status??'')==='sent') $source_message_id='';
            $out[]=array('time'=>$m->created_at,'created_at'=>$m->created_at,'type'=>$is_internal?'internal_note':($m->sender_type==='visitor'?'visitor':($m->sender_type==='system'?'system':'agent')),'name'=>$m->sender_name ?: ($m->sender_type==='visitor'?$hc->visitor_name:'Support'),'user_id'=>(int)$m->sender_user_id,'message'=>$message_content,'source_id'=>$source_message_id,'attachment'=>$att,'internal'=>$is_internal);
        }
        if (!empty($hc->ai_summary)) $out[]=array('time'=>$hc->created_at,'created_at'=>$hc->created_at,'type'=>'internal_note','name'=>'AI Support Summary','user_id'=>0,'message'=>"AI-generated conversation summary (internal):\n".(string)$hc->ai_summary,'source_id'=>'aisummary:'.(int)$hc->id,'internal'=>true);
        usort($out,function($a,$b){$c=strcmp($a['time'],$b['time']);return $c?:strcmp($a['source_id'],$b['source_id']);});
        if (!$out) {
            $issue = self::original_issue_text($hc);
            if ($issue !== '') $out[]=array('time'=>$hc->created_at,'created_at'=>$hc->created_at,'type'=>'visitor','name'=>$hc->visitor_name,'user_id'=>(int)$hc->user_id,'message'=>$issue,'source_id'=>'hcissue:'.(int)$hc->id);
        }
        return $out;
    }

    private static function attachment_source($m) {
        $file=basename((string)$m->attachment_path); $uploads=wp_upload_dir();
        $bases=array(HC_PATH.'storage/attachments',trailingslashit($uploads['basedir']).'helpcenter-private');
        foreach($bases as $candidate){$base=realpath($candidate);$path=$base?realpath($base.DIRECTORY_SEPARATOR.$file):false;if($path&&$base&&strpos($path,$base.DIRECTORY_SEPARATOR)===0&&is_readable($path))return $path;}
        return false;
    }

    private static function copy_attachment($m,$ticket_id,$message_id,$user_id) {
        global $wpdb;
        $file=basename((string)$m->attachment_path); $src=self::attachment_source($m);
        if (!$src) return false;
        $dir=hck_upload_dir(); $safe=sanitize_file_name($m->attachment_name ?: $file); $new=wp_generate_password(24,false,false).'_'.$safe; $dest=$dir.$new;
        if (!copy($src,$dest)) return false;
        $upload=wp_upload_dir();
        $saved=$wpdb->insert($wpdb->prefix.'hck_ticket_attachments',array('ticket_id'=>$ticket_id,'message_id'=>$message_id,'filename'=>$safe,'file_path'=>trailingslashit($upload['baseurl']).'hck-tickets/'.$new,'file_size'=>filesize($dest),'file_type'=>pathinfo($safe,PATHINFO_EXTENSION),'uploaded_by'=>$user_id,'created_at'=>current_time('mysql')));
        if (!$saved) { @unlink($dest); return false; }
        return $dest;
    }


}
HCK_HelpCenter_Integration::register();
