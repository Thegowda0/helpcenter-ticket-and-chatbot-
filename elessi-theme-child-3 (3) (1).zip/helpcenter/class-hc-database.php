<?php
/**
 * Help Center - Database Schema + Safe Migrations
 */

if (!defined('ABSPATH')) exit;

class HC_Database {

    const DB_VERSION = '2.6.0';

    /**
     * Run once on init — creates/migrates tables only if version changed.
     */
    public static function init() {
        global $wpdb;
        // Repair this critical column on every boot, even if a prior release recorded
        // the schema version before the ALTER TABLE actually succeeded.
        $articles_table = $wpdb->prefix . 'hc_articles';
        self::ensure_column($articles_table, 'category_hidden_status', "varchar(20) DEFAULT NULL");
        // Repair revision history independently of the version option: some installs
        // may already have recorded this version even though the table was never created.
        self::ensure_revision_table();

        $installed = get_option('hc_db_version', '0');
        if (version_compare($installed, self::DB_VERSION, '>=')) return;

        self::create_tables();
        self::migrate();
        self::seed_settings();
        update_option('hc_db_version', self::DB_VERSION);
    }

    /**
     * Force-create on demand.
     */
    public static function force_init() {
        self::create_tables();
        self::migrate();
        self::seed_settings();
        update_option('hc_db_version', self::DB_VERSION);
    }

    /** Ensure the revision table exists even when the saved schema version is stale. */
    public static function ensure_revision_table() {
        global $wpdb;
        $table = $wpdb->prefix . 'hc_revisions';
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
        if ($found === $table) return true;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            item_type varchar(10) NOT NULL,
            item_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            before_data longtext NOT NULL,
            after_data longtext NOT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY item_lookup (item_type, item_id),
            KEY created_at (created_at)
        ) {$charset};";
        dbDelta($sql);
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
        if ($found !== $table) {
            error_log('Help Center: unable to create revision table ' . $table . '. DB error: ' . $wpdb->last_error);
            return false;
        }
        return true;
    }

    /**
     * Create or migrate all tables. Uses dbDelta — safe, never drops data.
     */
    public static function create_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix;

        // ---- CATEGORIES ----
        dbDelta("CREATE TABLE {$p}hc_categories (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            slug varchar(255) NOT NULL,
            description text DEFAULT NULL,
            icon_type varchar(20) NOT NULL DEFAULT 'fontawesome',
            icon_value varchar(100) NOT NULL DEFAULT 'fa-folder',
            parent_id bigint(20) unsigned NOT NULL DEFAULT 0,
            sort_order int(11) NOT NULL DEFAULT 0,
            article_count int(11) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'published',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY parent_id (parent_id),
            KEY status (status)
        ) {$charset};");

        // ---- ARTICLES ----
        dbDelta("CREATE TABLE {$p}hc_articles (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            slug varchar(255) NOT NULL,
            excerpt text DEFAULT NULL,
            content longtext DEFAULT NULL,
            category_id bigint(20) unsigned NOT NULL DEFAULT 0,
            subcategory_id bigint(20) unsigned DEFAULT NULL,
            is_popular tinyint(1) NOT NULL DEFAULT 0,
            helpful_yes int(11) NOT NULL DEFAULT 0,
            helpful_no int(11) NOT NULL DEFAULT 0,
            view_count int(11) NOT NULL DEFAULT 0,
            reading_time int(11) NOT NULL DEFAULT 0,
            schema_type varchar(30) NOT NULL DEFAULT 'inherit',
            sort_order int(11) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'published',
            meta_keywords varchar(500) DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY category_id (category_id),
            KEY subcategory_id (subcategory_id),
            KEY status (status),
            KEY is_popular (is_popular)
        ) {$charset};");

        // ---- ARTICLE / FAQ REVISION HISTORY ----
        dbDelta("CREATE TABLE {$p}hc_revisions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            item_type varchar(10) NOT NULL,
            item_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            before_data longtext NOT NULL,
            after_data longtext NOT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY item_lookup (item_type, item_id),
            KEY created_at (created_at)
        ) {$charset};");

        // ---- FAQS ----
        dbDelta("CREATE TABLE {$p}hc_faqs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            question varchar(500) NOT NULL,
            answer longtext DEFAULT NULL,
            destination_type varchar(20) NOT NULL DEFAULT 'global',
            destination_id bigint(20) unsigned DEFAULT NULL,
            sort_order int(11) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'published',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY status (status),
            KEY destination (destination_type, destination_id)
        ) {$charset};");

        // ---- HELPFUL VOTES ----
        dbDelta("CREATE TABLE {$p}hc_helpful_votes (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            article_id bigint(20) unsigned NOT NULL,
            user_ip varchar(45) DEFAULT NULL,
            user_id bigint(20) unsigned DEFAULT 0,
            vote varchar(3) NOT NULL DEFAULT 'no',
            reason varchar(50) DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY article_id (article_id),
            KEY vote (vote)
        ) {$charset};");

        // ---- SEARCH LOG ----
        dbDelta("CREATE TABLE {$p}hc_search_log (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            search_query varchar(500) NOT NULL,
            results_count int(11) NOT NULL DEFAULT 0,
            user_ip varchar(45) DEFAULT NULL,
            user_id bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY search_query (search_query(191)),
            KEY results_count (results_count),
            KEY created_at (created_at)
        ) {$charset};");

        // ---- SEARCH RESULT CLICKS ----
        dbDelta("CREATE TABLE {$p}hc_search_clicks (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            article_id bigint(20) unsigned NOT NULL,
            search_query varchar(500) NOT NULL DEFAULT '',
            visitor_hash varchar(40) DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY article_id (article_id),
            KEY created_at (created_at),
            KEY search_query (search_query(191))
        ) {$charset};");

        // ---- SETTINGS ----
        dbDelta("CREATE TABLE {$p}hc_settings (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            setting_key varchar(100) NOT NULL,
            setting_value longtext DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY setting_key (setting_key)
        ) {$charset};");
    }


    // =============================================
    // MIGRATIONS (idempotent - safe to run more than once)
    // =============================================
    private static function ensure_column($table, $column, $definition) {
        global $wpdb;
        // SHOW COLUMNS is more compatible with restricted MySQL/MariaDB users than
        // INFORMATION_SCHEMA permissions and ensures old installs receive missing fields.
        $safe_table = preg_replace('/[^A-Za-z0-9_]/', '', (string) $table);
        $safe_column = preg_replace('/[^A-Za-z0-9_]/', '', (string) $column);
        if ($safe_table === '' || $safe_column === '') return;
        $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $safe_table));
        if ($table_exists !== $safe_table) return;
        $found = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$safe_table}` LIKE %s", $safe_column));
        if (!$found) {
            $wpdb->query("ALTER TABLE `{$safe_table}` ADD COLUMN `{$safe_column}` {$definition}");
            // If another request added it concurrently, ignore that race; otherwise keep the DB error visible in logs.
            if (!$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$safe_table}` LIKE %s", $safe_column))) {
                error_log('Help Center migration could not add column ' . $safe_table . '.' . $safe_column . ': ' . $wpdb->last_error);
            }
        }
    }

    public static function migrate() {
        global $wpdb;
        $p    = $wpdb->prefix;
        $cats = $p . 'hc_categories';
        $arts = $p . 'hc_articles';
        $faqs = $p . 'hc_faqs';
        $rel  = $p . 'hc_article_categories';

        // ---- columns the application code relies on ----
        self::ensure_column($cats, 'is_default',      "tinyint(1) NOT NULL DEFAULT 0");
        self::ensure_column($cats, 'deleted_at',      "datetime DEFAULT NULL");
        self::ensure_column($cats, 'last_action_at',  "datetime DEFAULT NULL");
        self::ensure_column($cats, 'last_action',     "varchar(50) DEFAULT NULL");

        self::ensure_column($arts, 'deleted_at',           "datetime DEFAULT NULL");
        self::ensure_column($arts, 'original_category_id', "bigint(20) unsigned DEFAULT NULL");
        self::ensure_column($arts, 'category_hidden_status', "varchar(20) DEFAULT NULL");
        self::ensure_column($arts, 'robots_meta',          "varchar(60) NOT NULL DEFAULT 'inherit'");
        self::ensure_column($arts, 'last_action_at',       "datetime DEFAULT NULL");
        self::ensure_column($arts, 'last_action',          "varchar(50) DEFAULT NULL");

        self::ensure_column($faqs, 'deleted_at',     "datetime DEFAULT NULL");
        self::ensure_column($faqs, 'draft_reasons',  "text DEFAULT NULL");
        self::ensure_column($faqs, 'last_action_at', "datetime DEFAULT NULL");
        self::ensure_column($faqs, 'last_action',    "varchar(50) DEFAULT NULL");

        // ---- article <-> category relation table ----
        $charset = $wpdb->get_charset_collate();
        $wpdb->query("CREATE TABLE IF NOT EXISTS {$rel} (
            article_id bigint(20) unsigned NOT NULL,
            category_id bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (article_id, category_id),
            KEY category_id (category_id)
        ) {$charset}");

        // ---- legacy statuses -> the clean model ----
        // Categories: published | hidden (+ trash via deleted_at)
        $wpdb->query("UPDATE {$cats} SET deleted_at = NOW(), status = 'hidden' WHERE status = 'trash' AND deleted_at IS NULL");
        $wpdb->query("UPDATE {$cats} SET status = 'hidden' WHERE status NOT IN ('published', 'hidden')");
        // Articles: published | draft (+ trash via deleted_at)
        $wpdb->query("UPDATE {$arts} SET deleted_at = NOW(), status = 'draft' WHERE status = 'trash' AND deleted_at IS NULL");
        $wpdb->query("UPDATE {$arts} SET status = 'draft' WHERE status NOT IN ('published', 'draft')");
        // FAQs: published | draft (+ trash via deleted_at)
        $wpdb->query("UPDATE {$faqs} SET deleted_at = NOW(), status = 'draft' WHERE status = 'trash' AND deleted_at IS NULL");
        $wpdb->query("UPDATE {$faqs} SET status = 'draft' WHERE status NOT IN ('published', 'draft')");

        // ---- default "Uncategorized" category + repair article links ----
        if (class_exists('HC_Lifecycle')) {
            HC_Lifecycle::ensure_default_category();

            // Articles that lost their category links (e.g. old FAQ-save bug): rebuild from articles.category_id.
            $wpdb->query("INSERT INTO {$rel} (article_id, category_id)
                SELECT a.id, a.category_id FROM {$arts} a
                WHERE a.category_id > 0
                  AND EXISTS (SELECT 1 FROM {$cats} c WHERE c.id = a.category_id)
                  AND NOT EXISTS (SELECT 1 FROM {$rel} r WHERE r.article_id = a.id)");

            // Anything still without a category goes to Uncategorized.
            $orphans = $wpdb->get_col("SELECT a.id FROM {$arts} a WHERE NOT EXISTS (SELECT 1 FROM {$rel} r WHERE r.article_id = a.id)");
            foreach ((array) $orphans as $aid) {
                HC_Lifecycle::normalize_article((int) $aid);
            }

            HC_Lifecycle::recount_categories();
        }
    }

    /**
     * Seed default settings if missing.
     */
    public static function seed_settings() {
        global $wpdb;
        $table = $wpdb->prefix . 'hc_settings';

        $defaults = array(
            // General
            'hc_site_title'          => 'Help Center',
            'hc_tagline'             => 'How can we help you today?',
            'hc_articles_per_page'   => '12',

            // Appearance
            'hc_primary_color'       => '#6366F1',
            'hc_accent_color'        => '#F59E0B',
            'hc_bg_color'            => '#F8FAFC',
            'hc_header_bg'           => '#FFFFFF',
            'hc_header_text'         => '#0F172A',
            'hc_dark_mode'           => 'auto',

            // Features
            'hc_show_search'         => '1',
            'hc_show_live_search'    => '1',
            'hc_show_breadcrumbs'    => '1',
            'hc_show_helpful'        => '1',
            'hc_show_related'        => '1',
            'hc_show_faqs'           => '1',
            'hc_show_toc'            => '1',
            'hc_show_reading_time'   => '1',
            'hc_show_view_count'     => '1',
            'hc_show_share'          => '1',
            'hc_show_print'          => '1',

            // FAQs
            'hc_faq_position'        => 'bottom',
            'hc_faq_max'             => '20',

            // SEO / Schema
            'hc_schema_enabled'      => '1',
            'hc_schema_breadcrumbs'  => '1',
            'hc_schema_faq'          => '1',
            'hc_schema_search'       => '1',
            'hc_schema_author'       => 'Support Team',
            'hc_schema_org_name'     => get_bloginfo('name'),
            'hc_schema_org_logo'     => '',
            'hc_schema_article_type' => 'TechArticle',

            // Contact
            'hc_contact_email'       => get_option('admin_email'),
            'hc_contact_phone'       => '',
            'hc_livechat_url'        => '',
            'hc_contact_upload'      => '1',
            'hc_contact_max_mb'      => '5',

            // Analytics
            'hc_log_searches'        => '1',
            'hc_log_retention_days'  => '90',

            // Advanced
            'hc_debug'               => '0',
        );

        foreach ($defaults as $key => $val) {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $table WHERE setting_key = %s", $key
            ));
            if (!$exists) {
                $wpdb->insert($table, array(
                    'setting_key'   => $key,
                    'setting_value' => $val,
                ));
            }
        }
    }

    /**
     * Uninstall helper (call from admin "Reset" action only).
     */
    public static function drop_all() {
        global $wpdb;
        $p = $wpdb->prefix;
        $wpdb->query("DROP TABLE IF EXISTS {$p}hc_articles");
        $wpdb->query("DROP TABLE IF EXISTS {$p}hc_categories");
        $wpdb->query("DROP TABLE IF EXISTS {$p}hc_faqs");
        $wpdb->query("DROP TABLE IF EXISTS {$p}hc_article_categories");
        $wpdb->query("DROP TABLE IF EXISTS {$p}hc_helpful_votes");
        $wpdb->query("DROP TABLE IF EXISTS {$p}hc_revisions");
        $wpdb->query("DROP TABLE IF EXISTS {$p}hc_search_log");
        $wpdb->query("DROP TABLE IF EXISTS {$p}hc_settings");
        delete_option('hc_db_version');
    }
}
