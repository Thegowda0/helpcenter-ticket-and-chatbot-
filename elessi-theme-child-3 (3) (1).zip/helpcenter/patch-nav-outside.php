<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/templates/wrapper.php';
$src = file_get_contents($file);

if (strpos($src, 'HC_NAV_OUTSIDE') !== false) {
    echo "SKIP: already moved outside\n";
    exit(0);
}

// Locate the category nav if-block
$navStart = strpos($src, "<?php if (!empty(\$nav_categories)");
if ($navStart === false) {
    echo "ERROR: category nav if-block not found\n";
    exit(1);
}

// Find the matching endif
$navEnd = strpos($src, "<?php endif; ?>", $navStart);
if ($navEnd === false) {
    echo "ERROR: matching endif not found\n";
    exit(1);
}
$navEnd += strlen("<?php endif; ?>");

$navBlock = substr($src, $navStart, $navEnd - $navStart);

// Remove it
$src = substr($src, 0, $navStart) . substr($src, $navEnd);

// Insert right after </header>
$headerClose = strpos($src, '</header>');
if ($headerClose === false) {
    echo "ERROR: </header> not found\n";
    exit(1);
}
$insertAt = $headerClose + strlen('</header>');

$src = substr($src, 0, $insertAt)
     . "\n\n<!-- HC_NAV_OUTSIDE: category nav moved outside sticky header -->\n"
     . $navBlock
     . substr($src, $insertAt);

file_put_contents($file, $src);
echo "OK: category nav moved outside sticky header\n";
