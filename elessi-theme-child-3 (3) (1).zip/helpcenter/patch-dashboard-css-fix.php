<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/assets/css/admin.css';
$src = file_get_contents($file);

// Remove our earlier aggressive v8.2 block
$start = strpos($src, '/* =============================================
   Dashboard — wider title column (v8.2)');
if ($start !== false) {
    // Find the end of this block
    $end = strpos($src, '/*', $start + 100);
    if ($end === false) $end = strlen($src);
    $src = substr($src, 0, $start) . substr($src, $end);
    echo "Removed v8.2 block\n";
} else {
    echo "v8.2 block not found\n";
}

// Also remove the older v8.1 dashboard block that may still be there
$start2 = strpos($src, '/* =============================================
   Dashboard cards — table containment (v8.1)');
if ($start2 !== false) {
    $end2 = strpos($src, '/*', $start2 + 100);
    if ($end2 === false) $end2 = strlen($src);
    $src = substr($src, 0, $start2) . substr($src, $end2);
    echo "Removed v8.1 block\n";
}

file_put_contents($file, $src);
echo "OK: old dashboard CSS removed\n";
