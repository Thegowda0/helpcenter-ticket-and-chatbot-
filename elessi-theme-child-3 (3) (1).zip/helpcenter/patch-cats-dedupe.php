<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/admin/categories-list.php';
$src = file_get_contents($file);

if (strpos($src, 'HC_CATS_DEDUPE') !== false) {
    echo "SKIP: already fixed\n";
    exit(0);
}

// Find the current query and replace with a top-level-only query
$old = "$sql = \"SELECT * FROM {\$wpdb->prefix}hc_categories \$where_sql ORDER BY parent_id ASC, sort_order ASC, name ASC LIMIT 100\";";

$new = "// HC_CATS_DEDUPE: fetch only top-level; hc_render_cat_rows() recurses into children itself\n"
     . "$sql = \"SELECT * FROM {\$wpdb->prefix}hc_categories \$where_sql AND parent_id = 0 ORDER BY sort_order ASC, name ASC LIMIT 100\";";

$count = 0;
$src = str_replace($old, $new, $src, $count);

if ($count === 0) {
    echo "ERROR: SQL block not matched. Paste this output:\n";
    echo "grep -n 'SELECT \\* FROM' admin/categories-list.php\n";
    exit(1);
}

file_put_contents($file, $src);
echo "OK: initial render now only top-level categories\n";
