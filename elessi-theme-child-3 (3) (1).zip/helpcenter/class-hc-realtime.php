<?php
/**
 * HelpCenter Realtime Transport Adapter.
 * Ably is a delivery layer only; WordPress/MySQL remain authoritative.
 */
if (!defined('ABSPATH')) exit;

class HC_Realtime {
    private static $deferred_ticket_events = array();
    private static $deferred_ai_events = array();
    private static $deferred_shutdown_registered = false;
    private static $flushing_deferred_events = false;
    const OPTION_KEY = 'hc_realtime_ably_key_enc';
    const OUTBOX_VERSION = '1';

    public static function register() {
        add_action('wp_ajax_hc_realtime_token', array(__CLASS__, 'issue_token'));
        add_action('wp_ajax_nopriv_hc_realtime_token', array(__CLASS__, 'issue_token'));
        add_action('wp_ajax_hc_realtime_test', array(__CLASS__, 'test_connection'));
        // Extend PHP-generated CSP headers for the Ably SDK and its realtime transports.
        add_action('send_headers', array(__CLASS__, 'allow_ably_csp'), 999);
        add_action('hc_realtime_flush_outbox', array(__CLASS__, 'flush_outbox'));
        add_action('hc_realtime_deferred_ticket_publish', array(__CLASS__, 'run_deferred_ticket_publish'), 10, 4);
        add_action('hc_realtime_deferred_ai_publish', array(__CLASS__, 'run_deferred_ai_publish'), 10, 4);
        add_filter('cron_schedules', array(__CLASS__, 'cron_schedules'));
        self::install_outbox();
    }

    /**
     * Add Ably to a CSP header when that policy is emitted by WordPress/PHP.
     * Server-level CSP headers must be adjusted in the hosting/security-panel config.
     */
    public static function allow_ably_csp() {
        if (headers_sent()) return;
        $headers = headers_list();
        $policies = array();
        foreach ($headers as $line) {
            if (stripos($line, 'Content-Security-Policy:') === 0) {
                $policies[] = trim(substr($line, strlen('Content-Security-Policy:')));
            }
        }
        if (!$policies) return;
        $updated = array();
        foreach ($policies as $policy) {
            $directives = array();
            foreach (explode(';', $policy) as $part) {
                $bits = preg_split('/\\s+/', trim($part));
                if (!$bits || empty($bits[0])) continue;
                $name = strtolower(array_shift($bits));
                $directives[$name] = array_values(array_unique(array_merge(isset($directives[$name]) ? $directives[$name] : array(), $bits)));
            }
            $fallback = isset($directives['default-src']) ? $directives['default-src'] : array("'self'");
            $script = isset($directives['script-src']) ? $directives['script-src'] : $fallback;
            if (!in_array('https://cdn.ably.com', $script, true)) $script[] = 'https://cdn.ably.com';
            $directives['script-src'] = $script;
            $connect = isset($directives['connect-src']) ? $directives['connect-src'] : $fallback;
            foreach (array('https://*.ably-realtime.com','wss://*.ably-realtime.com','https://rest.ably.io','wss://realtime.ably.io','https://main.realtime.ably.net','wss://ws-up.ably-realtime.com') as $origin) {
                if (!in_array($origin, $connect, true)) $connect[] = $origin;
            }
            $directives['connect-src'] = $connect;
            $parts = array();
            foreach ($directives as $name => $sources) $parts[] = $name . ($sources ? ' ' . implode(' ', $sources) : '');
            $updated[] = implode('; ', $parts);
        }
        // Replace PHP-generated policies instead of adding a second, more restrictive policy.
        header_remove('Content-Security-Policy');
        foreach ($updated as $policy) header('Content-Security-Policy: ' . $policy, false);
    }

    public static function cron_schedules($schedules) {
        if (!isset($schedules['hc_one_minute'])) $schedules['hc_one_minute'] = array('interval' => 60, 'display' => 'Every minute');
        return $schedules;
    }

    private static function outbox_table() {
        global $wpdb;
        return $wpdb->prefix . 'hc_realtime_outbox';
    }

    private static function install_outbox() {
        global $wpdb;
        if (get_option('hc_realtime_outbox_version') === self::OUTBOX_VERSION) return;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::outbox_table();
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            channel_name varchar(190) NOT NULL,
            event_name varchar(80) NOT NULL,
            payload longtext NOT NULL,
            attempts smallint(5) unsigned NOT NULL DEFAULT 0,
            next_attempt_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY due_events (next_attempt_at,id)
        ) {$charset};");
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
        if ($exists !== $table) return;
        update_option('hc_realtime_outbox_version', self::OUTBOX_VERSION, false);
        if (!wp_next_scheduled('hc_realtime_flush_outbox')) wp_schedule_event(time() + 30, 'hc_one_minute', 'hc_realtime_flush_outbox');
    }

    public static function encrypt_key($plain) {
        $plain = trim((string)$plain);
        if ($plain === '') return '';
        if (!function_exists('openssl_encrypt')) return '';
        $key = hash('sha256', wp_salt('auth') . '|' . wp_salt('secure_auth'), true);
        try { $iv = random_bytes(16); } catch (Throwable $e) { return ''; }
        $cipher = openssl_encrypt($plain, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        return $cipher === false ? '' : 'enc:v1:' . base64_encode($iv . $cipher);
    }

    private static function api_credentials() {
        $stored = (string) get_option(self::OPTION_KEY, '');
        if (strpos($stored, 'enc:v1:') !== 0 || !function_exists('openssl_decrypt')) return array('', '');
        $raw = base64_decode(substr($stored, 7), true);
        if (!$raw || strlen($raw) < 33) return array('', '');
        $iv = substr($raw, 0, 16);
        $cipher = substr($raw, 16);
        $key = hash('sha256', wp_salt('auth') . '|' . wp_salt('secure_auth'), true);
        $plain = openssl_decrypt($cipher, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        if (!$plain || strpos($plain, ':') === false) return array('', '');
        $parts = explode(':', $plain, 2);
        return array($parts[0], $parts[1]);
    }

    public static function is_configured() {
        list($name, $secret) = self::api_credentials();
        return $name !== '' && $secret !== '';
    }

    public static function save_api_key($key) {
        $key = trim(sanitize_text_field((string)$key));
        if ($key === '') return true;
        // Ably key format: appId.keyName:secret
        if (!preg_match('/^[A-Za-z0-9._-]+:[A-Za-z0-9+\/_=-]{12,}$/', $key)) return false;
        $encrypted = self::encrypt_key($key);
        if ($encrypted === '') return false;
        update_option(self::OPTION_KEY, $encrypted, false);
        return true;
    }

    private static function request_token($capability, $client_id, $ttl = 3600000) {
        list($key_name, $secret) = self::api_credentials();
        if (!$key_name || !$secret) return new WP_Error('hc_ably_not_configured', 'Ably API key is not configured.');
        $url = 'https://main.realtime.ably.net/keys/' . rawurlencode($key_name) . '/requestToken';
        try { $nonce = bin2hex(random_bytes(16)); } catch (Throwable $e) { return new WP_Error('hc_ably_crypto_unavailable', 'The server cannot generate a secure authentication nonce. Enable PHP OpenSSL and secure random support.'); }
        $response = wp_remote_post($url, array(
            'timeout' => 2.5,
            'redirection' => 0,
            'limit_response_size' => 65536,
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($key_name . ':' . $secret),
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ),
            'body' => wp_json_encode(array(
                'keyName' => $key_name,
                'clientId' => substr(sanitize_text_field($client_id), 0, 80),
                'capability' => wp_json_encode($capability),
                'ttl' => max(60000, min(3600000, (int)$ttl)),
                'timestamp' => (int) floor(microtime(true) * 1000),
                'nonce' => $nonce,
            )),
        ));
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || empty($body['token'])) {
            $message = is_array($body) ? ($body['error']['message'] ?? $body['message'] ?? 'Ably rejected the token request.') : 'Ably returned an invalid token response.';
            return new WP_Error('hc_ably_token_failed', sanitize_text_field($message), array('status' => $code));
        }
        return $body;
    }

    public static function issue_token() {
        if (!self::is_configured()) wp_send_json_error(array('message' => 'Real-time service is not configured.'), 503);
        $current_user = wp_get_current_user();
        $is_admin = is_user_logged_in() && current_user_can('manage_options');
        $is_agent = is_user_logged_in() && (
            in_array('hc_support_agent', (array)$current_user->roles, true) ||
            current_user_can('hc_agent_portal_access') ||
            current_user_can('hc_manage_ai_escalations')
        );
        $channel = '';
        $channels = array();
        $client_id = '';
        $channel_type = sanitize_key(wp_unslash($_POST['channel_type'] ?? 'support'));
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        // HCK uses its own ticket table and nonce. Its customer/agent portals
        // previously had no Ably token path, so they waited for the DB save and
        // a later transcript reload before the other side could see a reply.
        if ($channel_type === 'hck_ticket') {
            if (!wp_verify_nonce($nonce, 'hck_nonce')) {
                wp_send_json_error(array('message' => 'Please refresh the ticket page.'), 403);
            }
            if (!function_exists('hck_get_ticket') || !function_exists('hck_is_agent') || !function_exists('hck_user_can_access_ticket')) {
                wp_send_json_error(array('message' => 'HCK ticket service is unavailable.'), 503);
            }
            $hck_ticket_id = absint($_POST['ticket_id'] ?? 0);
            if (!$hck_ticket_id) wp_send_json_error(array('message' => 'A ticket ID is required.'), 400);
            $hck_ticket = hck_get_ticket($hck_ticket_id);
            if (!$hck_ticket || !empty($hck_ticket->merged_into)) {
                wp_send_json_error(array('message' => 'Ticket not found.'), 404);
            }
            $uid = (int) get_current_user_id();
            $hck_staff = $uid > 0 && hck_is_agent();
            if ($hck_staff) {
                if (!hck_user_can_access_ticket($hck_ticket, $uid)) {
                    wp_send_json_error(array('message' => 'You cannot access this ticket.'), 403);
                }
                // Agent Desk opens an HCK follow-up from a currently assigned HelpCenter
                // conversation. Bind the realtime token to that same customer/context;
                // a guessed HCK ticket ID alone must not grant a cross-customer channel.
                $source_hc_ticket_id = absint($_POST['source_hc_ticket_id'] ?? 0);
                if ($source_hc_ticket_id) {
                    global $wpdb;
                    $source_table = $wpdb->prefix . 'hc_ai_escalations';
                    $source_ticket = $wpdb->get_row($wpdb->prepare("SELECT id,user_id,visitor_email,assigned_agent_id,closed_by_agent_id,status FROM {$source_table} WHERE id=%d", $source_hc_ticket_id));
                    if (!$source_ticket) wp_send_json_error(array('message' => 'The linked HelpCenter conversation is no longer available.'), 404);
                    $source_access = ((int)$source_ticket->assigned_agent_id === $uid)
                        || ((string)$source_ticket->status === 'closed' && (int)$source_ticket->closed_by_agent_id === $uid)
                        || current_user_can('hck_view_tickets') || current_user_can('hc_manage_ai_escalations') || current_user_can('manage_options');
                    $links_table = $wpdb->prefix . 'hck_hc_links';
                    $verified_link = $wpdb->get_var($wpdb->prepare(
                        "SELECT id FROM {$links_table} WHERE hc_ticket_id=%d AND hck_ticket_id=%d LIMIT 1",
                        $source_hc_ticket_id, $hck_ticket_id
                    ));
                    if (!$source_access || !$verified_link) wp_send_json_error(array('message' => 'You cannot access this linked customer ticket.'), 403);
                }
                $hck_can_reply = function_exists('hck_user_can_handle_ticket') && hck_user_can_handle_ticket($hck_ticket, $uid);
            } else {
                $owner_id = function_exists('hck_get_ticket_user_id') ? (int) hck_get_ticket_user_id($hck_ticket) : 0;
                $guest_ticket_id = (!$uid && function_exists('hck_guest_session_ticket_id')) ? (int) hck_guest_session_ticket_id($hck_ticket_id) : 0;
                $customer_authorized = ($uid > 0 && $owner_id === $uid) || (!$uid && $guest_ticket_id === $hck_ticket_id);
                if (!$customer_authorized) wp_send_json_error(array('message' => 'Please verify your ticket access.'), 403);
                $hck_can_reply = !in_array((string)($hck_ticket->status ?? ''), array('closed','resolved'), true);
            }
            $customer_channel = 'hck-customer-' . $hck_ticket_id;
            $agent_channel = 'hck-agent-' . $hck_ticket_id;
            $channel = $hck_staff ? $customer_channel : $agent_channel;
            $channels = array($customer_channel, $agent_channel);
            $client_id = $hck_staff ? ('hck-staff-' . $uid) : ('hck-customer-' . $hck_ticket_id . ($uid ? '-' . $uid : '-guest'));
            if ($hck_staff) {
                // Every authorized staff viewer may receive public customer replies.
                // Only the assigned/eligible handler may publish public agent replies.
                $capability = array($customer_channel => array('subscribe'));
                $capability[$agent_channel] = $hck_can_reply ? array('publish', 'subscribe') : array('subscribe');
            } else {
                // Customers publish only their own ticket messages and receive public agent replies.
                $customer_can_publish = $hck_can_reply && empty($hck_ticket->merged_into);
                $capability = array(
                    $customer_channel => $customer_can_publish ? array('publish', 'subscribe') : array('subscribe'),
                    $agent_channel => array('subscribe'),
                );
            }
            $token = self::request_token($capability, $client_id, 3600000);
            if (is_wp_error($token)) wp_send_json_error(array('message' => $token->get_error_message()), 502);
            wp_send_json_success(array(
                'token' => $token,
                'channel' => $channel,
                'channels' => $channels,
                'transport' => 'ably',
                'direct_publish' => (bool)($hck_staff ? $hck_can_reply : $hck_can_reply),
            ));
        }

        $admin_nonce_ok = ($is_admin && (wp_verify_nonce($nonce, 'hc_nonce') || wp_verify_nonce($nonce, 'hc_agent_portal')));
        $agent_nonce_ok = ($is_agent && wp_verify_nonce($nonce, 'hc_agent_portal'));
        if ($admin_nonce_ok || $agent_nonce_ok) {
            $uid = get_current_user_id();
            $client_id = ($admin_nonce_ok ? 'admin-' : 'agent-') . $uid;
            if ($channel_type === 'agent_ticket') {
                $ticket_id = absint($_POST['ticket_id'] ?? 0);
                if (!$ticket_id) wp_send_json_error(array('message' => 'A ticket ID is required for its private realtime channel.'), 400);
                global $wpdb;
                $ticket_table = $wpdb->prefix . 'hc_ai_escalations';
                $ticket = $wpdb->get_row($wpdb->prepare("SELECT id,session_hash,assigned_agent_id,status,closed_by_agent_id FROM {$ticket_table} WHERE id=%d", $ticket_id));
                $can_publish_agent = ($ticket && !in_array((string)$ticket->status, array('closed','archived','converted'), true) && ($admin_nonce_ok || (int)$ticket->assigned_agent_id === $uid));
                $allowed = $admin_nonce_ok || ($ticket && ((int)$ticket->assigned_agent_id === $uid || ($ticket->status === 'closed' && (int)$ticket->closed_by_agent_id === $uid)));
                if (!$ticket || !$allowed) wp_send_json_error(array('message' => 'You are not allowed to subscribe to this ticket.'), 403);
                $channel = 'hc-ticket-' . $ticket_id . '-' . (int)$ticket->assigned_agent_id;
                // Hybrid direct transport: agents receive visitor messages on the
                // dedicated customer-message channel and on the assigned-ticket
                // fallback channel; public agent replies use the reply channel.
                $customer_channel = 'hc-customer-msg-' . $ticket_id;
                $reply_channel = 'hc-agent-reply-' . $ticket_id;
                $channels = array_values(array_filter(array($channel, $customer_channel, $reply_channel)));
            } else {
                $channel = 'hc-support-staff';
                $channels = array($channel);
            }
        } else {
            if (!wp_verify_nonce($nonce, 'hc_ai_public')) wp_send_json_error(array('message' => 'Please refresh the support chat.'), 403);
            $session = sanitize_text_field(wp_unslash($_POST['session_id'] ?? ''));
            $hash = class_exists('HC_AI_Platform') ? HC_AI_Platform::session_hash($session) : '';
            if (!$hash) wp_send_json_error(array('message' => 'Conversation not found. Please refresh the chat.'), 404);
            if ($channel_type === 'ai') {
                // Subscribe-only access to this visitor's unguessable AI conversation channel.
                $channel = 'hc-ai-visitor-' . substr($hash, 0, 48);
                $client_id = 'ai-visitor-' . substr($hash, 0, 24);
                $channels = array($channel);
            } else {
                if (!class_exists('HC_Live_Support')) wp_send_json_error(array('message' => 'Support conversation not found.'), 404);
                $requested_ticket_id = absint($_POST['ticket_id'] ?? 0);
                if ($requested_ticket_id) {
                    global $wpdb;
                    $ticket_table = $wpdb->prefix . 'hc_ai_escalations';
                    $ticket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$ticket_table} WHERE id=%d AND session_hash=%s LIMIT 1", $requested_ticket_id, $hash));
                } else {
                    $ticket = HC_Live_Support::ticket_for_session($hash);
                }
                if (!$ticket || !in_array($ticket->status, array('queued','active','waiting_agent','waiting_customer','pending_email'), true)) wp_send_json_error(array('message' => 'There is no active support conversation for this ticket.'), 404);
                $channel = 'hc-visitor-' . substr($hash, 0, 48);
                $client_id = 'visitor-' . substr($hash, 0, 24);
                $reply_channel = 'hc-agent-reply-' . (int)$ticket->id;
                $customer_channel = 'hc-customer-msg-' . (int)$ticket->id;
                $channels = array($channel, $reply_channel, $customer_channel);
            }
        }
        // Least-privilege, role-separated channel permissions. Customers publish
        // only to their ticket's customer-message channel; agents subscribe there.
        // Agents publish only to the ticket's agent-reply channel; customers subscribe
        // there. The server-owned visitor channel remains subscribe-only to browsers.
        $capability = array();
        if (isset($is_agent) && ($admin_nonce_ok || $agent_nonce_ok) && $channel_type === 'agent_ticket') {
            foreach ($channels as $name) $capability[$name] = array('subscribe');
            $reply_channel = 'hc-agent-reply-' . (int)$ticket_id;
            $capability[$reply_channel] = !empty($can_publish_agent) ? array('publish', 'subscribe') : array('subscribe');
            $customer_channel = 'hc-customer-msg-' . (int)$ticket_id;
            $capability[$customer_channel] = array('subscribe');
        } elseif (isset($is_agent) && ($admin_nonce_ok || $agent_nonce_ok) && $channel_type !== 'agent_ticket') {
            foreach ($channels as $name) $capability[$name] = array('subscribe');
        } elseif ($channel_type === 'support') {
            // A customer token is already bound to this exact ticket through the session hash.
            // Permit direct publish for every writable live ticket, including immediately
            // after a customer refresh and before agent_connected_at is committed.
            // The agent still needs its own authenticated ticket subscription.
            $can_publish_customer = isset($ticket) && in_array((string)$ticket->status, array('queued','active','waiting_agent','waiting_customer'), true);
            $capability[$channel] = array('subscribe');
            if (!empty($reply_channel)) $capability[$reply_channel] = array('subscribe');
            $customer_channel = 'hc-customer-msg-' . (int)$ticket->id;
            $capability[$customer_channel] = $can_publish_customer ? array('publish', 'subscribe') : array('subscribe');
        } else {
            foreach ($channels as $name) $capability[$name] = array('subscribe');
        }
        $token_ttl = in_array($channel_type, array('support','agent_ticket'), true) ? 300000 : 3600000;
        $token = self::request_token($capability, $client_id, $token_ttl);
        if (is_wp_error($token)) wp_send_json_error(array('message' => $token->get_error_message()), 502);
        wp_send_json_success(array('token' => $token, 'channel' => $channel, 'channels' => $channels, 'transport' => 'ably', 'direct_publish' => ($channel_type === 'support' ? !empty($can_publish_customer) : ($channel_type === 'agent_ticket' && !empty($can_publish_agent)))));
    }

    public static function test_connection() {
        if (!current_user_can('manage_options') || !check_ajax_referer('hc_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'Administrator permission required. Refresh the page and try again.'), 403);
        }
        if (!self::is_configured()) wp_send_json_error(array('message' => 'Add and save your complete Ably API key first.'), 400);
        try {
            $test_channel = 'hc-test-' . strtolower(wp_generate_password(10, false, false));
            $result = self::request_token(array($test_channel => array('subscribe')), 'hc-test-' . get_current_user_id());
            if (is_wp_error($result)) {
                $extra = $result->get_error_data();
                $status = is_array($extra) && !empty($extra['status']) ? (int)$extra['status'] : 0;
                $message = $result->get_error_message();
                if ($status === 401 || $status === 403) $message = 'Ably rejected the API key or its permissions. Verify the full key and that the key is enabled.';
                elseif ($status === 0) $message = 'WordPress could not reach Ably. Check that your hosting allows outbound HTTPS requests to main.realtime.ably.net.';
                wp_send_json_error(array('message' => $message, 'stage' => 'token_auth', 'upstream_status' => $status), 502);
            }
            if (!self::publish_channel($test_channel, 'hc.connection.test', array('probe'=>true,'created_at'=>time()), false)) {
                wp_send_json_error(array('message' => 'Ably token authentication succeeded, but publishing failed. Confirm the API key has publish permission and that outbound HTTPS is allowed.', 'stage' => 'publish'), 502);
            }
            wp_send_json_success(array('message' => 'Ably authentication and test publishing both succeeded.'));
        } catch (Throwable $e) {
            error_log('[HelpCenter Realtime] Ably test failed: ' . get_class($e) . ' - ' . $e->getMessage());
            wp_send_json_error(array('message' => 'The server encountered an error during the Ably test. Check the PHP error log for the HelpCenter Realtime entry.', 'stage' => 'php_exception'), 500);
        }
    }

    private static function publish_channel($channel, $event, $payload, $queue_on_failure = true) {
        list($key_name, $secret) = self::api_credentials();
        if (!$key_name || !$secret) return false;
        $url = 'https://main.realtime.ably.net/channels/' . rawurlencode($channel) . '/messages';
        $response = wp_remote_post($url, array(
            'timeout' => 2.5,
            'redirection' => 0,
            'limit_response_size' => 65536,
            'headers' => array('Authorization' => 'Basic ' . base64_encode($key_name . ':' . $secret), 'Content-Type' => 'application/json', 'Accept' => 'application/json'),
            'body' => wp_json_encode(array(array('name' => $event, 'data' => $payload))),
        ));
        if (!is_wp_error($response) && (int)wp_remote_retrieve_response_code($response) >= 200 && (int)wp_remote_retrieve_response_code($response) < 300) return true;
        if ($queue_on_failure) {
            global $wpdb;
            $wpdb->insert(self::outbox_table(), array('channel_name'=>$channel,'event_name'=>$event,'payload'=>wp_json_encode($payload),'attempts'=>0,'next_attempt_at'=>current_time('mysql', true),'created_at'=>current_time('mysql', true)), array('%s','%s','%s','%d','%s','%s'));
        }
        return false;
    }

    /** Publish one public HCK message to the sender-direction channel. */
    public static function publish_hck_message($ticket_id, $sender_type, $payload) {
        $ticket_id = absint($ticket_id);
        $sender_type = ($sender_type === 'agent') ? 'agent' : 'customer';
        if (!$ticket_id || !self::is_configured()) return false;
        $channel = 'hck-' . $sender_type . '-' . $ticket_id;
        return self::publish_channel($channel, 'hck.message', (array)$payload, true);
    }

    /** Publish a public HelpCenter agent reply to the visitor's reply channel. */
    public static function publish_agent_reply($ticket_id, $payload) {
        $ticket_id = absint($ticket_id);
        if (!$ticket_id || !is_array($payload) || empty($payload['message']) || !is_array($payload['message'])) return false;
        $message = $payload['message'];
        if (($message['sender_type'] ?? '') !== 'agent' || empty($message['client_message_id']) || empty($message['content'])) return false;
        if (!self::is_configured()) return false;
        // No outbox enqueue here: the normal post-save message.created event is
        // the durable recovery path. This relay is only the immediate fast path.
        return self::publish_channel('hc-agent-reply-' . $ticket_id, 'agent.message', $payload, false);
    }

    /** Publish an authenticated visitor's optimistic message to the assigned agent channel. */
    public static function publish_customer_message($ticket_id, $payload) {
        $ticket_id = absint($ticket_id);
        if (!$ticket_id || !is_array($payload) || empty($payload['message']) || !is_array($payload['message'])) return false;
        return self::publish_channel('hc-customer-msg-' . $ticket_id, 'customer.message', $payload, false);
    }

    /**
     * Publish staff invalidation metadata and the private message payload in one
     * Ably batch request. Ably processes the two channel groups in parallel.
     */
    private static function publish_ticket_batch($event, $staff_payload, $private_channels, $private_payload) {
        list($key_name, $secret) = self::api_credentials();
        if (!$key_name || !$secret) return false;
        $specs = array(
            array(
                'channels' => array('hc-support-staff'),
                'messages' => array(array('name' => (string)$event, 'data' => $staff_payload)),
            ),
        );
        $private_channels = array_values(array_unique(array_filter((array)$private_channels)));
        if ($private_channels) {
            $specs[] = array(
                'channels' => $private_channels,
                'messages' => array(array('name' => (string)$event, 'data' => $private_payload)),
            );
        }
        $response = wp_remote_post('https://main.realtime.ably.net/messages', array(
            'timeout' => 1.0,
            'redirection' => 0,
            'limit_response_size' => 65536,
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($key_name . ':' . $secret),
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ),
            'body' => wp_json_encode($specs),
        ));
        $ok = false;
        if (!is_wp_error($response)) {
            $code = (int)wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $ok = $code >= 200 && $code < 300 && !(is_array($body) && !empty($body['error']));
        }
        if ($ok) return true;

        // Preserve delivery if Ably is temporarily unavailable. A partial batch
        // can replay an already-delivered copy; clients deduplicate by message ID.
        foreach ($specs as $spec) {
            foreach ((array)$spec['channels'] as $channel) {
                global $wpdb;
                $wpdb->insert(self::outbox_table(), array(
                    'channel_name' => $channel,
                    'event_name' => (string)$event,
                    'payload' => wp_json_encode($spec['messages'][0]['data'] ?? array()),
                    'attempts' => 0,
                    'next_attempt_at' => current_time('mysql', true),
                    'created_at' => current_time('mysql', true),
                ), array('%s','%s','%s','%d','%s','%s'));
            }
        }
        return false;
    }

    private static function register_deferred_flush() {
        if (!self::$deferred_shutdown_registered) {
            self::$deferred_shutdown_registered = true;
            register_shutdown_function(array(__CLASS__, 'flush_deferred_ticket_events'));
        }
    }

    public static function publish_ticket_event($ticket_id, $event = 'ticket.updated', $message_id = 0, $extra = array()) {
        $ticket_id = absint($ticket_id);
        if (!$ticket_id || self::$flushing_deferred_events) return false;
        $item = array('ticket_id'=>$ticket_id,'event'=>(string)$event,'message_id'=>absint($message_id),'extra'=>is_array($extra)?$extra:array());
        foreach (self::$deferred_ticket_events as $existing) {
            if ($existing['ticket_id']===$item['ticket_id'] && $existing['event']===$item['event'] && $existing['message_id']===$item['message_id']) return true;
        }
        // Never hold the customer/agent send request open while making an
        // outbound Ably HTTP request. Persist the message first, return the AJAX
        // response, then publish from the shutdown flush. The incremental REST
        // sync remains the recovery path if Ably is unavailable.
        self::$deferred_ticket_events[] = $item;
        self::register_deferred_flush();
        return true;
    }

    public static function publish_ai_message_event($session_hash, $conversation_id, $message_id, $role) {
        $session_hash = (string)$session_hash;
        $conversation_id = absint($conversation_id);
        $message_id = absint($message_id);
        $role = sanitize_key($role);
        if (!$session_hash || !$conversation_id || !$message_id || !in_array($role, array('user','assistant'), true) || self::$flushing_deferred_events) return false;
        $item = array('channel'=>'hc-ai-visitor-' . substr($session_hash, 0, 48), 'conversation_id'=>$conversation_id, 'message_id'=>$message_id, 'role'=>$role);
        foreach (self::$deferred_ai_events as $existing) {
            if ($existing['channel']===$item['channel'] && $existing['message_id']===$item['message_id']) return true;
        }
        self::$deferred_ai_events[] = $item;
        self::register_deferred_flush();
        return true;
    }

    public static function flush_deferred_ticket_events() {
        if (self::$flushing_deferred_events || (empty(self::$deferred_ticket_events) && empty(self::$deferred_ai_events))) return;
        self::$flushing_deferred_events = true;
        if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
        if (function_exists('ignore_user_abort')) @ignore_user_abort(true);

        // The AJAX response has already been flushed above on PHP-FPM. Publish
        // ticket events now so live chat does not wait for traffic-driven WP-Cron.
        // On hosts without fastcgi_finish_request(), retain the non-blocking cron
        // fallback rather than making the user's send request wait for Ably REST.
        $scheduled = false;
        $can_publish_after_response = function_exists('fastcgi_finish_request');
        foreach (self::$deferred_ticket_events as $item) {
            if ($can_publish_after_response) {
                self::publish_ticket_event_now((int)$item['ticket_id'], (string)$item['event'], (int)$item['message_id'], (array)$item['extra']);
            } else {
                $args = array((int)$item['ticket_id'], (string)$item['event'], (int)$item['message_id'], (array)$item['extra']);
                if (!wp_next_scheduled('hc_realtime_deferred_ticket_publish', $args)) {
                    wp_schedule_single_event(time(), 'hc_realtime_deferred_ticket_publish', $args);
                }
                $scheduled = true;
            }
        }
        foreach (self::$deferred_ai_events as $item) {
            $args = array((string)$item['channel'], (int)$item['conversation_id'], (int)$item['message_id'], (string)$item['role']);
            if (!wp_next_scheduled('hc_realtime_deferred_ai_publish', $args)) {
                wp_schedule_single_event(time(), 'hc_realtime_deferred_ai_publish', $args);
            }
            $scheduled = true;
        }
        self::$deferred_ticket_events = array();
        self::$deferred_ai_events = array();
        self::$flushing_deferred_events = false;
        if ($scheduled && function_exists('spawn_cron')) spawn_cron(time());
    }

    public static function run_deferred_ticket_publish($ticket_id, $event, $message_id, $extra) {
        self::publish_ticket_event_now((int)$ticket_id, (string)$event, (int)$message_id, is_array($extra) ? $extra : array());
    }

    public static function run_deferred_ai_publish($channel, $conversation_id, $message_id, $role) {
        global $wpdb;
        $payload = array('conversation_id'=>(int)$conversation_id,'message_id'=>(int)$message_id,'role'=>sanitize_key($role),'occurred_at'=>time());
        $table = $wpdb->prefix . 'hc_ai_messages';
        $row = $wpdb->get_row($wpdb->prepare("SELECT id,role,content,sources,created_at FROM {$table} WHERE id=%d AND conversation_id=%d", (int)$message_id, (int)$conversation_id), ARRAY_A);
        if ($row) {
            $sources = !empty($row['sources']) ? json_decode($row['sources'], true) : array();
            $sources = is_array($sources) ? array_values(array_filter($sources, function($source) {
                return is_array($source) && !empty($source['title']) && !empty($source['url']) && wp_http_validate_url((string)$source['url']);
            })) : array();
            $payload['message'] = array('id'=>(int)$row['id'],'role'=>(string)$row['role'],'content'=>(string)$row['content'],'sources'=>$sources,'created_at'=>(string)$row['created_at']);
        }
        self::publish_channel((string)$channel, 'ai.message.created', $payload, true);
    }

    private static function publish_ticket_event_now($ticket_id, $event = 'ticket.updated', $message_id = 0, $extra = array()) {
        if (!self::is_configured()) return false;
        global $wpdb;
        $table = $wpdb->prefix . 'hc_ai_escalations';
        $ticket = $wpdb->get_row($wpdb->prepare("SELECT id,session_hash,status,assigned_agent_id,priority,last_message_id FROM {$table} WHERE id=%d", (int)$ticket_id));
        if (!$ticket) return false;
        // The staff-wide channel only carries invalidation metadata. Message text is
        // published exclusively to the ticket's private channel and its visitor channel.
        $payload = array('event'=>$event,'ticket_id'=>(int)$ticket_id,'message_id'=>absint($message_id),'occurred_at'=>time());
        if (isset($extra['typing'])) $payload['typing'] = (bool)$extra['typing'];
        if (strpos($event, 'typing.') === 0 && !empty($extra['typing'])) { $rate_key = 'hc_rt_' . md5($event . ':' . (int)$ticket_id); if (get_transient($rate_key)) return true; set_transient($rate_key, 1, 2); }
        $private_channels = array('hc-ticket-' . (int)$ticket_id . '-' . (int)$ticket->assigned_agent_id);
        if (!empty($ticket->session_hash)) $private_channels[] = 'hc-visitor-' . substr((string)$ticket->session_hash, 0, 48);
        $private_payload = $payload;
        if ($event === 'message.created' && $message_id) {
            $message_table = $wpdb->prefix . 'hc_ai_escalation_messages';
            $message = $wpdb->get_row($wpdb->prepare("SELECT id,sender_type,sender_user_id,sender_name,content,client_message_id,created_at,attachment_name,attachment_mime,attachment_size,attachment_kind,attachment_path,attachment_deleted_at FROM {$message_table} WHERE id=%d AND ticket_id=%d", (int)$message_id, (int)$ticket_id));
            if ($message && $message->sender_type !== 'internal_note' && empty($message->attachment_name)) {
                $private_payload['message'] = array(
                    'id'=>(int)$message->id,
                    'client_message_id'=>(string)$message->client_message_id,
                    'sender_type'=>(string)$message->sender_type,
                    'sender_user_id'=>(int)$message->sender_user_id,
                    'sender_name'=>(string)$message->sender_name,
                    'content'=>(string)$message->content,
                    'created_at'=>(string)$message->created_at
                );
            }
        }
        return self::publish_ticket_batch($event, $payload, $private_channels, $private_payload);
    }

    public static function publish_agent_event($agent_id, $event, $extra = array()) {
        if (!$agent_id || !self::is_configured()) return;
        // Generic staff event only; agents refresh their authorized queue through WordPress.
        $payload = array('event'=>$event,'occurred_at'=>time());
        if (isset($extra['available'])) $payload['available'] = (bool)$extra['available'];
        self::publish_channel('hc-support-staff', $event, $payload, true);
    }

    public static function flush_outbox() {
        if (!self::is_configured()) return;
        global $wpdb;
        $table = self::outbox_table();
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE next_attempt_at<=%s ORDER BY id ASC LIMIT 50", current_time('mysql', true)));
        foreach ((array)$rows as $row) {
            $payload = json_decode($row->payload, true);
            $ok = self::publish_channel($row->channel_name, $row->event_name, is_array($payload) ? $payload : array(), false);
            if ($ok) $wpdb->delete($table, array('id'=>(int)$row->id), array('%d'));
            else {
                $attempts = (int)$row->attempts + 1;
                if ($attempts >= 12) $wpdb->delete($table, array('id'=>(int)$row->id), array('%d'));
                else $wpdb->update($table, array('attempts'=>$attempts,'next_attempt_at'=>gmdate('Y-m-d H:i:s', time()+min(900, 15 * $attempts))), array('id'=>(int)$row->id), array('%d','%s'), array('%d'));
            }
        }
    }
}
