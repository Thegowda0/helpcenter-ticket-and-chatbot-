<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/admin/categories-list.php';
$src = file_get_contents($file);

// The broken line looks like:
//   $sql// HC_CATS_DEDUPE: ...
//    = "SELECT ...";
$broken = '$sql// HC_CATS_DEDUPE: fetch only top-level; hc_render_cat_rows() recurses into children itself
 = "SELECT * FROM {$wpdb->prefix}hc_categories $where_sql AND parent_id = 0 ORDER BY sort_order ASC, name ASC LIMIT 100";';

$fixed = '// HC_CATS_DEDUPE_V2
if ($view === \'trash\') {
    $sql = "SELECT * FROM {$wpdb->prefix}hc_categories $where_sql ORDER BY parent_id ASC, sort_order ASC, name ASC LIMIT 100";
} else {
    $sql = "SELECT * FROM {$wpdb->prefix}hc_categories $where_sql AND parent_id = 0 ORDER BY sort_order ASC, name ASC LIMIT 100";
}';

$count = 0;
$src = str_replace($broken, $fixed, $src, $count);

if ($count === 0) {
    echo "ERROR: broken block not found — paste output:\n";
    echo "sed -n '24,28p' categories-list.php\n";
    exit(1);
}

file_put_contents($file, $src);
echo "OK: broken SQL block repaired\n";
