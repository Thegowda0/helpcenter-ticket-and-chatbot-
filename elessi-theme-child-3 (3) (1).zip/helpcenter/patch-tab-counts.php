<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/class-hc-ajax.php';
$src = file_get_contents($file);

if (strpos($src, 'hc_tab_counts') !== false) {
    echo "SKIP: tab counts handler already present\n";
    exit(0);
}

// Register
$anchor = "add_action('wp_ajax_hc_bulk_categories', array(__CLASS__, 'bulk_categories'));";
$new = $anchor . "\n        add_action('wp_ajax_hc_tab_counts', array(__CLASS__, 'tab_counts'));";
$src = str_replace($anchor, $new, $src, $c1);

// Add method before final brace
$method = <<<'METHOD'

    public static function tab_counts() {
        self::check_admin();
        global $wpdb;
        $type = sanitize_key($_POST['type'] ?? 'articles');

        if ($type === 'faqs') {
            $t = $wpdb->prefix . 'hc_faqs';
        } elseif ($type === 'categories') {
            $t = $wpdb->prefix . 'hc_categories';
        } else {
            $t = $wpdb->prefix . 'hc_articles';
        }

        $all       = (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE deleted_at IS NULL");
        $published = (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE deleted_at IS NULL AND status='published'");
        $draft     = (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE deleted_at IS NULL AND status='draft'");
        $trash     = (int) $wpdb->get_var("SELECT COUNT(*) FROM $t WHERE deleted_at IS NOT NULL");

        wp_send_json_success(array(
            'all'       => $all,
            'published' => $published,
            'draft'     => $draft,
            'trash'     => $trash,
        ));
    }
METHOD;

$lastBrace = strrpos($src, '}');
$src = substr($src, 0, $lastBrace) . $method . "\n" . substr($src, $lastBrace);

file_put_contents($file, $src);
echo "OK: tab_counts handler added (reg=$c1)\n";
