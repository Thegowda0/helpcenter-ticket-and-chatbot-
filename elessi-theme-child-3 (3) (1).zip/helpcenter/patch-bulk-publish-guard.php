<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/class-hc-ajax.php';
$src = file_get_contents($file);

if (strpos($src, 'HC_BULK_PUBLISH_GUARD') !== false) {
    echo "SKIP: bulk publish guard already present\n";
    exit(0);
}

$old = "            case 'publish':
                \$wpdb->query(\"UPDATE \$t SET status='published' WHERE id IN (\$in)\");
                \$count = count(\$ids);
                break;";

$new = "            case 'publish':
                // HC_BULK_PUBLISH_GUARD: exclude FAQs whose linked article isn't live
                \$valid_ids = array();
                \$skipped = 0;
                foreach (\$ids as \$fid) {
                    \$faq = HC_Core::get_faq(\$fid);
                    if (!\$faq) { \$skipped++; continue; }
                    if (\$faq->destination_type === 'article' && \$faq->destination_id) {
                        \$art = HC_Core::get_article(\$faq->destination_id);
                        if (!\$art || \$art->status !== 'published') {
                            \$skipped++;
                            continue;
                        }
                    }
                    \$valid_ids[] = (int) \$fid;
                }
                if (!empty(\$valid_ids)) {
                    \$v_in = implode(',', \$valid_ids);
                    \$wpdb->query(\"UPDATE \$t SET status='published' WHERE id IN (\$v_in)\");
                }
                \$count = count(\$valid_ids);
                \$msg = \$count . ' FAQ(s) published';
                if (\$skipped > 0) \$msg .= ' · ' . \$skipped . ' skipped (linked article missing or not published)';
                wp_send_json_success(array('message' => \$msg, 'count' => \$count));
                // unreachable fallthrough prevention
                return;";

$count = 0;
$src = str_replace($old, $new, $src, $count);

if ($count === 0) {
    echo "SKIP: no matching publish case (bulk_faqs may already be custom).\n";
    exit(0);
}

file_put_contents($file, $src);
echo "OK: bulk publish guard installed (c=$count)\n";
