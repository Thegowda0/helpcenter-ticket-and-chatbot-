<?php
// Directory index guard; Nginx deployments must also deny direct attachment URLs.
http_response_code(404);
exit;
