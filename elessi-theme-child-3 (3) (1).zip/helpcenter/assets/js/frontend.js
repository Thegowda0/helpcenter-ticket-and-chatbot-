/**
 * Help Center - Frontend JS
 */
(function () {
    'use strict';

    function getData() { return window.hcData || {}; }

// Portal only the hero search form and its results while search is active.
// The rest of the hero stays in the page and is blurred with the background.
var heroPortal = null;
function activateHeroPortal(input) {
    var form = input && input.closest('.hc-hero-search');
    var dropdown = form && form.querySelector('#hcHeroSearchDropdown');
    if (!form || !dropdown) return;

    if (!heroPortal) {
        var formRect = form.getBoundingClientRect();
        var placeholder = document.createElement('div');
        placeholder.className = 'hc-hero-search-portal-placeholder';
        placeholder.setAttribute('aria-hidden', 'true');
        placeholder.style.width = formRect.width + 'px';
        placeholder.style.height = formRect.height + 'px';
        placeholder.style.flex = '0 0 ' + formRect.height + 'px';
        form.parentNode.insertBefore(placeholder, form);

        var dropdownPlaceholder = document.createComment('hc-hero-dropdown-placeholder');
        if (dropdown.parentNode) dropdown.parentNode.insertBefore(dropdownPlaceholder, dropdown);
        heroPortal = {
            form: form,
            input: input,
            dropdown: dropdown,
            placeholder: placeholder,
            dropdownPlaceholder: dropdownPlaceholder,
            formStyle: form.getAttribute('style'),
            dropdownStyle: dropdown.getAttribute('style'),
            formClass: form.className
        };
        document.body.appendChild(form);
        document.body.appendChild(dropdown);
        form.classList.add('hc-hero-search-portal');
        dropdown.classList.add('hc-search-dropdown-fixed');
        form.style.setProperty('position', 'fixed', 'important');
        form.style.setProperty('top', formRect.top + 'px', 'important');
        form.style.setProperty('left', formRect.left + 'px', 'important');
        form.style.setProperty('width', formRect.width + 'px', 'important');
        form.style.setProperty('max-width', 'calc(100vw - 16px)', 'important');
        form.style.setProperty('margin', '0', 'important');
        form.style.setProperty('z-index', '1200', 'important');
        form.style.setProperty('overflow', 'visible', 'important');
        form.style.setProperty('transform', 'none', 'important');
        form.style.setProperty('filter', 'none', 'important');
        form.style.setProperty('-webkit-filter', 'none', 'important');
        form.style.setProperty('opacity', '1', 'important');
        try { input.focus({ preventScroll: true }); } catch (e) { input.focus(); }
    }
    positionHeroDropdown();
}

function positionHeroDropdown() {
    if (!heroPortal) return;
    var p = heroPortal;
    var rect = p.form.getBoundingClientRect();
    var width = Math.min(rect.width, window.innerWidth - 16);
    var left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8));
    var top = Math.max(8, Math.min(rect.bottom + 8, window.innerHeight - 120));
    var dropdown = p.dropdown;
    dropdown.style.setProperty('position', 'fixed', 'important');
    dropdown.style.setProperty('top', top + 'px', 'important');
    dropdown.style.setProperty('left', left + 'px', 'important');
    dropdown.style.setProperty('width', width + 'px', 'important');
    dropdown.style.setProperty('right', 'auto', 'important');
    dropdown.style.setProperty('z-index', '1206', 'important');
    dropdown.style.setProperty('max-height', Math.max(120, window.innerHeight - top - 16) + 'px', 'important');
}

function restoreHeroPortal() {
    if (!heroPortal) return;
    var p = heroPortal;
    if (p.placeholder && p.placeholder.parentNode) {
        p.placeholder.parentNode.insertBefore(p.form, p.placeholder);
        p.placeholder.remove();
    }
    if (p.dropdownPlaceholder && p.dropdownPlaceholder.parentNode) {
        p.dropdownPlaceholder.parentNode.insertBefore(p.dropdown, p.dropdownPlaceholder);
        p.dropdownPlaceholder.remove();
    }
    p.form.className = p.formClass;
    if (p.formStyle === null) p.form.removeAttribute('style');
    else p.form.setAttribute('style', p.formStyle);
    p.dropdown.classList.remove('hc-search-dropdown-fixed');
    if (p.dropdownStyle === null) p.dropdown.removeAttribute('style');
    else p.dropdown.setAttribute('style', p.dropdownStyle);
    heroPortal = null;
}

    function initHeroPlaceholderTypewriter() {
        var input = document.getElementById('hcHeroSearchInput'); if (!input) return;
        var phrases=[]; try { phrases=JSON.parse(input.getAttribute('data-hc-placeholders')||'[]'); } catch(e) {}
        phrases=(Array.isArray(phrases)?phrases:[]).map(function(v){return String(v||'').trim();}).filter(Boolean).slice(0,8);
        if(!phrases.length)phrases=['Search for answers...'];
        var base=phrases[0], pi=0, ci=base.length, deleting=false, timer=null;
        function stop(){if(timer)clearTimeout(timer);timer=null;}
        function tick(){if(document.activeElement===input||input.value){stop();return;}var phrase=phrases[pi]||base;if(!deleting){ci=Math.min(phrase.length,ci+1);input.placeholder=phrase.slice(0,ci);if(ci>=phrase.length){deleting=true;timer=setTimeout(tick,1300);return;}}else{ci=Math.max(0,ci-1);input.placeholder=phrase.slice(0,ci);if(ci<=0){deleting=false;pi=(pi+1)%phrases.length;timer=setTimeout(tick,280);return;}}timer=setTimeout(tick,deleting?38:72);}
        timer=setTimeout(tick,1600);
        input.addEventListener('focus',function(){stop();input.placeholder=base;});
        input.addEventListener('input',function(){stop();if(!input.value){pi=0;ci=0;deleting=false;timer=setTimeout(tick,500);}});
        input.addEventListener('blur',function(){if(!input.value){ci=0;deleting=false;stop();timer=setTimeout(tick,500);}});
    }

    document.addEventListener('DOMContentLoaded', function () {
        window.addEventListener('resize', positionHeroDropdown, { passive: true });
        window.addEventListener('scroll', positionHeroDropdown, { passive: true, capture: true });
        document.addEventListener('touchmove', function (e) { if (!document.body.classList.contains('hc-search-active')) return; if (e.target.closest('.hc-search-dropdown, .hc-hero-search')) return; e.preventDefault(); }, { passive:false, capture:true });
        document.addEventListener('wheel', function (e) { if (!document.body.classList.contains('hc-search-active')) return; if (e.target.closest('.hc-search-dropdown, .hc-hero-search')) return; e.preventDefault(); }, { passive:false, capture:true });
        document.addEventListener('click', function (e) {
            if (!document.body.classList.contains('hc-search-active')) return;
            var activeSearch = e.target.closest('.hc-hero, .hc-hero-search, .hc-header-search, .hc-search-dropdown');
            if (!activeSearch) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                document.querySelectorAll('.hc-search-dropdown.open').forEach(function (dropdown) {
                    dropdown.classList.remove('open');
                });
                document.body.classList.remove('hc-search-active');
                document.documentElement.classList.remove('hc-search-active');
                restoreHeroPortal();
            }
        }, true);
        initHeroPlaceholderTypewriter();
        initLiveSearch();
        initAiSearchSummaryPage();
        initSearchClickTracking();
        initFaqToggle();
        initToc();
        initHelpfulVote();
        initArticleTools();
        initBackTop();
    });


    function initAiSearchSummaryPage(){
      var card=document.getElementById('hcAiSearchSummaryPage');if(!card)return;var q=card.getAttribute('data-query')||'';var d=getData();var fd=new FormData();fd.append('action','hc_ai_search_summary');fd.append('nonce',d.nonce||'');fd.append('query',q);fetch(d.ajaxUrl||'/wp-admin/admin-ajax.php',{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){if(!r.success||!r.data||!r.data.enabled){card.remove();return;}var copy=card.querySelector('.hc-ai-search-copy'),links=card.querySelector('.hc-ai-search-links'),full=String(r.data.summary||'');copy.textContent='';var pos=0;function type(){copy.textContent=full.slice(0,pos+=3);if(pos<full.length)window.setTimeout(type,14)}type();(r.data.sources||[]).forEach(function(src){var a=document.createElement('a');a.href=src.url;a.textContent=src.title;links.appendChild(a)})}).catch(function(){card.remove()});
    }

    function initSearchClickTracking() {
        document.addEventListener('click', function (event) {
            var link = event.target.closest('[data-hc-search-click="1"]');
            if (!link) return;
            var d = getData();
            var fd = new FormData();
            fd.append('action', 'hc_track_search_click');
            fd.append('article_id', link.getAttribute('data-hc-article-id') || '0');
            fd.append('query', link.getAttribute('data-hc-search-query') || '');
            // Fire-and-forget analytics; never delay navigation.
            if (navigator.sendBeacon) {
                try { navigator.sendBeacon(d.ajaxUrl || '/wp-admin/admin-ajax.php', fd); return; } catch (e) {}
            }
            fetch(d.ajaxUrl || '/wp-admin/admin-ajax.php', { method: 'POST', body: fd, credentials: 'same-origin', keepalive: true }).catch(function () {});
        }, true);
    }

    function initLiveSearch() {
        var d = getData();
        if (d.liveSearch === false) return;
        bindSearch('hcSearchInput', 'hcSearchDropdown');
        bindSearch('hcHeroSearchInput', 'hcHeroSearchDropdown');
    }

    function bindSearch(inputId, dropdownId) {
        var input    = document.getElementById(inputId);
        var dropdown = document.getElementById(dropdownId);
        if (!input || !dropdown) return;
        if (input.dataset.hcBound === '1') return;
        input.dataset.hcBound = '1';

        var timer;
        var requestSeq = 0;
        var aiTimer = null; var aiSeq = 0;

        if (inputId === 'hcHeroSearchInput') input.addEventListener('focus', function () {
            activateHeroPortal(input); document.body.classList.add('hc-search-active'); document.documentElement.classList.add('hc-search-active');
        });

        input.addEventListener('input', function () {
            clearTimeout(timer); clearTimeout(aiTimer);
            var q = this.value.trim();
            var currentSeq = ++requestSeq;

            if (q.length < 2) {
                dropdown.classList.remove('open'); dropdown.innerHTML = '';
                if (inputId !== 'hcHeroSearchInput' || document.activeElement !== input) {
                    document.body.classList.remove('hc-search-active'); document.documentElement.classList.remove('hc-search-active'); restoreHeroPortal();
                }
                return;
            }
            if (inputId === 'hcHeroSearchInput') activateHeroPortal(input);

            timer = setTimeout(function () {
                var d  = getData();
                var fd = new FormData();
                fd.append('action', 'hc_search');
                fd.append('nonce',  d.nonce || '');
                fd.append('query',  q);

                fetch(d.ajaxUrl || '/wp-admin/admin-ajax.php', { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function (r) {
                        return r.text().then(function (body) {
                            var parsed;
                            try { parsed = JSON.parse(body); }
                            catch (e) { throw new Error('Search endpoint returned a non-JSON response (HTTP ' + r.status + ').'); }
                            if (!r.ok) throw new Error((parsed && parsed.data && parsed.data.message) || 'Search request failed (HTTP ' + r.status + ').');
                            return parsed;
                        });
                    })
                    .then(function (res) {
                        if (currentSeq !== requestSeq || input.value.trim() !== q) return;
                        if (!res || res.success !== true || !res.data || !Array.isArray(res.data.results)) {
                            throw new Error((res && res.data && res.data.message) || 'Unexpected search response from WordPress.');
                        }
                        var items = res.data.results;
                        if (!items.length) {
                            dropdown.innerHTML = '<div class="hc-search-empty">No results for "' + escapeHtml(q) + '"</div>';
                            dropdown.classList.add('open');
                            if (inputId === 'hcHeroSearchInput') positionHeroDropdown();
                            document.body.classList.add('hc-search-active'); document.documentElement.classList.add('hc-search-active');
                            document.documentElement.classList.add('hc-search-active');
                            return;
                        }
                        var html = '';
                        html += '<section class="hc-ai-search-summary" id="hcAiSearchSummary"><div class="hc-ai-search-kicker">✦ AI SUMMARY</div><div class="hc-ai-search-copy">Preparing an answer from Help Center articles…</div><div class="hc-ai-search-links"></div></section>' ;
                        items.forEach(function (item) {
                            html += '<a href="' + escapeHtml(item.url || '#') + '" class="hc-search-item" data-hc-search-click="1" data-hc-article-id="' + Number(item.id || 0) + '" data-hc-search-query="' + escapeHtml(q) + '">' +
                                '<i class="fas fa-file-lines"></i>' +
                                '<div><strong>' + escapeHtml(item.title || '') + '</strong>' +
                                '<small>' + escapeHtml(item.category_name || 'General') + '</small></div>' +
                                '</a>';
                        });
                        var base = (d.homeUrl || window.location.origin + '/helpcenter/').replace(/\/$/, '') + '/search/';
                        html += '<a class="hc-search-view-all" href="' + escapeHtml(base + '?q=' + encodeURIComponent(q)) + '">View all results (' + (items.length >= 6 ? 'more' : 'all') + ') <i class="fas fa-arrow-right"></i></a>';
                        dropdown.innerHTML = html;
                        dropdown.classList.add('open');
                        if (window.hcData && window.hcData.aiEnabled) {
                          var summarySeq = ++aiSeq; clearTimeout(aiTimer); aiTimer = setTimeout(function(){
                            var afd=new FormData(); afd.append('action','hc_ai_search_summary'); afd.append('nonce',d.nonce||''); afd.append('query',q);
                            fetch(d.ajaxUrl||'/wp-admin/admin-ajax.php',{method:'POST',body:afd,credentials:'same-origin'}).then(function(x){return x.json()}).then(function(ar){if(summarySeq!==aiSeq||input.value.trim()!==q)return;var card=dropdown.querySelector('#hcAiSearchSummary');if(!card)return;if(!ar.success||!ar.data||!ar.data.enabled){card.remove();return;}var copy=card.querySelector('.hc-ai-search-copy'),links=card.querySelector('.hc-ai-search-links'),full=String(ar.data.summary||'');copy.textContent='';var pos=0;function type(){if(summarySeq!==aiSeq||!copy.isConnected)return;copy.textContent=full.slice(0,pos+=3);if(pos<full.length){window.setTimeout(type,14)}}type();(ar.data.sources||[]).forEach(function(src){var a=document.createElement('a');a.href=src.url;a.textContent=src.title;links.appendChild(a)});}).catch(function(){var card=dropdown.querySelector('#hcAiSearchSummary');if(card)card.remove()});
                          },350);
                        } else { var aiCard=dropdown.querySelector('#hcAiSearchSummary'); if(aiCard)aiCard.remove(); }
                        if (inputId === 'hcHeroSearchInput') positionHeroDropdown();
                        document.body.classList.add('hc-search-active'); document.documentElement.classList.add('hc-search-active');
                    })
                    .catch(function (err) {
                        if (currentSeq !== requestSeq) return;
                        console.error('[Help Center search]', err);
                        dropdown.innerHTML = '<div class="hc-search-empty">Search is temporarily unavailable. Please try again.</div><a class="hc-search-view-all" href="' + escapeHtml((getData().homeUrl || window.location.origin + '/helpcenter/').replace(/\/$/, '') + '/search/?q=' + encodeURIComponent(q)) + '">Open full search <i class="fas fa-arrow-right"></i></a>';
                        dropdown.classList.add('open');
                        if (inputId === 'hcHeroSearchInput') positionHeroDropdown();
                        document.body.classList.add('hc-search-active'); document.documentElement.classList.add('hc-search-active');
                    });
            }, 110);
        });

        input.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                dropdown.classList.remove('open');
                document.body.classList.remove('hc-search-active');
                document.documentElement.classList.remove('hc-search-active');
                restoreHeroPortal();
            }
            // Enter always uses the regular WordPress search-results route as a reliable fallback.
            if (e.key === 'Enter' && input.value.trim().length >= 2) {
                var form = input.closest('form');
                if (form) {
                    e.preventDefault();
                    form.submit();
                }
            }
        });

        document.addEventListener('click', function (e) {
            var wrap = input.closest('.hc-hero-search') || input.closest('.hc-header-search');
            if (e.target === document.body || e.target === document.documentElement) {
                dropdown.classList.remove('open');
                document.body.classList.remove('hc-search-active');
                document.documentElement.classList.remove('hc-search-active');
                restoreHeroPortal();
                return;
            }
            if (wrap && !wrap.contains(e.target) && !e.target.closest('.hc-search-dropdown')) {
                dropdown.classList.remove('open');
                document.body.classList.remove('hc-search-active');
                document.documentElement.classList.remove('hc-search-active');
                restoreHeroPortal();
            }
        });
    }

    function initFaqToggle() {
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('.hc-faq-q');
            if (!btn) return;
            e.preventDefault();
            var item = btn.closest('.hc-faq-item');
            if (!item) return;
            var list = item.closest('.hc-faq-list');
            if (list) {
                list.querySelectorAll('.hc-faq-item.open').forEach(function (o) {
                    if (o !== item) o.classList.remove('open');
                });
            }
            item.classList.toggle('open');
        });
    }

    function initToc() {
        var content = document.getElementById('hcArticleContent');
        var tocWrap = document.getElementById('hcToc');
        var tocList = document.getElementById('hcTocList');
        var tocToggle = document.getElementById('hcTocToggle');
        if (!content || !tocWrap || !tocList) return;

        // Clear any previous entries (in case function called twice)
        tocList.innerHTML = '';

        var headings = content.querySelectorAll('h2, h3, h4');
        if (headings.length < 2) { tocWrap.style.display = 'none'; return; }
        tocWrap.style.display = 'block';

        // Find the minimum heading level present so we can normalize the top level
        var minLevel = 6;
        headings.forEach(function (h) {
            var lvl = parseInt(h.tagName.substring(1), 10);
            if (lvl < minLevel) minLevel = lvl;
        });

        headings.forEach(function (h, i) {
            var id = h.id || ('hc-h-' + i);
            h.id = id;

            var rawLevel = parseInt(h.tagName.substring(1), 10);
            // Normalize: minLevel → 1, minLevel+1 → 2, etc.
            var normLevel = Math.min(3, rawLevel - minLevel + 1);

            var li = document.createElement('li');
            li.className = 'hc-toc-item lvl-' + normLevel;

            var a  = document.createElement('a');
            a.href = '#' + id;
            a.textContent = h.textContent.replace(/\s+/g, ' ').trim();
            a.className = 'lvl-' + normLevel;
            a.setAttribute('aria-level', String(normLevel));

            a.addEventListener('click', function (e) {
                e.preventDefault();
                var top = h.getBoundingClientRect().top + window.pageYOffset - 100;
                window.scrollTo({ top: top, behavior: 'smooth' });
                tocList.querySelectorAll('a').forEach(function (x) { x.classList.remove('active'); });
                a.classList.add('active');
            });

            li.appendChild(a);
            tocList.appendChild(li);
        });

        if (tocToggle) {
            tocToggle.addEventListener('click', function () { tocWrap.classList.toggle('open'); });
        }
    }

    function initHelpfulVote() {
        var buttons = document.querySelectorAll('.hc-helpful-btn[data-hc-vote]');
        if (!buttons.length) return;

        buttons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var articleId = this.getAttribute('data-article');
                var vote = this.getAttribute('data-hc-vote');
                if (vote === 'no') { showReasonPrompt(articleId, this); return; }
                submitVote(articleId, vote);
            });
        });
    }

    function showReasonPrompt(articleId, noButton) {
        var wrapper = document.getElementById('hcHelpful');
        if (!wrapper) return;
        var prompt = wrapper.querySelector('.hc-reason-prompt');
        if (!prompt) {
            prompt = document.createElement('div');
            prompt.className = 'hc-reason-prompt';
            prompt.innerHTML =
                '<h4>What went wrong?</h4>' +
                '<label class="hc-reason-option"><input type="radio" name="hc-reason" value="not-answered"> Didn\'t answer my question</label>' +
                '<label class="hc-reason-option"><input type="radio" name="hc-reason" value="too-complicated"> Too complicated</label>' +
                '<label class="hc-reason-option"><input type="radio" name="hc-reason" value="outdated"> Outdated information</label>' +
                '<label class="hc-reason-option"><input type="radio" name="hc-reason" value="broken"> Broken link / formatting</label>' +
                '<div class="hc-reason-actions">' +
                    '<button type="button" class="hc-btn hc-btn-primary" id="hcReasonSubmit">Submit</button>' +
                    '<button type="button" class="hc-btn hc-btn-outline" id="hcReasonSkip">Skip</button>' +
                '</div>';
            wrapper.appendChild(prompt);
        }
        prompt.classList.add('open');

        prompt.querySelector('#hcReasonSubmit').onclick = function () {
            var sel = prompt.querySelector('input[name="hc-reason"]:checked');
            prompt.classList.remove('open');
            submitVote(articleId, 'no', sel ? sel.value : '');
        };
        prompt.querySelector('#hcReasonSkip').onclick = function () {
            prompt.classList.remove('open');
            submitVote(articleId, 'no');
        };
    }

    function submitVote(articleId, vote, reason) {
        var d = getData();
        var fd = new FormData();
        fd.append('action', 'hc_helpful_vote');
        fd.append('nonce',  d.nonce || '');
        fd.append('article_id', articleId);
        fd.append('vote', vote);
        if (reason) fd.append('reason', reason);

        fetch(d.ajaxUrl || '/wp-admin/admin-ajax.php', { method: 'POST', body: fd })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.success) updateHelpfulUI(vote, res.data.new_counts);
                else toast((res.data && res.data.message) || 'Could not record vote', 'error');
            })
            .catch(function () { toast('Network error', 'error'); });
    }

    function updateHelpfulUI(vote, counts) {
        var yesBtn = document.querySelector('.hc-helpful-yes');
        var noBtn  = document.querySelector('.hc-helpful-no');
        if (yesBtn) { yesBtn.disabled = true; yesBtn.classList.remove('active'); }
        if (noBtn)  { noBtn.disabled  = true; noBtn.classList.remove('active'); }
        if (vote === 'yes' && yesBtn) yesBtn.classList.add('active');
        if (vote === 'no'  && noBtn)  noBtn.classList.add('active');

        var stats = document.getElementById('hcHelpfulStats');
        if (stats && counts) {
            var total = counts.yes + counts.no;
            var pct   = total > 0 ? Math.round((counts.yes / total) * 100) : 0;
            stats.innerHTML =
                '<span><strong>' + counts.yes + '</strong> of <strong>' + total + '</strong> found this helpful</span>' +
                '<div class="hc-helpful-bar"><div class="hc-helpful-bar-fill" style="width:' + pct + '%"></div></div>' +
                '<span class="hc-helpful-pct">' + pct + '%</span>';
        }
        toast('Thanks for your feedback!', 'success');
    }

    function initArticleTools() {
        document.querySelectorAll('[data-hc-copy]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(window.location.href).then(function () {
                        toast('Link copied!', 'success');
                    });
                }
            });
        });
        document.querySelectorAll('[data-hc-print]').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                window.print();
            });
        });
        document.querySelectorAll('[data-hc-share]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var p = this.getAttribute('data-hc-share');
                var u = encodeURIComponent(window.location.href);
                var t = encodeURIComponent(document.title);
                var shareUrl = '';
                if (p === 'twitter' || p === 'x') shareUrl = 'https://twitter.com/intent/tweet?url=' + u + '&text=' + t;
                if (p === 'facebook') shareUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + u;
                if (p === 'linkedin') shareUrl = 'https://www.linkedin.com/sharing/share-offsite/?url=' + u;
                if (p === 'native' && navigator.share) {
                    navigator.share({title: document.title, url: window.location.href}).catch(function(){});
                    return;
                }
                if (shareUrl) window.open(shareUrl, '_blank', 'noopener,noreferrer,width=600,height=500');
            });
        });
    }

    function initBackTop() {
        var btn = document.getElementById('hcBackTop');
        if (!btn) return;
        window.addEventListener('scroll', function () {
            if (window.scrollY > 400) btn.classList.add('visible');
            else btn.classList.remove('visible');
        }, { passive: true });
        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    function toast(message, type) {
        type = type || 'success';
        var existing = document.querySelector('.hc-front-toast');
        if (existing) existing.remove();
        var el = document.createElement('div');
        el.className = 'hc-front-toast';
        el.style.cssText = 'position:fixed;bottom:80px;left:50%;transform:translateX(-50%);padding:12px 24px;background:' +
            (type === 'success' ? '#10B981' : '#EF4444') +
            ';color:#fff;border-radius:10px;font-size:14px;font-weight:600;z-index:99999;box-shadow:0 10px 30px rgba(0,0,0,0.2);';
        el.textContent = message;
        document.body.appendChild(el);
        setTimeout(function () {
            el.style.transition = 'opacity 0.3s';
            el.style.opacity = '0';
            setTimeout(function () { el.remove(); }, 300);
        }, 2500);
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.textContent = str == null ? '' : str;
        return div.innerHTML;
    }

    // ---------- SCROLL TO CONTACT FORM (email card click) ----------
    document.addEventListener("click", function(e) {
        var trigger = e.target.closest("[data-hc-scroll-to-form]");
        if (!trigger) return;
        e.preventDefault();
        var section = document.getElementById("hcContactFormSection");
        var nameField = document.getElementById("hc-c-name");
        if (section) {
            var top = section.getBoundingClientRect().top + window.pageYOffset - 100;
            window.scrollTo({ top: top, behavior: "smooth" });
            setTimeout(function() {
                if (nameField) nameField.focus({ preventScroll: true });
            }, 500);
        }
    });

})();

/* =============================================
   CONTACT PAGE v3.1 — reveal, close, submit
   ============================================= */
(function() {
    'use strict';

    function qs(s, ctx) { return (ctx || document).querySelector(s); }
    function qsa(s, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(s)); }

    function showForm() {
        var section = qs('#hcContactFormSection');
        if (!section) return;
        section.style.display = '';
        var top = section.getBoundingClientRect().top + window.pageYOffset - 100;
        window.scrollTo({ top: top, behavior: 'smooth' });
        setTimeout(function() {
            var name = qs('#hc-c-name');
            if (name) name.focus({ preventScroll: true });
        }, 500);
    }

    function hideForm() {
        var section = qs('#hcContactFormSection');
        if (!section) return;
        section.style.display = 'none';
        var page = qs('.hc-contact-page');
        if (page) {
            var top = page.getBoundingClientRect().top + window.pageYOffset - 80;
            window.scrollTo({ top: top, behavior: 'smooth' });
        }
    }

    document.addEventListener('click', function(e) {
        var showBtn = e.target.closest('[data-hc-show-form]');
        if (showBtn) { e.preventDefault(); showForm(); return; }

        var closeBtn = e.target.closest('#hcContactFormClose');
        if (closeBtn) { e.preventDefault(); hideForm(); return; }
    });

    // Form submit
    document.addEventListener('submit', function(e) {
        var form = e.target;
        if (form.id !== 'hcContactForm') return;
        e.preventDefault();

        var btn = qs('#hcContactSubmit', form);
        var msg = qs('#hcContactMsg', form);
        if (!btn || !msg) return;

        var orig = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Sending…';
        btn.disabled = true;
        msg.textContent = '';
        msg.className = 'hc-contact-form-msg';

        var d = window.hcData || {};
        var fd = new FormData(form);
        fd.append('action', 'hc_contact_submit');
        fd.append('nonce', d.nonce || '');

        fetch(d.ajaxUrl || '/wp-admin/admin-ajax.php', { method: 'POST', body: fd })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (res && res.success) {
                    msg.textContent = (res.data && res.data.message) || 'Message sent!';
                    msg.className = 'hc-contact-form-msg success';
                    form.reset();
                } else {
                    msg.textContent = (res && res.data && res.data.message) || 'Something went wrong.';
                    msg.className = 'hc-contact-form-msg error';
                }
                btn.innerHTML = orig;
                btn.disabled = false;
            })
            .catch(function() {
                msg.textContent = 'Network error. Please try again.';
                msg.className = 'hc-contact-form-msg error';
                btn.innerHTML = orig;
                btn.disabled = false;
            });
    });
})();
// TOC_FIX_VERIFY_1792655473
