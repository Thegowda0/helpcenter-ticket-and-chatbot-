(function () {
  'use strict';

  function boot() {
    var root = document.getElementById('hc-ai-escalations-card');
    if (!root || root.dataset.liveBooted === '1') return;
    root.dataset.liveBooted = '1';

    var ajax = root.dataset.ajaxUrl || window.ajaxurl || '';
    var nonce = root.dataset.nonce || '';
    var currentUserId = parseInt(root.dataset.currentUser || '0', 10) || 0;
    var supervisor = root.dataset.supervisor === '1';
    var showAiHistory = root.dataset.showAiHistory !== '0';
    var aiOverviewEnabled = root.dataset.aiOverview !== '0';
    var composerMode = 'reply';
    var list = document.getElementById('hcSupportTicketList');
    var chat = document.getElementById('hcSupportChatPane');
    var visitor = document.getElementById('hcSupportVisitorPane');
    var live = document.getElementById('hcAiLiveStatus');
    var alertBtn = document.getElementById('hcAiEnableAlerts');
    var search = document.getElementById('hcSupportSearch');
    if (!ajax || !nonce || !list || !chat || !visitor) return;
    showInitialEmpty();

    function showInitialEmpty() { chat.innerHTML = '<div class="hc-support-empty-state"><span><i class="fas fa-headset"></i></span><h4>No conversation selected</h4><p>Select a ticket from the inbox to view its messages. New requests appear here automatically.</p></div>'; visitor.innerHTML = '<div class="hc-support-empty-state"><span><i class="fas fa-user-circle"></i></span><h4>Visitor details</h4><p>Visitor profile and related tickets appear when you open a conversation.</p></div>'; }

    var rows = [];
    var selected = 0;
    var lastMessageId = 0;
    var lastAiMessageId = 0;
    var filter = 'all';
    var alerts = root.dataset.alertsEnabled !== '0';
    var browserAlerts = root.dataset.browserNotifications !== '0';
    var alertSound = root.dataset.alertSound || 'urgent';
    var alertVolume = Math.max(0.2, Math.min(1, Number(root.dataset.alertVolume) || 0.9));
    var primed = false;
    var known = Object.create(null);
    var queueBusy = false;
    var ticketBusy = false;
    var typingTimer = null;
    var typingSentAt = 0;
    var typingState = false;
    var audioContext = null;
    var available = false;
    var lastSuccessfulSync = 0;
    var clockTimer = null;
    var uploadBusy = false;

    function request(action, extra) {
      var requestStarted = Date.now();
      var body = new FormData();
      body.append('action', action);
      body.append('nonce', nonce);
      Object.keys(extra || {}).forEach(function (key) {
        body.append(key, extra[key] == null ? '' : extra[key]);
      });
      // Do not abort normal message/summary requests after the old 9-second
      // ceiling. AI/provider calls and busy PHP-FPM workers can legitimately take
      // longer. Keep a generous safety ceiling and make it action-aware.
      var controller = window.AbortController ? new AbortController() : null;
      var timeoutMs = /(?:admin_send|escalation_send|send_staged)/.test(action) ? 60000
        : /(?:summary)/.test(action) ? 90000
        : /(?:admin_poll|status|presence)/.test(action) ? 30000 : 45000;
      var timedOut = false;
      var timeout = controller ? window.setTimeout(function () { timedOut = true; controller.abort(); }, timeoutMs) : null;
      return fetch(ajax, { method: 'POST', body: body, credentials: 'same-origin', cache: 'no-store', signal: controller ? controller.signal : undefined }).then(function (response) {
        if (!response.ok) throw new Error('The support server returned an error.');
        return response.json();
      }).then(function (payload) {
        if (timeout) window.clearTimeout(timeout);
        lastSuccessfulSync = Date.now();
        setConnectionState(true, lastSuccessfulSync - requestStarted);
        return payload;
      }).catch(function (error) {
        if (timeout) window.clearTimeout(timeout);
        setConnectionState(false);
        if (error && error.name === 'AbortError' && timedOut) {
          var timeoutError = new Error('The server took longer than expected to respond. Your message may still have been saved; refresh the conversation before sending it again.');
          timeoutError.code = 'HC_REQUEST_TIMEOUT';
          throw timeoutError;
        }
        throw error;
      });
    }

    var hcRealtimeConnection = null, hcRealtimeConnected = false, hcQueueTimer = null, hcTicketTimer = null;
    function configureRealtimeFallback(connected) {
      hcRealtimeConnected = !!connected;
      if (hcQueueTimer) window.clearInterval(hcQueueTimer);
      if (hcTicketTimer) window.clearInterval(hcTicketTimer);
      hcQueueTimer = window.setInterval(function () { refreshQueue(); }, hcRealtimeConnected ? 10000 : 3000);
      hcTicketTimer = window.setInterval(function () { if (selected && !document.hidden) updateSelected(); }, hcRealtimeConnected ? 8000 : 2500);
    }
    if (window.HCRealtimeClient && window.Ably) {
      window.HCRealtimeClient.connect({ajaxUrl: ajax, nonce: nonce}, function (event) {
        if (document.hidden) return;
        refreshQueue();
        if (selected && (!event.ticket_id || Number(event.ticket_id) === Number(selected))) updateSelected();
      }, function (state) {
        var status = document.getElementById('hcAiLiveStatus');
        if (status && state === 'connected') status.textContent = 'Ably live · REST recovery enabled';
        if (status && (state === 'disconnected' || state === 'suspended')) status.textContent = 'Reconnecting · fast REST fallback active';
        configureRealtimeFallback(state === 'connected');
      }).then(function (connection) { hcRealtimeConnection = connection; refreshQueue(); if (selected) updateSelected(); }).catch(function () { /* REST polling remains the fallback. */ });
    }

    function node(tag, className, text) {
      var item = document.createElement(tag);
      if (className) item.className = className;
      if (text !== undefined && text !== null) item.textContent = String(text);
      return item;
    }
    function supportMarkdown(value) {
      var safe=String(value||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;');
      return safe.split('\n').map(function(line){var t=line.trim();if(!t)return '<div class=\"hc-md-spacer\"></div>';if(/^[-*] /.test(t))return '<div class=\"hc-md-bullet\">• '+t.slice(2)+'</div>';if(/^#{1,3} /.test(t))return '<strong>'+t.replace(/^#{1,3} /,'')+'</strong>';return '<div>'+t.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>')+'</div>';}).join('');
    }

    function setConnectionState(connected, latency) {
      var state = document.getElementById('hcSupportConnectivity');
      var sync = document.getElementById('hcSupportLastSync');
      var slow = false; // A delayed but successful response is still a successful sync; do not show a false connection warning.
      if (state) {
        state.classList.toggle('is-live', !!connected && !slow);
        state.classList.toggle('is-offline', !connected);
        state.classList.toggle('is-slow', slow);
        state.innerHTML = !connected ? '<i class="fas fa-triangle-exclamation"></i> Connection interrupted · retrying' : (slow ? '<i class="fas fa-gauge-high"></i> Slow connection · updates may be delayed' : '<i class="fas fa-circle"></i> Connected · live updates');
      }
      if (sync && connected) sync.textContent = 'Last sync: ' + new Date().toLocaleTimeString() + (slow ? ' · ' + ((latency / 1000).toFixed(1)) + 's' : '');
    }

    function updateClock() {
      var clock = document.getElementById('hcSupportClock');
      if (clock) clock.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }

    function startAgentHeartbeat(manualToggle) {
      request('hc_ai_support_presence', { available: available ? 1 : 0, manual_toggle: manualToggle ? 1 : 0 }).then(function (r) {
        if (!r.success) throw new Error(r.data && r.data.message || 'Presence unavailable');
        if (typeof r.data.available !== 'undefined' && !!r.data.available !== available) { available = !!r.data.available; try { window.localStorage.setItem('hcAiSupportAvailable', available ? '1' : '0'); } catch(e) {} var presenceButton = document.getElementById('hcAiAgentAvailability'); if (presenceButton) { presenceButton.classList.toggle('is-available',available); presenceButton.classList.toggle('is-unavailable',!available); presenceButton.setAttribute('aria-pressed',available?'true':'false'); presenceButton.innerHTML = available ? '<i class="fas fa-circle"></i> Available' : '<i class="fas fa-circle"></i> Offline'; } }
        var online = document.getElementById('hcSupportCountOnline');
        if (online) online.textContent = r.data.online_agents || 0;
      }).catch(function () {});
    }

    function fmt(value) {
      if (!value) return '';
      var date = new Date(String(value).replace(' ', 'T'));
      return isNaN(date.getTime()) ? value : date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    }

    function statusLabel(status) {
      return ({ queued: 'Waiting', pending_email: 'Legacy email follow-up', converted: 'Moved to HCK ticket', active: 'Active', waiting_agent: 'Visitor replied', waiting_customer: 'Waiting for visitor', closed: 'Closed', archived: 'Archived' })[status] || status;
    }

    function claimCrossTabAlert(key) {
      if (!key) return true;
      try { var storageKey = 'hc-agent-alert:' + String(key), now = Date.now(), prior = Number(window.localStorage.getItem(storageKey) || 0); if (prior && now - prior < 120000) return false; window.localStorage.setItem(storageKey, String(now)); return true; } catch (e) { return true; }
    }
    function beep(key, force) {
      if ((!alerts && !force) || (key && !claimCrossTabAlert('sound:' + key))) return;
      try {
        var Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return;
        if (!audioContext) audioContext = new Ctx();
        if (audioContext.state === 'suspended') audioContext.resume();
        var patterns = {urgent:[1046,1318,1568,1318,1046],bell:[660,990,1320,990],classic:[988,784,988,784,1318],digital:[784,784,1174,784],chime:[880,1174,1568],soft:[523,659,784]};
        var notes = patterns[alertSound] || patterns.urgent, base = audioContext.currentTime;
        notes.forEach(function (hz, index) {
          var oscillator = audioContext.createOscillator(), gain = audioContext.createGain(), at = base + index * 0.16;
          oscillator.type = alertSound === 'digital' ? 'square' : 'sine';
          oscillator.frequency.setValueAtTime(hz, at);
          gain.gain.setValueAtTime(0.0001, at);
          gain.gain.exponentialRampToValueAtTime(Math.max(0.01, alertVolume) * 0.85, at + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.27);
          oscillator.connect(gain); gain.connect(audioContext.destination);
          oscillator.start(at); oscillator.stop(at + 0.29);
        });
      } catch (error) { /* Browser audio is optional; unread state remains authoritative. */ }
    }


    var previewSoundButton = document.getElementById('hcAdminPreviewNotificationSound');
    if (previewSoundButton) {
      previewSoundButton.addEventListener('click', function () {
        var soundField = document.querySelector('[name="settings[hc_ai_support_alert_sound]"]');
        var volumeField = document.querySelector('[name="settings[hc_ai_support_alert_volume]"]');
        if (soundField) alertSound = soundField.value || 'urgent';
        if (volumeField) alertVolume = Math.max(0.2, Math.min(1, Number(volumeField.value) || 0.9));
        beep('', true);
      });
    }

    function browserNotify(title, body, key) {
      if (key && !claimCrossTabAlert('notify:' + key)) return;
      if (browserAlerts && 'Notification' in window && Notification.permission === 'granted' && document.hidden) {
        try { new Notification(title, { body: body }); } catch (error) { /* Notifications are optional. */ }
      }
    }

    if (alertBtn) {
      alertBtn.addEventListener('click', function () {
        alerts = alerts && root.dataset.alertsEnabled !== '0';
        var Ctx = window.AudioContext || window.webkitAudioContext;
        if (Ctx && !audioContext) audioContext = new Ctx();
        if (audioContext && audioContext.state === 'suspended') audioContext.resume();
        if (browserAlerts && 'Notification' in window && Notification.permission === 'default') Notification.requestPermission();
        alertBtn.innerHTML = '<i class="fas fa-bell"></i> Alerts enabled';
        alertBtn.classList.add('is-active');
        beep();
      });
    }


    document.addEventListener('click', function () { if (!audioContext) { var Ctx = window.AudioContext || window.webkitAudioContext; if (Ctx) audioContext = new Ctx(); } if (audioContext && audioContext.state === 'suspended') audioContext.resume(); }, { once: true });
    var availabilityBtn = document.getElementById('hcAiAgentAvailability');
    if (availabilityBtn) {
      try { available = window.localStorage.getItem('hcAiSupportAvailable') === '1'; } catch (e) { available = false; }
      function paintAvailability() { availabilityBtn.classList.toggle('is-available', available); availabilityBtn.classList.toggle('is-unavailable', !available); availabilityBtn.setAttribute('aria-pressed', available ? 'true' : 'false'); availabilityBtn.innerHTML = available ? '<i class="fas fa-circle"></i> Available' : '<i class="fas fa-circle"></i> Offline'; }
      paintAvailability();
      availabilityBtn.addEventListener('click', function () { available = !available; try { window.localStorage.setItem('hcAiSupportAvailable', available ? '1' : '0'); } catch (e) {} paintAvailability(); startAgentHeartbeat(true); });
    }

    document.querySelectorAll('.hc-support-force-logout').forEach(function(button){
      button.addEventListener('click', function(event){
        event.preventDefault(); event.stopPropagation();
        if(!supervisor) return;
        var agentId = parseInt(button.dataset.agentId,10)||0;
        if(!agentId || !window.confirm('Force logout this agent? Their active tickets will return to the queue or be assigned to other available agents.')) return;
        button.disabled = true;
        request('hc_ai_support_force_logout',{agent_id:agentId}).then(function(response){
          if(!response.success) throw new Error(response.data&&response.data.message||'Could not force logout agent.');
          window.alert(response.data.message||'Agent logged out.');
          refreshQueue();
        }).catch(function(error){window.alert(error.message)}).finally(function(){button.disabled=false});
      });
    });

    function filteredRows() {
      var query = search ? search.value.trim().toLowerCase() : '';
      return rows.filter(function (ticket) {
        var statusMatch = filter === 'queue' ? (ticket.status === 'queued' || ticket.status === 'pending_email') :
          filter === 'mine' ? (parseInt(ticket.assigned_agent_id, 10) === currentUserId && ticket.status !== 'closed' && ticket.status !== 'archived' && ticket.status !== 'converted') :
          filter === 'closed' ? ticket.status === 'closed' :
          filter === 'archived' ? ticket.status === 'archived' : filter === 'all' ? ticket.status !== 'archived' : true;
        if (!statusMatch) return false;
        if (!query) return true;
        return [ticket.id, ticket.visitor_name, ticket.visitor_email, ticket.issue, ticket.assigned_agent_name, ticket.last_message_preview].join(' ').toLowerCase().indexOf(query) !== -1;
      });
    }

    function renderStats(counts) {
      var fields = { queued: 'Queued', active: 'Active', mine: 'Mine', unread: 'Unread', closed: 'Closed', archived: 'Archived', online_agents: 'Online' };
      Object.keys(fields).forEach(function (key) {
        var target = document.getElementById('hcSupportCount' + fields[key]);
        if (target) target.textContent = (counts && counts[key]) || 0;
      });
      var queue = document.getElementById('hcSupportFilterQueue');
      if (queue) queue.textContent = (counts && counts.queued) || 0;
      var badge = document.getElementById('hcAiEscalationBadge');
      var activePending = parseInt(counts && counts.active_pending || 0, 10) || 0;
      if (badge) { badge.textContent = activePending > 99 ? '99+' : String(activePending); badge.hidden = activePending < 1; }
    }

    function showEmptyWorkspace() {
      chat.innerHTML = '<div class="hc-support-empty-state"><span><i class="fas fa-headset"></i></span><h4>No conversation selected</h4><p>Select a ticket from the inbox to view its messages. New and active requests will appear here automatically.</p></div>';
      visitor.innerHTML = '<div class="hc-support-empty-state"><span><i class="fas fa-user-circle"></i></span><h4>Visitor details</h4><p>Visitor profile and related tickets appear when you open a conversation.</p></div>';
    }

    function renderList() {
      list.textContent = '';
      var data = filteredRows();
      if (selected && !data.some(function (ticket) { return ticket.id === selected; })) { selected = 0; showEmptyWorkspace(); }
      if (!data.length) {
        list.appendChild(node('div', 'hc-support-empty', search && search.value ? 'No tickets match your search.' : (filter === 'queue' ? 'No visitors are waiting.' : 'No tickets in this view.')));
        return;
      }
      data.forEach(function (ticket) {
        var button = node('button', 'hc-support-ticket-item' + (selected === ticket.id ? ' is-selected' : ''));
        button.type = 'button';
        button.disabled = uploadBusy && selected !== ticket.id;
        var top = node('span', 'hc-support-ticket-item-top');
        top.append(node('strong', '', '#' + ticket.id + ' · ' + ticket.visitor_name), node('em', 'hc-support-pill status-' + ticket.status, statusLabel(ticket.status)));
        if(ticket.priority && ticket.priority!=='normal') top.appendChild(node('em','hc-support-priority priority-'+ticket.priority,ticket.priority.toUpperCase()));
        var preview = node('span', 'hc-support-ticket-preview', ticket.last_message_preview || ticket.issue || 'No message yet');
        var bottom = node('span', 'hc-support-ticket-bottom');
        bottom.append(node('small', '', ticket.assigned_agent_name ? 'Agent: ' + ticket.assigned_agent_name : 'Unassigned'));
        if(ticket.status==='queued' && ticket.queue_started_at){var queuedAt=new Date(String(ticket.queue_started_at).replace(' ','T'));if(!isNaN(queuedAt.getTime()))bottom.appendChild(node('small','hc-support-queue-age','Waiting '+Math.max(0,Math.floor((Date.now()-queuedAt.getTime())/60000))+'m'));}
        if (ticket.unread_count) bottom.appendChild(node('small', 'hc-support-unread', ticket.unread_count + ' unread'));
        button.append(top, preview, bottom);
        button.addEventListener('click', function () { openTicket(ticket.id); });
        list.appendChild(button);
      });
    }

    function appendBubble(parent, senderType, senderName, content, createdAt, attachment, avatarUrl, messageId) {
      var kind = senderType === 'visitor' ? 'visitor' : (senderType === 'system' ? 'system' : (senderType === 'internal_note' ? 'internal_note' : (senderType === 'ai' ? 'ai' : 'agent')));
      var article = node('article', 'hc-support-message ' + kind);
      if (messageId) article.dataset.ticketMessageId = String(messageId);
      if (kind !== 'system' && kind !== 'internal_note') {
        var avatar = node('span', 'hc-support-message-avatar');
        if (kind === 'ai') avatar.innerHTML = '<i class="fas fa-robot" aria-hidden="true"></i>';
        else if (avatarUrl) { var avatarImg = node('img'); avatarImg.src = avatarUrl; avatarImg.alt = ''; avatarImg.loading = 'lazy'; avatar.appendChild(avatarImg); }
        else avatar.textContent = (senderName || (kind === 'visitor' ? 'V' : 'A')).trim().charAt(0).toUpperCase();
        article.appendChild(avatar);
      }
      if (kind === 'system') {
        article.textContent = content || senderName || 'Support update';
        parent.appendChild(article);
        return article;
      }
      var contentBox = node('div', 'hc-support-message-content');
      var meta = node('div', 'hc-support-message-meta');
      var displayName = kind === 'internal_note' ? 'Internal note · ' + (senderName || 'Agent') : (kind === 'ai' ? 'AI Bot' : (senderName || (kind === 'visitor' ? 'Customer' : 'Support agent')));
      if (kind === 'internal_note') meta.append(node('i', 'fa-solid fa-lock', ''));
      meta.append(node('strong', '', displayName));
      meta.append(node('time', '', fmt(createdAt)));
      contentBox.append(meta);
      if (content) contentBox.appendChild(node('div', 'hc-support-message-body', content));
      if (attachment && attachment.expired) { contentBox.appendChild(node('div', 'hc-support-attachment-expired', 'Attachment expired: the file was automatically removed from HelpCenter storage under the administrator’s retention policy. Ask the sender to upload it again if needed.')); }
      if (attachment && attachment.url) {
        var card = node('a', 'hc-support-attachment'); card.href = attachment.url; card.target = '_blank'; card.rel = 'noopener noreferrer';
        var fileIcon = attachment.kind === 'image' ? 'fa-image' : (attachment.kind === 'video' ? 'fa-video' : (attachment.kind === 'zip' ? 'fa-file-zipper' : 'fa-file-lines'));
        var fileLabel=node('span','hc-support-file-name',attachment.name||'Download attachment');fileLabel.title=attachment.name||'Download attachment';card.append(node('i', 'fas ' + fileIcon),fileLabel);
        card.appendChild(node('small', '', (Math.max(1, Math.round((attachment.size || 0) / 1024))) + ' KB · ' + String(attachment.mime || 'file'))); contentBox.appendChild(card);
        if (attachment.kind === 'image') { var preview = node('img', 'hc-support-image-preview'); preview.src = attachment.url; preview.alt = attachment.name || 'Shared image'; preview.loading = 'lazy'; contentBox.appendChild(preview); }
        else if (attachment.kind === 'video') { var video = node('video', 'hc-support-video-preview'); video.src = attachment.url; video.controls = true; video.preload = 'metadata'; contentBox.appendChild(video); }
      }
      article.appendChild(contentBox);
      parent.appendChild(article);
      return article;
    }

    function renderContext(context, ticketId) {
      if (!context || !context.length) return null;
      var details = node('details', 'hc-support-context');
      details.open = showAiHistory;
      var summary = node('summary', '', 'View AI conversation before handoff · ' + context.length + ' messages');
      var body = node('div', 'hc-support-context-body');
      context.forEach(function (message) {
        var isUser = message.role === 'user';
        var row = node('div', 'hc-support-context-message' + (isUser ? ' is-user' : ' is-assistant'));
        var avatar = node('span','hc-support-context-avatar',isUser ? 'U' : '');
        if (!isUser) avatar.innerHTML = '<i class="fas fa-robot" aria-hidden="true"></i>';
        var messageBody = node('div','hc-support-context-copy');
        var meta = node('strong','', (isUser ? 'Customer' : 'AI Assistant') + ' · ' + fmt(message.created_at));
        messageBody.append(meta,node('p','',message.content || ''));
        row.append(avatar,messageBody);
        body.appendChild(row);
      });
      details.append(summary, body);
      return details;
    }

    function renderHeader(ticket) {
      var header = node('div', 'hc-support-chat-header');
      var identity = node('div', 'hc-support-agent-id');
      var assignedName = ticket.assigned_agent_name || '';
      var headerAvatar = node('span', 'hc-support-agent-avatar', (ticket.visitor_name || 'V').trim().charAt(0).toUpperCase());
      if (ticket.visitor_avatar) { var headerImg=node('img'); headerImg.src=ticket.visitor_avatar; headerImg.alt=''; headerImg.loading='lazy'; headerAvatar.textContent=''; headerAvatar.appendChild(headerImg); }
      identity.appendChild(headerAvatar);
      var identityText = node('div', '');
      identityText.append(node('strong', '', ticket.visitor_name + ' · Ticket #' + ticket.id));
      identityText.append(node('small', '', assignedName ? 'Handled by ' + assignedName : 'Waiting for a support specialist'));
      identity.appendChild(identityText);
      var actions = node('div', 'hc-support-header-actions');
      var backToInbox = node('button','hc-admin-btn hc-admin-btn-small hc-support-back-inbox','← Tickets'); backToInbox.type='button'; backToInbox.addEventListener('click',function(){var ticketPane=root.querySelector('.hc-support-ticket-pane');if(ticketPane)ticketPane.scrollIntoView({behavior:'smooth',block:'start'});}); actions.appendChild(backToInbox);
      actions.appendChild(node('span', 'hc-support-pill status-' + ticket.status, statusLabel(ticket.status)));
      if (!ticket.assigned_agent_id && ticket.status !== 'closed' && ticket.status !== 'archived' && ticket.status !== 'converted') {
        var claim = node('button', 'hc-admin-btn hc-admin-btn-small hc-admin-btn-primary', 'Claim ticket');
        claim.type = 'button'; claim.addEventListener('click', claimSelected); actions.appendChild(claim);
      } else if (parseInt(ticket.assigned_agent_id, 10) === currentUserId) {
        actions.appendChild(node('span', 'hc-support-pill status-active', 'Assigned to you'));
      } else if (ticket.assigned_agent_id) {
        actions.appendChild(node('span', 'hc-support-pill', 'Assigned to ' + assignedName));
      }
      if (ticket.hck_ticket_id) {
        var openHck = node('a','hc-admin-btn hc-admin-btn-small hc-admin-btn-primary','Open HCK ticket'); openHck.href = ticket.hck_ticket_url || (window.location.origin + '/ticket/admin/view/' + ticket.hck_ticket_id + '/'); openHck.target='_blank'; openHck.rel='noopener'; actions.appendChild(openHck);
      } else if (ticket.status !== 'closed' && ticket.status !== 'archived' && ticket.status !== 'converted' && (parseInt(ticket.assigned_agent_id, 10) === currentUserId || supervisor)) {
        var convert = node('button','hc-admin-btn hc-admin-btn-small hc-admin-btn-primary','Convert to Follow-up Ticket'); convert.type='button'; convert.addEventListener('click',convertSelectedToHck); actions.appendChild(convert);
      }
      if (ticket.status === 'closed' && (parseInt(ticket.assigned_agent_id, 10) === currentUserId || supervisor)) {
        var archive = node('button', 'hc-admin-btn hc-admin-btn-small', 'Archive ticket');
        archive.type = 'button'; archive.addEventListener('click', archiveSelected); actions.appendChild(archive);
      } else if (ticket.status !== 'closed' && ticket.status !== 'archived' && ticket.status !== 'converted' && (parseInt(ticket.assigned_agent_id, 10) === currentUserId || supervisor)) {
        var close = node('button', 'hc-admin-btn hc-admin-btn-small hc-admin-btn-danger', 'Close ticket');
        close.type = 'button'; close.addEventListener('click', closeSelected); actions.appendChild(close);
      }
      header.append(identity, actions);
      return header;
    }

    function renderVisitor(data) {
      var ticket = data.ticket;
      visitor.textContent = '';
      var card = node('div', 'hc-support-visitor-card');
      var visitorAvatar=node('div','hc-support-visitor-avatar',(ticket.visitor_name || 'V').trim().charAt(0).toUpperCase()); if(ticket.visitor_avatar){var visitorImg=node('img');visitorImg.src=ticket.visitor_avatar;visitorImg.alt='';visitorImg.loading='lazy';visitorAvatar.textContent='';visitorAvatar.appendChild(visitorImg);} card.appendChild(visitorAvatar);
      card.append(node('h4', '', ticket.visitor_name), node('p', '', ticket.visitor_email));
      var fields = node('dl', 'hc-support-visitor-fields');
      [
        ['Ticket', '#' + ticket.id],
        ['Account', ticket.user_id ? 'WordPress user #' + ticket.user_id : 'Guest visitor'],
        ['Agent', ticket.assigned_agent_name || 'Not assigned'],
        ['Visitor status', ticket.visitor_online ? 'Online' : 'Offline'],
        ['Agent presence', ticket.agent_typing ? 'Typing…' : (ticket.agent_online ? 'Online' : 'Offline')],
        ['Ticket status', statusLabel(ticket.status)],
        ['Conversation', ticket.conversation_id ? '#' + ticket.conversation_id : 'Not linked']
      ].forEach(function (pair) {
        var row = node('div', ''); row.dataset.field = pair[0].toLowerCase().replace(/[^a-z]+/g, '-'); row.append(node('dt', '', pair[0]), node('dd', '', pair[1])); fields.appendChild(row);
      });
      card.appendChild(fields); visitor.appendChild(card);
      if (aiOverviewEnabled) {
        var overview = node('section', 'hc-support-ai-overview');
        overview.appendChild(node('h4', '', '✨ AI ticket overview'));
        var overviewText = node('div', 'hc-support-ai-overview-markdown');
        overviewText.innerHTML = supportMarkdown(ticket.ai_summary || 'Generate a concise handover summary of the complete AI and human-support conversation.');
        overview.appendChild(overviewText);
        var summaryButton = node('button', 'hc-admin-btn hc-admin-btn-secondary hc-admin-btn-small', ticket.ai_summary ? 'Regenerate overview' : 'Generate AI overview');
        summaryButton.type = 'button';
        summaryButton.addEventListener('click', function () {
          summaryButton.disabled = true; summaryButton.textContent = 'Generating…';
          request('hc_ai_escalation_summary', {ticket_id:ticket.id}).then(function (response) {
            if (!response.success) throw new Error(response.data && response.data.message || 'Could not generate overview.');
            overviewText.innerHTML = supportMarkdown(response.data.summary || 'No summary returned.'); summaryButton.textContent = 'Regenerate overview';
          }).catch(function (error) { overviewText.textContent = error.message; summaryButton.textContent = 'Try again'; }).finally(function () { summaryButton.disabled = false; });
        });
        overview.appendChild(summaryButton); visitor.appendChild(overview);
      }
      if (ticket.status !== 'archived' && ticket.status !== 'closed' && ticket.status !== 'converted' && (supervisor || parseInt(ticket.assigned_agent_id,10)===currentUserId)) {
        var priorityBox=node('div','hc-support-assignment'); priorityBox.appendChild(node('h4','','Ticket priority'));
        var prioritySelect=node('select',''); [['low','Low'],['normal','Normal'],['high','High'],['urgent','Urgent']].forEach(function(pair){prioritySelect.appendChild(new Option(pair[1],pair[0]))}); prioritySelect.value=ticket.priority||'normal';
        var prioritySave=node('button','hc-admin-btn hc-admin-btn-secondary','Update priority');prioritySave.type='button';prioritySave.addEventListener('click',function(){prioritySave.disabled=true;request('hc_ai_escalation_priority',{ticket_id:ticket.id,priority:prioritySelect.value}).then(function(r){if(!r.success)throw new Error(r.data&&r.data.message||'Priority update failed.');refreshQueue();return openTicket(ticket.id)}).catch(function(e){window.alert(e.message)}).finally(function(){prioritySave.disabled=false})});
        priorityBox.append(prioritySelect,prioritySave);visitor.appendChild(priorityBox);
      }
      if (ticket.status === 'archived' && supervisor && Array.isArray(data.agents)) {
        var restoreBox = node('div', 'hc-support-assignment');
        restoreBox.appendChild(node('h4', '', 'Restore archived ticket'));
        restoreBox.appendChild(node('p', 'hc-support-muted', 'Return this ticket to the queue or assign it directly to an online agent with available capacity.'));
        var restoreSelect = node('select', '');
        restoreSelect.appendChild(new Option('Return to unassigned queue', '0'));
        data.agents.forEach(function (agent) { var option = new Option(agent.name + (agent.email ? ' · '+agent.email : '') + (agent.online ? ' · Online' : ' · Offline'), String(agent.id)); option.disabled = !agent.online; restoreSelect.appendChild(option); });
        var restoreButton = node('button', 'hc-admin-btn hc-admin-btn-primary', 'Restore ticket');
        restoreButton.type = 'button';
        restoreButton.addEventListener('click', function () {
          var targetId = parseInt(restoreSelect.value, 10) || 0;
          if (!window.confirm('Restore ticket #' + ticket.id + (targetId ? ' and assign it to ' + restoreSelect.options[restoreSelect.selectedIndex].text : ' to the unassigned queue') + '?')) return;
          restoreButton.disabled = true;
          request('hc_ai_escalation_restore', { ticket_id: ticket.id, agent_id: targetId }).then(function (response) {
            if (!response.success) throw new Error(response.data && response.data.message || 'Could not restore ticket.');
            filter = targetId ? (targetId === currentUserId ? 'mine' : 'all') : 'queue';
            document.querySelectorAll('[data-support-filter]').forEach(function (item) { item.classList.toggle('is-active', item.dataset.supportFilter === filter); });
            return refreshQueue().then(function () { return openTicket(ticket.id); });
          }).catch(function (error) { window.alert(error.message); }).finally(function () { restoreButton.disabled = false; });
        });
        restoreBox.append(restoreSelect, restoreButton);
        visitor.appendChild(restoreBox);
      }
      if ((supervisor || parseInt(ticket.assigned_agent_id, 10) === currentUserId) && Array.isArray(data.agents) && ticket.status !== 'closed' && ticket.status !== 'archived' && ticket.status !== 'converted') {
        var assignment = node('div', 'hc-support-assignment');
        assignment.appendChild(node('h4', '', 'Ticket ownership'));
        assignment.appendChild(node('p', 'hc-support-muted', 'Only the assigned agent can reply. The owner or a supervisor can transfer this ticket to another enabled agent.'));
        var agentSearch = node('input', ''); agentSearch.type='search'; agentSearch.placeholder='Search agents by name or email…'; agentSearch.style.width='100%'; agentSearch.style.margin='6px 0';
        var select = node('select', '');
        select.appendChild(new Option('Unassigned · return to queue', '0'));
        agentSearch.addEventListener('input',function(){Array.prototype.forEach.call(select.options,function(opt){if(opt.value==='0')return;opt.hidden=opt.text.toLowerCase().indexOf(agentSearch.value.toLowerCase())<0;});});
        data.agents.forEach(function (agent) { var option = new Option(agent.name + (agent.email ? ' · '+agent.email : '') + (agent.online ? ' · Online' : ' · Offline'), String(agent.id)); option.disabled = !agent.online && parseInt(agent.id,10) !== parseInt(ticket.assigned_agent_id,10); select.appendChild(option); });
        select.value = String(ticket.assigned_agent_id || 0);
        var transfer = node('button', 'hc-admin-btn hc-admin-btn-secondary', 'Reassign ticket');
        transfer.type = 'button';
        transfer.addEventListener('click', function () {
          var targetId = parseInt(select.value, 10) || 0;
          if (targetId === (parseInt(ticket.assigned_agent_id, 10) || 0)) return;
          if (!window.confirm('Reassign ticket #' + ticket.id + ' to ' + (targetId ? select.options[select.selectedIndex].text : 'the unassigned queue') + '?')) return;
          transfer.disabled = true;
          request('hc_ai_escalation_transfer', { ticket_id: ticket.id, agent_id: targetId }).then(function (response) {
            if (!response.success) throw new Error(response.data && response.data.message || 'Ticket could not be reassigned.');
            return refreshQueue().then(function () { return openTicket(ticket.id); });
          }).catch(function (error) { window.alert(error.message); }).finally(function () { transfer.disabled = false; });
        });
        assignment.append(agentSearch, select, transfer);
        visitor.appendChild(assignment);
      }
      var related = node('div', 'hc-support-related'); related.appendChild(node('h4', '', 'Previous support tickets'));
      if (data.related && data.related.length) {
        data.related.forEach(function (relatedTicket) {
          var item = node('div', 'hc-support-related-item');
          item.append(node('strong', '', 'Ticket #' + relatedTicket.id + ' · ' + statusLabel(relatedTicket.status)), node('small', '', fmt(relatedTicket.last_activity || relatedTicket.created_at)));
          related.appendChild(item);
        });
      } else related.appendChild(node('p', 'hc-support-muted', 'No other tickets are linked to this visitor.'));
      visitor.appendChild(related);
    }

    function updateVisitorPresence(ticket) {
      var fields = visitor.querySelector('.hc-support-visitor-fields');
      if (!fields) return;
      var visitorRow = fields.querySelector('[data-field=\"visitor-status\"] dd');
      var agentRow = fields.querySelector('[data-field=\"agent-presence\"] dd');
      var statusRow = fields.querySelector('[data-field=\"ticket-status\"] dd');
      var assignedRow = fields.querySelector('[data-field="agent"] dd');
      if (visitorRow) visitorRow.textContent = ticket.visitor_online ? 'Online' : 'Offline';
      if (agentRow) agentRow.textContent = ticket.agent_typing ? 'Typing…' : (ticket.agent_online ? 'Online' : 'Offline');
      if (assignedRow) assignedRow.textContent = ticket.assigned_agent_name || 'Not assigned';
      if (statusRow) statusRow.textContent = statusLabel(ticket.status);
    }

    function updateTypingIndicator(ticket) {
      var transcript = chat.querySelector('.hc-support-transcript');
      if (!transcript) return;
      var indicator = transcript.querySelector('.hc-support-typing');
      if (ticket.visitor_typing) {
        if (!indicator) { indicator = node('div', 'hc-support-typing', ticket.visitor_name + ' is typing…'); transcript.appendChild(indicator); }
        else indicator.textContent = ticket.visitor_name + ' is typing…';
      } else if (indicator) indicator.remove();
    }

    function renderInitial(data) {
      var ticket = data.ticket;
      chat.textContent = '';
      chat.appendChild(renderHeader(ticket));
      if(ticket.status==='closed'){var closedBanner=node('div','hc-support-closed-banner','This ticket was closed by '+(ticket.closed_by_name||ticket.assigned_agent_name||'the support team')+'.');chat.appendChild(closedBanner);}
      var transcript = node('div', 'hc-support-transcript');
      var context = renderContext(data.context || [], ticket.id);
      if (context) transcript.appendChild(context);
      transcript.appendChild(node('div', 'hc-support-handoff-divider', 'Human support conversation · Ticket #' + ticket.id));
      var issueText = String(ticket.issue || '').trim();
      var hasEscalationMessage = issueText && (data.messages || []).some(function(message){
        return message.sender_type === 'visitor' && String(message.content || '').trim() === issueText;
      });
      // Keep the original handoff concern distinct; later visitor messages must not hide it.
      if (issueText && !hasEscalationMessage) appendBubble(transcript, 'visitor', ticket.visitor_name, issueText, ticket.created_at, null, ticket.visitor_avatar);
      (data.messages || []).forEach(function (message) { appendBubble(transcript, message.sender_type, message.sender_name, message.content, message.created_at, message.attachment, message.avatar_url, message.id); });
      chat.appendChild(transcript);
      var scrollLatest = node('button', 'hc-support-scroll-latest'); scrollLatest.innerHTML = '<i class="fas fa-arrow-down" aria-hidden="true"></i>'; scrollLatest.type = 'button'; scrollLatest.title = 'Scroll to latest message'; scrollLatest.hidden = true; scrollLatest.addEventListener('click', function(){transcript.scrollTo({top:transcript.scrollHeight,behavior:'smooth'});scrollLatest.hidden=true;}); chat.appendChild(scrollLatest);
      transcript.addEventListener('scroll', function(){var atBottom=transcript.scrollHeight-transcript.scrollTop-transcript.clientHeight<90;scrollLatest.hidden=atBottom;});
      var form = node('div', 'hc-support-reply-box');
      var modeBar = node('div', 'hc-support-composer-modes');
      var replyMode = node('button', 'is-active', 'Reply to customer'); replyMode.type = 'button'; replyMode.dataset.mode = 'reply';
      var noteMode = node('button', '', '🔒 Internal note'); noteMode.type = 'button'; noteMode.dataset.mode = 'note';
      modeBar.append(replyMode, noteMode); composerMode = 'reply';
      var quickReplies=node('select','hc-support-quick-replies');quickReplies.appendChild(new Option('Insert a quick reply…',''));[['Hello! I’m reviewing your request and will help you shortly.','Greeting'],['Thank you for waiting. I’m checking the details for you.','Waiting update'],['Could you please share the missing details so I can assist you further?','Request details'],['I have reviewed the conversation and will guide you through the next steps.','Next steps']].forEach(function(pair){quickReplies.appendChild(new Option(pair[1],pair[0]))});
      var textarea = node('textarea', ''); textarea.rows = 2; textarea.maxLength = 5000;
      quickReplies.addEventListener('change',function(){if(quickReplies.value){textarea.value=quickReplies.value;textarea.focus();quickReplies.value='';saveDraft();}});
      textarea.placeholder = ticket.status === 'converted' ? 'Converted to HCK. Continue in the ticket portal.' : ((ticket.status === 'closed' || ticket.status === 'archived') ? 'This ticket is not accepting replies.' : 'Reply to ' + ticket.visitor_name + '…');
      var isTicketOwner = parseInt(ticket.assigned_agent_id, 10) === currentUserId;
      var ticketIsReadOnly = ticket.status === 'closed' || ticket.status === 'archived' || ticket.status === 'converted';
      textarea.disabled = ticketIsReadOnly || (!isTicketOwner && !supervisor);
      var draftKey='hcSupportDraft:'+ticket.id; try{textarea.value=window.localStorage.getItem(draftKey)||'';}catch(e){}
      function saveDraft(){try{if(textarea.value)window.localStorage.setItem(draftKey,textarea.value);else window.localStorage.removeItem(draftKey);}catch(e){}}
      textarea.addEventListener('input',saveDraft);
      var send = node('button', 'hc-admin-btn hc-admin-btn-primary hc-support-send-button', 'Send reply'); send.type = 'button'; send.disabled = textarea.disabled;
      var uploadTools = node('div', 'hc-support-upload-tools');
      var attach = node('button', 'hc-admin-btn hc-admin-btn-secondary hc-admin-btn-small hc-support-attach-button', 'Attach file'); attach.type = 'button'; attach.disabled = ticket.status === 'closed' || ticket.status === 'archived' || ticket.status === 'converted' || parseInt(ticket.assigned_agent_id, 10) !== currentUserId;
      var fileInput = node('input', ''); fileInput.type = 'file'; fileInput.accept = '.jpg,.jpeg,.png,.gif,.webp,.mp4,.webm,.txt,.csv,.pdf,.zip'; fileInput.disabled = attach.disabled;
      var progress = node('div', 'hc-support-upload-progress'); progress.hidden = true; var progressBar = node('span', ''); progress.appendChild(progressBar);
      var note = node('small', 'hc-support-reply-note', ticket.status === 'converted' ? 'Converted to HCK. Continue in the ticket portal.' : ((ticket.status === 'closed' || ticket.status === 'archived') ? 'Ticket is not active.' : (textarea.disabled ? 'Only the assigned agent or a supervisor can reply.' : (ticket.status === 'pending_email' ? 'Legacy email follow-up mode.' : 'Enter to send · Shift + Enter for a new line'))));
      function setComposerMode(mode) { composerMode = mode; replyMode.classList.toggle('is-active', mode === 'reply'); noteMode.classList.toggle('is-active', mode === 'note'); send.textContent = mode === 'note' ? 'Save internal note' : 'Send reply'; textarea.placeholder = mode === 'note' ? 'Write a private note for other support agents…' : 'Reply to ' + ticket.visitor_name + '…'; attach.hidden = mode === 'note'; var canSend = !ticketIsReadOnly && (mode === 'note' ? (isTicketOwner || supervisor) : isTicketOwner); textarea.disabled = !canSend; send.disabled = !canSend; if(mode==='note' && !canSend) note.textContent='Only the assigned agent or a supervisor can add internal notes.'; else if(mode==='reply' && !canSend) note.textContent='Only the assigned agent can send customer replies.'; }
      replyMode.addEventListener('click', function(){setComposerMode('reply')}); noteMode.addEventListener('click', function(){setComposerMode('note')});
      attach.addEventListener('click', function () { if (!attach.disabled) fileInput.click(); });
      fileInput.addEventListener('change', function () { if (fileInput.files && fileInput.files[0]) uploadAdminFile(fileInput.files[0], textarea, send, attach, fileInput, progress, progressBar, note); });
      send.addEventListener('click', function () { sendAdminMessage(textarea, send, note, composerMode); });
      textarea.addEventListener('keydown', function (event) { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); send.click(); } });
      textarea.addEventListener('input', function(){ if(composerMode==='reply')sendTyping(); });
      uploadTools.append(attach, fileInput); form.append(modeBar, quickReplies, textarea, uploadTools, progress, send, note); chat.appendChild(form);
      renderVisitor(data);
      updateTypingIndicator(ticket);
      function scrollTranscriptToLatest(){transcript.scrollTop=transcript.scrollHeight;var last=transcript.lastElementChild;if(last&&last.scrollIntoView)last.scrollIntoView({block:'end',behavior:'auto'});transcript.scrollTop=transcript.scrollHeight;}
      requestAnimationFrame(function(){scrollTranscriptToLatest();requestAnimationFrame(scrollTranscriptToLatest);});
      setTimeout(scrollTranscriptToLatest,180);setTimeout(scrollTranscriptToLatest,500);
      transcript.querySelectorAll('img').forEach(function(img){if(!img.complete)img.addEventListener('load',scrollTranscriptToLatest,{once:true});});
      scrollLatest.hidden = true;
    }

    function sendTyping() {
      if (!selected || !chat.querySelector('.hc-support-reply-box textarea:not(:disabled)')) return;
      var now = Date.now();
      if (!typingState || now - typingSentAt > 1500) {
        typingSentAt = now;
        typingState = true;
        request('hc_ai_escalation_admin_typing', { ticket_id: selected, typing: 1 }).catch(function () {});
      }
      if (typingTimer) window.clearTimeout(typingTimer);
      typingTimer = window.setTimeout(function () {
        typingState = false;
        request('hc_ai_escalation_admin_typing', { ticket_id: selected, typing: 0 }).catch(function () {});
      }, 2600);
    }

    function openTicket(id) {
      if (uploadBusy && selected !== parseInt(id, 10)) return;
      if (typingTimer) window.clearTimeout(typingTimer);
      if (selected && typingState) request('hc_ai_escalation_admin_typing', { ticket_id: selected, typing: 0 }).catch(function () {});
      selected = parseInt(id, 10) || 0;
      lastMessageId = 0;
      lastAiMessageId = 0;
      typingState = false;
      renderList();
      chat.innerHTML = '<div class="hc-support-loading"><i class="fas fa-circle-notch fa-spin"></i> Loading conversation…</div>';
      request('hc_ai_escalation_ticket', { ticket_id: selected, after_id: 0 }).then(function (response) {
        if (!response.success) throw new Error(response.data && response.data.message || 'Could not load ticket.');
        if (selected !== parseInt(id, 10)) return;
        renderInitial(response.data);
        lastMessageId = (response.data.messages || []).reduce(function (max, message) { return Math.max(max, parseInt(message.id, 10) || 0); }, 0);
        lastAiMessageId = (response.data.context || []).reduce(function(max,row){return Math.max(max,Number(row.id)||0);},0);
      }).catch(function (error) { chat.textContent = error.message; });
    }

    function updateSelected() {
      if (!selected || ticketBusy) return Promise.resolve();
      ticketBusy = true;
      var ticketId = selected;
      return request('hc_ai_escalation_ticket', { ticket_id: ticketId, after_id: lastMessageId, ai_after_id: lastAiMessageId }).then(function (response) {
        if (!response.success || selected !== ticketId) return;
        var data = response.data, ticket = data.ticket;
        var transcript = chat.querySelector('.hc-support-transcript');
        if (!transcript) { openTicket(ticketId); return; }
        var wasAtBottom = transcript.scrollHeight - transcript.scrollTop - transcript.clientHeight < 90;
        (data.messages || []).forEach(function (message) {
          var messageId = parseInt(message.id, 10) || 0;
          if (messageId <= lastMessageId) return;
          if (!transcript.querySelector('[data-ticket-message-id="' + messageId + '"]')) {
            appendBubble(transcript, message.sender_type, message.sender_name, message.content, message.created_at, message.attachment, message.avatar_url, messageId);
          }
          // Advance only through rows actually delivered in this ordered response.
          lastMessageId = Math.max(lastMessageId, messageId);
        });
        (data.context || []).forEach(function(message){var mid=Number(message.id)||0;if(mid<=lastAiMessageId)return;appendBubble(transcript,message.role==='user'?'visitor':'ai',message.role==='user'?data.ticket.visitor_name:'AI Bot',message.content,message.created_at,null,'');lastAiMessageId=Math.max(lastAiMessageId,mid);});
        var latestControl = chat.querySelector('.hc-support-scroll-latest');
        if ((data.messages || []).length && wasAtBottom) transcript.scrollTop = transcript.scrollHeight;
        if (latestControl) latestControl.hidden = wasAtBottom || !(data.messages || []).length;
        var oldHeader = chat.querySelector('.hc-support-chat-header');
        if (oldHeader) oldHeader.replaceWith(renderHeader(ticket));
        var textarea = chat.querySelector('.hc-support-reply-box textarea');
        var send = chat.querySelector('.hc-support-send-button');
        var attach = chat.querySelector('.hc-support-attach-button');
        var ticketOwner = parseInt(ticket.assigned_agent_id,10) === currentUserId;
        var ticketClosed = ticket.status === 'closed' || ticket.status === 'archived' || ticket.status === 'converted';
        var canCompose = !ticketClosed && (composerMode === 'note' ? (ticketOwner || supervisor) : ticketOwner);
        if (textarea) { textarea.disabled = uploadBusy || !canCompose; textarea.placeholder = ticket.status === 'converted' ? 'Converted to HCK. Continue in the ticket portal.' : (ticketClosed ? 'This ticket is not accepting replies.' : (composerMode === 'note' ? 'Write a private note for other support agents…' : 'Reply to ' + ticket.visitor_name + '…')); }
        if (send) send.disabled = uploadBusy || !canCompose;
        if (attach) attach.disabled = uploadBusy || !ticketOwner || ticketClosed;
        var note = chat.querySelector('.hc-support-reply-note');
        if (note) note.textContent = ticket.status === 'converted' ? 'Converted to HCK. Continue in the ticket portal.' : (ticketClosed ? 'Ticket is not active.' : (canCompose ? (composerMode === 'note' ? 'Private note · visible only to support staff.' : 'Enter to send · Shift + Enter for a new line') : (composerMode === 'note' ? 'Only the assigned agent or a supervisor can add internal notes.' : 'Only the assigned agent can send customer replies.')));
        updateTypingIndicator(ticket);
        updateVisitorPresence(ticket);
      }).catch(function () {
        if (live) { live.textContent = 'Reconnecting…'; live.classList.remove('is-live'); }
      }).finally(function () { ticketBusy = false; });
    }

    function claimSelected() {
      if (!selected) return;
      var claimTicketId = selected;
      request('hc_ai_escalation_accept', { ticket_id: claimTicketId }).then(function (response) {
        if (!response.success) throw new Error(response.data && response.data.message || 'Could not claim ticket.');
        refreshQueue(); if (selected === claimTicketId) openTicket(claimTicketId);
      }).catch(function (error) { window.alert(error.message); });
    }

    function convertSelectedToHck() {
      if (!selected || !window.confirm('Move this live conversation into an HCK follow-up ticket? The full AI and human history and attachments will be copied. The original chat will become read-only, and all future customer replies must be sent through the ticket portal.')) return;
      var id = selected;
      request('hc_ai_escalation_convert_hck', { ticket_id: id }).then(function(response) {
        if (!response.success) throw new Error(response.data && response.data.message || 'Could not convert this conversation.');
        var url = response.data.url || '';
        window.alert('Follow-up ticket created: ' + (response.data.ticket_number || ('ticket #' + response.data.ticket_id)) + '. The original chat is now read-only.');
        if (!response.data.already_converted && (!response.data.email_sent || !response.data.followup_email_sent)) window.alert('The ticket was created, but one or both customer emails were not confirmed by the mail transport. Check the mail logs and resend the guest access link from the HCK ticket if needed.');
        refreshQueue(); openTicket(id);
      }).catch(function(error) { window.alert(error.message); });
    }

    function closeSelected() {
      if (!selected || !window.confirm('Close this support ticket? The visitor will be able to use the AI assistant again.')) return;
      var closeTicketId = selected;
      request('hc_ai_escalation_close', { ticket_id: closeTicketId }).then(function (response) {
        if (!response.success) throw new Error(response.data && response.data.message || 'Could not close ticket.');
        refreshQueue(); if (selected === closeTicketId) openTicket(closeTicketId);
      }).catch(function (error) { window.alert(error.message); });
    }

    function archiveSelected() {
      if (!selected || !window.confirm('Archive this closed ticket? Its messages and attachments will be preserved.')) return;
      var id = selected;
      request('hc_ai_escalation_archive', { ticket_id: id }).then(function (response) {
        if (!response.success) throw new Error(response.data && response.data.message || 'Could not archive ticket.');
        filter = 'archived'; document.querySelectorAll('[data-support-filter]').forEach(function (item) { item.classList.toggle('is-active', item.dataset.supportFilter === 'archived'); });
        return refreshQueue().then(function () { openTicket(id); });
      }).catch(function (error) { window.alert(error.message); });
    }

    function restoreSelected() {
      if (!selected || !window.confirm('Restore this archived ticket to the support queue?')) return;
      var id = selected;
      request('hc_ai_escalation_restore', { ticket_id: id, agent_id: 0 }).then(function (response) {
        if (!response.success) throw new Error(response.data && response.data.message || 'Could not restore ticket.');
        filter = 'queue'; document.querySelectorAll('[data-support-filter]').forEach(function (item) { item.classList.toggle('is-active', item.dataset.supportFilter === 'queue'); });
        return refreshQueue().then(function () { openTicket(id); });
      }).catch(function (error) { window.alert(error.message); });
    }

    function requestRetry(action, payload, attempts) {
      var remaining = attempts || 3;
      function run() {
        return request(action, payload).catch(function (error) {
          if (--remaining <= 0) throw error;
          return new Promise(function (resolve) { window.setTimeout(resolve, 500 * Math.pow(2, 3 - remaining)); }).then(run);
        });
      }
      return run();
    }

    function uploadAdminFile(file, textarea, send, attach, fileInput, progress, progressBar, note) {
      if (!selected || !file || uploadBusy) return;
      if (!window.confirm('Upload “' + file.name + '” (' + (file.size / 1048576).toFixed(2) + ' MB) to ticket #' + selected + '?')) { fileInput.value = ''; return; }
      uploadBusy = true;
      var uploadTicketId = selected;
      var wasDisabled = textarea.disabled;
      var signature = [file.name, file.size, file.lastModified].join(':');
      var clientId = fileInput.dataset.uploadSignature === signature && fileInput.dataset.uploadClientId ? fileInput.dataset.uploadClientId : (window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : String(Date.now()) + '-' + Math.random().toString(16).slice(2));
      fileInput.dataset.uploadSignature = signature; fileInput.dataset.uploadClientId = clientId;
      textarea.disabled = true; send.disabled = true; send.style.visibility = 'visible'; send.setAttribute('aria-label','Uploading attachment'); attach.disabled = true; fileInput.disabled = true; progress.hidden = false; progressBar.style.width = '0%'; note.textContent = 'Uploading ' + file.name + '…';
      var attempts = 0;
      function transmit() {
        attempts++;
        var xhr = new XMLHttpRequest(); xhr.open('POST', ajax, true); xhr.withCredentials = true;
        xhr.upload.onprogress = function (event) { if (event.lengthComputable) { var pct = Math.max(0, Math.min(100, Math.round(event.loaded / event.total * 100))); progressBar.style.width = pct + '%'; note.textContent = 'Uploading ' + file.name + ' · ' + pct + '%'; } };
        xhr.onload = function () {
          var response = null; try { response = JSON.parse(xhr.responseText); } catch (e) {}
          if (xhr.status >= 200 && xhr.status < 300 && response && response.success) {
            var transcript = selected === uploadTicketId ? chat.querySelector('.hc-support-transcript') : null;
            if (transcript && response.data.message) { var m = response.data.message; var mid = parseInt(m.id, 10) || 0; if (mid > lastMessageId && !transcript.querySelector('[data-ticket-message-id="' + mid + '"]')) { appendBubble(transcript, m.sender_type, m.sender_name, m.content, m.created_at, m.attachment, m.avatar_url, mid); transcript.scrollTop = transcript.scrollHeight; } }
            delete fileInput.dataset.uploadSignature; delete fileInput.dataset.uploadClientId;
            note.textContent = response.data.email_mode ? (response.data.email_sent === true ? 'File saved and email already delivered.' : (response.data.email_sent === false ? 'File saved; email delivery needs attention.' : 'File saved and email queued.')) : 'File uploaded and sent. Your typed message was kept separate.';
            finish(); refreshQueue(); return;
          }
          if (attempts < 2 && xhr.status >= 500) { note.textContent = 'Server reconnecting · retrying upload…'; transmit(); return; }
          note.textContent = response && response.data && response.data.message ? response.data.message : 'Upload failed. Select the same file to retry.'; finish();
        };
        xhr.onerror = function () { if (attempts < 2) { note.textContent = 'Connection interrupted · retrying safely…'; transmit(); return; } note.textContent = 'Connection interrupted. Select the same file again to retry safely.'; finish(); };
        var data = new FormData(); data.append('action','hc_ai_escalation_upload'); data.append('nonce',nonce); data.append('ticket_id',String(uploadTicketId)); data.append('client_message_id',clientId); data.append('file',file); xhr.send(data);
      }
      function finish() { uploadBusy = false; textarea.disabled = wasDisabled; send.disabled = wasDisabled; send.style.visibility = 'visible'; send.removeAttribute('aria-label'); attach.disabled = wasDisabled; fileInput.disabled = false; fileInput.value = ''; window.setTimeout(function(){progress.hidden = true; progressBar.style.width='0%';}, 1100); renderList(); updateSelected(); }
      transmit();
    }

    function sendAdminMessage(textarea, button, note, mode) {
      var message = textarea.value.trim();
      if (!message || !selected || button.disabled || uploadBusy) return;
      var sendTicketId = selected;
      button.disabled = true; note.textContent = 'Sending…';
      if (typingTimer) { window.clearTimeout(typingTimer); typingTimer = null; }
      request('hc_ai_escalation_admin_typing', { ticket_id: selected, typing: 0 }).catch(function () {});
      var clientId = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : String(Date.now()) + '-' + Math.random().toString(16).slice(2);
      requestRetry(mode === 'note' ? 'hc_ai_escalation_admin_send_note' : 'hc_ai_escalation_admin_send', { ticket_id: sendTicketId, message: message, client_message_id: clientId }, 3).then(function (response) {
        if (!response.success) throw new Error(response.data && response.data.message || 'Reply could not be sent.');
        textarea.value = ''; try{window.localStorage.removeItem('hcSupportDraft:'+sendTicketId);}catch(e){} note.textContent = response.data.message || 'Message sent.';
        var transcript = selected === sendTicketId ? chat.querySelector('.hc-support-transcript') : null;
        if (transcript && response.data.message_data) {
          var saved = response.data.message_data;
          var savedId = parseInt(saved.id, 10) || parseInt(response.data.message_id, 10) || 0;
          if (savedId > lastMessageId && !transcript.querySelector('[data-ticket-message-id="' + savedId + '"]')) {
            appendBubble(transcript, saved.sender_type, saved.sender_name, saved.content, saved.created_at, saved.attachment, saved.avatar_url, savedId);
            // Keep the confirmed-poll cursor unchanged. The next ordered poll will
            // receive any messages that were inserted before this optimistic reply.
            transcript.scrollTop = transcript.scrollHeight;
          }
        } else if (selected === sendTicketId) { updateSelected(); }
        refreshQueue();
      }).catch(function (error) { note.textContent = error.message; }).finally(function () { button.disabled = false; textarea.focus(); });
    }

    function refreshQueue() {
      if (queueBusy) return Promise.resolve();
      queueBusy = true;
      return request('hc_ai_escalation_admin_poll', {}).then(function (response) {
        if (!response.success) throw new Error('Support queue unavailable.');
        var next = response.data.tickets || [];
        if (primed && alerts) {
          next.forEach(function (ticket) {
            var previous = known[ticket.id];
            if (!previous && ticket.status !== 'closed' && ticket.status !== 'archived' && ticket.status !== 'converted') {
              var mine = parseInt(ticket.assigned_agent_id, 10) === currentUserId;
              if (mine || ticket.status === 'queued' || ticket.status === 'pending_email' || supervisor) {
                beep('ticket-new:' + ticket.id); browserNotify(mine ? 'Ticket automatically assigned to you' : 'New human support request', ticket.visitor_name + ': ' + String(ticket.issue || '').slice(0, 100), 'ticket-new:' + ticket.id);
              }
            } else if (previous && parseInt(ticket.assigned_agent_id,10) !== parseInt(previous.assigned_agent_id,10) && parseInt(ticket.assigned_agent_id,10) === currentUserId) {
              beep('ticket-assigned:' + ticket.id + ':' + currentUserId); browserNotify('Ticket assigned to you', ticket.visitor_name + ' · Ticket #' + ticket.id, 'ticket-assigned:' + ticket.id + ':' + currentUserId);
            } else if (previous && parseInt(ticket.last_message_id, 10) > parseInt(previous.last_message_id, 10) && ticket.last_sender_type === 'visitor') {
              beep('ticket:' + ticket.last_message_id); browserNotify('New visitor message', ticket.visitor_name + ': ' + String(ticket.last_message_preview || '').slice(0, 100), 'message:' + ticket.id + ':ticket:' + ticket.last_message_id);
            }
          });
        }
        known = Object.create(null); next.forEach(function (ticket) { known[ticket.id] = ticket; });
        rows = next;
        renderStats(response.data.counts || {}); renderList(); primed = true;
        if (live) { live.innerHTML = '<i class="fas fa-circle"></i> Live · ' + new Date().toLocaleTimeString(); live.classList.add('is-live'); }
        var updated = document.getElementById('hcSupportQueueUpdated'); if (updated) updated.textContent = 'Updated ' + new Date().toLocaleTimeString();
      }).catch(function () {
        if (live) { live.textContent = 'Reconnecting…'; live.classList.remove('is-live'); }
      }).finally(function () { queueBusy = false; });
    }

    document.querySelectorAll('[data-support-filter]').forEach(function (button) {
      button.addEventListener('click', function () {
        filter = button.dataset.supportFilter;
        document.querySelectorAll('[data-support-filter]').forEach(function (item) { item.classList.toggle('is-active', item === button); });
        renderList();
      });
    });
    if (search) search.addEventListener('input', renderList);

    // Prime notification state without sounding for tickets that existed before this page opened.
    refreshQueue().then(function () { primed = true; });
    startAgentHeartbeat();
    window.setInterval(startAgentHeartbeat, 10000);
    updateClock(); clockTimer = window.setInterval(updateClock, 1000);
    configureRealtimeFallback(false);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) { refreshQueue(); updateSelected(); } });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
