(function () {
    'use strict';
    function showEditorLoadError(message) {
        document.querySelectorAll('[data-hc-block-editor]').forEach(function (wrapper) {
            var canvas = wrapper.querySelector('.hc-gutenberg-editor-canvas');
            var textarea = document.getElementById(wrapper.getAttribute('data-textarea'));
            if (canvas) canvas.innerHTML = '<div class="notice notice-error hc-block-editor-load-error"><p>' + message + '</p><p>Reload the page after updating WordPress. Your existing content remains available below.</p></div>';
            if (textarea) { textarea.style.display = 'block'; textarea.removeAttribute('aria-hidden'); }
        });
    }
    if (!window.wp || !wp.element || !wp.blocks || !wp.blockEditor || !wp.blockEditor.BlockEditorProvider) {
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { showEditorLoadError('The WordPress block editor packages did not load on this screen.'); });
        else showEditorLoadError('The WordPress block editor packages did not load on this screen.');
        return;
    }

    var el = wp.element.createElement;
    var useState = wp.element.useState;
    var blockEditor = wp.blockEditor;
    var roots = [];

    function getComponent(name) { return blockEditor[name] || null; }
    function EditorApp(props) {
        var _state = useState(props.initialBlocks), blocks = _state[0], setBlocks = _state[1];
        var settings = {
            alignments: ['wide', 'full'],
            hasFixedToolbar: false,
            focusMode: false,
            codeEditingEnabled: true,
            __experimentalFeatures: { appearanceTools: true },
            mediaUpload: function (args) {
                if (wp.media) {
                    var frame = wp.media({ title: 'Select or upload media', button: { text: 'Use this media' }, multiple: false });
                    frame.on('select', function () { var a = frame.state().get('selection').first().toJSON(); if (args && args.onFileChange) args.onFileChange({ id: a.id, url: a.url, alt: a.alt || '', title: a.title || '' }); });
                    frame.open();
                }
            }
        };
        function sync(next) {
            setBlocks(next);
            props.textarea.value = wp.blocks.serialize(next);
            props.textarea.dispatchEvent(new Event('input', { bubbles: true }));
            props.textarea.dispatchEvent(new Event('change', { bubbles: true }));
        }
        window.HCBlockEditors = window.HCBlockEditors || {};
        window.HCBlockEditors[props.type] = {
            getContent: function () { return wp.blocks.serialize(blocks); },
            setContent: function (content) { var next = wp.blocks.parse(content || ''); if (!next || !next.length) next = [wp.blocks.createBlock('core/paragraph', { placeholder: 'Start writing or type / to choose a block' })]; setBlocks(next); props.textarea.value = wp.blocks.serialize(next); }
        };
        var Inserter = getComponent('Inserter');
        var BlockList = getComponent('BlockList');
        var BlockTools = getComponent('BlockTools');
        var WritingFlow = getComponent('WritingFlow');
        var ObserveTyping = getComponent('ObserveTyping');
        var BlockToolbar = getComponent('BlockToolbar');
        var BlockInspector = getComponent('BlockInspector');
        var KeyboardShortcuts = getComponent('KeyboardShortcuts');
        var appender = getComponent('ButtonBlockAppender');
        var content = BlockList ? el(BlockList, { className: 'hc-block-list', renderAppender: appender ? function () { return el(appender, { rootClientId: undefined }); } : undefined }) : el('p', null, 'The WordPress block editor could not load its block list component. Please update WordPress and reload.');
        if (WritingFlow) content = el(WritingFlow, null, content);
        if (ObserveTyping) content = el(ObserveTyping, null, content);
        if (BlockTools) content = el(BlockTools, null, content);
        var toolbarItems = [];
        if (Inserter) toolbarItems.push(el(Inserter, { key: 'inserter', position: 'bottom right', showInserterHelpPanel: true }));
        if (BlockToolbar) toolbarItems.push(el('div', { key: 'block-toolbar', className: 'hc-block-toolbar-inner' }, el(BlockToolbar, null)));
        var sidebar = BlockInspector ? el('aside', { className: 'hc-block-inspector' }, el(BlockInspector, null)) : null;
        return el(blockEditor.BlockEditorProvider, {
            value: blocks,
            onInput: sync,
            onChange: sync,
            settings: settings
        },
            KeyboardShortcuts ? el(KeyboardShortcuts, null) : null,
            el('div', { className: 'hc-gutenberg-shell' },
                el('div', { className: 'hc-gutenberg-toolbar' }, toolbarItems),
                el('div', { className: 'hc-gutenberg-workspace' },
                    el('main', { className: 'hc-gutenberg-content' },
                        el('div', { className: 'hc-gutenberg-content-inner' }, content)
                    ),
                    sidebar
                )
            )
        );
    }

    function mount(wrapper) {
        var textarea = document.getElementById(wrapper.getAttribute('data-textarea'));
        var canvas = wrapper.querySelector('.hc-gutenberg-editor-canvas');
        if (!textarea || !canvas || canvas.dataset.mounted === '1') return;
        canvas.dataset.mounted = '1';
        try {
            if (wp.blockLibrary && wp.blockLibrary.registerCoreBlocks) wp.blockLibrary.registerCoreBlocks();
            else if (wp.blocks.registerCoreBlocks) wp.blocks.registerCoreBlocks();
            var initial = wp.blocks.parse(textarea.value || '');
            if (!initial || !initial.length) initial = [wp.blocks.createBlock('core/paragraph', { placeholder: 'Start writing or type / to choose a block' })];
            var app = el(EditorApp, { initialBlocks: initial, textarea: textarea, type: wrapper.getAttribute('data-hc-block-editor') });
            if (wp.element.createRoot) {
                var root = wp.element.createRoot(canvas); root.render(app); roots.push(root);
            } else if (wp.element.render) {
                wp.element.render(app, canvas); roots.push({ unmount: function () { wp.element.unmountComponentAtNode(canvas); } });
            }
            textarea.value = wp.blocks.serialize(initial);
            textarea.style.display = 'none';
            textarea.setAttribute('aria-hidden', 'true');
            wrapper.classList.add('hc-block-editor-ready');
        } catch (e) {
            canvas.dataset.mounted = '0';
            canvas.innerHTML = '<div class="notice notice-error"><p>The WordPress block editor failed to initialize. Your content is still available in the source field below.</p></div>';
            textarea.style.display = 'block';
        }
    }

    function boot() {
        document.querySelectorAll('[data-hc-block-editor]').forEach(mount);
        document.querySelectorAll('.hc-edit-form, #hcFaqForm').forEach(function (form) {
            form.addEventListener('submit', function () {
                document.querySelectorAll('[data-hc-block-editor]').forEach(function (wrapper) {
                    var textarea = document.getElementById(wrapper.getAttribute('data-textarea'));
                    var canvas = wrapper.querySelector('.hc-gutenberg-editor-canvas');
                    if (textarea && canvas && canvas.dataset.mounted === '1') textarea.value = textarea.value || '';
                });
            }, true);
        });
    }
    if (wp.domReady) wp.domReady(boot); else document.addEventListener('DOMContentLoaded', boot);
})();
