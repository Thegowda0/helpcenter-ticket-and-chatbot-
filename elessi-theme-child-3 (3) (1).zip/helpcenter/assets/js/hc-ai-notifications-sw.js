/* HelpCenter customer notification worker.
 * Displays notifications requested by the open HelpCenter page on mobile browsers.
 * The push event handler is ready for a server-side Web Push publisher; this file
 * does not itself create subscriptions or send push messages.
 */
self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  var target = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (clients) {
      for (var i = 0; i < clients.length; i++) {
        var client = clients[i];
        if ('focus' in client) {
          return client.focus().then(function (focused) {
            if (focused && 'navigate' in focused && target) {
              try { return focused.navigate(target); } catch (e) { return focused; }
            }
            return focused;
          });
        }
      }
      return self.clients.openWindow(target);
    })
  );
});

self.addEventListener('push', function (event) {
  var payload = {
    title: 'Help Center support reply',
    body: 'You have a new reply from your support team.',
    url: '/',
    tag: 'hc-support-reply'
  };
  try {
    if (event.data) payload = Object.assign(payload, event.data.json());
  } catch (e) {
    try { if (event.data) payload.body = event.data.text(); } catch (ignored) {}
  }
  event.waitUntil(self.registration.showNotification(payload.title, {
    body: payload.body,
    icon: payload.icon || undefined,
    badge: payload.badge || undefined,
    tag: payload.tag,
    renotify: false,
    data: { url: payload.url || '/', ticket_id: payload.ticket_id || 0 }
  }));
});
