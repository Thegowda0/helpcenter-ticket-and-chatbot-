(function () {
  'use strict';
  function boot() {
    var root = document.getElementById('hc-ai-conversations-card');
    if (!root || root.dataset.liveBooted === '1') return;
    root.dataset.liveBooted = '1';
    var ajax = root.dataset.ajaxUrl || window.ajaxurl || '';
    var nonce = root.dataset.nonce || '';
    if (!ajax || !nonce) return;
    var detail = root.querySelector('.hc-ai-conversation-detail[data-hc-ai-conversation-id]');
    var conversationId = detail ? parseInt(detail.dataset.hcAiConversationId || '0', 10) : 0;
    var cursor = 0;
    var ticketCursor = 0;
    var busy = false;
    var listBusy = false;
    var lastListSignature = '';
    var body = root.querySelector('.hc-admin-card-body');
    var lightbox = document.createElement('div'); lightbox.className='hc-ai-history-lightbox'; lightbox.hidden=true; lightbox.setAttribute('role','dialog'); lightbox.setAttribute('aria-modal','true'); lightbox.setAttribute('aria-label','Image preview');
    lightbox.innerHTML='<div class="hc-lightbox-bg" data-lightbox-close></div><div class="hc-lightbox-panel"><div class="hc-lightbox-head"><strong class="hc-lightbox-title">Image preview</strong><button type="button" data-lightbox-close aria-label="Close preview"><i class="fas fa-times"></i> Close</button></div><div class="hc-lightbox-stage"><img alt="Attachment preview"></div><div class="hc-lightbox-actions"><a class="hc-lightbox-download" href="#" download><i class="fas fa-download"></i> Download</a><button type="button" data-lightbox-close><i class="fas fa-times"></i> Cancel</button></div></div>';
    document.body.appendChild(lightbox);
    function closeLightbox(){lightbox.hidden=true;lightbox.querySelector('img').removeAttribute('src');document.body.classList.remove('hc-preview-open');}
    lightbox.addEventListener('click',function(e){if(e.target.closest('[data-lightbox-close]'))closeLightbox();});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!lightbox.hidden)closeLightbox();});
    function openLightbox(url,name){var img=lightbox.querySelector('img');img.src=url;img.alt=name||'Attachment preview';lightbox.querySelector('.hc-lightbox-title').textContent=name||'Attachment preview';var dl=lightbox.querySelector('.hc-lightbox-download');dl.href=url+(url.indexOf('?')>=0?'&':'?')+'download=1';dl.setAttribute('download',name||'attachment');lightbox.hidden=false;document.body.classList.add('hc-preview-open');}

    function request(action, extra) {
      var form = new FormData();
      form.append('action', action);
      form.append('nonce', nonce);
      Object.keys(extra || {}).forEach(function (key) { form.append(key, extra[key] == null ? '' : extra[key]); });
      var controller = window.AbortController ? new AbortController() : null;
      var timeoutMs = /summary/.test(action) ? 90000 : /send|reply/.test(action) ? 60000 : 45000;
      var timedOut = false;
      var timeout = controller ? window.setTimeout(function () { timedOut = true; controller.abort(); }, timeoutMs) : null;
      return fetch(ajax, { method: 'POST', body: form, credentials: 'same-origin', cache: 'no-store', signal: controller ? controller.signal : undefined }).then(function (r) {
        if (!r.ok) throw new Error('Conversation history is temporarily unavailable.');
        return r.json();
      }).catch(function (error) { if (error && error.name === 'AbortError' && timedOut) throw new Error('The server took too long to respond. Please check the conversation before retrying.'); throw error; }).finally(function () { if (timeout) window.clearTimeout(timeout); });
    }
    function el(tag, cls, value) {
      var n = document.createElement(tag);
      if (cls) n.className = cls;
      if (value !== undefined && value !== null) n.textContent = String(value);
      return n;
    }
    function formatBytes(bytes){var n=Number(bytes)||0;if(n<=0)return '';var u=['B','KB','MB','GB'],i=Math.min(3,Math.floor(Math.log(n)/Math.log(1024)));return (n/Math.pow(1024,i)).toFixed(i?1:0)+' '+u[i];}
    function niceDate(value) {
      if (!value) return '';
      var date = new Date(String(value).replace(' ', 'T'));
      return isNaN(date.getTime()) ? String(value) : date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    }
    function escapeHtml(value){return String(value==null?'':value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#39;')}
    function inlineMarkdown(value){var x=escapeHtml(value);x=x.replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/__([^_]+)__/g,'<strong>$1</strong>').replace(/(^|[^*])\*([^*]+)\*/g,'$1<em>$2</em>');x=x.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/gi,function(_,label,url){try{var u=new URL(url,window.location.href);if(u.protocol!=='https:'&&u.protocol!=='http:')return label;return '<a href=\"'+u.href.replace(/\"/g,'%22')+'\" target=\"_blank\" rel=\"noopener noreferrer\">'+label+'</a>'}catch(e){return label}});return x}
    function renderMarkdown(node,source){var lines=String(source||'').replace(/\r/g,'').split('\n'),html='',para=[],list='',code=false,codeLines=[];function fp(){if(para.length){html+='<p>'+para.map(inlineMarkdown).join('<br>')+'</p>';para=[]}}function fl(){if(list){html+='</'+list+'>';list=''}}lines.forEach(function(line){if(/^\s*```/.test(line)){fp();fl();if(!code){code=true;codeLines=[]}else{html+='<pre><code>'+escapeHtml(codeLines.join('\n'))+'</code></pre>';code=false}return}if(code){codeLines.push(line);return}if(!line.trim()){fp();fl();return}var h=line.match(/^\s*(#{1,4})\s+(.+)$/);if(h){fp();fl();var n=h[1].length;html+='<h'+n+'>'+inlineMarkdown(h[2])+'</h'+n+'>';return}var li=line.match(/^\s*[-*+]\s+(.+)$/),oi=line.match(/^\s*\d+[.)]\s+(.+)$/);if(li||oi){fp();var t=li?'ul':'ol';if(list!==t){fl();list=t;html+='<'+list+'>'}html+='<li>'+inlineMarkdown((li||oi)[1])+'</li>';return}fl();para.push(line)});if(code)html+='<pre><code>'+escapeHtml(codeLines.join('\n'))+'</code></pre>';fp();fl();node.innerHTML=html||'<p></p>'}
    function addExpandControl(article, textNode) {
      window.requestAnimationFrame(function () {
        if (!textNode || textNode.scrollHeight <= 250 || article.querySelector('.hc-ai-message-expand')) return;
        textNode.classList.add('is-collapsed');
        var button = el('button','hc-ai-message-expand','Show full reply');
        button.type = 'button'; button.setAttribute('aria-expanded','false');
        button.addEventListener('click',function(){
          var expanded = textNode.classList.toggle('is-collapsed');
          button.textContent = expanded ? 'Show full reply' : 'Show less';
          button.setAttribute('aria-expanded',expanded?'false':'true');
        });
        article.appendChild(button);
      });
    }
    function enhanceExistingMessages(){
      detail.querySelectorAll('.hc-ai-admin-message').forEach(function(article){
        article.querySelectorAll('img.hc-ai-admin-attachment-preview').forEach(function(img){if(img.dataset.lightboxReady==='1')return;img.dataset.lightboxReady='1';img.style.cursor='zoom-in';img.addEventListener('click',function(){openLightbox(img.currentSrc||img.src,img.alt||'Attachment');});});
        var textNode=article.querySelector('.hc-ai-admin-message-text');
        if(textNode)addExpandControl(article,textNode);
        var label=article.querySelector('.hc-ai-admin-message-label');
        if(label && article.classList.contains('is-assistant') && !label.querySelector('.hc-ai-role-icon')){
          var icon=el('i','fas fa-robot hc-ai-role-icon');label.insertBefore(icon,label.firstChild);
        }
      });
    }
    function addSources(host, raw) {
      if (!raw) return;
      var sources;
      try { sources = JSON.parse(raw); } catch (e) { return; }
      if (!Array.isArray(sources) || !sources.length) return;
      var wrap = el('div', 'hc-ai-admin-message-sources');
      wrap.appendChild(el('strong', '', 'Sources used'));
      sources.forEach(function (source) {
        var url = source && source.url ? String(source.url) : '';
        try {
          var parsed = new URL(url, window.location.href);
          if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return;
          var a = el('a', '', source.title || 'Help article');
          a.href = parsed.href; a.target = '_blank'; a.rel = 'noopener noreferrer';
          if (source.score !== undefined && !isNaN(Number(source.score))) a.appendChild(document.createTextNode(' · score ' + Number(source.score).toFixed(3)));
          wrap.appendChild(a);
        } catch (e) { /* Ignore malformed source destinations. */ }
      });
      if (wrap.children.length > 1) host.appendChild(wrap);
    }
    function appendMessage(message) {
      var role = String(message.role || 'assistant');
      var isVisitor = role === 'user' || role === 'visitor';
      var isAgent = role === 'agent';
      var isSystem = role === 'system';
      var cssRole = isVisitor ? 'user' : isAgent ? 'agent' : isSystem ? 'system' : 'assistant';
      var article = el('article', 'hc-ai-admin-message is-' + cssRole);
      var sourceType = message.source_type || 'ai';
      var sourceId = parseInt(message.source_id || message.id, 10) || 0;
      article.dataset.hcMessageId = sourceType + ':' + sourceId;
      var labelText = isVisitor ? 'Visitor' : isAgent ? (message.sender_name || 'Human Agent') : isSystem ? 'Support update' : 'AI Assistant';
      var label = el('div', 'hc-ai-admin-message-label');
      if (!isVisitor && !isAgent && !isSystem) label.appendChild(el('i','fas fa-robot hc-ai-role-icon'));
      label.appendChild(document.createTextNode(labelText));
      label.appendChild(el('time', '', niceDate(message.created_at)));
      article.appendChild(label);
      var textNode=el('div','hc-ai-admin-message-text');renderMarkdown(textNode,message.content||'');article.appendChild(textNode);addExpandControl(article,textNode);
      if (message.attachment && message.attachment.url) {
        var attachment = message.attachment, preview = null;
        if (attachment.kind === 'image' || String(attachment.mime || '').indexOf('image/') === 0) { var trigger=el('button','hc-ai-admin-attachment-open hc-ai-image-only'); trigger.type='button';trigger.setAttribute('aria-label','Open image attachment');trigger.title=attachment.name||'Image attachment';trigger.addEventListener('click',function(){openLightbox(attachment.url,attachment.name||'Attachment');});preview = el('img','hc-ai-admin-attachment-preview'); preview.src=attachment.url; preview.alt=attachment.name||'Attachment preview'; preview.loading='lazy';preview.addEventListener('load',function(){var dims=preview.naturalWidth&&preview.naturalHeight?' · '+preview.naturalWidth+' × '+preview.naturalHeight+' px':'';}); trigger.appendChild(preview);article.appendChild(trigger); }
        else if (attachment.kind === 'video' || String(attachment.mime || '').indexOf('video/') === 0) { preview = el('video','hc-ai-admin-attachment-preview'); preview.src=attachment.url; preview.controls=true; preview.preload='metadata'; }
        else if (attachment.mime === 'application/pdf' || attachment.mime === 'text/plain' || attachment.mime === 'text/csv') { preview = el('iframe','hc-ai-admin-attachment-preview'); preview.src=attachment.url; preview.title=attachment.name||'Attachment preview'; preview.loading='lazy'; preview.setAttribute('sandbox',''); }
        if (preview && !(attachment.kind === 'image' || String(attachment.mime || '').indexOf('image/') === 0)) article.appendChild(preview); else if (!preview) article.appendChild(el('small','hc-ai-admin-attachment-unavailable',(attachment.name||'Attachment')+' · Preview unavailable'));
      }
      addSources(article, message.sources);
      detail.appendChild(article);
      if (sourceType === 'ticket') ticketCursor = Math.max(ticketCursor, sourceId);
      else cursor = Math.max(cursor, sourceId);
    }
    if (detail && conversationId) {
      detail.querySelectorAll('[data-hc-message-id]').forEach(function (message) { cursor = Math.max(cursor, parseInt(message.dataset.hcMessageId || '0', 10) || 0); });
      enhanceExistingMessages();
      function jumpToLatest(){detail.scrollTop=detail.scrollHeight;var last=detail.lastElementChild;if(last&&last.scrollIntoView)last.scrollIntoView({block:'end',behavior:'auto'});detail.scrollTop=detail.scrollHeight;}
      window.requestAnimationFrame(function(){jumpToLatest();window.setTimeout(jumpToLatest,100);window.setTimeout(jumpToLatest,300);window.setTimeout(jumpToLatest,650);});
      var detailWasNearBottom=true;detail.addEventListener('scroll',function(){detailWasNearBottom=detail.scrollHeight-detail.scrollTop-detail.clientHeight<140;},{passive:true});if(window.MutationObserver){var detailObserver=new MutationObserver(function(){if(detailWasNearBottom)requestAnimationFrame(function(){detail.scrollTop=detail.scrollHeight;});});detailObserver.observe(detail,{childList:true,subtree:true});}detail.addEventListener('load',function(e){if(e.target&&e.target.tagName==='IMG'&&detailWasNearBottom)detail.scrollTop=detail.scrollHeight;},true);
      function pollDetail() {
        if (busy || document.hidden) return;
        busy = true;
        var nearBottom = detail.scrollHeight - detail.scrollTop - detail.clientHeight < 140;
        request('hc_ai_conversation_messages_live', { conversation_id: conversationId, after_id: cursor, ticket_after_id: ticketCursor }).then(function (response) {
          if (!response.success) return;
          (response.data.messages || []).forEach(appendMessage);
          if ((response.data.messages || []).length && nearBottom) detail.scrollTop = detail.scrollHeight;
          var existing = Number(response.data.total_messages);
          if (!Number.isFinite(existing)) existing = detail.querySelectorAll('[data-hc-message-id]').length;
          var countNode = root.querySelector('[data-live-message-count]');
          if (countNode) countNode.textContent = existing + ' messages';
        }).catch(function () { /* Keep the existing transcript visible while reconnecting. */ }).finally(function () { busy = false; });
      }
      pollDetail();
      window.setInterval(pollDetail, 2500);
      document.addEventListener('visibilitychange', function () { if (!document.hidden) pollDetail(); });
    } else {
      var search = root.querySelector('#hcAiConversationSearch');
      var sort = root.querySelector('#hcAiConversationSort');
      var size = root.querySelector('#hcAiConversationPageSize');
      var count = root.querySelector('#hcAiHistoryResultCount');
      var pager = root.querySelector('#hcAiHistoryPagination');
      var page = 1, perPage = 10, q = '', sortBy = 'updated', sortDir = 'DESC', searchTimer = null;
      function renderList(items, meta) {
        var grid = root.querySelector('.hc-ai-conversation-grid');
        if (!grid) { grid = el('div', 'hc-ai-conversation-grid'); var controls=root.querySelector('#hcAiHistoryControls'); if(controls)controls.insertAdjacentElement('afterend',grid); else if(body)body.appendChild(grid); }
        grid.textContent = '';
        items.forEach(function (item) {
          var a = el('a', 'hc-ai-conversation-card'); a.href = item.url;
          var top = el('div', 'hc-ai-conversation-card-top'); var avatar = el('span', 'hc-ai-conversation-avatar'); avatar.appendChild(el('i', 'fas ' + (item.is_user ? 'fa-user-check' : 'fa-user')));
          top.append(avatar, el('span', 'hc-ai-conversation-person', item.visitor || 'Visitor'), el('time', '', niceDate(item.updated_at)));
          a.append(top, el('strong', '', item.title || 'New conversation'), el('small', '', (parseInt(item.message_count, 10) || 0) + ' messages · Started ' + niceDate(item.created_at)));
          if (Array.isArray(item.ticket_ids) && item.ticket_ids.length) { var tickets=el('span','hc-ai-ticket-id-list'); tickets.appendChild(el('i','fas fa-ticket-alt')); tickets.appendChild(document.createTextNode(' '+item.ticket_ids.map(function(id){return '#'+id;}).join(' · '))); a.appendChild(tickets); }
          a.appendChild(el('span', 'hc-ai-open-label', 'Open conversation →'));
          grid.appendChild(a);
        });
        var total=Number(meta.total)||0,pages=Number(meta.pages)||0;
        if(count)count.textContent=total+' conversations · Page '+(meta.page||1)+' of '+Math.max(1,pages);
        if(pager){pager.textContent='';var prev=el('button','hc-admin-btn hc-admin-btn-small','Previous');prev.type='button';prev.disabled=page<=1;prev.addEventListener('click',function(){page=Math.max(1,page-1);pollList()});var next=el('button','hc-admin-btn hc-admin-btn-small','Next');next.type='button';next.disabled=page>=pages;next.addEventListener('click',function(){page=Math.min(pages,page+1);pollList()});pager.append(prev,el('span','', 'Page '+page),next)}
        if(!items.length){grid.appendChild(el('p','hc-muted','No conversations match this search.'))}
      }
      function pollList() {
        if (listBusy || document.hidden) return;
        listBusy = true;
        request('hc_ai_conversations_live', {q:q,page:page,per_page:perPage,sort_by:sortBy,sort_dir:sortDir}).then(function (response) {
          if (response.success) renderList(response.data.items || [], response.data);
        }).catch(function (error) { if(count)count.textContent=error.message||'Conversation history could not be loaded.'; }).finally(function () { listBusy = false; });
      }
      if(search)search.addEventListener('input',function(){q=search.value.trim();page=1;if(searchTimer)clearTimeout(searchTimer);searchTimer=setTimeout(pollList,250)});
      if(sort)sort.addEventListener('change',function(){var parts=sort.value.split(':');sortBy=parts[0]||'updated';sortDir=parts[1]||'DESC';page=1;pollList()});
      if(size)size.addEventListener('change',function(){perPage=Math.max(1,Math.min(50,parseInt(size.value,10)||10));page=1;pollList()});
      pollList();
      window.setInterval(pollList, 15000);
      document.addEventListener('visibilitychange', function () { if (!document.hidden) pollList(); });
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
