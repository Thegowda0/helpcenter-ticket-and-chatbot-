(function(){
'use strict';
var c=window.HCWebPushConfig;
if(!c||!c.enabled||!('serviceWorker'in navigator)||!('PushManager'in window))return;
function b64(s){var p='='.repeat((4-s.length%4)%4);var raw=atob((s+p).replace(/-/g,'+').replace(/_/g,'/'));var out=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}
function visitor(){try{return localStorage.getItem(c.visitorKey||'hc_ai_visitor_v49')||''}catch(e){return ''}}
function request(data){var body=new URLSearchParams();Object.keys(data).forEach(function(k){body.set(k,typeof data[k]==='string'?data[k]:JSON.stringify(data[k]))});body.set('nonce',c.nonce);return fetch(c.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()}).then(function(r){return r.json()}).then(function(r){if(!r||!r.success)throw new Error(r&&r.data&&r.data.message||'Push request failed');return r.data})}
function save(sub){var a=c.agent?'agent':'customer',ticket='0';try{ticket=localStorage.getItem(c.ticketKey||'hc_ai_sessions_v49_active_support_ticket')||'0'}catch(e){}return request({action:'hc_web_push_subscribe',audience:a,visitor_id:visitor(),ticket_id:ticket,subscription:sub.toJSON()}).then(function(r){try{if(a==='agent')localStorage.setItem('hc_web_push_agent_'+String(c.userId),'1');else localStorage.setItem('hc_web_push_ticket_'+String(ticket),'1')}catch(e){}window.dispatchEvent(new CustomEvent('hc-web-push-enabled'));return r;});}
function enable(){return navigator.serviceWorker.register(c.serviceWorker,{scope:'/'}).then(function(reg){return reg.pushManager.getSubscription().then(function(sub){if(sub)return save(sub);return reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64(c.publicKey)}).then(save);});}).then(function(result){heartbeat();return result;});}
function permission(){return ('Notification'in window)?Notification.permission:'unsupported';}
function state(){var p=permission();return {permission:p,subscribed:isEnabled(),blocked:p==='denied',supported:p!=='unsupported'&&('serviceWorker'in navigator)&&('PushManager'in window)};}
function emitState(){window.dispatchEvent(new CustomEvent('hc-web-push-state',{detail:state()}));}
function enableFromGesture(){
 if(c.browserEnabled===false)return Promise.resolve({status:'disabled'});
 var p=permission();
 if(p==='unsupported')return Promise.resolve({status:'unsupported'});
 if(p==='denied')return Promise.resolve({status:'blocked'});
 var ask=p==='default'?Notification.requestPermission():Promise.resolve(p);
 return ask.then(function(granted){if(granted!=='granted'){emitState();return {status:granted==='denied'?'blocked':'not-granted'};}return enable().then(function(){emitState();return {status:'active'};});}).catch(function(error){emitState();return {status:'error',error:error};});
}
function isEnabled(){try{if(c.agent)return localStorage.getItem('hc_web_push_agent_'+String(c.userId))==='1';var id=localStorage.getItem(c.ticketKey||'hc_ai_sessions_v49_active_support_ticket')||'0';return localStorage.getItem('hc_web_push_ticket_'+String(id))==='1'}catch(e){return false}}
window.HCWebPush={enable:enable,enableFromGesture:enableFromGesture,isEnabled:isEnabled,permission:permission,state:state,disable:function(){return navigator.serviceWorker.getRegistration('/').then(function(reg){if(!reg)return;return reg.pushManager.getSubscription().then(function(sub){if(!sub)return;return request({action:'hc_web_push_unsubscribe',endpoint:sub.endpoint}).then(function(){return sub.unsubscribe()})})})},isSupported:true,hasPermission:function(){return permission()==='granted'}};
function tabId(){try{var id=sessionStorage.getItem('hc_web_push_tab_id');if(!id){id=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():('tab-'+Date.now()+'-'+Math.random().toString(16).slice(2));sessionStorage.setItem('hc_web_push_tab_id',id)}return id}catch(e){return 'tab-'+Date.now()}}
function activeTicket(){try{if(c.agent&&typeof window.HCAgentPushGetActiveTicket==='function')return Number(window.HCAgentPushGetActiveTicket())||0;if(!c.agent&&typeof window.HCCustomerPushGetActiveTicket==='function')return Number(window.HCCustomerPushGetActiveTicket())||0}catch(e){}return 0}
function sendPresence(sub,forceHidden){if(!sub||!sub.endpoint)return Promise.resolve();var visible=!forceHidden&&!document.hidden&&document.hasFocus(),ticket=visible?activeTicket():0;return request({action:'hc_web_push_presence',endpoint:sub.endpoint,client_id:tabId(),active_ticket_id:String(ticket),is_visible:visible?'1':'0',visitor_id:visitor()}).catch(function(error){if(error&&error.message&&!/no saved HelpCenter push subscription/i.test(error.message))console.debug('[HC Web Push] Presence update unavailable:',error.message)});}
function updatePresence(forceHidden){return navigator.serviceWorker.getRegistration('/').then(function(reg){if(!reg)return null;return reg.pushManager.getSubscription()}).then(function(sub){if(sub)return sendPresence(sub,!!forceHidden);}).catch(function(){});}
function heartbeat(){updatePresence(false)}
window.HCWebPush.updatePresence=heartbeat;

function setButtonLabel(btn,label){if(!btn)return;var node=Array.prototype.find.call(btn.childNodes,function(n){return n.nodeType===3;});if(node)node.textContent=' '+label;else btn.appendChild(document.createTextNode(label));}
function buttonMessage(btn,result){
 if(!btn)return;
 if(result.status==='blocked'){setButtonLabel(btn,'Retry after allowing');btn.title='Open the site settings from the browser address bar, set Notifications to Allow, then click here again.';}
 else if(result.status==='active'){setButtonLabel(btn,'Push notifications enabled');btn.title='This browser is subscribed to HelpCenter push notifications.';}
 else if(result.status==='unsupported'){setButtonLabel(btn,'Notifications not supported');}
 else if(result.status==='disabled'){setButtonLabel(btn,'Notifications disabled by admin');}
 else if(result.status==='error'){setButtonLabel(btn,'Retry notification setup');btn.title=(result.error&&result.error.message)||'Push setup failed';console.warn('[HC Web Push]',result.error);}
 else {setButtonLabel(btn,'Enable notifications');}
}
// A denied permission cannot be prompted again by page JavaScript. The user must
// change this site's permission in browser settings, then retry from a user click.
document.addEventListener('click',function(e){var btn=e.target.closest('[data-hc-enable-push]');if(!btn)return;e.preventDefault();var original=btn.textContent;btn.disabled=true;enableFromGesture().then(function(result){buttonMessage(btn,result);window.dispatchEvent(new CustomEvent('hc-web-push-enable-result',{detail:result}));}).finally(function(){btn.disabled=false;if(!btn.isConnected)return;if(permission()==='granted'&&isEnabled())buttonMessage(btn,{status:'active'});else if(permission()==='denied')buttonMessage(btn,{status:'blocked'});else if(btn.textContent===original)btn.textContent='Enable notifications';});});
// Permission can be changed in browser settings while this tab is open. Refresh
// the UI on return/focus; the user then clicks Retry to create the subscription.
['focus','pageshow'].forEach(function(name){window.addEventListener(name,function(){emitState();heartbeat();});});window.addEventListener('blur',function(){updatePresence(true)});window.addEventListener('pagehide',function(){updatePresence(true)});document.addEventListener('visibilitychange',function(){if(!document.hidden){emitState();heartbeat();}else updatePresence(true);});window.setInterval(heartbeat,15000);
window.addEventListener('hc-web-push-state',function(e){var d=e.detail||{};document.querySelectorAll('[data-hc-enable-push]').forEach(function(btn){if(d.permission==='denied')buttonMessage(btn,{status:'blocked'});else if(d.permission==='granted'&&d.subscribed)buttonMessage(btn,{status:'active'});else if(d.permission==='granted')setButtonLabel(btn,'Finish enabling notifications');else if(d.permission==='default')setButtonLabel(btn,'Enable notifications');});});
if(navigator.permissions&&navigator.permissions.query){navigator.permissions.query({name:'notifications'}).then(function(status){status.addEventListener('change',emitState);}).catch(function(){});}
emitState();heartbeat();
})();
