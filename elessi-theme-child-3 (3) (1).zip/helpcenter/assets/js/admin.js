/**
 * Help Center Admin - JS (Clean Rebuild)
 */
var data = window.hcAdmin || {};

        function bootAdmin() {
        initSidebar();
        initRevisionRestore();
        initRevisionDiff();
        initArticleForm();
        initFaqForm();
        initCategoryForm();
        initDeletes();
        initTrashActions();
        initBulkActions();
        initSearch();
        initSorting();
        initSettingsForm();
    var rtTest = document.getElementById('hcRealtimeTest');
    if (rtTest && rtTest.dataset.hcBound !== '1') {
        rtTest.dataset.hcBound = '1';
        rtTest.addEventListener('click', function () {
            var result = document.getElementById('hcRealtimeTestResult');
            rtTest.disabled = true; if (result) result.textContent = 'Testing…';
            var fd = new FormData(); fd.append('action','hc_realtime_test'); fd.append('nonce',data.nonce || '');
            fetch(data.ajaxUrl || '/wp-admin/admin-ajax.php',{method:'POST',credentials:'same-origin',body:fd,cache:'no-store'}).then(function(response){return response.text().then(function(raw){var json=null;try{json=JSON.parse(raw);}catch(parseError){var excerpt=String(raw||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,180);var message='WordPress returned an HTML/server error (HTTP '+response.status+').';if(response.status===502)message='Your hosting server returned HTTP 502 while contacting Ably. Check the hosting PHP error log and outbound HTTPS access.';else if(excerpt)message+=' '+excerpt;throw new Error(message);}if(!response.ok&&!json.success)throw new Error((json.data&&json.data.message)||('Request failed (HTTP '+response.status+').'));return json;});}).then(function(r){if(!r.success)throw new Error(r.data&&r.data.message||'Ably test failed');if(result)result.textContent=r.data.message||'Ably connected.';}).catch(function(e){if(result)result.textContent=e.message||'Ably test failed.';}).finally(function(){rtTest.disabled=false;});
        });
    }

    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootAdmin);
    } else {
        bootAdmin(); // DOM is already ready!
    }


    // SETTINGS FORM — persist settings over authenticated AJAX.
    function initSettingsForm() {
        var form = document.getElementById('hcSettingsForm');
        if (!form || form.dataset.hcBound === '1') return;
        form.dataset.hcBound = '1';
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var btn = document.getElementById('hcSettingsSaveBtn');
            var original = btn ? btn.innerHTML : '';
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving…'; }
            var fd = new FormData(form);
            fd.append('action', 'hc_save_settings'); fd.append('nonce', data.nonce || '');
            function submitSettings(retried) {
                return fetch(data.ajaxUrl || '/wp-admin/admin-ajax.php', {method:'POST', credentials:'same-origin', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(r){
                        var msg = (r.data && r.data.message) || '';
                        if (!r.success && !retried && /nonce failed|invalid nonce|security check/i.test(msg)) {
                            var nf = new FormData(); nf.append('action','hc_refresh_nonce');
                            return fetch(data.ajaxUrl || '/wp-admin/admin-ajax.php',{method:'POST',credentials:'same-origin',body:nf}).then(function(x){return x.json();}).then(function(n){
                                if (!n.success || !n.data || !n.data.nonce) throw new Error((n.data && n.data.message) || 'Could not refresh security token. Reload the page.');
                                data.nonce = n.data.nonce; fd.set('nonce', data.nonce); return submitSettings(true);
                            });
                        }
                        if (!r.success) throw new Error(msg || 'Settings could not be saved.');
                        showSettingsNotice(msg || 'Settings saved successfully.', false);
                    });
            }
            submitSettings(false)
                .catch(function(err){showSettingsNotice(err.message || 'Settings could not be saved.', true);})
                .finally(function(){if(btn){btn.disabled=false;btn.innerHTML=original;}});
        });
    }
    function showSettingsNotice(message, error) {
        var old = document.getElementById('hcSettingsSaveNotice'); if(old) old.remove();
        var n = document.createElement('div'); n.id='hcSettingsSaveNotice'; n.className='hc-admin-notice '+(error?'hc-notice-error':'hc-notice-success'); n.textContent=message;
        var form=document.getElementById('hcSettingsForm'); if(form) form.insertBefore(n, form.firstChild);
    }

    // =============================================
    // SIDEBAR
    // =============================================
    function initSidebar() {
        var toggle = document.getElementById('hcAdminMenuToggle');
        var close = document.getElementById('hcAdminSidebarClose');
        var sidebar = document.getElementById('hcAdminSidebar');
        var overlay = document.getElementById('hcAdminOverlay');
        if (!sidebar) return;
        if (toggle) toggle.addEventListener('click', function() { sidebar.classList.toggle('open'); });
        if (close) close.addEventListener('click', function() { sidebar.classList.remove('open'); });
        if (overlay) overlay.addEventListener('click', function() { sidebar.classList.remove('open'); });
    }

    // =============================================
    // ARTICLE FORM (MULTI-CATEGORY SAVE)
    // =============================================
    function initArticleForm() {
        // Wait for the form to exist
        var form = document.getElementById('hcArticleForm');
        if (!form) {
            setTimeout(initArticleForm, 200);
            return;
        }

        // Auto-slug
        var titleInput = document.getElementById('hcTitle');
        var slugInput = document.getElementById('hcSlug');
        var slugEdited = slugInput && slugInput.value !== '';
        if (slugInput) slugInput.addEventListener('input', function() { slugEdited = true; });
        if (titleInput && slugInput) {
            titleInput.addEventListener('input', function() {
                if (!slugEdited) slugInput.value = slugify(this.value);
            });
        }

        initAutosave(form, 'article');
        initQuickCategoryAdd();
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var id = form.getAttribute('data-id') || 0;
            var btn = document.getElementById('hcArticleSaveBtn');
            var orig = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            btn.disabled = true;

            var fd = new FormData(form);
            
            // Gather all checked categories
            var selectedCats = [];
            document.querySelectorAll('input[name="category_ids[]"]:checked').forEach(function(cb) {
                selectedCats.push(cb.value);
            });
            fd.delete('category_ids[]');
            fd.set('category_ids_string', selectedCats.join(','));

            fd.append('action', 'hc_save_article');
            fd.append('nonce', data.nonce);
            fd.append('id', id);

            if (typeof tinymce !== 'undefined' && tinymce.get('hcContent')) {
                fd.set('content', tinymce.get('hcContent').getContent());
            }

            ajax(fd).then(function(res) {
                if (res.success) {
                    form.dataset.hcManualSave = '1'; try{localStorage.removeItem('hc_editor_backup_article_'+(form.getAttribute('data-id')||'new_'+location.pathname));}catch(e){}
                    toast('Article saved', 'success');
                    setTimeout(function() {
                        window.location.href = data.homeUrl + 'articles/';
                    }, 600);
                } else {
                    toast((res.data && res.data.message) ? res.data.message : 'Error', 'error');
                    btn.innerHTML = orig;
                    btn.disabled = false;
                }
            }).catch(function() {
                toast('Network error', 'error');
                btn.innerHTML = orig;
                btn.disabled = false;
            });
        });
    }

    function initRevisionRestore() {
        var preview = document.getElementById('hcRestorePreview');
        var confirmBtn = document.getElementById('hcConfirmRestore');
        document.querySelectorAll('.hc-restore-revision').forEach(function(btn){
            btn.addEventListener('click', function(){
                if (!preview) return;
                preview.hidden = false;
                document.body.style.overflow = 'hidden';
            });
        });
        if (preview) {
            preview.querySelectorAll('[data-hc-restore-cancel]').forEach(function(btn){
                btn.addEventListener('click', function(){ preview.hidden = true; document.body.style.overflow = ''; });
            });
        }
        if (confirmBtn) confirmBtn.addEventListener('click', function(){
            if (!window.confirm('Confirm restore? This will replace the current saved content with the version shown in the preview.')) return;
            confirmBtn.disabled = true;
            var fd = new FormData(); fd.append('action','hc_restore_revision'); fd.append('nonce',data.nonce||''); fd.append('revision_id',confirmBtn.dataset.revisionId||'0');
            ajax(fd).then(function(res){
                if(!res.success) throw new Error((res.data&&res.data.message)||'Could not restore revision');
                toast(res.data.message||'Revision restored','success');
                var target=confirmBtn.getAttribute('data-editor-url');
                if(target){ target += (target.indexOf('?')===-1?'?':'&')+'hc_revision_restored=1'; window.location.href=target; }
                else if(res.data&&res.data.type&&res.data.id){ window.location.href=(data.homeUrl||'/helpcenter/admin/').replace(/\/$/,'/')+(res.data.type==='article'?'articles/edit/':'faqs/edit/')+res.data.id+'/?hc_revision_restored=1'; }
                else { window.location.reload(); }
            }).catch(function(err){toast(err.message||'Could not restore revision','error');confirmBtn.disabled=false;});
        });
    }

    function initRevisionDiff() {
        function append(el, text, cls) {
            if (!text) return;
            if (!cls) { el.appendChild(document.createTextNode(text)); return; }
            var mark = document.createElement(cls === 'del' ? 'del' : 'ins');
            mark.className = cls === 'del' ? 'hc-revision-removed' : 'hc-revision-added';
            mark.textContent = text; el.appendChild(mark);
        }
        function renderDiff(oldEl, newEl) {
            var aText = oldEl.textContent || '', bText = newEl.textContent || '';
            if (aText === bText) return; // no false highlighting for unchanged fields
            var a = aText.match(/\s+|[\w]+|[^\w\s]/g) || [];
            var b = bText.match(/\s+|[\w]+|[^\w\s]/g) || [];
            oldEl.textContent = ''; newEl.textContent = '';
            // LCS token diff keeps unchanged words unhighlighted. Guard very large documents.
            if (a.length * b.length > 450000) {
                var prefix = 0, max = Math.min(a.length,b.length);
                while (prefix < max && a[prefix] === b[prefix]) prefix++;
                var suffix = 0; while (suffix < a.length-prefix && suffix < b.length-prefix && a[a.length-1-suffix] === b[b.length-1-suffix]) suffix++;
                a.slice(0,prefix).forEach(t=>append(oldEl,t)); b.slice(0,prefix).forEach(t=>append(newEl,t));
                a.slice(prefix,a.length-suffix).forEach(t=>append(oldEl,t,'del')); b.slice(prefix,b.length-suffix).forEach(t=>append(newEl,t,'ins'));
                if(suffix){a.slice(a.length-suffix).forEach(t=>append(oldEl,t));b.slice(b.length-suffix).forEach(t=>append(newEl,t));} return;
            }
            var dp = Array.from({length:a.length+1},()=>new Uint32Array(b.length+1));
            for(var i=a.length-1;i>=0;i--) for(var j=b.length-1;j>=0;j--) dp[i][j] = a[i]===b[j] ? dp[i+1][j+1]+1 : Math.max(dp[i+1][j],dp[i][j+1]);
            var x=0,y=0,del='',ins='';
            function flush(){append(oldEl,del,'del');append(newEl,ins,'ins');del='';ins='';}
            while(x<a.length && y<b.length){
                if(a[x]===b[y]){flush();append(oldEl,a[x]);append(newEl,b[y]);x++;y++;}
                else if(dp[x+1][y] >= dp[x][y+1]){del+=a[x++];}
                else {ins+=b[y++];}
            }
            while(x<a.length) del+=a[x++]; while(y<b.length) ins+=b[y++]; flush();
        }
        document.querySelectorAll('[data-hc-diff-field]').forEach(function(field){
            var oldEl=field.querySelector('[data-hc-old]'), newEl=field.querySelector('[data-hc-new]');
            if(oldEl&&newEl) renderDiff(oldEl,newEl);
        });
        // Legacy compatibility for any old markup still present.
        document.querySelectorAll('.hc-revision-field').forEach(function(field){
            var oldEl=field.querySelector('.hc-revision-before pre'), newEl=field.querySelector('.hc-revision-after pre');
            if(oldEl&&newEl) renderDiff(oldEl,newEl);
        });
    }

    function initQuickCategoryAdd() {
        var input=document.getElementById('hcQuickCategoryName'), button=document.getElementById('hcQuickAddCategory'), msg=document.getElementById('hcQuickCategoryMessage');
        if(!input||!button) return;
        button.addEventListener('click',function(){
            var name=input.value.trim(); if(!name){input.focus();return;}
            button.disabled=true; if(msg)msg.textContent='Creating category…';
            var fd=new FormData(); fd.append('action','hc_save_category'); fd.append('nonce',data.nonce||''); fd.append('name',name); fd.append('slug',slugify(name)); fd.append('description',''); fd.append('icon_value','fa-folder'); fd.append('parent_id','0'); fd.append('sort_order','0'); fd.append('status','published'); fd.append('id','0');
            ajax(fd).then(function(res){if(!res.success)throw new Error((res.data&&res.data.message)||'Could not create category');
                var box=document.querySelector('.hc-multi-cat-box'); if(box){var label=document.createElement('label');label.style.cssText='display:flex;align-items:center;padding:8px;margin-bottom:2px;cursor:pointer';var cb=document.createElement('input');cb.type='checkbox';cb.name='category_ids[]';cb.value=res.data.id;cb.checked=true;cb.style.marginRight='10px';var icon=document.createElement('i');icon.className='fas fa-folder';icon.style.cssText='color:#4F46E5;margin-right:8px';var text=document.createElement('span');text.style.cssText='font-size:14px;color:#334155;font-weight:500';text.textContent=name;label.appendChild(cb);label.appendChild(icon);label.appendChild(text);box.appendChild(label);}
                input.value=''; if(msg)msg.textContent='Category created and selected. Save the article to keep the assignment.'; toast('Category created','success');
            }).catch(function(err){if(msg)msg.textContent=err.message||'Could not create category';toast(err.message||'Could not create category','error');}).finally(function(){button.disabled=false;});
        });
    }

    // =============================================
    // FAQ FORM (destination selector + rich text save)
    // =============================================
    function initFaqForm() {
        var form = document.getElementById('hcFaqForm');
        if (!form || form.dataset.hcBound === '1') return;
        form.dataset.hcBound = '1';
        var type = document.getElementById('hcFaqDestType');
        var catWrap = document.getElementById('hcFaqDestCat');
        var artWrap = document.getElementById('hcFaqDestArt');
        function updateDestinationFields() {
            var value = type ? type.value : 'global';
            if (catWrap) catWrap.style.display = value === 'category' ? 'block' : 'none';
            if (artWrap) artWrap.style.display = value === 'article' ? 'block' : 'none';
        }
        if (type) type.addEventListener('change', updateDestinationFields);
        updateDestinationFields();
        initAutosave(form, 'faq');
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var btn = document.getElementById('hcFaqSaveBtn');
            var original = btn ? btn.innerHTML : '';
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...'; }
            var fd = new FormData(form);
            var destinationType = type ? type.value : 'global';
            var destinationId = 0;
            if (destinationType === 'category') destinationId = form.querySelector('[name="destination_id_cat"]')?.value || 0;
            if (destinationType === 'article') destinationId = form.querySelector('[name="destination_id_art"]')?.value || 0;
            fd.set('destination_id', destinationId);
            fd.append('action', 'hc_save_faq');
            fd.append('nonce', data.nonce || '');
            fd.set('id', form.getAttribute('data-id') || 0);
            if (typeof tinymce !== 'undefined' && tinymce.get('hcFaqAnswer')) fd.set('answer', tinymce.get('hcFaqAnswer').getContent());
            ajax(fd).then(function(res) {
                if (res.success) {
                    form.dataset.hcManualSave = '1'; try{localStorage.removeItem('hc_editor_backup_faq_'+(form.getAttribute('data-id')||'new_'+location.pathname));}catch(e){}
                    toast((res.data && res.data.message) || 'FAQ saved', 'success');
                    window.location.href = data.homeUrl + 'faqs/';
                } else {
                    toast((res.data && res.data.message) || 'Unable to save FAQ', 'error');
                    if (btn) { btn.disabled = false; btn.innerHTML = original; }
                }
            }).catch(function() {
                toast('Network error while saving FAQ', 'error');
                if (btn) { btn.disabled = false; btn.innerHTML = original; }
            });
        });
    }

    // WordPress-like autosave for article/FAQ editors. Saves every 8 seconds after edits.
    function initAutosave(form, type) {
        var status = document.getElementById('hcAutosaveStatus');
        var timer = null, dirty = false, saving = false, changedSinceManualSave = false;
        var initialId = parseInt(form.getAttribute('data-id') || '0', 10);
        function editorContent() {
            var name = type === 'article' ? 'hcContent' : 'hcFaqAnswer';
            if (typeof tinymce !== 'undefined' && tinymce.get(name)) return tinymce.get(name).getContent();
            var ta = form.querySelector('textarea[name="' + (type === 'article' ? 'content' : 'answer') + '"]');
            return ta ? ta.value : '';
        }
        var backupKey='hc_editor_backup_'+type+'_'+(form.getAttribute('data-id')||'new_'+location.pathname);
        function snapshot(){var obj={};form.querySelectorAll('input[name],textarea[name],select[name]').forEach(function(el){if(el.name==='category_ids[]')return;obj[el.name]=el.value;});obj[type==='article'?'content':'answer']=editorContent();return obj;}
        function applySnapshot(obj){if(!obj)return;Object.keys(obj).forEach(function(k){if(k===(type==='article'?'content':'answer'))return;var el=form.querySelector('[name="'+k.replace(/"/g,'')+'"]');if(el)el.value=obj[k];});var ed=typeof tinymce!=='undefined'?tinymce.get(type==='article'?'hcContent':'hcFaqAnswer'):null;if(ed)ed.setContent(obj[type==='article'?'content':'answer']||'');else{var ta=form.querySelector('textarea[name="'+(type==='article'?'content':'answer')+'"]');if(ta)ta.value=obj[type==='article'?'content':'answer']||'';} }
        function showBackupNotice(obj){var old=document.getElementById('hcBrowserBackupNotice');if(old)old.remove();var box=document.createElement('div');box.id='hcBrowserBackupNotice';box.style.cssText='background:#fff7ed;border:1px solid #fb923c;border-radius:6px;padding:14px;margin:0 0 14px;color:#7c2d12';box.innerHTML='<strong>The backup of this post in your browser is different from the version below.</strong><p style="margin:6px 0 10px">Restore the backup to replace the current editor content with the last browser backup. You can use undo and redo in the editor to return to the previous content.</p><button type="button" class="hc-admin-btn hc-admin-btn-primary" id="hcRestoreBrowserBackup">Restore the backup</button> <button type="button" class="hc-admin-btn hc-admin-btn-outline" id="hcCloseBrowserBackup">Close</button>';var statusEl=form.querySelector('#hcAutosaveStatus');if(statusEl)form.insertBefore(box,statusEl);else form.prepend(box);document.getElementById('hcRestoreBrowserBackup').addEventListener('click',function(){applySnapshot(obj);box.remove();dirty=true;changedSinceManualSave=true;setStatus('Restored browser backup — saving…');timer=setTimeout(save,100);});document.getElementById('hcCloseBrowserBackup').addEventListener('click',function(){box.remove();});}
        function setStatus(text, error) { if(status){status.textContent=text;status.style.color=error?'#B91C1C':'#64748B';} }
        function storeBrowserBackup(){try{localStorage.setItem(backupKey,JSON.stringify({data:snapshot(),time:Date.now()}));}catch(e){}}
        function markDirty(){dirty=true;changedSinceManualSave=true;form.dataset.hcManualSave='0';setStatus('Unsaved changes…');storeBrowserBackup();if(timer)clearTimeout(timer);timer=setTimeout(save,900);}
        form.addEventListener('input', markDirty); form.addEventListener('change', markDirty);
        var revisionWasRestored = false;
        try {
            var urlParams = new URLSearchParams(window.location.search);
            revisionWasRestored = urlParams.get('hc_revision_restored') === '1';
            if (revisionWasRestored) {
                localStorage.removeItem(backupKey);
                urlParams.delete('hc_revision_restored');
                var cleanQuery = urlParams.toString();
                window.history.replaceState({}, document.title, window.location.pathname + (cleanQuery ? '?' + cleanQuery : '') + window.location.hash);
            } else {
                var prior=localStorage.getItem(backupKey);
                if(prior){var saved=JSON.parse(prior);if(saved&&saved.data&&saved.time){var current=snapshot();if(JSON.stringify(saved.data)!==JSON.stringify(current))showBackupNotice(saved.data);}}
            }
        } catch(e){}
        if (typeof tinymce !== 'undefined') {
            var bindEditor = function(){ var ed=tinymce.get(type==='article'?'hcContent':'hcFaqAnswer'); if(ed && !ed.__hcAutosaveBound){ed.__hcAutosaveBound=true;ed.on('input change keyup',markDirty);} };
            setTimeout(bindEditor,1000); setTimeout(bindEditor,2500);
        }
        function save(){ if(!dirty || saving)return; saving=true;dirty=false;setStatus('Saving…');
            var fd=new FormData(); fd.append('action',type==='article'?'hc_autosave_article':'hc_autosave_faq'); fd.append('nonce',data.nonce||''); fd.append('id',form.getAttribute('data-id')||'0');
            var title=form.querySelector('[name="title"]'); if(title)fd.append('title',title.value);
            var slug=form.querySelector('[name="slug"]'); if(slug)fd.append('slug',slug.value);
            var excerpt=form.querySelector('[name="excerpt"]'); if(excerpt)fd.append('excerpt',excerpt.value);
            var question=form.querySelector('[name="question"]'); if(question)fd.append('question',question.value);
            fd.append(type==='article'?'content':'answer',editorContent());
            ajax(fd).then(function(res){if(!res.success)throw new Error((res.data&&res.data.message)||'Autosave failed');if(res.data&&res.data.id){form.setAttribute('data-id',res.data.id);var hidden=form.querySelector('[name="id"]');if(hidden)hidden.value=res.data.id;}setStatus('All changes saved automatically at '+new Date().toLocaleTimeString());})
            .catch(function(err){dirty=true;setStatus(err.message||'Autosave failed — retrying shortly',true);timer=setTimeout(save,3000);}).finally(function(){saving=false;if(dirty)timer=setTimeout(save,900);});
        }
        window.addEventListener('beforeunload',function(e){if(changedSinceManualSave && form.dataset.hcManualSave !== '1'){e.preventDefault();e.returnValue='';}});
    }

    // =============================================
    // CATEGORY FORM
    // =============================================
    function initCategoryForm() {
        var form = document.getElementById('hcCategoryForm');
        if (!form || form.dataset.hcBound === '1') return;
        form.dataset.hcBound = '1';
        var catName = document.getElementById('hcCatName');
        var catSlug = document.getElementById('hcCatSlug');
        var slugManuallyEdited = !!(catSlug && catSlug.value);
        if (catSlug) catSlug.addEventListener('input', function(){ slugManuallyEdited = true; });
        if (catName && catSlug) catName.addEventListener('input', function(){ if (!slugManuallyEdited) catSlug.value = slugify(this.value); });
        var iconValue = document.getElementById('hcIconValue');
        var iconPreview = document.getElementById('hcIconPreview');
        var customIconInput = document.getElementById('hcIconCustomInput');
        var customIconPreview = document.getElementById('hcIconCustomPreview');
        var customIconStatus = document.getElementById('hcIconCustomStatus');
        function normalizeIconClasses(value) {
            value = (value || '').trim();
            if (!value) return 'fas fa-folder';
            if (!/^(fa[srlbd]?\s+)?fa-[a-z0-9-]+(\s+fa-[a-z0-9-]+)*$/i.test(value)) {
                if (/^[a-z0-9-]+$/i.test(value)) value = 'fa-' + value;
                else return '';
            }
            if (!/fa[srlbd]/i.test(value)) value = 'fas ' + value;
            return value;
        }
        if (customIconInput) {
            customIconInput.value = iconValue ? iconValue.value : '';
            function previewCustomIcon(apply) {
                var classes = normalizeIconClasses(customIconInput.value);
                if (customIconPreview) customIconPreview.className = 'hc-icon-custom-preview ' + (classes || 'fas fa-question');
                if (customIconStatus) customIconStatus.textContent = classes ? 'Preview' : 'Use a valid Font Awesome class';
                if (apply && classes) {
                    if (iconValue) iconValue.value = classes.replace(/^fas\s+/, '');
                    if (iconPreview) iconPreview.className = classes;
                    form.querySelectorAll('.hc-icon-btn').forEach(function(b){ b.classList.remove('active'); });
                }
            }
            customIconInput.addEventListener('input', function(){ previewCustomIcon(false); });
            customIconInput.addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); previewCustomIcon(true); } });
            customIconInput.addEventListener('change', function(){ previewCustomIcon(true); });
            previewCustomIcon(false);
        }
        form.querySelectorAll('.hc-icon-btn[data-icon]').forEach(function(iconBtn) {
            iconBtn.addEventListener('click', function() {
                var selected = this.getAttribute('data-icon') || 'fa-folder';
                if (iconValue) iconValue.value = selected;
                form.querySelectorAll('.hc-icon-btn').forEach(function(b){ b.classList.toggle('active', b === iconBtn); });
                if (iconPreview) iconPreview.className = 'fas ' + selected;
            });
        });
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var id = form.getAttribute('data-id') || 0;
            var btn = document.getElementById('hcCatSaveBtn');
            var orig = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            btn.disabled = true;
            var fd = new FormData(form);
            fd.append('action', 'hc_save_category');
            fd.append('nonce', data.nonce);
            fd.append('id', id);
            ajax(fd).then(function(res) {
                if (res.success) {
                    toast('Category saved', 'success');
                    setTimeout(function() { window.location.href = data.homeUrl + 'categories/'; }, 600);
                } else {
                    toast((res.data && res.data.message) ? res.data.message : 'Error', 'error');
                    btn.innerHTML = orig;
                    btn.disabled = false;
                }
            }).catch(function() {
                toast('Network error', 'error');
                btn.innerHTML = orig;
                btn.disabled = false;
            });
        });
    }

    // =============================================
    // DELETE ACTIONS (Single)
    // =============================================
    function initDeletes() {
        document.addEventListener('click', function(e) {
            var btn = e.target.closest('[data-hc-delete-article], [data-hc-delete-category], [data-hc-delete-faq]');
            if (!btn) return;
            e.preventDefault();
            if (!confirm('Are you sure you want to delete this?')) return;

            var action = 'hc_delete_article';
            var id = btn.getAttribute('data-hc-delete-article');
            if (!id) { action = 'hc_delete_category'; id = btn.getAttribute('data-hc-delete-category'); }
            if (!id) { action = 'hc_delete_faq'; id = btn.getAttribute('data-hc-delete-faq'); }

            var fd = new FormData();
            fd.append('action', action);
            fd.append('nonce', data.nonce);
            fd.append('id', id);

            ajax(fd).then(function(res) {
                if (res.success) {
                    toast('Item moved to trash', 'success');
                    window.location.reload();
                } else {
                    alert((res.data && res.data.message) || 'Error');
                }
            });
        });
    }


    // =============================================
    // TRASH ACTIONS (restore, permanently delete, empty trash)
    // =============================================
    function initTrashActions() {
        document.addEventListener('click', function(e) {
            var btn = e.target.closest('[data-hc-restore-article], [data-hc-restore-faq], [data-hc-restore-category], [data-hc-hard-delete-article], [data-hc-hard-delete-faq], [data-hc-hard-delete-category], .hc-empty-trash-btn');
            if (!btn) return;
            e.preventDefault();
            var action = '', id = '', type = '';
            if (btn.classList.contains('hc-empty-trash-btn')) {
                type = btn.getAttribute('data-trash-type') || 'all';
                if (!window.confirm('Permanently delete all items in this trash? This cannot be undone.')) return;
                action = 'hc_empty_trash';
            } else {
                var attrs = [
                    ['data-hc-restore-article','hc_restore_article','article'], ['data-hc-restore-faq','hc_restore_faq','faq'], ['data-hc-restore-category','hc_restore_category','category'],
                    ['data-hc-hard-delete-article','hc_hard_delete_article','article'], ['data-hc-hard-delete-faq','hc_hard_delete_faq','faq'], ['data-hc-hard-delete-category','hc_hard_delete_category','category']
                ];
                for (var i=0; i<attrs.length; i++) {
                    var val = btn.getAttribute(attrs[i][0]);
                    if (val) { id = val; action = attrs[i][1]; type = attrs[i][2]; break; }
                }
                if (!action || !id) return;
                if (action.indexOf('hard_delete') !== -1 && !window.confirm('Permanently delete this item? This cannot be undone.')) return;
            }
            btn.disabled = true;
            var fd = new FormData(); fd.append('action', action); fd.append('nonce', data.nonce || '');
            if (id) fd.append('id', id); if (type && action === 'hc_empty_trash') fd.append('type', type);
            ajax(fd).then(function(res) {
                if (res.success) { toast((res.data && res.data.message) || 'Action completed', 'success'); window.location.reload(); }
                else { toast((res.data && res.data.message) || 'Action failed', 'error'); btn.disabled = false; }
            }).catch(function() { toast('Network error', 'error'); btn.disabled = false; });
        });
    }

    // =============================================
    // BULK ACTIONS (Restored & Working)
    // =============================================
    function initBulkActions() {
        var bulkBar = document.getElementById('hcBulkBar');
        if (!bulkBar) return;
        bulkBar.classList.remove('open');
        bulkBar.style.display = 'none';

        function updateUI() {
            var checked = document.querySelectorAll('.hc-row-check:checked');
            var count = checked.length;
            var bulkCount = document.querySelector('.hc-bulk-count');
            
            if (bulkCount) bulkCount.textContent = count;

            // Hide an action only when it cannot change any selected row.
            // A mixed selection always retains the action, like WordPress bulk actions.
            var selectedRows = Array.from(checked).map(function(cb) { return cb.closest('tr'); }).filter(Boolean);
            var listType = bulkBar.getAttribute('data-list') || 'articles';
            var view = bulkBar.getAttribute('data-view') || '';
            bulkBar.querySelectorAll('[data-bulk-op]').forEach(function(btn) {
                var op = btn.getAttribute('data-bulk-op');
                var hide = false;
                if (selectedRows.length) {
                    if (op === 'publish') hide = selectedRows.every(function(row) { return row.getAttribute('data-status') === 'published'; });
                    else if (op === 'draft' && (listType === 'articles' || listType === 'faqs')) hide = selectedRows.every(function(row) { return row.getAttribute('data-status') === 'draft'; });
                    else if (op === 'hide' && listType === 'categories') hide = selectedRows.every(function(row) { return row.getAttribute('data-status') === 'hidden'; });
                    else if (op === 'delete') hide = selectedRows.every(function(row) { return row.getAttribute('data-trashed') === '1'; });
                    else if (op === 'restore' || op === 'hard_delete') hide = view !== 'trash';
                }
                btn.style.display = hide ? 'none' : '';
            });
            
            if (count > 0) {
                bulkBar.style.display = 'flex';
                bulkBar.classList.add('open');
            } else {
                bulkBar.classList.remove('open');
                bulkBar.style.display = 'none';
            }

            var selectAll = document.querySelector('.hc-check-all');
            if (selectAll) {
                var allBoxes = document.querySelectorAll('.hc-row-check');
                selectAll.checked = (count > 0 && count === allBoxes.length);
            }
        }

        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('hc-row-check') || e.target.classList.contains('hc-check-all')) {
                if (e.target.classList.contains('hc-check-all')) {
                    var state = e.target.checked;
                    document.querySelectorAll('.hc-row-check').forEach(function(cb) { cb.checked = state; });
                }
                updateUI();
            }
        });

        var clearBtn = document.querySelector('[data-bulk-clear]');
        if (clearBtn) {
            clearBtn.addEventListener('click', function() {
                document.querySelectorAll('.hc-row-check').forEach(function(cb) { cb.checked = false; });
                var sa = document.querySelector('.hc-check-all');
                if (sa) sa.checked = false;
                updateUI();
            });
        }

        document.querySelectorAll('[data-bulk-op]').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                var op = btn.getAttribute('data-bulk-op');
                var checked = document.querySelectorAll('.hc-row-check:checked');
                var ids = Array.from(checked).map(function(cb) { return cb.value; });
                var listType = bulkBar.getAttribute('data-list') || 'articles';

                if (ids.length === 0) return;

                // Special guard for Publish
                if (listType === 'articles' && op === 'publish') {
                    var origHTML = btn.innerHTML;
                    btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Checking...';
                    btn.disabled = true;

                    var checkFd = new FormData();
                    checkFd.append('action', 'hc_check_bulk_articles_categories');
                    checkFd.append('nonce', data.nonce);
                    ids.forEach(function(id) { checkFd.append('article_ids[]', id); });

                    fetch(data.ajaxUrl, { method: 'POST', body: checkFd })
                        .then(function(r) { return r.json(); })
                        .then(function(res) {
                            btn.innerHTML = origHTML;
                            btn.disabled = false;
                            if (res.success && res.data.blocked_articles && res.data.blocked_articles.length > 0) {
                                var blocked = res.data.blocked_articles;
                                var msg = "These articles will be published, but visitors will not see them yet because all of their categories are hidden:\n\n";
                                blocked.forEach(function(a) { msg += "- " + a.title + "\n"; });
                                msg += "\nThey appear automatically once one of their categories is published.\n\nPublish them anyway?";
                                if (confirm(msg)) runBulk(op, ids, listType, btn);
                            } else {
                                runBulk(op, ids, listType, btn);
                            }
                        })
                        .catch(function() {
                            btn.innerHTML = origHTML;
                            btn.disabled = false;
                            alert('Error checking categories.');
                        });
                } else {
                    runBulk(op, ids, listType, btn);
                }
            });
        });

        function runBulk(op, ids, listType, btn) {
            var orig = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Processing...';
            btn.disabled = true;
            var fd = new FormData();
            fd.append('action', 'hc_bulk_' + listType);
            fd.append('nonce', data.nonce);
            fd.append('op', op);
            ids.forEach(function(id) { fd.append('ids[]', id); });

            fetch(data.ajaxUrl, { method: 'POST', body: fd })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res.success) {
                        window.location.reload();
                    } else {
                        alert((res.data && res.data.message) || 'Action failed');
                        btn.innerHTML = orig;
                        btn.disabled = false;
                    }
                })
                .catch(function() {
                    alert('Network error');
                    btn.innerHTML = orig;
                    btn.disabled = false;
                });
        }
    }

    // =============================================
    // AJAX SEARCH (Articles, FAQs, Categories)
    // =============================================
    function initSearch() {
        if (!document.querySelector('.hc-articles-search') && !document.querySelector('.hc-faqs-search') && !document.querySelector('.hc-cats-search')) return;
        var configs = [
            { wrap: '.hc-articles-search', action: 'hc_admin_search_articles', tbody: '.hc-articles-tbody', count: '.hc-articles-count' },
            { wrap: '.hc-faqs-search', action: 'hc_admin_search_faqs', tbody: '.hc-faqs-tbody', count: '.hc-faqs-count' },
            { wrap: '.hc-cats-search', action: 'hc_admin_search_categories', tbody: '.hc-cats-tbody', count: '.hc-cats-count' }
        ];

        configs.forEach(function(cfg) {
            var wrap = document.querySelector(cfg.wrap);
            if (!wrap) return;
            var input = wrap.querySelector('input[type="text"]');
            var tbody = document.querySelector(cfg.tbody);
            var countEl = wrap.querySelector(cfg.count) || wrap.querySelector('.hc-search-count');
            var spinner = wrap.querySelector('.hc-search-spinner');
            var catSelect = wrap.querySelector('.hc-articles-cat');
            var view = wrap.getAttribute('data-view') || '';
            
            if (!input || !tbody) return;
            var timer;
            var searchRequestId = 0;
            // Preserve the server-rendered, paginated list so clearing search returns to the selected page size.
            var initialRowsHTML = tbody.innerHTML;
            var initialCountText = countEl ? countEl.textContent : '';
            var pagination = wrap.querySelector('.hc-admin-pagination') || document.getElementById('hcArticlesPagination') || document.querySelector('.hc-admin-pagination');

            function restoreInitialList() {
                tbody.innerHTML = initialRowsHTML;
                if (countEl) countEl.textContent = initialCountText;
                if (pagination) pagination.style.display = '';
                if (spinner) spinner.style.display = 'none';
            }

            input.addEventListener('input', function() {
                clearTimeout(timer);
                var requestId = ++searchRequestId;
                var q = this.value.trim();
                var catValue = catSelect ? (catSelect.value || '0') : '0';
                if (!q && catValue === '0') {
                    restoreInitialList();
                    return;
                }
                if (pagination) pagination.style.display = 'none';
                if (spinner) spinner.style.display = 'inline-block';

                timer = setTimeout(function() {
                    var fd = new FormData();
                    fd.append('action', cfg.action);
                    fd.append('nonce', data.nonce);
                    fd.append('q', q);
                    fd.append('view', view);
                    fd.append('sort', new URLSearchParams(window.location.search).get('sort') || 'asc');
                    fd.append('orderby', new URLSearchParams(window.location.search).get('orderby') || '');
                    if (catSelect) fd.append('cat', catSelect.value || '0');

                    fetch(data.ajaxUrl, { method: 'POST', body: fd })
                        .then(function(r) { return r.json(); })
                        .then(function(res) {
                            if (requestId !== searchRequestId || !res.success) return;
                            var rows = res.data.rows || [];
                            if (countEl) countEl.textContent = (typeof res.data.total === 'number' ? res.data.total : rows.length) + ' results';
                            tbody.innerHTML = '';
                            if (rows.length === 0) {
                                tbody.innerHTML = '<tr><td colspan="10" style="text-align: center !important; width: 100% !important; padding: 60px !important; color: #94A3B8 !important; font-size: 15px !important; border: none !important;"><i class="fas fa-search" style="font-size: 24px; margin-bottom: 12px; opacity: 0.5;"></i><br>No results found</td></tr>';
                                return;
                            }
                            rows.forEach(function(row) {
                                tbody.appendChild(renderRow(cfg.wrap.replace('.', ''), row));
                            });
                        })
                        .catch(function() {})
                        .finally(function() { if (requestId === searchRequestId && spinner) spinner.style.display = 'none'; });
                }, 300);
            });
            if (catSelect) catSelect.addEventListener('change', function() { input.dispatchEvent(new Event('input', { bubbles: true })); });
        });
    }

    function renderRow(type, row) {
        var tr = document.createElement('tr');
        tr.setAttribute('data-row-id', row.id);
        
        // --- ARTICLES ---
        if (type === 'hc-articles-search') {
            var actions = '<a href="' + row.edit_url + '" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" title="Edit"><i class="fas fa-pen"></i></a>';
            if (row.is_trashed) {
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" data-hc-restore-article="' + row.id + '" title="Restore"><i class="fas fa-undo"></i></button>';
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-hard-delete-article="' + row.id + '" title="Delete permanently"><i class="fas fa-trash-alt"></i></button>';
            } else {
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-delete-article="' + row.id + '" title="Move to trash"><i class="fas fa-trash"></i></button>';
            }

            var statusHtml = row.is_trashed ? '<span class="hc-status hc-status-trash">trashed</span>' : '<span class="hc-status hc-status-' + row.status + '">' + row.status + '</span>';
            var actionCell = '<td class="hc-muted" title="' + escapeHtml(row.last_action_at || '') + '">' + (row.last_action_human || '—') + '<br><small style="font-size:11px;color:#94A3B8;">' + escapeHtml(row.last_action || '—') + '</small></td>';

            tr.innerHTML = '<td><input type="checkbox" class="hc-row-check" value="' + row.id + '"></td>' +
                '<td><a href="' + row.edit_url + '" class="hc-admin-link">' + escapeHtml(row.title) + '</a></td>' +
                '<td>' + escapeHtml(row.category_name || '—') + '</td>' +
                '<td>' + statusHtml + '</td>' +
                '<td>' + (row.view_count || 0) + '</td>' +
                actionCell +
                '<td><div class="hc-admin-row-actions">' + actions + '</div></td>';
        }
        
        // --- FAQS ---
        else if (type === 'hc-faqs-search') {
            var actions = '<a href="' + row.edit_url + '" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" title="Edit"><i class="fas fa-pen"></i></a>';
            if (row.is_trashed) {
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" data-hc-restore-faq="' + row.id + '" title="Restore"><i class="fas fa-undo"></i></button>';
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-hard-delete-faq="' + row.id + '" title="Delete permanently"><i class="fas fa-trash-alt"></i></button>';
            } else {
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-delete-faq="' + row.id + '" title="Move to trash"><i class="fas fa-trash"></i></button>';
            }

            var statusHtml = row.is_trashed ? '<span class="hc-status hc-status-trash">trashed</span>' : '<span class="hc-status hc-status-' + row.status + '">' + escapeHtml(row.status) + '</span>';
            if (!row.is_trashed && row.status === 'published' && row.hidden_reason) {
                statusHtml += '<br><span class="hc-status hc-status-hidden" title="' + escapeHtml(row.hidden_reason) + '" style="margin-top:4px;display:inline-block;cursor:help;">not visible</span><small style="display:block;color:#B45309;max-width:210px;">' + escapeHtml(row.hidden_reason) + '</small>';
            }
            var actionCell = '<td class="hc-muted" title="' + escapeHtml(row.last_action_at || '') + '">' + (row.last_action_human || '—') + '<br><small style="font-size:11px;color:#94A3B8;">' + escapeHtml(row.last_action || '—') + '</small></td>';

            tr.innerHTML = '<td><input type="checkbox" class="hc-row-check" value="' + row.id + '"></td>' +
                '<td><a href="' + row.edit_url + '" class="hc-admin-link">' + escapeHtml(row.question) + '</a></td>' +
                '<td class="hc-muted">' + escapeHtml(row.dest || '—') + '</td>' +
                '<td>' + (row.sort || 0) + '</td>' +
                '<td>' + statusHtml + '</td>' +
                actionCell +
                '<td><div class="hc-admin-row-actions">' + actions + '</div></td>';
        }
        
        // --- CATEGORIES ---
        else if (type === 'hc-cats-search') {
            var actions = '<a href="' + row.edit_url + '" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" title="Edit"><i class="fas fa-pen"></i></a>';
            if (row.is_trashed) {
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" data-hc-restore-category="' + row.id + '" title="Restore"><i class="fas fa-undo"></i></button>';
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-hard-delete-category="' + row.id + '" title="Delete permanently"><i class="fas fa-trash-alt"></i></button>';
            } else if (row.is_default === 1) {
                actions += '<span class="hc-admin-badge-default" title="Default category — cannot be deleted"><i class="fas fa-lock"></i> Default</span>';
            } else {
                actions += '<button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-delete-category="' + row.id + '" title="Move to trash"><i class="fas fa-trash"></i></button>';
            }

            var icon = '<i class="fas ' + (row.icon_value || 'fa-folder') + '" style="color:#4F46E5; margin-right:8px; vertical-align:middle;"></i>';
            var statusHtml = row.is_trashed ? '<span class="hc-status hc-status-trash">trashed</span>' : '<span class="hc-status hc-status-' + row.status + '">' + row.status + '</span>';
            var actionCell = '<td class="hc-muted" title="' + escapeHtml(row.last_action_at || '') + '">' + (row.last_action_human || '—') + '<br><small style="font-size:11px;color:#94A3B8;">' + escapeHtml(row.last_action || '—') + '</small></td>';
            var checkboxCell = (row.is_default === 1) ? '<td></td>' : '<td><input type="checkbox" class="hc-row-check" value="' + row.id + '"></td>';

            var parentBubble = '';
            if (row.parent_id > 0 && row.parent_name) {
                parentBubble = ' <span class="hc-parent-chip" title="Parent category"><i class="fas fa-level-up-alt"></i> in ' + escapeHtml(row.parent_name) + '</span>';
            }

            tr.innerHTML = checkboxCell + '<td></td>' +
                '<td><div style="display: flex; align-items: center; flex-wrap: nowrap;">' + 
                    icon + 
                    '<a href="' + row.edit_url + '" class="hc-admin-link" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">' + escapeHtml(row.name) + '</a>' + 
                    parentBubble + 
                '</div></td>' +
                '<td class="hc-muted">' + escapeHtml(row.slug) + '</td>' +
                '<td>' + (row.article_count || 0) + '</td>' +
                '<td>' + statusHtml + '</td>' +
                actionCell +
                '<td><div class="hc-admin-row-actions">' + actions + '</div></td>';
        }
        
        return tr;
    }

    // =============================================
    // UNIVERSAL SORTING
    // =============================================
    function initSorting() {
        var tables = document.querySelectorAll('.hc-admin-table');
        if (!tables.length) return;
        
        tables.forEach(function(table) {
            var headers = table.querySelectorAll('th');
            var urlParams = new URLSearchParams(window.location.search);
            var currentOrderBy = urlParams.get('orderby') || '';
            var currentSort = urlParams.get('sort') || 'asc';

            headers.forEach(function(th) {
                // Skip checkboxes, empty headers, and Actions
                if (th.querySelector('input') || th.textContent.trim() === '' || th.textContent.includes('Actions')) return;

                // Clean the header text: remove any existing icons or SVG tags
                var cleanText = th.innerHTML.replace(/<i[^>]*><\/i>/g, '').trim();
                
                var colKey = cleanText.toLowerCase().replace(/\s+/g, '_');
                th.style.cursor = 'pointer';

                // Add the single correct icon based on current sort state
                if (currentOrderBy === colKey) {
                    var icon = currentSort === 'desc' ? ' <i class="fas fa-sort-down" style="margin-left:4px;"></i>' : ' <i class="fas fa-sort-up" style="margin-left:4px;"></i>';
                    th.innerHTML = cleanText + icon;
                } else {
                    th.innerHTML = cleanText + ' <i class="fas fa-sort" style="opacity:0.3; margin-left:4px;"></i>';
                }

                // Attach the click event
                th.addEventListener('click', function() {
                    var newSort = (currentOrderBy === colKey && currentSort === 'desc') ? 'asc' : 'desc';
                    var url = new URL(window.location.href);
                    url.searchParams.set('orderby', colKey);
                    url.searchParams.set('sort', newSort);
                    window.location.href = url.toString();
                });
            });
        });
    }

    // =============================================
    // HELPERS
    // =============================================
    function ajax(fd) {
        return fetch(data.ajaxUrl, { method: 'POST', body: fd }).then(function(r) { return r.json(); });
    }

    function toast(msg, type) {
        if (typeof msg === 'object' && msg !== null) {
            msg = msg.message || JSON.stringify(msg);
        }
        var el = document.querySelector('.hc-admin-toast') || document.createElement('div');
        el.className = 'hc-admin-toast hc-admin-toast-' + (type || 'success') + ' show';
        el.textContent = msg;
        if (!el.parentNode) document.body.appendChild(el);
        clearTimeout(el._timer);
        el._timer = setTimeout(function() { el.classList.remove('show'); }, 4000);
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.textContent = str == null ? '' : str;
        return div.innerHTML;
    }

    function slugify(str) {
        return (str || '').toString().toLowerCase().trim().replace(/[^\w\s-]/g, '').replace(/[\s_]+/g, '-');
    }


/* =============================================
   CATEGORY SEARCH FILTER (ARTICLE EDIT)
   ============================================= */
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('hcCatSearch');
    if (!searchInput) return;
    
    searchInput.addEventListener('input', function() {
        var q = this.value.toLowerCase().trim();
        var labels = document.querySelectorAll('.hc-multi-cat-box label');
        
        labels.forEach(function(label) {
            var text = label.textContent.toLowerCase();
            if (text.indexOf(q) !== -1) {
                label.style.display = 'flex';
            } else {
                label.style.display = 'none';
            }
        });
    });
});
