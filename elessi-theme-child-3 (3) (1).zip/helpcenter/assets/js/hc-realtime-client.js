
(function (window) {
  'use strict';

  if (window.HCRealtimeClient) {
    return;
  }

  /*
   * Keep refresh recovery isolated by browser tab and by logical connection.
   * sessionStorage is copied by some browsers when a tab is duplicated. A
   * small localStorage lease lets the new tab detect that copied identity and
   * rotate to a fresh one instead of trying to recover the original tab's
   * Ably connection. A normal reload releases the lease on pagehide and keeps
   * the sessionStorage identity, so recovery remains available.
   */
  var recoveryTabContext = null;
  var recoveryLeaseTimer = null;
  var RECOVERY_TAB_SESSION_KEY = 'hc.ably.tab-context.v2';
  var RECOVERY_LEASE_PREFIX = 'hc.ably.tab-lease.v2.';
  var RECOVERY_LEASE_TTL = 150000;
  var RECOVERY_LEASE_INTERVAL = 20000;

  function randomRecoveryId() {
    var bytes = new Uint8Array(16);
    var i;

    try {
      if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
        window.crypto.getRandomValues(bytes);
        var hex = '';
        for (i = 0; i < bytes.length; i++) {
          hex += ('0' + bytes[i].toString(16)).slice(-2);
        }
        return hex;
      }
    } catch (error) {}

    var fallback = '';
    for (i = 0; i < 4; i++) {
      fallback += Math.floor(Math.random() * 0x100000000).toString(16);
    }
    return fallback;
  }

  function writeRecoveryLease(context) {
    if (!context || !context.canRecover || !context.leaseKey) return;

    try {
      window.localStorage.setItem(context.leaseKey, JSON.stringify({
        owner: context.owner,
        expiresAt: Date.now() + RECOVERY_LEASE_TTL
      }));
    } catch (error) {
      context.canRecover = false;
    }
  }

  function getRecoveryTabContext() {
    if (recoveryTabContext) return recoveryTabContext;

    var tabId = '';
    var owner = randomRecoveryId();
    var canUseSessionStorage = false;
    var canUseLocalStorage = false;
    var leaseKey = '';

    try {
      tabId = window.sessionStorage.getItem(RECOVERY_TAB_SESSION_KEY) || '';
      canUseSessionStorage = true;
    } catch (error) {}

    if (!tabId) tabId = randomRecoveryId();

    if (canUseSessionStorage) {
      try {
        leaseKey = RECOVERY_LEASE_PREFIX + tabId;
        var rawLease = window.localStorage.getItem(leaseKey);
        var existingLease = rawLease ? JSON.parse(rawLease) : null;

        /* A different live document owns this copied sessionStorage identity. */
        if (
          existingLease &&
          existingLease.owner &&
          existingLease.owner !== owner &&
          Number(existingLease.expiresAt) > Date.now()
        ) {
          tabId = randomRecoveryId();
          leaseKey = RECOVERY_LEASE_PREFIX + tabId;
        }

        window.sessionStorage.setItem(RECOVERY_TAB_SESSION_KEY, tabId);
        canUseLocalStorage = true;
      } catch (error) {
        canUseLocalStorage = false;
      }
    }

    /* Without cross-tab coordination, use a fresh non-recovering identity. */
    if (!canUseSessionStorage || !canUseLocalStorage) {
      tabId = randomRecoveryId();
      leaseKey = '';
    }

    recoveryTabContext = {
      id: tabId,
      owner: owner,
      leaseKey: leaseKey,
      canRecover: canUseSessionStorage && canUseLocalStorage
    };

    if (recoveryTabContext.canRecover) {
      writeRecoveryLease(recoveryTabContext);
      recoveryLeaseTimer = window.setInterval(function () {
        writeRecoveryLease(recoveryTabContext);
      }, RECOVERY_LEASE_INTERVAL);
    }

    return recoveryTabContext;
  }

  function releaseRecoveryTabLease(event) {
    if (event && event.persisted) return;

    if (recoveryLeaseTimer) {
      window.clearInterval(recoveryLeaseTimer);
      recoveryLeaseTimer = null;
    }

    var context = recoveryTabContext;
    if (!context || !context.canRecover || !context.leaseKey) return;

    try {
      var rawLease = window.localStorage.getItem(context.leaseKey);
      var lease = rawLease ? JSON.parse(rawLease) : null;
      if (lease && lease.owner === context.owner) {
        window.localStorage.removeItem(context.leaseKey);
      }
    } catch (error) {}
  }

  if (window.addEventListener) {
    window.addEventListener('pagehide', releaseRecoveryTabLease);
  }

  function hashRecoveryScope(value) {
    var input = String(value || 'helpcenter');
    var hash = 2166136261;

    for (var i = 0; i < input.length; i++) {
      hash ^= input.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }

    return (hash >>> 0).toString(36);
  }

  function getRecoveryOptions(config) {
    var context = getRecoveryTabContext();
    var scope = String(config.recoveryScope || '');

    if (!scope) {
      scope = [
        config.channelType || 'support',
        config.sessionId ? 'session:' + String(config.sessionId) : '',
        config.ticketId ? 'ticket:' + String(config.ticketId) : '',
        config.sourceHcTicketId ? 'source:' + String(config.sourceHcTicketId) : ''
      ].join('|');
    }

    var path = '';
    try {
      path = window.location && window.location.pathname
        ? window.location.pathname
        : '';
    } catch (error) {}

    return {
      enabled: !!context.canRecover,
      storageName: 'hc.ably.recovery.v2.' + context.id + '.' + hashRecoveryScope(path + '|' + scope)
    };
  }

  /**
   * Request a short-lived Ably token from WordPress.
   *
   * WordPress remains responsible for identity, permissions and
   * deciding which channels this client may access.
   */
  function postToken(config) {
    var body = new FormData();

    body.append('action', 'hc_realtime_token');
    body.append('nonce', config.nonce || '');
    body.append('channel_type', config.channelType || 'support');

    if (config.sessionId) {
      body.append('session_id', String(config.sessionId));
    }

    if (config.ticketId) {
      body.append('ticket_id', String(config.ticketId));
    }

    if (config.sourceHcTicketId) {
      body.append(
        'source_hc_ticket_id',
        String(config.sourceHcTicketId)
      );
    }

    return fetch(config.ajaxUrl, {
      method: 'POST',
      body: body,
      credentials: 'same-origin',
      cache: 'no-store'
    })
      .then(function (response) {
        return response.text().then(function (raw) {
          var result;

          try {
            result = JSON.parse(raw);
          } catch (error) {
            throw new Error(
              'WordPress realtime endpoint returned an invalid response (HTTP ' +
              response.status + ').'
            );
          }

          if (!response.ok && (!result || result.success !== true)) {
            throw new Error(
              result &&
              result.data &&
              result.data.message
                ? result.data.message
                : 'Realtime token request failed (HTTP ' +
                  response.status + ').'
            );
          }

          return result;
        });
      })
      .then(function (result) {
        if (
          !result ||
          result.success !== true ||
          !result.data ||
          !result.data.token
        ) {
          throw new Error(
            result &&
            result.data &&
            result.data.message
              ? result.data.message
              : 'Realtime authentication failed.'
          );
        }

        return result.data;
      });
  }

  /**
   * Create an Ably connection and subscribe to all authorized channels.
   *
   * IMPORTANT:
   * The connection is considered ready only after:
   *   1. The Ably socket is connected.
   *   2. Every required channel is attached.
   *
   * A connected socket alone is NOT sufficient.
   */
  function connect(config, onEvent, onState) {
    if (
      !window.Ably ||
      !config ||
      !config.ajaxUrl
    ) {
      return Promise.reject(
        new Error('Ably client library or configuration is unavailable.')
      );
    }

    return postToken(config).then(function (initialTokenData) {
      var firstTokenData = initialTokenData;

      var channelName = initialTokenData.channel || '';

      var channelNames =
        Array.isArray(initialTokenData.channels) &&
        initialTokenData.channels.length
          ? initialTokenData.channels
          : [channelName];

      channelNames = channelNames.filter(function (name, index, all) {
        return (
          typeof name === 'string' &&
          name.length > 0 &&
          all.indexOf(name) === index
        );
      });

      if (!channelNames.length) {
        throw new Error(
          'WordPress did not provide an authorized Ably channel.'
        );
      }

      /**
       * Use the initial token once.
       * Subsequent authentication requests obtain a fresh token from WP.
       */
      var recoveryOptions = getRecoveryOptions(config);
      var clientOptions = {
        authCallback: function (_params, callback) {
          var request = firstTokenData
            ? Promise.resolve(firstTokenData)
            : postToken(config);

          firstTokenData = null;

          request
            .then(function (value) {
              callback(null, value.token);
            })
            .catch(function (error) {
              callback(error);
            });
        },

        autoConnect: true,
        echoMessages: false,
        disconnectedRetryTimeout: 3000,
        suspendedRetryTimeout: 5000,
        /* Do not explicitly close on refresh; let Ably persist recoverable state. */
        closeOnUnload: !recoveryOptions.enabled
      };

      if (recoveryOptions.enabled) {
        clientOptions.recoveryKeyStorageName = recoveryOptions.storageName;
        clientOptions.recover = function (_lastConnectionDetails, callback) {
          callback(true);
        };
      }

      var client;
      try {
        client = new window.Ably.Realtime(clientOptions);
      } catch (clientError) {
        if (recoveryOptions.enabled) {
          try { window.sessionStorage.removeItem(recoveryOptions.storageName); } catch (storageError) {}
        }
        throw clientError;
      }

      var channels = [];
      var channelMap = Object.create(null);
      var messageHandlers = [];
      var channelStateHandlers = [];

      channelNames.forEach(function (name) {
        var channel = client.channels.get(name);

        channels.push(channel);
        channelMap[name] = channel;
      });

      var closed = false;
      var closeRequested = false;
      var pendingPublishes = 0;
      var readyWaiters = [];

      function settleReadyWaiters(error) {
        var waiters = readyWaiters.slice();
        readyWaiters = [];
        waiters.forEach(function (waiter) {
          if (waiter.timer) window.clearTimeout(waiter.timer);
          if (error) waiter.reject(error);
          else waiter.resolve(connection);
        });
      }

      function waitForReady(timeoutMs) {
        if (closed || closeRequested) {
          return Promise.reject(new Error('Ably connection is closed.'));
        }
        if (allChannelsAttached()) return Promise.resolve(connection);

        var timeout = Math.max(1000, Math.min(30000, Number(timeoutMs) || 15000));
        return new Promise(function (resolve, reject) {
          var waiter = {
            resolve: resolve,
            reject: reject,
            timer: null
          };
          waiter.timer = window.setTimeout(function () {
            readyWaiters = readyWaiters.filter(function (item) { return item !== waiter; });
            reject(new Error('Ably ticket channels did not become ready within ' + timeout + ' ms.'));
          }, timeout);
          readyWaiters.push(waiter);

          // Close the small race between the first readiness check and registration.
          if (allChannelsAttached()) settleReadyWaiters();
        });
      }
      function clearConnectionRecoveryKey() {
        if (!recoveryOptions.enabled) return;
        try {
          window.sessionStorage.removeItem(recoveryOptions.storageName);
        } catch (error) {}
      }
      var closeTimer = null;
      var connectTimer = null;

      var lastNotifiedState = '';
      var initialSettled = false;

      var resolveInitialConnection;
      var rejectInitialConnection;

      /**
       * Notify the application about realtime state changes.
       */
      function reportState(state, reason) {
        if (
          closed ||
          typeof onState !== 'function' ||
          lastNotifiedState === state
        ) {
          return;
        }

        lastNotifiedState = state;

        if (
          window.console &&
          typeof window.console.debug === 'function'
        ) {
          console.debug(
            '[HelpCenter Ably] Realtime state:',
            state,
            reason && (reason.message || reason.code)
              ? (reason.message || reason.code)
              : ''
          );
        }

        try {
          onState(state, reason || null);
        } catch (error) {
          if (window.console && console.warn) {
            console.warn(
              '[HelpCenter Ably] State callback failed.',
              error
            );
          }
        }
      }

      /**
       * Check actual channel readiness.
       *
       * This is the central readiness check.
       */
      function allChannelsAttached() {
        if (
          !client.connection ||
          client.connection.state !== 'connected'
        ) {
          return false;
        }

        return channels.every(function (channel) {
          return channel.state === 'attached';
        });
      }

      /**
       * The application only receives "connected" when every
       * required channel is attached.
       */
      function updateReadyState(reason) {
        if (closed || closeRequested) {
          return;
        }

        // A terminal channel failure is not a transient socket disconnect.
        // Ably will not automatically reattach a channel in FAILED state (for
        // example, after an authorization/capability error). Surface it to the
        // owning dashboard so it can obtain a fresh token and create a client.
        var failedChannel = channels.find(function (channel) {
          return channel.state === 'failed';
        });
        if (failedChannel) {
          var baseChannelReason = failedChannel.errorReason || reason || null;
          var channelReason = new Error(
            'Ably channel ' + (failedChannel.name || 'unknown') + ' entered FAILED state' +
            (baseChannelReason && baseChannelReason.message ? ': ' + baseChannelReason.message : '.')
          );
          if (baseChannelReason && baseChannelReason.code) channelReason.code = baseChannelReason.code;
          channelReason.cause = baseChannelReason || null;
          if (!initialSettled) {
            failInitialConnection(channelReason);
          } else {
            settleReadyWaiters(channelReason);
            reportState('failed', channelReason);
          }
          return;
        }

        if (allChannelsAttached()) {
          settleReadyWaiters();
          reportState('connected', reason);

          if (!initialSettled) {
            initialSettled = true;

            if (connectTimer) {
              window.clearTimeout(connectTimer);
              connectTimer = null;
            }

            resolveInitialConnection(connection);
          }

          return;
        }

        var state = (
          client.connection &&
          client.connection.state
        )
          ? client.connection.state
          : 'connecting';

        /**
         * The socket may already be connected while one or more
         * channels are still attaching. Keep the application in
         * its recovery/fallback state until they all attach.
         */
        if (state === 'connected') {
          state = 'connecting';
        }

        reportState(state, reason);
      }

      /**
       * Remove the listeners installed by this client.
       */
      function removeListeners() {
        messageHandlers.forEach(function (entry) {
          try {
            entry.channel.unsubscribe(entry.handler);
          } catch (error) {}
        });

        messageHandlers = [];

        channelStateHandlers.forEach(function (entry) {
          try {
            if (typeof entry.channel.off === 'function') {
              entry.channel.off(entry.event, entry.handler);
            }
          } catch (error) {}
        });

        channelStateHandlers = [];

        try {
          if (
            client.connection &&
            typeof client.connection.off === 'function' &&
            connectionStateHandler
          ) {
            client.connection.off(connectionStateHandler);
          }
        } catch (error) {}
      }

      /**
       * Finish closing only after already-started publishes settle.
       */
      function finishClose() {
        if (
          !closeRequested ||
          pendingPublishes > 0 ||
          closed
        ) {
          return;
        }

        closed = true;

        if (closeTimer) {
          window.clearTimeout(closeTimer);
          closeTimer = null;
        }

        if (connectTimer) {
          window.clearTimeout(connectTimer);
          connectTimer = null;
        }

        removeListeners();
        settleReadyWaiters(new Error('Ably connection was closed before becoming ready.'));
        clearConnectionRecoveryKey();

        try {
          client.close();
        } catch (error) {}
      }

      /**
       * Handle a failed initial connection.
       */
      function failInitialConnection(reason) {
        if (initialSettled || closed) {
          return;
        }

        initialSettled = true;

        if (connectTimer) {
          window.clearTimeout(connectTimer);
          connectTimer = null;
        }

        closeRequested = true;
        pendingPublishes = 0;

        removeListeners();
        settleReadyWaiters(reason || new Error('Ably connection failed before becoming ready.'));
        clearConnectionRecoveryKey();

        try {
          client.close();
        } catch (error) {}

        closed = true;

        rejectInitialConnection(
          reason ||
          new Error('Ably connection or channel attachment failed.')
        );
      }

      /**
       * Publish only to a channel that is actually attached.
       *
       * This prevents a connected socket from being mistaken for
       * an available publishing channel.
       */
      function publishTo(name, eventName, payload) {
        var target = name
          ? channelMap[name]
          : (channels[0] || null);

        if (closeRequested || closed) {
          return Promise.reject(
            new Error('Ably connection is closing.')
          );
        }

        if (
          !target ||
          typeof target.publish !== 'function'
        ) {
          return Promise.reject(
            new Error('The authorized Ably channel is unavailable.')
          );
        }

        if (
          !client.connection ||
          client.connection.state !== 'connected' ||
          target.state !== 'attached'
        ) {
          return Promise.reject(
            new Error(
              'Ably channel is not attached. Use the persistence recovery path.'
            )
          );
        }

        pendingPublishes++;

        var publishRequest;

        try {
          publishRequest = target.publish(
            String(eventName || 'message'),
            payload || {}
          );
        } catch (error) {
          pendingPublishes = Math.max(
            0,
            pendingPublishes - 1
          );

          finishClose();

          return Promise.reject(error);
        }

        return Promise.resolve(publishRequest)
          .then(function (result) {
            return result;
          })
          .finally(function () {
            pendingPublishes = Math.max(
              0,
              pendingPublishes - 1
            );

            finishClose();
          });
      }

      /**
       * Public connection object.
       *
       * This preserves the interface already used by the project.
       */
      var connection = {
        client: client,

        channel: channels[0] || null,

        channels: channels,

        channelName: channelName,

        directPublish: !!initialTokenData.direct_publish,

        publish: function (eventName, payload) {
          return publishTo(channelName, eventName, payload);
        },

        publishTo: publishTo,

        isReady: function () {
          return !closed && !closeRequested && allChannelsAttached();
        },

        whenReady: waitForReady,

        close: function () {
          if (closed || closeRequested) {
            return;
          }

          closeRequested = true;
          settleReadyWaiters(new Error('Ably connection is closing.'));

          /**
           * Allow an already-started publish to finish.
           * Do not leave a connection open indefinitely.
           */
          if (pendingPublishes > 0) {
            closeTimer = window.setTimeout(function () {
              if (
                window.console &&
                typeof window.console.warn === 'function'
              ) {
                console.warn(
                  '[HelpCenter Ably] Closing after publish-drain timeout.',
                  {
                    pending: pendingPublishes
                  }
                );
              }

              pendingPublishes = 0;
              finishClose();
            }, 5000);
          }

          finishClose();
        }
      };

      return new Promise(function (resolve, reject) {
        resolveInitialConnection = resolve;
        rejectInitialConnection = reject;

        /**
         * A socket connection or channel attachment must not
         * leave the initial connect promise pending forever.
         */
        var connectTimeoutMs = Math.max(
          5000,
          Math.min(
            30000,
            Number(config.connectTimeoutMs) || 15000
          )
        );

        connectTimer = window.setTimeout(function () {
          failInitialConnection(
            new Error(
              'Ably connection or channel attachment timed out after ' +
              connectTimeoutMs +
              ' ms.'
            )
          );
        }, connectTimeoutMs);

        /**
         * Connection state listener.
         */
        var connectionStateHandler = function (stateChange) {
          if (!stateChange) {
            return;
          }

          var current = stateChange.current;
          var reason = stateChange.reason || null;

          if (
            current === 'failed' ||
            current === 'closed'
          ) {
            if (!initialSettled) {
              failInitialConnection(reason);
            } else {
              settleReadyWaiters(reason || new Error('Ably connection entered ' + current + ' state.'));
              reportState(current, reason);
            }

            return;
          }

          updateReadyState(reason);
        };

        client.connection.on(connectionStateHandler);

        /**
         * Track every channel's attachment state.
         *
         * This also handles channel reattachment after an Ably
         * reconnect. A socket reconnect alone is not enough.
         */
        channels.forEach(function (channel) {
          [
            'attached',
            'attaching',
            'detached',
            'failed',
            'suspended'
          ].forEach(function (eventName) {
            var handler = function (stateChange) {
              var reason = (
                stateChange &&
                stateChange.reason
              )
                ? stateChange.reason
                : null;

              updateReadyState(reason);
            };

            channel.on(eventName, handler);

            channelStateHandlers.push({
              channel: channel,
              event: eventName,
              handler: handler
            });
          });
        });

        /**
         * Subscribe to every authorized channel.
         *
         * Ably SDK v2 returns a Promise from subscribe().
         * Waiting for these promises ensures the initial connection
         * is not exposed to callers before channel attachment.
         */
        var subscriptions = channels.map(function (channel, index) {
          var subscribedChannelName = channelNames[index];

          var messageHandler = function (message) {
            if (
              closed ||
              typeof onEvent !== 'function'
            ) {
              return;
            }

            try {
              onEvent(
                message && message.data
                  ? message.data
                  : {},
                message && message.name
                  ? message.name
                  : '',
                subscribedChannelName
              );
            } catch (error) {
              if (window.console && console.error) {
                console.error(
                  '[HelpCenter Ably] Message callback failed.',
                  error
                );
              }
            }
          };

          messageHandlers.push({
            channel: channel,
            handler: messageHandler
          });

          try {
            return Promise.resolve(
              channel.subscribe(messageHandler)
            ).then(function () {
              updateReadyState();
              return channel;
            });
          } catch (error) {
            return Promise.reject(error);
          }
        });

        Promise.all(subscriptions)
          .then(function () {
            updateReadyState();
          })
          .catch(function (error) {
            failInitialConnection(error);
          });

        /**
         * Handle the case where the socket is already connected
         * before the listeners are registered.
         */
        updateReadyState();
      });
    });
  }

  window.HCRealtimeClient = {
    connect: connect
  };

})(window);