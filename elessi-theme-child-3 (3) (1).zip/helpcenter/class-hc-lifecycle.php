<?php
/**
 * Help Center - Lifecycle & Visibility (single source of truth)
 *
 * ONE RULE for what visitors can see:
 *   An item is public only if it AND everything above it is live.
 *     - Category : status = published, not trashed, and (if a subcategory) its parent is live too.
 *     - Article  : status = published, not trashed, and in at least one live category.
 *     - FAQ      : status = published, not trashed, and (if linked) its article / category is live.
 *
 * Hiding a category never rewrites its articles or FAQs. Publishing it again brings them back.
 *
 * TRASH / DELETE rules:
 *     - Trashing a category (and its subcategories) moves articles that would be left with no
 *       category into the default "Uncategorized" category. Restoring puts them back.
 *     - Permanently deleting a category detaches its FAQs (sent to trash) and cleans all links.
 *     - Permanently deleting an article sends its linked FAQs to trash and cleans votes + links.
 */

if (!defined('ABSPATH')) exit;

class HC_Lifecycle {

    // =============================================
    // SMALL HELPERS
    // =============================================
    private static function ints($ids) {
        return array_values(array_unique(array_filter(array_map('intval', (array) $ids))));
    }

    private static function in_list($ids) {
        return implode(',', self::ints($ids));
    }

    private static function tbl($name) {
        global $wpdb;
        return $wpdb->prefix . 'hc_' . $name;
    }

    // =============================================
    // VISIBILITY (SQL FRAGMENTS)
    // =============================================

    /**
     * SQL condition: category alias $a is live (published, not trashed, parent live).
     */
    public static function sql_category_live($a = 'c') {
        $cats = self::tbl('categories');
        $p    = $a . '_p';
        return "({$a}.deleted_at IS NULL AND {$a}.status = 'published' AND ({$a}.parent_id = 0 OR EXISTS ("
             . "SELECT 1 FROM {$cats} {$p} WHERE {$p}.id = {$a}.parent_id AND {$p}.deleted_at IS NULL AND {$p}.status = 'published')))";
    }

    /**
     * SQL condition: article alias $a is public.
     * Uses the article<->category relation table; falls back to articles.category_id for
     * any legacy article that has no relation rows yet.
     */
    public static function sql_article_live($a = 'a') {
        $cats = self::tbl('categories');
        $rel  = self::tbl('article_categories');
        $live1 = self::sql_category_live('lc1');
        $live2 = self::sql_category_live('lc2');
        return "({$a}.status = 'published' AND {$a}.deleted_at IS NULL AND ("
             . "EXISTS (SELECT 1 FROM {$rel} lr1 JOIN {$cats} lc1 ON lc1.id = lr1.category_id WHERE lr1.article_id = {$a}.id AND {$live1})"
             . " OR (NOT EXISTS (SELECT 1 FROM {$rel} lr2 WHERE lr2.article_id = {$a}.id)"
             . " AND EXISTS (SELECT 1 FROM {$cats} lc2 WHERE lc2.id = {$a}.category_id AND {$live2}))"
             . "))";
    }

    // =============================================
    // VISIBILITY (SINGLE ITEM CHECKS + ADMIN NOTES)
    // =============================================
    public static function category_is_live($cat_id) {
        global $wpdb;
        $cats = self::tbl('categories');
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT c.id FROM {$cats} c WHERE c.id = %d AND " . self::sql_category_live('c'),
            (int) $cat_id
        ));
    }

    public static function article_is_live($article_id) {
        global $wpdb;
        $arts = self::tbl('articles');
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT a.id FROM {$arts} a WHERE a.id = %d AND " . self::sql_article_live('a'),
            (int) $article_id
        ));
    }

    /**
     * Why an article is NOT visible to visitors. Empty string = it is visible.
     */
    public static function article_hidden_reason($article) {
        if (!$article) return 'Article no longer exists';
        if (!empty($article->deleted_at)) return 'Article is in the trash';
        if ($article->status === 'hidden') {
            if (!empty($article->category_hidden_status)) return 'All of its categories are hidden or in the trash';
            return 'Article is hidden';
        }
        if ($article->status !== 'published') return 'Article is a draft';
        if (!self::article_is_live($article->id)) return 'All of its categories are hidden or in the trash';
        return '';
    }

    /**
     * Why a FAQ is NOT visible to visitors. Empty string = it is visible.
     */
    public static function faq_hidden_reason($faq) {
        global $wpdb;
        if (!$faq) return 'FAQ no longer exists';
        if (!empty($faq->deleted_at)) return 'FAQ is in the trash';
        if ($faq->status !== 'published') return 'FAQ is a draft';

        if ($faq->destination_type === 'article' && $faq->destination_id) {
            $art = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . self::tbl('articles') . " WHERE id = %d", (int) $faq->destination_id
            ));
            if (!$art) return 'Its linked article no longer exists';
            $why = self::article_hidden_reason($art);
            if ($why !== '') return 'Linked article: ' . $why;
        }

        if ($faq->destination_type === 'category' && $faq->destination_id) {
            if (!self::category_is_live($faq->destination_id)) {
                return 'Its linked category is hidden or in the trash';
            }
        }
        return '';
    }

    /**
     * The category to show for an article (breadcrumb / badge): its primary category when live,
     * otherwise any live category, otherwise the stored primary (so the Uncategorized fallback works).
     */
    public static function primary_category($article) {
        global $wpdb;
        if (!$article) return null;
        $cats = self::tbl('categories');
        $rel  = self::tbl('article_categories');

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT c.* FROM {$rel} ac JOIN {$cats} c ON c.id = ac.category_id
             WHERE ac.article_id = %d AND " . self::sql_category_live('c') . "
             ORDER BY (c.id = %d) DESC, c.sort_order ASC, c.id ASC
             LIMIT 1",
            (int) $article->id, (int) $article->category_id
        ));
        if ($row) return $row;

        $fallback = HC_Core::get_category($article->category_id);
        return $fallback ? $fallback : null;
    }

    // =============================================
    // DEFAULT CATEGORY + SLUGS + COUNTS
    // =============================================

    /**
     * Returns the id of the default "Uncategorized" category, creating it if missing.
     */
    public static function ensure_default_category() {
        global $wpdb;
        $cats = self::tbl('categories');

        $id = (int) $wpdb->get_var("SELECT id FROM {$cats} WHERE is_default = 1 AND deleted_at IS NULL LIMIT 1");
        if ($id) return $id;

        // A trashed default? bring it back.
        $trashed = (int) $wpdb->get_var("SELECT id FROM {$cats} WHERE is_default = 1 LIMIT 1");
        if ($trashed) {
            $wpdb->update($cats, array('deleted_at' => null, 'status' => 'published', 'parent_id' => 0), array('id' => $trashed));
            return $trashed;
        }

        // An existing 'uncategorized' slug that isn't flagged yet? flag it.
        $by_slug = (int) $wpdb->get_var("SELECT id FROM {$cats} WHERE slug = 'uncategorized' LIMIT 1");
        if ($by_slug) {
            $wpdb->update($cats, array('is_default' => 1, 'deleted_at' => null, 'status' => 'published', 'parent_id' => 0), array('id' => $by_slug));
            return $by_slug;
        }

        $wpdb->insert($cats, array(
            'name'        => 'Uncategorized',
            'slug'        => 'uncategorized',
            'description' => '',
            'icon_type'   => 'fontawesome',
            'icon_value'  => 'fa-folder',
            'parent_id'   => 0,
            'sort_order'  => 999,
            'status'      => 'published',
            'is_default'  => 1,
        ));
        return (int) $wpdb->insert_id;
    }

    /**
     * Make $slug available in $table_suffix ('articles' | 'categories').
     * A trashed item holding the slug is renamed out of the way.
     * Returns false when an ACTIVE item already uses it.
     */
    public static function claim_slug($table_suffix, $slug, $exclude_id = 0) {
        global $wpdb;
        $t = self::tbl($table_suffix);
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT id, deleted_at FROM {$t} WHERE slug = %s AND id != %d LIMIT 1",
            $slug, (int) $exclude_id
        ));
        if (!$row) return true;
        if (!empty($row->deleted_at)) {
            $wpdb->update($t, array('slug' => $slug . '-trash-' . $row->id . '-' . time()), array('id' => $row->id));
            return true;
        }
        return false;
    }

    /**
     * Recount published articles for every category (relation table is the source of truth).
     */
    public static function recount_categories() {
        global $wpdb;
        $cats = self::tbl('categories');
        $arts = self::tbl('articles');
        $rel  = self::tbl('article_categories');
        $wpdb->query(
            "UPDATE {$cats} cc SET cc.article_count = (
                SELECT COUNT(DISTINCT ar.id) FROM {$rel} rr
                JOIN {$arts} ar ON ar.id = rr.article_id
                WHERE rr.category_id = cc.id AND ar.status = 'published' AND ar.deleted_at IS NULL
            )"
        );
    }

    // =============================================
    // ARTICLE <-> CATEGORY MEMBERSHIP
    // =============================================

    /**
     * Replace an article's categories with $cat_ids.
     */
    public static function set_article_categories($article_id, $cat_ids) {
        global $wpdb;
        $rel = self::tbl('article_categories');
        $article_id = (int) $article_id;
        if (!$article_id) return;

        $wpdb->delete($rel, array('article_id' => $article_id), array('%d'));
        foreach (self::ints($cat_ids) as $cid) {
            $wpdb->insert($rel, array('article_id' => $article_id, 'category_id' => $cid), array('%d', '%d'));
        }
    }

    /**
     * Keep an article consistent: it must belong to at least one non-trashed category
     * (falls back to Uncategorized) and articles.category_id must point at one of them.
     */
    public static function normalize_article($article_id) {
        global $wpdb;
        $article_id = (int) $article_id;
        if (!$article_id) return;

        $arts = self::tbl('articles');
        $cats = self::tbl('categories');
        $rel  = self::tbl('article_categories');

        $member = array_map('intval', (array) $wpdb->get_col($wpdb->prepare(
            "SELECT ac.category_id FROM {$rel} ac JOIN {$cats} c ON c.id = ac.category_id
             WHERE ac.article_id = %d AND c.deleted_at IS NULL
             ORDER BY ac.category_id ASC",
            $article_id
        )));

        if (empty($member)) {
            $default = self::ensure_default_category();
            $has = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$rel} WHERE article_id = %d AND category_id = %d", $article_id, $default
            ));
            if (!$has) {
                $wpdb->insert($rel, array('article_id' => $article_id, 'category_id' => $default), array('%d', '%d'));
            }
            $member = array($default);
        }

        $current = (int) $wpdb->get_var($wpdb->prepare("SELECT category_id FROM {$arts} WHERE id = %d", $article_id));
        if (!in_array($current, $member, true)) {
            $wpdb->update($arts, array('category_id' => $member[0]), array('id' => $article_id));
        }

        $sub = (int) $wpdb->get_var($wpdb->prepare("SELECT subcategory_id FROM {$arts} WHERE id = %d", $article_id));
        if ($sub && !in_array($sub, $member, true)) {
            $wpdb->update($arts, array('subcategory_id' => null), array('id' => $article_id));
        }
    }

    // =============================================
    // CATEGORIES
    // =============================================

    /** Category id + its direct subcategories (max 2 levels). */
    public static function tree_ids($cat_id) {
        global $wpdb;
        $cat_id = (int) $cat_id;
        $subs = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . self::tbl('categories') . " WHERE parent_id = %d", $cat_id
        ));
        return self::ints(array_merge(array($cat_id), (array) $subs));
    }

    private static function strip_default($ids) {
        $default = self::ensure_default_category();
        return array_values(array_diff(self::ints($ids), array($default)));
    }

    /**
     * Publish or hide categories. Nothing else is rewritten - visibility is computed.
     * Returns number of categories changed.
     */
    public static function sync_articles_for_category_visibility($category_ids) {
        global $wpdb;
        $ids = self::ints($category_ids);
        if (!$ids) return;
        $in = implode(',', $ids);
        $arts = self::tbl('articles');
        $rel = self::tbl('article_categories');
        $article_ids = self::ints(array_merge((array) $wpdb->get_col("SELECT DISTINCT article_id FROM {$rel} WHERE category_id IN ({$in})"), (array) $wpdb->get_col("SELECT id FROM {$arts} WHERE category_id IN ({$in})")));
        foreach ($article_ids as $aid) {
            $article = $wpdb->get_row($wpdb->prepare("SELECT id,status,deleted_at,category_hidden_status FROM {$arts} WHERE id=%d", $aid));
            if (!$article || !empty($article->deleted_at)) continue;
            $live_count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT ac.category_id) FROM {$rel} ac JOIN " . self::tbl('categories') . " c ON c.id=ac.category_id WHERE ac.article_id=%d AND " . self::sql_category_live('c'), $aid
            ));
            if ($live_count === 0 && in_array($article->status, array('published','draft'), true)) {
                $wpdb->update($arts, array('category_hidden_status' => $article->status, 'status' => 'hidden', 'updated_at' => current_time('mysql')), array('id' => $aid));
                HC_Core::log_action('article', $aid, 'Hidden because all categories are hidden');
            } elseif ($live_count > 0 && $article->status === 'hidden' && in_array($article->category_hidden_status, array('published','draft'), true)) {
                $restore_status = $article->category_hidden_status;
                $wpdb->update($arts, array('status' => $restore_status, 'category_hidden_status' => null, 'updated_at' => current_time('mysql')), array('id' => $aid));
                HC_Core::log_action('article', $aid, $restore_status === 'published' ? 'Published after category became visible' : 'Restored as Draft after category became visible');
            }
        }
    }

    public static function set_categories_status($ids, $status) {
        global $wpdb;
        if (!in_array($status, array('published', 'hidden'), true)) return 0;
        $ids = self::strip_default($ids);
        if (empty($ids)) return 0;
        $affected = array();
        foreach ($ids as $cid) $affected = array_merge($affected, self::tree_ids($cid));
        $affected = self::ints($affected);
        $in = implode(',', $ids);
        $wpdb->query($wpdb->prepare(
            "UPDATE " . self::tbl('categories') . " SET status = %s, updated_at = %s WHERE id IN ({$in}) AND deleted_at IS NULL AND status != %s",
            $status, current_time('mysql'), $status
        ));
        foreach ($ids as $cid) {
            HC_Core::log_action('category', $cid, $status === 'published' ? 'Published' : 'Hidden');
        }
        self::sync_articles_for_category_visibility($affected);
        self::recount_categories();
        return count($ids);
    }

    /**
     * Move categories (and their subcategories) to the trash.
     * Articles left with no category are moved to Uncategorized (and remember where they came from).
     * Returns array('trashed' => n, 'reassigned' => n).
     */
    public static function trash_categories($ids) {
        global $wpdb;
        $cats = self::tbl('categories');
        $arts = self::tbl('articles');
        $rel  = self::tbl('article_categories');

        $ids = self::strip_default($ids);
        $trashed = 0;
        $reassigned = 0;
        if (empty($ids)) return array('trashed' => 0, 'reassigned' => 0);

        $now = current_time('mysql');

        foreach ($ids as $cid) {
            $exists = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$cats} WHERE id = %d AND deleted_at IS NULL", $cid));
            if (!$exists) continue;

            $tree = self::tree_ids($cid);
            $in   = implode(',', $tree);

            // Trash the category and the subcategories that are still active.
            $wpdb->query($wpdb->prepare(
                "UPDATE {$cats} SET deleted_at = %s WHERE id IN ({$in}) AND deleted_at IS NULL", $now
            ));

            // Articles that were in this tree
            $article_ids = self::ints($wpdb->get_col("SELECT DISTINCT article_id FROM {$rel} WHERE category_id IN ({$in})"));
            foreach ($article_ids as $aid) {
                $left = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$rel} ac JOIN {$cats} c ON c.id = ac.category_id
                     WHERE ac.article_id = %d AND c.deleted_at IS NULL", $aid
                ));
                if ($left === 0) {
                    $came_from = (int) $wpdb->get_var($wpdb->prepare(
                        "SELECT category_id FROM {$rel} WHERE article_id = %d AND category_id IN ({$in}) ORDER BY category_id ASC LIMIT 1", $aid
                    ));
                    $wpdb->update($arts, array('original_category_id' => $came_from ? $came_from : $cid), array('id' => $aid));
                    $reassigned++;
                }
                self::normalize_article($aid);
            }

            HC_Core::log_action('category', $cid, 'Moved to Trash');
            $trashed++;
        }

        self::recount_categories();
        return array('trashed' => $trashed, 'reassigned' => $reassigned);
    }

    /**
     * Restore categories from trash as HIDDEN, re-link the articles that were moved to Uncategorized.
     * Returns array('restored' => n, 'relinked' => n).
     */
    public static function restore_categories($ids) {
        global $wpdb;
        $cats = self::tbl('categories');
        $arts = self::tbl('articles');
        $rel  = self::tbl('article_categories');

        $default = self::ensure_default_category();
        $restored = 0;
        $relinked = 0;

        foreach (self::ints($ids) as $cid) {
            if ($cid === $default) continue;
            $row = $wpdb->get_row($wpdb->prepare("SELECT id, parent_id, deleted_at FROM {$cats} WHERE id = %d", $cid));
            if (!$row || empty($row->deleted_at)) continue;

            // Restore it + the subcategories that were trashed together with it.
            $tree = array($cid);
            $subs = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$cats} WHERE parent_id = %d AND deleted_at = %s", $cid, $row->deleted_at
            ));
            $tree = self::ints(array_merge($tree, (array) $subs));
            $in = implode(',', $tree);

            // A subcategory whose parent is still trashed becomes top-level.
            if ((int) $row->parent_id > 0) {
                $parent_alive = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$cats} WHERE id = %d AND deleted_at IS NULL", (int) $row->parent_id
                ));
                if (!$parent_alive) {
                    $wpdb->update($cats, array('parent_id' => 0), array('id' => $cid));
                }
            }

            $wpdb->query($wpdb->prepare(
                "UPDATE {$cats} SET deleted_at = NULL, status = 'hidden', updated_at = %s WHERE id IN ({$in})",
                current_time('mysql')
            ));

            // Re-link articles that were parked in Uncategorized.
            $parked = $wpdb->get_results(
                "SELECT id, original_category_id FROM {$arts} WHERE original_category_id IN ({$in})"
            );
            foreach ($parked as $p) {
                $orig = (int) $p->original_category_id;
                $has = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$rel} WHERE article_id = %d AND category_id = %d", $p->id, $orig
                ));
                if (!$has) {
                    $wpdb->insert($rel, array('article_id' => (int) $p->id, 'category_id' => $orig), array('%d', '%d'));
                }
                // Remove the temporary Uncategorized link (only if it was the fallback).
                $wpdb->delete($rel, array('article_id' => (int) $p->id, 'category_id' => $default), array('%d', '%d'));
                $wpdb->update($arts, array('category_id' => $orig, 'original_category_id' => null), array('id' => (int) $p->id));
                self::normalize_article($p->id);
                $relinked++;
            }

            HC_Core::log_action('category', $cid, 'Restored from Trash');
            $restored++;
        }

        self::recount_categories();
        return array('restored' => $restored, 'relinked' => $relinked);
    }

    /**
     * Permanently delete categories (+ subcategories). FAQs pointing at them go to the trash,
     * articles keep living (moved to Uncategorized if they have nowhere else).
     */
    public static function hard_delete_categories($ids) {
        global $wpdb;
        $cats = self::tbl('categories');
        $arts = self::tbl('articles');
        $rel  = self::tbl('article_categories');

        $ids = self::strip_default($ids);
        $count = 0;

        foreach ($ids as $cid) {
            $tree = self::tree_ids($cid);
            $in   = implode(',', $tree);

            $article_ids = self::ints($wpdb->get_col("SELECT DISTINCT article_id FROM {$rel} WHERE category_id IN ({$in})"));

            // FAQs first (needs the category rows to still exist for subcategory lookup)
            HC_Core::detach_faqs_from_category($cid, 'Category was permanently deleted');

            $wpdb->query("DELETE FROM {$rel} WHERE category_id IN ({$in})");
            $wpdb->query("UPDATE {$arts} SET original_category_id = NULL WHERE original_category_id IN ({$in})");
            $wpdb->query("DELETE FROM {$cats} WHERE id IN ({$in})");

            foreach ($article_ids as $aid) {
                self::normalize_article($aid);
            }
            $count++;
        }

        self::recount_categories();
        return $count;
    }

    // =============================================
    // ARTICLES
    // =============================================
    public static function set_articles_status($ids, $status) {
        global $wpdb;
        if (!in_array($status, array('published', 'draft'), true)) return 0;
        $ids = self::ints($ids);
        if (empty($ids)) return 0;
        $in = implode(',', $ids);
        $changed_ids = self::ints($wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . self::tbl('articles') . " WHERE id IN ({$in}) AND deleted_at IS NULL AND status != %s", $status
        )));
        if (empty($changed_ids)) return 0;
        $changed_in = implode(',', $changed_ids);
        $wpdb->query($wpdb->prepare(
            "UPDATE " . self::tbl('articles') . " SET status = %s, category_hidden_status = NULL, updated_at = %s WHERE id IN ({$changed_in}) AND deleted_at IS NULL AND status != %s",
            $status, current_time('mysql'), $status
        ));
        $changed = (int) $wpdb->rows_affected;
        foreach ($changed_ids as $aid) {
            HC_Core::log_action('article', $aid, $status === 'published' ? 'Published' : 'Moved to Draft');
        }
        self::recount_categories();
        return $changed;
    }

    public static function trash_articles($ids) {
        global $wpdb;
        $ids = self::ints($ids);
        if (empty($ids)) return 0;
        $in = implode(',', $ids);
        $wpdb->query($wpdb->prepare(
            "UPDATE " . self::tbl('articles') . " SET deleted_at = %s WHERE id IN ({$in}) AND deleted_at IS NULL",
            current_time('mysql')
        ));
        foreach ($ids as $aid) {
            HC_Core::log_action('article', $aid, 'Moved to Trash');
        }
        self::recount_categories();
        return count($ids);
    }

    public static function restore_articles($ids) {
        global $wpdb;
        $ids = self::ints($ids);
        if (empty($ids)) return 0;
        $in = implode(',', $ids);
        $wpdb->query($wpdb->prepare(
            "UPDATE " . self::tbl('articles') . " SET deleted_at = NULL, status = 'draft', updated_at = %s WHERE id IN ({$in})",
            current_time('mysql')
        ));
        foreach ($ids as $aid) {
            self::normalize_article($aid);
            HC_Core::log_action('article', $aid, 'Restored from Trash');
        }
        self::recount_categories();
        return count($ids);
    }

    public static function hard_delete_articles($ids) {
        global $wpdb;
        $arts = self::tbl('articles');
        $faqs = self::tbl('faqs');
        $ids  = self::ints($ids);
        $count = 0;

        foreach ($ids as $aid) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT id, title FROM {$arts} WHERE id = %d", $aid));
            if (!$row) continue;
            $title = (string) $row->title;

            // Linked FAQs -> trash (as drafts, with a reason)
            $linked = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$faqs} WHERE destination_type = 'article' AND destination_id = %d AND deleted_at IS NULL", $aid
            ));
            foreach ((array) $linked as $fid) {
                $wpdb->update($faqs, array('status' => 'draft', 'deleted_at' => current_time('mysql')), array('id' => (int) $fid));
                HC_Core::log_faq_draft_reason((int) $fid, 'Linked article "' . wp_trim_words($title, 6) . '" was permanently deleted');
            }

            $wpdb->delete(self::tbl('article_categories'), array('article_id' => $aid), array('%d'));
            $wpdb->delete(self::tbl('helpful_votes'), array('article_id' => $aid), array('%d'));
            $wpdb->delete($arts, array('id' => $aid), array('%d'));
            $count++;
        }

        self::recount_categories();
        return $count;
    }

    // =============================================
    // FAQS
    // =============================================
    public static function set_faqs_status($ids, $status) {
        global $wpdb;
        if (!in_array($status, array('published', 'draft'), true)) return 0;
        $ids = self::ints($ids);
        if (empty($ids)) return 0;
        $in = implode(',', $ids);
        $wpdb->query($wpdb->prepare(
            "UPDATE " . self::tbl('faqs') . " SET status = %s, updated_at = %s WHERE id IN ({$in}) AND deleted_at IS NULL AND status != %s",
            $status, current_time('mysql'), $status
        ));
        $changed = (int) $wpdb->rows_affected;
        if ($changed > 0) {
            foreach ($ids as $fid) {
                HC_Core::log_action('faq', $fid, $status === 'published' ? 'Published' : 'Moved to Draft');
            }
        }
        return $changed;
    }

    public static function trash_faqs($ids) {
        global $wpdb;
        $ids = self::ints($ids);
        if (empty($ids)) return 0;
        $in = implode(',', $ids);
        $wpdb->query($wpdb->prepare(
            "UPDATE " . self::tbl('faqs') . " SET deleted_at = %s WHERE id IN ({$in}) AND deleted_at IS NULL",
            current_time('mysql')
        ));
        foreach ($ids as $fid) {
            HC_Core::log_action('faq', $fid, 'Moved to Trash');
        }
        return count($ids);
    }

    public static function restore_faqs($ids) {
        global $wpdb;
        $ids = self::ints($ids);
        if (empty($ids)) return 0;
        $in = implode(',', $ids);
        $wpdb->query("UPDATE " . self::tbl('faqs') . " SET deleted_at = NULL, status = 'draft' WHERE id IN ({$in})");
        foreach ($ids as $fid) {
            HC_Core::log_action('faq', $fid, 'Restored from Trash');
        }
        return count($ids);
    }

    public static function hard_delete_faqs($ids) {
        global $wpdb;
        $ids = self::ints($ids);
        if (empty($ids)) return 0;
        $in = implode(',', $ids);
        $wpdb->query("DELETE FROM " . self::tbl('faqs') . " WHERE id IN ({$in})");
        return count($ids);
    }

    // =============================================
    // EMPTY TRASH
    // =============================================
    public static function empty_trash($type) {
        global $wpdb;
        $count = 0;

        if ($type === 'articles' || $type === 'all') {
            $ids = $wpdb->get_col("SELECT id FROM " . self::tbl('articles') . " WHERE deleted_at IS NOT NULL");
            $count += self::hard_delete_articles($ids);
        }
        if ($type === 'faqs' || $type === 'all') {
            $ids = $wpdb->get_col("SELECT id FROM " . self::tbl('faqs') . " WHERE deleted_at IS NOT NULL");
            $count += self::hard_delete_faqs($ids);
        }
        if ($type === 'categories' || $type === 'all') {
            $ids = $wpdb->get_col("SELECT id FROM " . self::tbl('categories') . " WHERE deleted_at IS NOT NULL");
            $count += self::hard_delete_categories($ids);
        }
        return $count;
    }
}
