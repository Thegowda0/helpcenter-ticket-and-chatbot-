<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/assets/js/frontend.js';
$src = file_get_contents($file);
$orig = $src;

// 1. Replace "var data = window.hcData || {};" with a safer accessor
$src = preg_replace(
    '/(var\s+data\s*=\s*window\.hcData\s*\|\|\s*\{\};)/',
    '// Use a getter so it always resolves at call-time, not at load-time
    function hcApi() { return window.hcData || {}; }',
    $src, 1, $c1
);

// 2. Also replace any bare "data." references with "hcApi()."
// Be careful — only replace where it's clearly reading from the global
$src = preg_replace('/\bdata\.ajaxUrl\b/', 'hcApi().ajaxUrl', $src);
$src = preg_replace('/\bdata\.nonce\b/', 'hcApi().nonce', $src);
$src = preg_replace('/\bdata\.homeUrl\b/', 'hcApi().homeUrl', $src);

// 3. Force the initializer to run even if DOMContentLoaded already fired
$needle = "document.addEventListener('DOMContentLoaded', function() {";
$pos = strpos($src, $needle);
if ($pos !== false) {
    $guard = "document.addEventListener('DOMContentLoaded', function() {\n        hcInit();\n    });\n\n    function hcInit() {";
    $src = substr_replace($src, $guard, $pos, strlen($needle));
    // close extra brace at the end (the original closing "});")
    // The original DOMContentLoaded body ended with "});" — now that's "}"
    $src = preg_replace('/\}\);\s*$/', '}\n})();', $src, 1);
}

if ($src === $orig) {
    echo "WARN: no changes made — patterns may not match. Manual inspect needed.\n";
    exit(1);
}

file_put_contents($file, $src);
echo "OK: JS scoping fixed ($c1 var replaced).\n";
