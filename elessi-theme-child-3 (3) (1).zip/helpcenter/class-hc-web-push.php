<?php
/** HelpCenter Web Push (VAPID + Minishlink WebPush). */
if (!defined('ABSPATH')) exit;

final class HC_Web_Push {
    const OPTION = 'hc_web_push_vapid_keys_v1';
    const TABLE_SUFFIX = 'hc_web_push_subscriptions';
    const VERSION = '1.3.0';
    const PRESENCE_SUFFIX = 'hc_web_push_presence';
    private static $queued_sends = array();
    private static $send_shutdown_registered = false;

    public static function register() {
        add_action('init', array(__CLASS__, 'maybe_create_table'), 8);
        self::register_sw_route();
        add_filter('query_vars', array(__CLASS__, 'query_vars'));
        add_action('template_redirect', array(__CLASS__, 'serve_service_worker'), 0);
        add_action('wp_ajax_hc_web_push_subscribe', array(__CLASS__, 'subscribe'));
        add_action('wp_ajax_nopriv_hc_web_push_subscribe', array(__CLASS__, 'subscribe'));
        add_action('wp_ajax_hc_web_push_presence', array(__CLASS__, 'presence'));
        add_action('wp_ajax_nopriv_hc_web_push_presence', array(__CLASS__, 'presence'));
        add_action('wp_ajax_hc_web_push_unsubscribe', array(__CLASS__, 'unsubscribe'));
        add_action('hc_web_push_send_queued', array(__CLASS__, 'run_queued_send'), 10, 1);
        add_action('wp_ajax_hc_web_push_generate_keys', array(__CLASS__, 'generate_keys_ajax'));
        add_action('wp_ajax_hc_web_push_install_dependency', array(__CLASS__, 'install_dependency_ajax'));
        add_action('wp_footer', array(__CLASS__, 'print_client_bootstrap'), 99);
    }

    public static function table() { global $wpdb; return $wpdb->prefix . self::TABLE_SUFFIX; }
    public static function presence_table() { global $wpdb; return $wpdb->prefix . self::PRESENCE_SUFFIX; }

    public static function maybe_create_table() {
        if (get_option('hc_web_push_db_version') === self::VERSION) return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table(); $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            endpoint_hash char(64) NOT NULL,
            endpoint text NOT NULL,
            public_key varchar(255) NOT NULL,
            auth_token varchar(255) NOT NULL,
            content_encoding varchar(32) NOT NULL DEFAULT 'aes128gcm',
            audience_type varchar(20) NOT NULL DEFAULT 'customer',
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            visitor_id varchar(96) NOT NULL DEFAULT '',
            ticket_id bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY endpoint_hash (endpoint_hash),
            KEY audience_user (audience_type,user_id),
            KEY visitor_id (visitor_id),
            KEY ticket_id (ticket_id)
        ) {$charset};";
        dbDelta($sql);
        $presence = self::presence_table();
        $presence_sql = "CREATE TABLE {$presence} (
            endpoint_hash char(64) NOT NULL,
            client_id varchar(64) NOT NULL,
            audience_type varchar(20) NOT NULL DEFAULT 'customer',
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            visitor_id varchar(96) NOT NULL DEFAULT '',
            active_ticket_id bigint(20) unsigned NOT NULL DEFAULT 0,
            is_visible tinyint(1) NOT NULL DEFAULT 0,
            last_seen_at datetime NOT NULL,
            PRIMARY KEY  (endpoint_hash,client_id),
            KEY active_ticket (active_ticket_id,is_visible,last_seen_at),
            KEY audience_user (audience_type,user_id)
        ) {$charset};";
        dbDelta($presence_sql);
        update_option('hc_web_push_db_version', self::VERSION, false);
    }

    public static function query_vars($vars) { $vars[] = 'hc_web_push_sw'; return $vars; }
    public static function register_sw_route() {
        add_rewrite_rule('^hc-web-push-sw\.js$', 'index.php?hc_web_push_sw=1', 'top');
        if (get_option('hc_web_push_rewrite_flushed') !== self::VERSION) { flush_rewrite_rules(false); update_option('hc_web_push_rewrite_flushed', self::VERSION, false); }
    }

    public static function serve_service_worker() {
        if (!get_query_var('hc_web_push_sw')) return;
        $scope = trailingslashit(home_url('/'));
        header('Content-Type: application/javascript; charset=utf-8');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Service-Worker-Allowed: /');
        echo "'use strict';\n";
        echo "self.addEventListener('push',function(event){var data={};try{data=event.data?event.data.json():{}}catch(e){data={body:event.data?event.data.text():''}};var title=data.title||'HelpCenter support update';var options={body:data.body||'You have a new support message.',icon:data.icon||'',badge:data.badge||'',tag:data.tag||('hc-push-'+Date.now()),renotify:!!data.renotify,timestamp:Number(data.timestamp)||Date.now(),data:{url:data.url||" . wp_json_encode($scope) . ",ticketId:data.ticketId||0},requireInteraction:!!data.requireInteraction};event.waitUntil(self.registration.showNotification(title,options));});\n";
        echo "self.addEventListener('notificationclick',function(event){event.notification.close();var url=(event.notification.data&&event.notification.data.url)||" . wp_json_encode($scope) . ";event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(function(list){for(var i=0;i<list.length;i++){if('focus'in list[i])return list[i].focus().then(function(c){if(c&&'navigate'in c&&url)c.navigate(url);return c;});}return clients.openWindow?clients.openWindow(url):undefined;}));});\n";

        exit;
    }

    public static function keys() {
        $keys = get_option(self::OPTION, array());
        if (!is_array($keys) || empty($keys['publicKey']) || empty($keys['privateKey'])) return array();
        return $keys;
    }

    public static function generate_keys() {
        if (!class_exists('Minishlink\\WebPush\\VAPID')) return new WP_Error('hc_webpush_dependency', 'Install the bundled Web Push dependency with Composer first.');
        try {
            $keys = \Minishlink\WebPush\VAPID::createVapidKeys();
            if (empty($keys['publicKey']) || empty($keys['privateKey'])) return new WP_Error('hc_webpush_keys', 'VAPID key generation returned incomplete keys.');
            update_option(self::OPTION, array('publicKey'=>$keys['publicKey'],'privateKey'=>$keys['privateKey'],'subject'=>self::subject()), false);
            return $keys;
        } catch (Throwable $e) { return new WP_Error('hc_webpush_keys', $e->getMessage()); }
    }

    private static function subject() {
        $admin = get_option('admin_email');
        return 'mailto:' . (is_email($admin) ? $admin : 'admin@example.com');
    }

    /** Return a compact, administrator-safe dependency status. */
    public static function dependency_status() {
        $autoload = __DIR__ . '/vendor/autoload.php';
        if (file_exists($autoload)) require_once $autoload;
        $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
        $runner = (function_exists('proc_open') && !in_array('proc_open', $disabled, true)) ? 'proc_open' : ((function_exists('exec') && !in_array('exec', $disabled, true)) ? 'exec' : null);
        $cli_php = $runner ? self::find_cli_php($runner) : false;
        return array(
            'installed' => class_exists('Minishlink\\WebPush\\WebPush'),
            'writable' => is_writable(__DIR__),
            'php' => PHP_VERSION,
            'openssl' => extension_loaded('openssl'),
            'curl' => extension_loaded('curl'),
            'mbstring' => extension_loaded('mbstring'),
            'process_runner' => (bool)$runner,
            'php_cli' => (bool)$cli_php,
            'php_cli_path' => $cli_php ? $cli_php : '',
        );
    }

    /** Install Composer dependencies from the HelpCenter admin without terminal access. */
    public static function install_dependency_ajax() {
        if (!current_user_can('manage_options')) wp_send_json_error(array('message'=>'Administrator permission required.'),403);
        check_ajax_referer('hc_web_push_admin','nonce');
        $status = self::dependency_status();
        if ($status['installed']) {
            if (!self::keys()) { $generated = self::generate_keys(); if (is_wp_error($generated)) wp_send_json_error(array('message'=>$generated->get_error_message()),500); }
            wp_send_json_success(array('message'=>'Web Push engine is installed and VAPID keys are ready.'));
        }
        if (version_compare(PHP_VERSION, '8.2.0', '<')) wp_send_json_error(array('message'=>'This server needs PHP 8.2 or newer for the current Web Push engine. Ask your hosting provider to select PHP 8.2+ for this website.'),500);
        if (!$status['openssl'] || !$status['curl'] || !$status['mbstring']) wp_send_json_error(array('message'=>'The server must enable PHP OpenSSL, cURL, and mbstring extensions. Please ask your hosting provider to enable the missing extension(s); no terminal command is required.'),500);
        if (!is_writable(__DIR__)) wp_send_json_error(array('message'=>'The HelpCenter directory is not writable by PHP. Please allow WordPress to write to the HelpCenter directory or ask your hosting provider to fix its file permissions.'),500);

        $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
        $runner = (function_exists('proc_open') && !in_array('proc_open', $disabled, true)) ? 'proc_open' : ((function_exists('exec') && !in_array('exec', $disabled, true)) ? 'exec' : null);
        if (!$runner) wp_send_json_error(array('message'=>'Your hosting provider has disabled PHP process execution, so WordPress cannot run Composer automatically. Ask the host to enable proc_open for this one-time installation, or ask them to install the dependency. The rest of HelpCenter does not need terminal access.'),500);

        $temp_dir = function_exists('sys_get_temp_dir') ? sys_get_temp_dir() : __DIR__;
        $composer = rtrim($temp_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'hc-composer-' . substr(hash('sha256', __DIR__), 0, 12) . '.phar';
        if (!file_exists($composer) || filesize($composer) < 100000) {
            $response = wp_remote_get('https://getcomposer.org/download/latest-stable/composer.phar', array('timeout'=>90, 'redirection'=>3, 'limit_response_size'=>12000000, 'user-agent'=>'HelpCenter-WebPush-Installer/'.self::VERSION));
            if (is_wp_error($response)) wp_send_json_error(array('message'=>'Could not download Composer securely: '.$response->get_error_message()),500);
            $code = (int) wp_remote_retrieve_response_code($response);
            $binary = wp_remote_retrieve_body($response);
            if ($code !== 200 || strlen($binary) < 100000 || strpos(substr($binary,0,160), '<?php') === false) wp_send_json_error(array('message'=>'Composer download could not be verified. Please try again later or contact your hosting provider.'),500);
            $checksum_response = wp_remote_get('https://getcomposer.org/download/latest-stable/composer.phar.sha256', array('timeout'=>30, 'redirection'=>3, 'limit_response_size'=>512, 'user-agent'=>'HelpCenter-WebPush-Installer/'.self::VERSION));
            if (is_wp_error($checksum_response) || (int)wp_remote_retrieve_response_code($checksum_response) !== 200) wp_send_json_error(array('message'=>'Could not verify the official Composer download checksum. Please retry later.'),500);
            $expected_checksum = strtolower(trim((string)wp_remote_retrieve_body($checksum_response)));
            if (!preg_match('/^[a-f0-9]{64}$/', $expected_checksum) || !hash_equals($expected_checksum, hash('sha256', $binary))) wp_send_json_error(array('message'=>'Composer checksum verification failed. The installer was not executed.'),500);
            if (file_put_contents($composer, $binary, LOCK_EX) === false) wp_send_json_error(array('message'=>'Could not save the verified Composer installer in the server temporary directory.'),500);
        }

        // PHP_BINARY under PHP-FPM commonly points to php-fpm8.x, which is
        // not a CLI interpreter and cannot execute Composer. Discover and test
        // a real CLI binary instead of blindly trusting PHP_BINARY.
        $php = !empty($status['php_cli_path']) ? $status['php_cli_path'] : false;
        if (!$php) {
            wp_send_json_error(array('message'=>'The website is running PHP-FPM, but a PHP CLI executable could not be found. HelpCenter checked common PHP CLI locations and did not use php-fpm. Ask your hosting provider to enable the matching PHP CLI binary (for example /usr/bin/php8.3) for this website. No settings or keys were changed.'),500);
        }
        $command = escapeshellarg($php).' '.escapeshellarg($composer).' install --no-dev --no-scripts --optimize-autoloader --no-interaction --no-progress --prefer-dist --working-dir='.escapeshellarg(__DIR__);
        if (function_exists('set_time_limit')) @set_time_limit(0);
        $output = '';
        $exit_code = 1;
        if ($runner === 'proc_open') {
            $log_file = rtrim($temp_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'hc-composer-' . substr(hash('sha256', __DIR__), 0, 12) . '.log';
            $descriptors = array(0=>array('pipe','r'),1=>array('file',$log_file,'a'),2=>array('file',$log_file,'a'));
            $composer_home = rtrim($temp_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'hc-composer-home-' . substr(hash('sha256', __DIR__), 0, 12);
            if (!is_dir($composer_home)) @mkdir($composer_home, 0700, true);
            $env = array('PATH'=>(string)(getenv('PATH') ?: '/usr/local/bin:/usr/bin:/bin'),'HOME'=>(string)(getenv('HOME') ?: $temp_dir),'COMPOSER_HOME'=>$composer_home,'COMPOSER_ALLOW_SUPERUSER'=>'1');
            if (getenv('TMPDIR')) $env['TMPDIR'] = (string)getenv('TMPDIR');
            if (getenv('SystemRoot')) $env['SystemRoot'] = (string)getenv('SystemRoot');
            $process = @proc_open($command, $descriptors, $pipes, __DIR__, $env);
            if (is_resource($process)) {
                fclose($pipes[0]);
                $exit_code = proc_close($process);
                $output = is_file($log_file) ? (string)file_get_contents($log_file) : '';
                if (is_file($log_file)) @unlink($log_file);
            } else $output = 'PHP proc_open could not start Composer.';
        } else {
            $line = $command.' 2>&1';
            $lines=array(); $exit_code=1; @exec($line, $lines, $exit_code); $output=implode("\n",$lines);
        }
        if ($exit_code !== 0 || !file_exists(__DIR__.'/vendor/autoload.php')) {
            $tail = function_exists('mb_substr') ? mb_substr($output,-1800) : substr($output,-1800);
            wp_send_json_error(array('message'=>'Composer could not finish installing the Web Push library. '.($tail ? 'Details: '.$tail : 'Check the hosting PHP execution and outbound HTTPS settings.')),500);
        }
        require_once __DIR__.'/vendor/autoload.php';
        if (!class_exists('Minishlink\\WebPush\\WebPush')) wp_send_json_error(array('message'=>'Composer completed, but the Web Push library could not be loaded. Check the generated vendor directory.'),500);
        $keys = self::keys();
        if (!$keys) { $generated = self::generate_keys(); if (is_wp_error($generated)) wp_send_json_error(array('message'=>'The Web Push engine installed, but VAPID key generation failed: '.$generated->get_error_message()),500); }
        if (is_file($composer)) @unlink($composer);
        wp_send_json_success(array('message'=>'Setup complete. HelpCenter installed the Web Push engine and generated your VAPID keys automatically. No terminal or manual key configuration was needed.'));
    }


    /** Find a working PHP CLI binary; never mistake the FPM daemon for CLI PHP. */
    private static function find_cli_php($runner) {
        $candidates = array();
        if (defined('PHP_BINDIR') && PHP_BINDIR) $candidates[] = rtrim(PHP_BINDIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'php';
        if (defined('PHP_BINARY') && PHP_BINARY) {
            $binary_dir = dirname(PHP_BINARY);
            $candidates[] = $binary_dir . DIRECTORY_SEPARATOR . 'php';
            // PHP_BINARY may itself be php-fpm; only test sibling CLI names.
        }
        foreach (array('php', 'php8.4', 'php8.3', 'php8.2', 'php8.1', '/usr/bin/php', '/usr/local/bin/php', '/usr/bin/php8.4', '/usr/bin/php8.3', '/usr/bin/php8.2', '/usr/local/bin/php83', '/opt/cpanel/ea-php84/root/usr/bin/php', '/opt/cpanel/ea-php83/root/usr/bin/php', '/opt/cpanel/ea-php82/root/usr/bin/php') as $candidate) {
            $candidates[] = $candidate;
        }
        $seen = array();
        foreach ($candidates as $candidate) {
            $candidate = trim((string)$candidate);
            if ($candidate === '' || isset($seen[$candidate])) continue;
            $seen[$candidate] = true;
            // Do not execute obvious FPM/CGI binaries as the Composer interpreter.
            if (preg_match('/php(?:-fpm|fpm|cgi)(?:[0-9.]*)$/i', basename($candidate))) continue;
            $probe = escapeshellarg($candidate) . ' -r ' . escapeshellarg('echo PHP_SAPI . "|" . PHP_VERSION;');
            $output = '';
            $code = 1;
            if ($runner === 'proc_open') {
                $descriptors = array(0=>array('pipe','r'),1=>array('pipe','w'),2=>array('pipe','w'));
                $proc = @proc_open($probe, $descriptors, $pipes, __DIR__);
                if (is_resource($proc)) {
                    fclose($pipes[0]);
                    $stdout = stream_get_contents($pipes[1]); fclose($pipes[1]);
                    $stderr = stream_get_contents($pipes[2]); fclose($pipes[2]);
                    $code = proc_close($proc);
                    $output = trim((string)$stdout);
                }
            } else {
                $lines = array(); @exec($probe . ' 2>/dev/null', $lines, $code); $output = trim(implode("\n", $lines));
            }
            if ($code === 0 && preg_match('/^cli\|([0-9]+(?:\.[0-9]+)*)$/', $output, $m) && version_compare($m[1], '8.2.0', '>=')) return $candidate;
        }
        return false;
    }

    public static function generate_keys_ajax() {
        if (!current_user_can('manage_options')) wp_send_json_error(array('message'=>'Administrator permission required.'),403);
        check_ajax_referer('hc_web_push_admin','nonce');
        $keys = self::generate_keys();
        if (is_wp_error($keys)) wp_send_json_error(array('message'=>$keys->get_error_message()),500);
        wp_send_json_success(array('publicKey'=>$keys['publicKey'],'message'=>'VAPID keys generated. The private key is stored server-side.'));
    }

    private static function verify_request() {
        $nonce = isset($_REQUEST['nonce']) ? sanitize_text_field(wp_unslash($_REQUEST['nonce'])) : '';
        return $nonce && wp_verify_nonce($nonce, 'hc_web_push');
    }

    public static function subscribe() {
        if (!self::verify_request()) wp_send_json_error(array('message'=>'Session expired. Refresh the page and try again.'),403);
        $raw = isset($_POST['subscription']) ? wp_unslash($_POST['subscription']) : '';
        $sub = json_decode($raw, true);
        if (!is_array($sub) || empty($sub['endpoint']) || empty($sub['keys']['p256dh']) || empty($sub['keys']['auth'])) wp_send_json_error(array('message'=>'Invalid browser push subscription.'),400);
        $endpoint = esc_url_raw($sub['endpoint']);
        $parts = wp_parse_url($endpoint);
        if (!$parts || empty($parts['scheme']) || strtolower($parts['scheme']) !== 'https' || empty($parts['host'])) wp_send_json_error(array('message'=>'Push endpoint must use HTTPS.'),400);
        $push_host = strtolower((string)$parts['host']);
        $allowed_hosts = array('fcm.googleapis.com','push.services.mozilla.com','updates.push.services.mozilla.com','web.push.apple.com','notify.windows.com');
        $allowed = false; foreach ($allowed_hosts as $allowed_host) { if ($push_host === $allowed_host || substr($push_host, -strlen('.'.$allowed_host)) === '.'.$allowed_host) { $allowed = true; break; } }
        if (!$allowed) wp_send_json_error(array('message'=>'This browser push service endpoint is not supported.'),400);
        $audience = (isset($_POST['audience']) && $_POST['audience'] === 'agent') ? 'agent' : 'customer';
        $user_id = 0; $visitor_id = '';
        if ($audience === 'agent') {
            if (!is_user_logged_in() || !(current_user_can('hc_agent_portal_access') || current_user_can('manage_options'))) wp_send_json_error(array('message'=>'Agent login required.'),403);
            $user_id = get_current_user_id();
        } else {
            $visitor_id = isset($_POST['visitor_id']) ? sanitize_text_field(wp_unslash($_POST['visitor_id'])) : '';
            if (!$visitor_id || strlen($visitor_id) > 96 || !preg_match('/^[a-zA-Z0-9_-]+$/', $visitor_id)) wp_send_json_error(array('message'=>'Customer browser identity is missing. Reload the chat and try again.'),400);
        }
        global $wpdb; $table=self::table(); $hash=hash('sha256',$endpoint); $now=current_time('mysql');
        $ticket_id = ($audience === 'customer') ? absint($_POST['ticket_id'] ?? 0) : 0;
        if ($audience === 'customer') {
            if (!$ticket_id || !class_exists('HC_AI_Platform')) wp_send_json_error(array('message'=>'Open your active support chat before enabling push notifications.'),400);
            $ticket_table = $wpdb->prefix . 'hc_ai_escalations';
            $visitor_hash = HC_AI_Platform::session_hash($visitor_id);
            $owned = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$ticket_table} WHERE id=%d AND visitor_hash=%s LIMIT 1", $ticket_id, $visitor_hash));
            if (!$owned) wp_send_json_error(array('message'=>'This browser is not authorized for that support conversation.'),403);
        }
        $row=array('endpoint_hash'=>$hash,'endpoint'=>$endpoint,'public_key'=>sanitize_text_field($sub['keys']['p256dh']),'auth_token'=>sanitize_text_field($sub['keys']['auth']),'content_encoding'=>sanitize_key($sub['contentEncoding']??'aes128gcm'),'audience_type'=>$audience,'user_id'=>$user_id,'visitor_id'=>$visitor_id,'ticket_id'=>$ticket_id,'created_at'=>$now,'updated_at'=>$now);
        $formats=array('%s','%s','%s','%s','%s','%s','%d','%s','%d','%s','%s');
        $wpdb->replace($table,$row,$formats);
        if ($wpdb->last_error) wp_send_json_error(array('message'=>'Could not save this browser subscription.'),500);
        wp_send_json_success(array('saved'=>true,'audience'=>$audience));
    }

    /** Update per-tab foreground state so push can be suppressed only for the exact open ticket. */
    public static function presence() {
        if (!self::verify_request()) wp_send_json_error(array('message'=>'Session expired. Refresh the page and try again.'),403);
        $endpoint = isset($_POST['endpoint']) ? esc_url_raw(wp_unslash($_POST['endpoint'])) : '';
        $client_id = isset($_POST['client_id']) ? sanitize_key(wp_unslash($_POST['client_id'])) : '';
        $active_ticket = absint($_POST['active_ticket_id'] ?? 0);
        $visible = !empty($_POST['is_visible']) ? 1 : 0;
        if (!$endpoint || !$client_id || strlen($client_id) > 64) wp_send_json_error(array('message'=>'Invalid push presence data.'),400);
        $hash = hash('sha256', $endpoint);
        global $wpdb;
        $subscription = $wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table().' WHERE endpoint_hash=%s LIMIT 1', $hash));
        if (!$subscription) wp_send_json_error(array('message'=>'This browser has no saved HelpCenter push subscription.'),404);
        if ($subscription->audience_type === 'agent') {
            if (!is_user_logged_in() || get_current_user_id() !== (int)$subscription->user_id || !(current_user_can('hc_agent_portal_access') || current_user_can('manage_options'))) wp_send_json_error(array('message'=>'Agent session does not match this push subscription.'),403);
        } else {
            $visitor_id = isset($_POST['visitor_id']) ? sanitize_text_field(wp_unslash($_POST['visitor_id'])) : '';
            if (!$visitor_id || !hash_equals((string)$subscription->visitor_id, $visitor_id)) wp_send_json_error(array('message'=>'Customer session does not match this push subscription.'),403);
            if ($active_ticket && (int)$subscription->ticket_id !== $active_ticket) $active_ticket = 0;
        }
        if (!$visible) $active_ticket = 0;
        if (wp_rand(1,100) === 1) $wpdb->query($wpdb->prepare('DELETE FROM '.self::presence_table().' WHERE last_seen_at < %s', wp_date('Y-m-d H:i:s', time()-3*DAY_IN_SECONDS)));
        $wpdb->replace(self::presence_table(), array(
            'endpoint_hash'=>$hash,
            'client_id'=>$client_id,
            'audience_type'=>$subscription->audience_type,
            'user_id'=>(int)$subscription->user_id,
            'visitor_id'=>(string)$subscription->visitor_id,
            'active_ticket_id'=>$active_ticket,
            'is_visible'=>$visible,
            'last_seen_at'=>current_time('mysql'),
        ), array('%s','%s','%s','%d','%s','%d','%d','%s'));
        wp_send_json_success(array('tracked'=>true,'active_ticket_id'=>$active_ticket,'visible'=>(bool)$visible));
    }

    public static function unsubscribe() {
        if (!self::verify_request()) wp_send_json_error(array('message'=>'Session expired.'),403);
        $endpoint=isset($_POST['endpoint'])?esc_url_raw(wp_unslash($_POST['endpoint'])):'';
        if (!$endpoint) wp_send_json_error(array('message'=>'Missing endpoint.'),400);
        global $wpdb; $hash=hash('sha256',$endpoint); $where=array('endpoint_hash'=>$hash);
        if (is_user_logged_in()) { $where['user_id']=get_current_user_id(); }
        $wpdb->delete(self::table(),$where);
        wp_send_json_success(array('removed'=>true));
    }

    private static function record_delivery($data) {
        $data['time'] = current_time('mysql');
        update_option('hc_web_push_last_delivery', $data, false);
    }

    /** Queue push delivery so Web Push network latency never delays message save/ACK. */
    public static function send($audience, $target, $title, $body, $url='', $tag='', $context_ticket_id=0, $created_at='') {
        $item = array(
            'audience'=>sanitize_key($audience), 'target'=>absint($target),
            'title'=>sanitize_text_field($title), 'body'=>wp_strip_all_tags((string)$body),
            'url'=>esc_url_raw($url), 'tag'=>sanitize_text_field($tag),
            'ticket_id'=>absint($context_ticket_id), 'created_at'=>sanitize_text_field($created_at),
        );
        if (!in_array($item['audience'], array('agent','customer'), true) || !$item['target']) return false;
        self::$queued_sends[] = $item;
        if (!self::$send_shutdown_registered) {
            self::$send_shutdown_registered = true;
            register_shutdown_function(array(__CLASS__, 'flush_queued_sends'));
        }
        return true;
    }

    private static function notification_timestamp($created_at='') {
        $created_at = trim((string)$created_at);
        if ($created_at !== '' && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $created_at)) {
            $gmt = get_gmt_from_date($created_at);
            $stamp = strtotime($gmt . ' UTC');
            if ($stamp) return (int)$stamp * 1000;
        }
        return (int) round(microtime(true) * 1000);
    }

    /** Run after the AJAX response has been sent; use WP-Cron as non-FPM fallback. */
    public static function flush_queued_sends() {
        if (!self::$queued_sends) return;
        $items = self::$queued_sends;
        self::$queued_sends = array();
        if (function_exists('ignore_user_abort')) @ignore_user_abort(true);
        if (function_exists('fastcgi_finish_request')) {
            @fastcgi_finish_request();
            foreach ($items as $item) {
                self::send_now($item['audience'], $item['target'], $item['title'], $item['body'], $item['url'], $item['tag'], $item['ticket_id'], $item['created_at']);
            }
            return;
        }
        // No PHP-FPM response-finisher: dispatch independent one-shot jobs and
        // spawn WP-Cron immediately instead of holding the chat AJAX request open.
        foreach ($items as $item) {
            $args = array($item);
            wp_schedule_single_event(time(), 'hc_web_push_send_queued', $args);
        }
        if (function_exists('spawn_cron')) spawn_cron(time());
    }

    public static function run_queued_send($item) {
        if (!is_array($item) || empty($item['audience']) || empty($item['target'])) return;
        self::send_now($item['audience'], (int)$item['target'], $item['title'] ?? '', $item['body'] ?? '', $item['url'] ?? '', $item['tag'] ?? '', (int)($item['ticket_id'] ?? 0), $item['created_at'] ?? '');
    }

    private static function send_now($audience, $target, $title, $body, $url='', $tag='', $context_ticket_id=0, $created_at='') {
        // Web Push is governed only by the browser-notification setting. Sound alerts are a separate channel.
        if (class_exists('HC_Core') && HC_Core::get_setting('hc_ai_support_browser_notifications','1') !== '1') return 0;
        if (!class_exists('Minishlink\\WebPush\\WebPush')) return new WP_Error('hc_webpush_dependency','Web Push dependency is not installed.');
        $keys=self::keys(); if (!$keys) return new WP_Error('hc_webpush_keys','VAPID keys have not been generated.');
        global $wpdb; $table=self::table(); $context_ticket_id=absint($context_ticket_id);
        if ($audience === 'agent') $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE audience_type='agent' AND user_id=%d",absint($target)));
        else $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE audience_type='customer' AND ticket_id=%d",absint($target)));
        if (!$rows) { self::record_delivery(array('status'=>'no_subscription','audience'=>$audience,'target'=>absint($target),'ticket_id'=>$context_ticket_id,'attempted'=>0,'sent'=>0,'failed'=>0,'suppressed'=>0)); return 0; }
        $cutoff = wp_date('Y-m-d H:i:s', time()-45);
        $presence_table = self::presence_table();
        $deliver = array(); $suppressed = 0;
        foreach ($rows as $row) {
            if ($context_ticket_id) {
                $active = (int)$wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$presence_table} WHERE endpoint_hash=%s AND active_ticket_id=%d AND is_visible=1 AND last_seen_at >= %s",
                    hash('sha256',$row->endpoint), $context_ticket_id, $cutoff
                ));
                if ($active) { $suppressed++; continue; }
            }
            $deliver[] = $row;
        }
        if (!$deliver) { self::record_delivery(array('status'=>'suppressed_same_ticket','audience'=>$audience,'target'=>absint($target),'ticket_id'=>$context_ticket_id,'attempted'=>0,'sent'=>0,'failed'=>0,'suppressed'=>$suppressed)); return 0; }
        try {
            $auth=array('VAPID'=>array('subject'=>$keys['subject']??self::subject(),'publicKey'=>$keys['publicKey'],'privateKey'=>$keys['privateKey']));
            $webPush=new \Minishlink\WebPush\WebPush($auth,array('TTL'=>300,'urgency'=>'high'));
            $ticket_id = $context_ticket_id ?: (($audience === 'customer') ? absint($target) : 0);
            $payload=wp_json_encode(array('title'=>wp_strip_all_tags($title),'body'=>wp_strip_all_tags($body),'url'=>$url?:home_url('/helpcenter/'),'tag'=>$tag?:('hc-support-update-'.wp_generate_uuid4()),'renotify'=>true,'ticketId'=>$ticket_id,'timestamp'=>self::notification_timestamp($created_at)));
            foreach($deliver as $row){
                $subscription=\Minishlink\WebPush\Subscription::create(array('endpoint'=>$row->endpoint,'publicKey'=>$row->public_key,'authToken'=>$row->auth_token,'contentEncoding'=>$row->content_encoding?:'aes128gcm'));
                $webPush->queueNotification($subscription,$payload);
            }
            $sent=0; $failed=0;
            foreach($webPush->flush() as $report){
                if($report->isSuccess()){$sent++;continue;}
                $failed++;
                if($report->isSubscriptionExpired()){
                    $expired_hash=hash('sha256',$report->getEndpoint());
                    $wpdb->delete($table,array('endpoint_hash'=>$expired_hash));
                    $wpdb->delete($presence_table,array('endpoint_hash'=>$expired_hash));
                } else error_log('[HelpCenter Web Push] Delivery failed: '.$report->getReason());
            }
            self::record_delivery(array('status'=>$failed ? ($sent ? 'partial_failure' : 'failed') : 'accepted_by_push_service','audience'=>$audience,'target'=>absint($target),'ticket_id'=>$ticket_id,'attempted'=>count($deliver),'sent'=>$sent,'failed'=>$failed,'suppressed'=>$suppressed));
            if (defined('WP_DEBUG') && WP_DEBUG) error_log('[HelpCenter Web Push] audience='.$audience.' target='.absint($target).' ticket='.$ticket_id.' attempted='.count($deliver).' sent='.$sent.' failed='.$failed.' suppressed_same_ticket='.$suppressed);
            return $sent;
        } catch(Throwable $e) { self::record_delivery(array('status'=>'exception','audience'=>$audience,'target'=>absint($target),'ticket_id'=>$context_ticket_id,'attempted'=>count($deliver),'sent'=>0,'failed'=>count($deliver),'suppressed'=>$suppressed,'error'=>substr($e->getMessage(),0,240))); error_log('[HelpCenter Web Push] '.$e->getMessage()); return new WP_Error('hc_webpush_send',$e->getMessage()); }
    }

    public static function print_client_bootstrap() {
        if (is_admin()) return;
        $keys=self::keys(); $public=$keys['publicKey']??'';
        $ajax=admin_url('admin-ajax.php'); $nonce=wp_create_nonce('hc_web_push');
        $agent=is_user_logged_in() && (current_user_can('hc_agent_portal_access') || current_user_can('manage_options'));
        $config=array('enabled'=>(bool)$public,'browserEnabled'=>(HC_Core::get_setting('hc_ai_support_browser_notifications','1')==='1'),'publicKey'=>$public,'ajax'=>$ajax,'nonce'=>$nonce,'agent'=>$agent,'userId'=>get_current_user_id(),'serviceWorker'=>home_url('/hc-web-push-sw.js'),'visitorKey'=>'hc_ai_visitor_v49','ticketKey'=>'hc_ai_sessions_v49_active_support_ticket');
        echo '<script>window.HCWebPushConfig='.wp_json_encode($config).';</script>';
        echo '<script src="'.esc_url(HC_URL.'assets/js/hc-web-push.js?ver='.self::VERSION).'" defer></script>';
        if ($agent) echo '<div id="hc-agent-push-optin" style="position:fixed;right:18px;bottom:18px;z-index:99999;background:#20243a;color:#fff;padding:10px 12px;border-radius:10px;font:13px system-ui;box-shadow:0 5px 20px #0003"><span>Get ticket alerts when away?</span> <button type="button" data-hc-enable-push style="margin-left:8px">Enable</button> <button type="button" aria-label="Dismiss" onclick="this.parentNode.remove()" style="margin-left:4px">×</button></div>';
    }

}
