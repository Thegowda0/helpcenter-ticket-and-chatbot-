<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// Read the current tab/view from URL
$view = isset($_GET['view']) ? sanitize_key($_GET['view']) : '';
$valid_views = array('', 'published', 'draft', 'trash');
if (!in_array($view, $valid_views, true)) $view = '';

// Build WHERE for initial render
$where  = array();
$params = array();

if ($view === 'trash') {
    $where[] = 'deleted_at IS NOT NULL';
} else {
    $where[] = 'deleted_at IS NULL';
    if ($view === 'published' || $view === 'draft') {
        $where[] = 'status = %s';
        $params[] = $view;
    }
}

$where_sql = 'WHERE ' . implode(' AND ', $where);

$sort_dir = (isset($_GET['sort']) && strtolower($_GET['sort']) === 'desc') ? 'DESC' : 'ASC';
$orderby = isset($_GET['orderby']) ? sanitize_key($_GET['orderby']) : '';
$sort = (isset($_GET['sort']) && strtolower($_GET['sort']) === 'asc') ? 'ASC' : 'DESC';

$allowed_faq = array(
    'question'    => 'question',
    'destination' => 'destination_type',
    'status'      => 'status',
    'last_action' => 'updated_at',
    'order'       => 'sort_order'
);

if (array_key_exists($orderby, $allowed_faq)) {
    $faq_order_sql = "ORDER BY {$allowed_faq[$orderby]} $sort";
} else {
    $faq_order_sql = "ORDER BY updated_at DESC, created_at DESC";
}
$orderby = isset($_GET["orderby"]) ? sanitize_key($_GET["orderby"]) : "";
$sort = (isset($_GET["sort"]) && strtolower($_GET["sort"]) === "asc") ? "ASC" : "DESC";

$allowed_faq = array(
    "question"    => "question",
    "destination" => "destination_type",
    "status"      => "status",
    "last_action" => "updated_at",
    "order"       => "sort_order"
);

if (array_key_exists($orderby, $allowed_faq)) {
    $faq_order_sql = "ORDER BY {$allowed_faq[$orderby]} $sort";
} else {
    $faq_order_sql = "ORDER BY updated_at DESC, created_at DESC";
}

$orderby = isset($_GET['orderby']) ? sanitize_key($_GET['orderby']) : '';
$sort = (isset($_GET['sort']) && strtolower($_GET['sort']) === 'asc') ? 'ASC' : 'DESC';

$allowed_faq = array(
    'question'    => 'question',
    'destination' => 'destination_type',
    'status'      => 'status',
    'last_action' => 'updated_at',
    'order'       => 'sort_order'
);

if (array_key_exists($orderby, $allowed_faq)) {
    $faq_order_sql = "ORDER BY {$allowed_faq[$orderby]} $sort";
} else {
    $faq_order_sql = "ORDER BY updated_at DESC, created_at DESC";
}
$sql = "SELECT * FROM {$wpdb->prefix}hc_faqs $where_sql $faq_order_sql LIMIT " . max(10, min(100, (int) get_user_meta(get_current_user_id(), 'hc_admin_per_page', true) ?: 10));
$faqs = $params
    ? $wpdb->get_results($wpdb->prepare($sql, $params))
    : $wpdb->get_results($sql);

// Tab counts
$count_all       = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_faqs");
$count_published = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_faqs WHERE deleted_at IS NULL AND status='published'");
$count_draft     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_faqs WHERE deleted_at IS NULL AND status='draft'");
$count_trash     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_faqs WHERE deleted_at IS NOT NULL");

$initial_count = ($view === 'published') ? $count_published
               : (($view === 'draft')     ? $count_draft
               : (($view === 'trash')     ? $count_trash
               : $count_all));

$base_url = home_url('/helpcenter/admin/faqs/');

function hc_faq_destination_label($faq) {
    switch ($faq->destination_type) {
        case 'global':   return 'Global (everywhere)';
        case 'home':     return 'Home page only';
        case 'contact':  return 'Contact page only';
        case 'category':
            $c = HC_Core::get_category($faq->destination_id);
            return 'Category: ' . ($c ? $c->name : 'Unknown');
        case 'article':
            $a = HC_Core::get_article($faq->destination_id);
            return 'Article: ' . ($a ? wp_trim_words($a->title, 6) : 'Unknown');
    }
    return '—';
}
?>

<!-- TABS -->
<nav class="hc-list-tabs">
    <a href="<?php echo esc_url($base_url); ?>" class="hc-list-tab <?php echo $view === '' ? 'active' : ''; ?>">
        <i class="fas fa-circle-question"></i> All
        <span class="hc-tab-count"><?php echo $count_all; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=published'); ?>" class="hc-list-tab <?php echo $view === 'published' ? 'active' : ''; ?>">
        <i class="fas fa-circle-check"></i> Published
        <span class="hc-tab-count"><?php echo $count_published; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=draft'); ?>" class="hc-list-tab <?php echo $view === 'draft' ? 'active' : ''; ?>">
        <i class="fas fa-pen"></i> Draft
        <span class="hc-tab-count"><?php echo $count_draft; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=trash'); ?>" class="hc-list-tab hc-list-tab-trash <?php echo $view === 'trash' ? 'active' : ''; ?>">
        <i class="fas fa-trash-alt"></i> Trash
        <span class="hc-tab-count"><?php echo $count_trash; ?></span>
    </a>
</nav>

<!-- TOOLBAR -->
<div class="hc-admin-toolbar hc-faqs-search" data-view="<?php echo esc_attr($view); ?>">
    <div class="hc-admin-filters">
        <div class="hc-search-wrap">
            <i class="fas fa-search hc-search-icon"></i>
            <input type="text" name="s" placeholder="Search FAQs by question or answer..." autocomplete="off">
            <span class="hc-faqs-spinner hc-search-spinner" style="display:none;">
                <i class="fas fa-circle-notch fa-spin"></i>
            </span>
        </div>

        <span class="hc-faqs-count hc-search-count">
            <?php echo $initial_count; ?> <?php echo $initial_count === 1 ? 'result' : 'results'; ?>
        </span>

        <?php if ($view === 'trash'): ?>
        <button type="button" class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm hc-empty-trash-btn" data-trash-type="faqs">
            <i class="fas fa-trash-alt"></i> Empty Trash
        </button>
        <?php endif; ?>
    </div>

    <?php if ($view !== 'trash'): ?>
    <a href="<?php echo esc_url(home_url('/helpcenter/admin/faqs/new/')); ?>" class="hc-admin-btn hc-admin-btn-primary">
        <i class="fas fa-plus"></i> New FAQ
    </a>
    <?php endif; ?>
</div>

<div class="hc-admin-card">
    <div class="hc-admin-card-body hc-flush">
        <table class="hc-admin-table">
            <thead>
                <tr>
                    <th style="width:36px;"><input type="checkbox" class="hc-check-all" data-target=".hc-faqs-tbody" id="hc-faqs-select-all"></th>
                    <th>Question</th>
                    <th>Destination</th>
                    <th>Order</th>
                    <th>Status</th>
                    <th>Last Action</th>
                    <th style="width:140px;">Actions</th>
                </tr>
            </thead>
            <tbody class="hc-faqs-tbody">
                <?php if (!empty($faqs)): ?>
                <?php foreach ($faqs as $f):
        $is_trashed = !empty($f->deleted_at);
    // Calculate Destination text
    $dest = '—';
    switch ($f->destination_type) {
        case 'global':  $dest = 'Global'; break;
        case 'home':    $dest = 'Home'; break;
        case 'contact': $dest = 'Contact'; break;
        case 'category':
            $c = HC_Core::get_category($f->destination_id);
            $dest = 'Category: ' . ($c ? $c->name : 'Unknown');
            break;
        case 'article':
            $a = HC_Core::get_article($f->destination_id);
            $dest = 'Article: ' . ($a ? wp_trim_words($a->title, 6) : 'Unknown');
            break;
    } ?>
                <tr data-row-id="<?php echo (int) $f->id; ?>" data-status="<?php echo esc_attr($f->status); ?>" data-trashed="<?php echo $is_trashed ? '1' : '0'; ?>" class="<?php echo $is_trashed ? 'hc-trashed-row' : ''; ?>" <?php if ($is_trashed): ?>style="opacity: 0.65;"<?php endif; ?>>
            
            <!-- 1. Checkbox -->
            <td style="text-align: center;">
                <input type="checkbox" class="hc-row-check" value="<?php echo (int) $f->id; ?>">
            </td>

            <!-- 2. Question -->
            <td>
                <a href="<?php echo esc_url(home_url('/helpcenter/admin/faqs/edit/' . $f->id . '/')); ?>" class="hc-admin-link">
                    <?php echo esc_html($f->question); ?>
                </a>
            </td>

            <!-- 3. Destination (Restored) -->
            <td class="hc-muted"><?php echo esc_html($dest); ?></td>

            <!-- 4. Order -->
            <td><?php echo (int) $f->sort_order; ?></td>

            <!-- 5. Status -->
            <td>
                <?php if ($is_trashed): ?>
                    <span class="hc-status hc-status-trash">trashed</span>
                <?php else: ?>
                    <?php $faq_hidden_reason = HC_Lifecycle::faq_hidden_reason($f); ?>
                    <span class="hc-status hc-status-<?php echo esc_attr($f->status); ?>"><?php echo esc_html($f->status); ?></span>
                    <?php if ($faq_hidden_reason !== '' && $f->status === 'published'): ?>
                        <span class="hc-status hc-status-hidden" title="<?php echo esc_attr($faq_hidden_reason); ?>" style="margin-top:4px;display:inline-block;cursor:help;">not visible</span>
                        <small style="display:block;color:#B45309;max-width:210px;" title="<?php echo esc_attr($faq_hidden_reason); ?>"><?php echo esc_html($faq_hidden_reason); ?></small>
                    <?php endif; ?>
                <?php endif; ?>
            </td>

            <!-- 6. Last Action -->
            <td class="hc-muted" title="<?php echo esc_attr($f->updated_at); ?>">
                <?php echo esc_html(HC_Core::human_time($f->updated_at)); ?><br>
                <small style="font-size:11px;color:#94A3B8;"><?php echo esc_html($f->last_action ?: '—'); ?></small>
            </td>

            <!-- 7. Actions -->
            <td style="text-align: right;">
                <div class="hc-admin-row-actions" style="justify-content: flex-end;">
                    <?php if ($is_trashed): ?>
                        <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" data-hc-restore-faq="<?php echo (int) $f->id; ?>" title="Restore"><i class="fas fa-undo"></i></button>
                        <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-hard-delete-faq="<?php echo (int) $f->id; ?>" title="Delete permanently"><i class="fas fa-trash-alt"></i></button>
                    <?php else: ?>
                        <a href="<?php echo esc_url(home_url('/helpcenter/admin/faqs/edit/' . $f->id . '/')); ?>" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" title="Edit"><i class="fas fa-pen"></i></a>
                        <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-delete-faq="<?php echo (int) $f->id; ?>" title="Move to trash"><i class="fas fa-trash"></i></button>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
                <?php endforeach; ?>
                <?php else: ?>
                <tr><td colspan="6" style="text-align:center;padding:48px;color:#94A3B8;">
                    <?php echo $view === 'trash' ? 'Trash is empty.' : 'No FAQs yet.'; ?>
                </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- BULK ACTION BAR -->
<div class="hc-bulk-bar" id="hcBulkBar" data-list="faqs" data-view="<?php echo esc_attr($view); ?>">
    <div class="hc-bulk-bar-count"><span class="hc-bulk-count">0</span> selected</div>
    <div class="hc-bulk-bar-actions">
        <?php if ($view === 'trash'): ?>
        <button type="button" class="hc-bulk-btn" data-bulk-op="restore"><i class="fas fa-undo"></i> Restore</button>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-danger" data-bulk-op="hard_delete"><i class="fas fa-trash-alt"></i> Delete Permanently</button>
        <?php else: ?>
        <button type="button" class="hc-bulk-btn" data-bulk-op="publish"><i class="fas fa-eye"></i> Publish</button>
        <button type="button" class="hc-bulk-btn" data-bulk-op="draft"><i class="fas fa-pen"></i> Draft</button>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-danger" data-bulk-op="delete"><i class="fas fa-trash"></i> Move to Trash</button>
        <?php endif; ?>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-outline" data-bulk-clear><i class="fas fa-times"></i> Clear</button>
    </div>
</div>
