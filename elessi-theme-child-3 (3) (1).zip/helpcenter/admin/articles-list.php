<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// Read the current tab/view from URL
$view = isset($_GET['view']) ? sanitize_key($_GET['view']) : '';
$valid_views = array('', 'published', 'draft', 'hidden', 'trash');
if (!in_array($view, $valid_views, true)) $view = '';

// Build the WHERE clause for the initial render
$where  = array();
$params = array();

if ($view === 'trash') {
    $where[] = 'a.deleted_at IS NOT NULL';
} else {
    $where[] = 'a.deleted_at IS NULL';
    if ($view === 'published' || $view === 'draft' || $view === 'hidden') {
        $where[] = 'a.status = %s';
        $params[] = $view;
    }
}

$where_sql = 'WHERE ' . implode(' AND ', $where);

// Initial rows
$orderby = isset($_GET['orderby']) ? sanitize_key($_GET['orderby']) : '';
$sort = (isset($_GET['sort']) && strtolower($_GET['sort']) === 'asc') ? 'ASC' : 'DESC';

$allowed_art = array(
    'title'       => 'a.title',
    'category'    => 'category_name',
    'status'      => 'a.status',
    'views'       => 'a.view_count',
    'last_action' => 'a.updated_at',
    'order'       => 'a.sort_order'
);

if (array_key_exists($orderby, $allowed_art)) {
    $art_order_sql = "ORDER BY {$allowed_art[$orderby]} $sort";
} else {
    $art_order_sql = "ORDER BY a.updated_at DESC, a.created_at DESC";
}
$allowed_per_page = array(10, 20, 50, 100, 200, 500, 1000);
if (isset($_GET['per_page'])) {
    $requested_per_page = absint($_GET['per_page']);
    if (in_array($requested_per_page, $allowed_per_page, true)) {
        update_user_meta(get_current_user_id(), 'hc_admin_per_page', $requested_per_page);
    }
}
$stored_per_page = (int) get_user_meta(get_current_user_id(), 'hc_admin_per_page', true);
$admin_per_page = in_array($stored_per_page, $allowed_per_page, true) ? $stored_per_page : 10;
$admin_page = max(1, absint($_GET['paged'] ?? 1));
$count_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles a $where_sql";
$total_articles = (int) ($params ? $wpdb->get_var($wpdb->prepare($count_sql, $params)) : $wpdb->get_var($count_sql));
$total_pages = max(1, (int) ceil($total_articles / $admin_per_page));
$admin_page = min($admin_page, $total_pages);
$admin_offset = ($admin_page - 1) * $admin_per_page;
$sql = "SELECT a.*, (SELECT GROUP_CONCAT(DISTINCT cc.name ORDER BY cc.name SEPARATOR ', ') FROM {$wpdb->prefix}hc_article_categories ac JOIN {$wpdb->prefix}hc_categories cc ON cc.id = ac.category_id AND cc.deleted_at IS NULL WHERE ac.article_id = a.id) AS category_name
        FROM {$wpdb->prefix}hc_articles a
        $where_sql
        $art_order_sql
        LIMIT " . (int)$admin_per_page . " OFFSET " . (int)$admin_offset;

$articles = $params
    ? $wpdb->get_results($wpdb->prepare($sql, $params))
    : $wpdb->get_results($sql);

// Tab counts
$count_all       = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles");
$count_published = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NULL AND status='published'");
$count_draft     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NULL AND status='draft'");
$count_hidden    = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NULL AND status='hidden'");
$count_trash     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NOT NULL");

// Initial result count for the visible tab
$initial_count = ($view === 'published') ? $count_published
               : (($view === 'draft')     ? $count_draft
               : (($view === 'hidden')    ? $count_hidden
               : (($view === 'trash')     ? $count_trash
               : $count_all)));

$categories = HC_Core::get_categories(0, 'any');

$base_url = home_url('/helpcenter/admin/articles/');
?>

<!-- TABS -->
<nav class="hc-list-tabs">
    <a href="<?php echo esc_url($base_url); ?>" class="hc-list-tab <?php echo $view === '' ? 'active' : ''; ?>">
        <i class="fas fa-file-lines"></i> All
        <span class="hc-tab-count"><?php echo $count_all; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=published'); ?>" class="hc-list-tab <?php echo $view === 'published' ? 'active' : ''; ?>">
        <i class="fas fa-circle-check"></i> Published
        <span class="hc-tab-count"><?php echo $count_published; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=draft'); ?>" class="hc-list-tab <?php echo $view === 'draft' ? 'active' : ''; ?>">
        <i class="fas fa-pen"></i> Draft
        <span class="hc-tab-count"><?php echo $count_draft; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=hidden'); ?>" class="hc-list-tab <?php echo $view === 'hidden' ? 'active' : ''; ?>">
        <i class="fas fa-eye-slash"></i> Hidden
        <span class="hc-tab-count"><?php echo $count_hidden; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=trash'); ?>" class="hc-list-tab hc-list-tab-trash <?php echo $view === 'trash' ? 'active' : ''; ?>">
        <i class="fas fa-trash-alt"></i> Trash
        <span class="hc-tab-count"><?php echo $count_trash; ?></span>
    </a>
</nav>

<!-- TOOLBAR (search fires via AJAX) -->
<div class="hc-admin-toolbar hc-articles-search" data-view="<?php echo esc_attr($view); ?>">
    <div class="hc-admin-filters">
        <label class="hc-articles-per-page" style="display:flex;align-items:center;gap:7px;white-space:nowrap;">Show
            <select name="per_page" id="hcArticlesPerPage" aria-label="Articles per page">
                <?php foreach ($allowed_per_page as $page_size): ?>
                <option value="<?php echo (int) $page_size; ?>" <?php selected($admin_per_page, $page_size); ?>><?php echo (int) $page_size; ?></option>
                <?php endforeach; ?>
            </select> articles per page
        </label>
        <div class="hc-search-wrap">
            <i class="fas fa-search hc-search-icon"></i>
            <input type="text" name="s" placeholder="Search articles..." autocomplete="off">
            <span class="hc-articles-spinner hc-search-spinner" style="display:none;">
                <i class="fas fa-circle-notch fa-spin"></i>
            </span>
        </div>

        <select name="cat" class="hc-articles-cat">
            <option value="0">All Categories</option>
            <?php foreach ($categories as $c): ?>
            <option value="<?php echo (int) $c->id; ?>"><?php echo esc_html($c->name); ?></option>
            <?php endforeach; ?>
        </select>

        <span class="hc-articles-count hc-search-count">
            <?php echo $initial_count; ?> <?php echo $initial_count === 1 ? 'result' : 'results'; ?>
        </span>

        <?php if ($view === 'trash'): ?>
        <button type="button" class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm hc-empty-trash-btn" data-trash-type="articles">
            <i class="fas fa-trash-alt"></i> Empty Trash
        </button>
        <?php endif; ?>
    </div>

    <?php if ($view !== 'trash'): ?>
    <a href="<?php echo esc_url(home_url('/helpcenter/admin/articles/new/')); ?>" class="hc-admin-btn hc-admin-btn-primary">
        <i class="fas fa-plus"></i> New Article
    </a>
    <?php endif; ?>
</div>

<div class="hc-admin-card">
    <div class="hc-admin-card-body hc-flush">
        <table class="hc-admin-table">
            <thead>
                <tr>
                    <th style="width:36px;"><input type="checkbox" class="hc-check-all" data-target=".hc-articles-tbody" id="hc-articles-select-all"></th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Views</th>
                    <th>Last Action</th>
                    <th style="width:140px;">Actions</th>
                </tr>
            </thead>
            <tbody class="hc-articles-tbody">
                <?php if (!empty($articles)): ?>
                <?php foreach ($articles as $a):
        $is_trashed = !empty($a->deleted_at);
        // Fetch all categories for this article
        $art_cats = $wpdb->get_col($wpdb->prepare(
            "SELECT c.name 
             FROM {$wpdb->prefix}hc_article_categories ac
             JOIN {$wpdb->prefix}hc_categories c ON ac.category_id = c.id
             WHERE ac.article_id = %d AND c.deleted_at IS NULL", 
            $a->id
        ));
        $cat_display = !empty($art_cats) ? implode(', ', $art_cats) : '—';
         ?>
                <tr data-row-id="<?php echo (int) $a->id; ?>" data-status="<?php echo esc_attr($a->status); ?>" data-trashed="<?php echo $is_trashed ? '1' : '0'; ?>" class="<?php echo $is_trashed ? 'hc-trashed-row' : ''; ?>" <?php if ($is_trashed): ?>style="opacity: 0.65;"<?php endif; ?>>
            
            <!-- 1. Checkbox -->
            <td style="text-align: center;">
                <input type="checkbox" class="hc-row-check" value="<?php echo (int) $a->id; ?>">
            </td>

            <!-- 2. Title -->
            <td>
                <a href="<?php echo esc_url(home_url('/helpcenter/admin/articles/edit/' . $a->id . '/')); ?>" class="hc-admin-link">
                    <?php echo esc_html($a->title); ?>
                </a>
            </td>

            <!-- 3. Category -->
            
            <td class="hc-muted" title="<?php echo esc_attr($cat_display); ?>">
                <?php 
                $art_cats = $wpdb->get_col($wpdb->prepare(
                    "SELECT c.name FROM {$wpdb->prefix}hc_article_categories ac 
                     JOIN {$wpdb->prefix}hc_categories c ON ac.category_id = c.id 
                     WHERE ac.article_id = %d AND c.deleted_at IS NULL", 
                    $a->id
                ));
                echo esc_html(!empty($art_cats) ? implode(', ', $art_cats) : '—'); 
                ?>
            </td>

            <!-- 4. Status -->
            <td>
                <?php if ($is_trashed): ?>
                    <span class="hc-status hc-status-trash">trashed</span>
                <?php else: ?>
                    <?php if ($a->status === 'hidden'): ?>
                        <?php $hc_underlying_status = in_array($a->category_hidden_status ?? '', array('published', 'draft'), true) ? $a->category_hidden_status : 'draft'; ?>
                        <span class="hc-status hc-status-hidden">Hidden</span>
                        <div style="margin-top:4px;font-size:11px;line-height:1.45;color:#64748b;">
                            <?php echo esc_html(HC_Lifecycle::article_hidden_reason($a)); ?><br>
                            Actual status: <strong><?php echo esc_html(ucfirst($hc_underlying_status)); ?></strong>
                        </div>
                    <?php else: ?>
                        <span class="hc-status hc-status-<?php echo esc_attr($a->status); ?>"><?php echo esc_html($a->status); ?></span>
                    <?php endif; ?>
                <?php endif; ?>
            </td>

            <!-- 5. Views -->
            <td><?php echo (int) $a->view_count; ?></td>

            <!-- 6. Last Action -->
            <td class="hc-muted" title="<?php echo esc_attr($a->updated_at); ?>">
                <?php echo esc_html(HC_Core::human_time($a->updated_at)); ?><br>
                <small style="font-size:11px;color:#94A3B8;"><?php echo esc_html($a->last_action ?: '—'); ?></small>
            </td>

            <!-- 8. Actions -->
            <td style="text-align: right;">
                <div class="hc-admin-row-actions" style="justify-content: flex-end;">
                    <?php if ($is_trashed): ?>
                        <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" data-hc-restore-article="<?php echo (int) $a->id; ?>" title="Restore"><i class="fas fa-undo"></i></button>
                        <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-hard-delete-article="<?php echo (int) $a->id; ?>" title="Delete permanently"><i class="fas fa-trash-alt"></i></button>
                    <?php else: ?>
                        <a href="<?php echo esc_url(home_url('/helpcenter/admin/articles/edit/' . $a->id . '/')); ?>" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" title="Edit"><i class="fas fa-pen"></i></a>
                        <?php if ($a->status === 'published' || $a->status === 'draft'): ?><a href="<?php echo esc_url(add_query_arg(array('hc_preview'=>(int)$a->id,'hc_preview_token'=>wp_create_nonce('hc_preview_'.(int)$a->id)), home_url('/helpcenter/article/'.$a->slug.'/'))); ?>" target="_blank" rel="noopener" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" title="Preview in new tab"><i class="fas fa-eye"></i></a><?php endif; ?>
                        <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-delete-article="<?php echo (int) $a->id; ?>" title="Move to trash"><i class="fas fa-trash"></i></button>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
                <?php endforeach; ?>
                <?php else: ?>
                <tr><td colspan="7" style="text-align:center;padding:48px;color:#94A3B8;">
                    <?php echo $view === 'trash' ? 'Trash is empty.' : 'No articles yet.'; ?>
                </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php if ($total_pages > 1): $page_url_args = $_GET; ?>
<nav class="hc-admin-pagination" id="hcArticlesPagination" aria-label="Article list pagination">
  <?php if ($admin_page > 1): $page_url_args['paged'] = $admin_page - 1; ?><a class="hc-admin-btn hc-admin-btn-outline" href="<?php echo esc_url(add_query_arg($page_url_args, $base_url)); ?>">← Previous</a><?php endif; ?>
  <span>Page <?php echo (int)$admin_page; ?> of <?php echo (int)$total_pages; ?> · <?php echo (int)$total_articles; ?> articles</span>
  <?php if ($admin_page < $total_pages): $page_url_args['paged'] = $admin_page + 1; ?><a class="hc-admin-btn hc-admin-btn-outline" href="<?php echo esc_url(add_query_arg($page_url_args, $base_url)); ?>">Next →</a><?php endif; ?>
</nav>
<style>.hc-admin-pagination{display:flex;justify-content:center;align-items:center;gap:16px;flex-wrap:wrap;padding:18px;color:#64748b}.hc-admin-pagination a{text-decoration:none}</style>
<?php endif; ?>
<script>
(function(){var sel=document.getElementById('hcArticlesPerPage');if(!sel)return;sel.addEventListener('change',function(){var u=new URL(window.location.href);u.searchParams.set('per_page',this.value);u.searchParams.delete('paged');u.searchParams.delete('s');window.location.assign(u.toString());});})();
</script>

<!-- BULK ACTION BAR -->
<div class="hc-bulk-bar" id="hcBulkBar" data-list="articles" data-view="<?php echo esc_attr($view); ?>">
    <div class="hc-bulk-bar-count"><span class="hc-bulk-count">0</span> selected</div>
    <div class="hc-bulk-bar-actions">
        <?php if ($view === 'trash'): ?>
        <button type="button" class="hc-bulk-btn" data-bulk-op="restore"><i class="fas fa-undo"></i> Restore</button>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-danger" data-bulk-op="hard_delete"><i class="fas fa-trash-alt"></i> Delete Permanently</button>
        <?php else: ?>
        <button type="button" class="hc-bulk-btn" data-bulk-op="publish"><i class="fas fa-eye"></i> Publish</button>
        <button type="button" class="hc-bulk-btn" data-bulk-op="draft"><i class="fas fa-pen"></i> Move to Draft</button>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-danger" data-bulk-op="delete"><i class="fas fa-trash"></i> Move to Trash</button>
        <?php endif; ?>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-outline" data-bulk-clear><i class="fas fa-times"></i> Clear</button>
    </div>
</div>
