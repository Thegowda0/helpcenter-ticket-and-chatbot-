<?php
/**
 * Help Center Admin - HTML Shell (fully isolated)
 */

if (!defined('ABSPATH')) exit;

$page = get_query_var('hc_page') ?: 'admin-dashboard';
$user = wp_get_current_user();
$site_name = HC_Core::get_setting('hc_site_title', 'Help Center');
$counts = HC_Admin::get_counts();
$menu_items = array(
    array('id'=>'dashboard','group'=>'OVERVIEW','label'=>'Dashboard','url'=>home_url('/helpcenter/admin/'),'icon'=>'fa-chart-pie','pages'=>array('admin-dashboard')),
    array('id'=>'knowledge-base','group'=>'CONTENT','label'=>'Knowledge Base','url'=>home_url('/helpcenter/admin/section/knowledge-base/'),'icon'=>'fa-book-open','pages'=>array('admin-hub','admin-articles','admin-article-edit','admin-categories','admin-category-edit','admin-faqs','admin-faq-edit','admin-popular','admin-revisions')),
    array('id'=>'analytics-quality','group'=>'INSIGHTS','label'=>'Analytics & Quality','url'=>home_url('/helpcenter/admin/section/analytics-quality/'),'icon'=>'fa-chart-line','pages'=>array('admin-search-log','admin-seo-audit','admin-performance-audit')),
    array('id'=>'ai-platform','group'=>'AUTOMATION','label'=>'AI Platform','url'=>home_url('/helpcenter/admin/section/ai-platform/'),'icon'=>'fa-brain','pages'=>array('admin-ai-platform')),
    array('id'=>'support-operations','group'=>'SUPPORT','label'=>'Support Operations','url'=>home_url('/helpcenter/admin/section/support-operations/'),'icon'=>'fa-headset','pages'=>array('admin-human-support')),
    array('id'=>'agents-team','group'=>'SUPPORT','label'=>'Agents & Team','url'=>home_url('/helpcenter/admin/section/agents-team/'),'icon'=>'fa-users','pages'=>array('admin-agents')),
    array('id'=>'settings','group'=>'ADMINISTRATION','label'=>'Settings','url'=>home_url('/helpcenter/admin/section/settings/'),'icon'=>'fa-sliders','pages'=>array('admin-settings','admin-web-push')),
);


if (!current_user_can('manage_options') && class_exists('HC_Live_Support') && HC_Live_Support::can_manage()) {
    $menu_items = array_values(array_filter($menu_items, function($item) { return $item['id'] === 'support-operations'; }));
}

$current_id = '';
if ($page === 'admin-hub') {
    $hub_key = sanitize_key(get_query_var('hc_hub'));
    $current_id = in_array($hub_key, array('knowledge-base','analytics-quality','ai-platform','support-operations','agents-team','settings'), true) ? $hub_key : 'knowledge-base';
} else {
    foreach ($menu_items as $item) {
        if (in_array($page, $item['pages'], true)) { $current_id = $item['id']; break; }
    }
}

$page_titles = array(
    'admin-dashboard'      => 'Dashboard',
    'admin-hub'            => array('knowledge-base'=>'Knowledge Base','analytics-quality'=>'Analytics & Quality','ai-platform'=>'AI Platform','support-operations'=>'Support Operations','agents-team'=>'Agents & Team','settings'=>'Settings')[sanitize_key(get_query_var('hc_hub'))] ?? 'Workspace',
    'admin-articles'       => 'Articles',
    'admin-article-edit'   => 'Edit Article',
    'admin-categories'     => 'Categories',
    'admin-category-edit'  => 'Edit Category',
    'admin-faqs'           => 'FAQs',
    'admin-faq-edit'       => 'Edit FAQ',
    'admin-revisions'      => 'Revision History',
    'admin-search-log'     => 'Search Log',
    'admin-seo-audit'      => 'SEO Audit',
    'admin-performance-audit' => 'Performance & Security',
    'admin-settings'       => 'Settings — ' . ucwords(str_replace('-', ' ', sanitize_key(get_query_var('hc_settings_section') ?: 'general'))),
    'admin-web-push'       => 'Notifications & Web Push',
    'admin-ai-platform'    => 'AI Platform',
    'admin-human-support'  => 'Human Support',
    'admin-agents' => 'Support Agents',
);
$page_title = isset($page_titles[$page]) ? $page_titles[$page] : 'Help Center';

$template_map = array(
    'admin-dashboard'     => 'dashboard.php',
    'admin-hub'           => 'section-hub.php',
    'admin-articles'      => 'articles-list.php',
    'admin-article-edit'  => 'article-edit.php',
    'admin-popular'       => 'popular-list.php',
    'admin-categories'    => 'categories-list.php',
    'admin-category-edit' => 'category-edit.php',
    'admin-faqs'          => 'faqs-list.php',
    'admin-faq-edit'      => 'faq-edit.php',
    'admin-revisions'     => 'revisions.php',
    'admin-search-log'    => 'search-log.php',
    'admin-seo-audit'     => 'seo-audit.php',
    'admin-performance-audit' => 'performance-audit.php',
    'admin-settings'      => 'settings.php',
    'admin-web-push'      => 'web-push.php',
    'admin-ai-platform'   => 'ai-platform.php',
    'admin-human-support' => 'human-support.php',
    'admin-agents' => 'agents.php',
);

$css_v = file_exists(HC_PATH . 'assets/css/admin.css') ? filemtime(HC_PATH . 'assets/css/admin.css') . '-' . wp_rand(1000,9999) : HC_VERSION;
$js_v  = file_exists(HC_PATH . 'assets/js/admin.js')  ? filemtime(HC_PATH . 'assets/js/admin.js')  : HC_VERSION;
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html($page_title); ?> — Help Center Admin</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.3.1/css/all.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
<link rel="stylesheet" href="<?php echo esc_url(HC_ASSETS . 'css/admin.css?v=' . $css_v); ?>">
<?php /* HC_ENQUEUE_EDITOR_WRAPPER + HC_EDITOR_HOOKS */
if (in_array($page, array('admin-article-edit','admin-faq-edit'), true)) {
    // Enqueue BEFORE printing so scripts actually appear in the head
    wp_enqueue_media();
    wp_enqueue_editor();
    // HC_NO_EMOJI: disable deprecated emoji functions
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    wp_print_styles();
    wp_print_head_scripts();
}
?>
<style id="hc-inline-table-fix">
/* HC_INLINE_TABLE_FIX */
.hc-admin-card-body.hc-flush table.hc-admin-table {
    table-layout: fixed !important;
    width: 100% !important;
    display: table !important;
}
.hc-admin-card-body.hc-flush table.hc-admin-table th,
.hc-admin-card-body.hc-flush table.hc-admin-table td {
    display: table-cell !important;
    text-align: left !important;
    padding: 16px 24px !important;
}
.hc-admin-card-body.hc-flush table.hc-admin-table th:nth-child(1),
.hc-admin-card-body.hc-flush table.hc-admin-table td:nth-child(1) {
    width: 60% !important;
    text-align: left !important;
}
.hc-admin-card-body.hc-flush table.hc-admin-table th:nth-child(2),
.hc-admin-card-body.hc-flush table.hc-admin-table td:nth-child(2) {
    width: 15% !important;
    text-align: left !important;
}
.hc-admin-card-body.hc-flush table.hc-admin-table th:nth-child(3),
.hc-admin-card-body.hc-flush table.hc-admin-table td:nth-child(3) {
    width: 25% !important;
    text-align: right !important;
}
</style>
</head>
<body class="hc-admin-body">

<div class="hc-admin-layout">

    <aside class="hc-admin-sidebar" id="hcAdminSidebar">
        <div class="hc-admin-sidebar-head">
            <i class="fas fa-circle-question"></i>
            <span>Help Center</span>
            <button type="button" class="hc-admin-sidebar-close" id="hcAdminSidebarClose">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <nav class="hc-admin-nav">
            <?php $last_group = ''; foreach ($menu_items as $item):
                if ($item['group'] !== $last_group) { echo '<div class="hc-admin-nav-section-label">' . esc_html($item['group']) . '</div>'; $last_group = $item['group']; }
                $active = $item['id'] === $current_id;
                $badge = 0;
                if ($item['id'] === 'knowledge-base') $badge = $counts['articles'] + $counts['categories'] + $counts['faqs'];
                if ($item['id'] === 'support-operations') $badge = $counts['support'];
            ?>
            <a href="<?php echo esc_url($item['url']); ?>" class="hc-admin-nav-link <?php echo $active ? 'active' : ''; ?>">
                <i class="fas <?php echo esc_attr($item['icon']); ?>"></i>
                <span><?php echo esc_html($item['label']); ?></span>
                <?php if (in_array($item['id'], array('knowledge-base','support-operations'), true) && $badge > 0): $badge_label = $badge > 999 ? '999+' : (string) $badge; $badge_title = number_format_i18n($badge) . ' ' . strtolower($item['label']); ?><span class="hc-admin-nav-badge" title="<?php echo esc_attr($badge_title); ?>" aria-label="<?php echo esc_attr($badge_title); ?>"><?php echo esc_html($badge_label); ?></span><?php endif; ?>
            </a>
            <?php endforeach; ?>
        </nav>

        <div class="hc-admin-sidebar-foot">
            <a href="<?php echo esc_url(home_url('/helpcenter/')); ?>" target="_blank" class="hc-admin-nav-link">
                <i class="fas fa-external-link-alt"></i>
                <span>View Help Center</span>
            </a>
            <a href="<?php echo esc_url(home_url('/ticket/admin/')); ?>" target="_blank" class="hc-admin-nav-link">
                <i class="fas fa-headset"></i>
                <span>Ticket Admin</span>
            </a>
            <a href="<?php echo esc_url(wp_logout_url(home_url('/helpcenter/admin/'))); ?>" class="hc-admin-nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>

    <div class="hc-admin-main">
        <header class="hc-admin-topbar">
            <button type="button" class="hc-admin-menu-toggle" id="hcAdminMenuToggle">
                <i class="fas fa-bars"></i>
            </button>
            <h1 class="hc-admin-topbar-title"><?php echo esc_html($page_title); ?></h1>
            <div class="hc-admin-topbar-user">
                <span><?php echo esc_html($user->display_name); ?></span>
                <img src="<?php echo esc_url(get_avatar_url($user->ID, array('size' => 32))); ?>" alt="">
            </div>
        </header>

        <div class="hc-admin-content">
            <?php HC_Admin::render_notice(); ?>

            <?php
            if (isset($template_map[$page])) {
                include HC_ADMIN_PATH . $template_map[$page];
            } else {
                echo '<div class="hc-admin-empty"><p>Page not found</p></div>';
            }
            ?>
        </div>
    </div>

</div>

<div class="hc-admin-overlay" id="hcAdminOverlay"></div>


<script>
var hcAdmin = {
    ajaxUrl: <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>,
    nonce:   <?php echo wp_json_encode(wp_create_nonce('hc_nonce')); ?>,
    homeUrl: <?php echo wp_json_encode(home_url('/helpcenter/admin/')); ?>
};
</script>

<?php

?>

<?php /* HC_EDITOR_HOOKS: footer scripts */
if (in_array($page, array('admin-article-edit','admin-faq-edit'), true)) {
    wp_print_media_templates();
    wp_print_footer_scripts();
}
?>
<?php
// HC_INLINE_JQUERY: load jQuery and admin.js inline JUST BEFORE </body>
$jquery_path = ABSPATH . 'wp-includes/js/jquery/jquery.min.js';
if (file_exists($jquery_path)) {
    echo "<script data-cfasync=\"false\">\n" . file_get_contents($jquery_path) . "\n</script>\n";
}
$admin_js_path = HC_PATH . 'assets/js/admin.js';
if (file_exists($admin_js_path)) {
    echo "<script data-cfasync=\"false\">\n" . file_get_contents($admin_js_path) . "\n</script>\n";
}
?>
</body>
</html>
<?php
exit;
