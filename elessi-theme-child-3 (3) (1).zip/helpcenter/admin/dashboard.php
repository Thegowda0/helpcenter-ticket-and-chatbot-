<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// Helper: safe title truncation with ellipsis
if (!function_exists('hc_dash_title')) {
    function hc_dash_title($title, $max = 60) {
        $title = (string) $title;
        if (mb_strlen($title) <= $max) return $title;
        return mb_substr($title, 0, $max - 1) . '…';
    }
}

$stats = array(
    'articles'     => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles WHERE status = 'published' AND deleted_at IS NULL"),
    'drafts'       => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles WHERE status = 'draft' AND deleted_at IS NULL"),
    'categories'   => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_categories WHERE parent_id = 0 AND deleted_at IS NULL"),
    'faqs'         => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_faqs WHERE status = 'published' AND deleted_at IS NULL"),
    'views'        => (int) $wpdb->get_var("SELECT SUM(view_count) FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NULL"),
    'helpful_yes'  => (int) $wpdb->get_var("SELECT SUM(helpful_yes) FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NULL"),
    'helpful_no'   => (int) $wpdb->get_var("SELECT SUM(helpful_no) FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NULL"),
);

$total_votes = $stats['helpful_yes'] + $stats['helpful_no'];
$helpful_rate = $total_votes > 0 ? round(($stats['helpful_yes'] / $total_votes) * 100) : 0;

$recent = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NULL ORDER BY updated_at DESC LIMIT 5");
$popular = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}hc_articles WHERE status = 'published' AND deleted_at IS NULL ORDER BY view_count DESC LIMIT 5");

$top_searches = $wpdb->get_results(
    "SELECT search_query, COUNT(*) as cnt FROM {$wpdb->prefix}hc_search_log
     WHERE results_count > 0 AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY search_query ORDER BY cnt DESC LIMIT 5"
);
$failed_searches = $wpdb->get_results(
    "SELECT search_query, COUNT(*) as cnt FROM {$wpdb->prefix}hc_search_log
     WHERE results_count = 0 AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY search_query ORDER BY cnt DESC LIMIT 5"
);

$link = function($a) {
    return home_url('/helpcenter/admin/articles/edit/' . $a->id . '/');
};
?>

<div class="hc-admin-stats">
    <div class="hc-admin-stat">
        <div class="hc-admin-stat-icon" style="background:#EEF2FF;color:#6366F1;"><i class="fas fa-file-lines"></i></div>
        <div><span class="hc-admin-stat-value"><?php echo $stats['articles']; ?></span><span class="hc-admin-stat-label">Articles</span></div>
    </div>
    <div class="hc-admin-stat">
        <div class="hc-admin-stat-icon" style="background:#F0FDF4;color:#10B981;"><i class="fas fa-folder-tree"></i></div>
        <div><span class="hc-admin-stat-value"><?php echo $stats['categories']; ?></span><span class="hc-admin-stat-label">Categories</span></div>
    </div>
    <div class="hc-admin-stat">
        <div class="hc-admin-stat-icon" style="background:#FFFBEB;color:#F59E0B;"><i class="fas fa-circle-question"></i></div>
        <div><span class="hc-admin-stat-value"><?php echo $stats['faqs']; ?></span><span class="hc-admin-stat-label">FAQs</span></div>
    </div>
    <div class="hc-admin-stat">
        <div class="hc-admin-stat-icon" style="background:#FEF2F2;color:#EF4444;"><i class="fas fa-eye"></i></div>
        <div><span class="hc-admin-stat-value"><?php echo number_format($stats['views']); ?></span><span class="hc-admin-stat-label">Views</span></div>
    </div>
    <div class="hc-admin-stat">
        <div class="hc-admin-stat-icon" style="background:#F0FDF4;color:#10B981;"><i class="fas fa-thumbs-up"></i></div>
        <div><span class="hc-admin-stat-value"><?php echo $helpful_rate; ?>%</span><span class="hc-admin-stat-label">Helpful Rate</span></div>
    </div>
</div>

<div class="hc-dashboard-workspaces">
    <div class="hc-dashboard-workspaces-head"><div><span>WORKSPACES</span><h2>Manage your Help Center</h2><p>Every HelpCenter tool is grouped by the work it supports. Open a workspace to find its related tools and actions.</p></div></div>
    <div class="hc-dashboard-workspaces-grid">
        <a href="<?php echo esc_url(home_url('/helpcenter/admin/section/knowledge-base/')); ?>"><i class="fas fa-book-open"></i><strong>Knowledge Base</strong><span>Articles, categories and FAQs</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(home_url('/helpcenter/admin/section/analytics-quality/')); ?>"><i class="fas fa-chart-line"></i><strong>Analytics & Quality</strong><span>Search, SEO and site health</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(home_url('/helpcenter/admin/section/ai-platform/')); ?>"><i class="fas fa-brain"></i><strong>AI Platform</strong><span>AI search and assistant setup</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(home_url('/helpcenter/admin/section/support-operations/')); ?>"><i class="fas fa-headset"></i><strong>Support Operations</strong><span>Escalations and live support</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(home_url('/helpcenter/admin/section/agents-team/')); ?>"><i class="fas fa-users"></i><strong>Agents & Team</strong><span>Support agent management</span><b>Open workspace →</b></a>
        <a href="<?php echo esc_url(home_url('/helpcenter/admin/section/settings/')); ?>"><i class="fas fa-sliders"></i><strong>Settings</strong><span>Help Center configuration</span><b>Open workspace →</b></a>
    </div>
</div>

<div class="hc-admin-grid-2">

    <div class="hc-admin-card">
        <div class="hc-admin-card-head">
            <h3>Recent Articles</h3>
            <a href="<?php echo esc_url(home_url('/helpcenter/admin/articles/')); ?>" class="hc-admin-btn hc-admin-btn-sm hc-admin-btn-outline">View All</a>
        </div>
        <div class="hc-admin-card-body hc-flush">
            <?php if (!empty($recent)): ?>
            <table class="hc-admin-table">
                <tbody>
                    <?php foreach ($recent as $a): ?>
                    <tr>
                        <td title="<?php echo esc_attr($a->title); ?>">
                            <a href="<?php echo esc_url($link($a)); ?>" class="hc-admin-link">
                                <?php echo esc_html(hc_dash_title($a->title, 60)); ?>
                            </a>
                        </td>
                        <td><span class="hc-status hc-status-<?php echo esc_attr($a->status); ?>"><?php echo esc_html($a->status); ?></span></td>
                        <td class="hc-muted"><?php echo esc_html(HC_Core::time_ago($a->updated_at)); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="hc-admin-empty"><p>No articles yet</p></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="hc-admin-card">
        <div class="hc-admin-card-head">
            <h3>Popular Articles</h3>
        </div>
        <div class="hc-admin-card-body hc-flush">
            <?php if (!empty($popular)): ?>
            <table class="hc-admin-table">
                <tbody>
                    <?php foreach ($popular as $a): ?>
                    <tr>
                        <td title="<?php echo esc_attr($a->title); ?>">
                            <a href="<?php echo esc_url($link($a)); ?>" class="hc-admin-link">
                                <?php echo esc_html(hc_dash_title($a->title, 60)); ?>
                            </a>
                        </td>
                        <td class="hc-muted"><?php echo (int) $a->view_count; ?> views</td>
                        <td class="hc-muted"><i class="fas fa-thumbs-up"></i> <?php echo (int) $a->helpful_yes; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="hc-admin-empty"><p>No data yet</p></div>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php if (!empty($top_searches) || !empty($failed_searches)): ?>
<div class="hc-admin-grid-2">

    <?php if (!empty($top_searches)): ?>
    <div class="hc-admin-card">
        <div class="hc-admin-card-head"><h3>Top Searches (30d)</h3></div>
        <div class="hc-admin-card-body hc-flush">
            <table class="hc-admin-table">
                <tbody>
                    <?php foreach ($top_searches as $s): ?>
                    <tr>
                        <td><?php echo esc_html(wp_trim_words($s->search_query, 6)); ?></td>
                        <td class="hc-muted"><?php echo (int) $s->cnt; ?>×</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($failed_searches)): ?>
    <div class="hc-admin-card hc-admin-card-warn">
        <div class="hc-admin-card-head">
            <h3><i class="fas fa-triangle-exclamation"></i> Searches With No Results</h3>
            <span class="hc-muted" style="font-size:12px;">Content gaps to fill</span>
        </div>
        <div class="hc-admin-card-body hc-flush">
            <table class="hc-admin-table">
                <tbody>
                    <?php foreach ($failed_searches as $s): ?>
                    <tr>
                        <td><?php echo esc_html(wp_trim_words($s->search_query, 6)); ?></td>
                        <td class="hc-muted"><?php echo (int) $s->cnt; ?>×</td>
                        <td>
                            <a href="<?php echo esc_url(home_url('/helpcenter/admin/articles/new/')); ?>" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-primary">Create</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

</div>
<?php endif; ?>
