<?php
if (!defined('ABSPATH')) exit;


// HC_TRASH_EDIT_GUARD: block editing trashed items
$id = (int) get_query_var('hc_id');
if ($id > 0) {
    global $wpdb;
    $is_trashed = $wpdb->get_var($wpdb->prepare("SELECT deleted_at FROM {$wpdb->prefix}hc_articles WHERE id = %d", $id));
    if ($is_trashed) {
        wp_die('This article is in the trash and cannot be edited. Restore it first.', 'Item in Trash', array('back_link' => true));
    }
}
$article = $id ? HC_Core::get_article($id) : null;
$is_edit = $article !== null;

// Load ALL categories (flat list) so we can build the tree
global $wpdb;
$cats = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}hc_categories WHERE deleted_at IS NULL ORDER BY name ASC");

// Load currently assigned categories
$assigned_cats = array();
if ($is_edit) {
    global $wpdb;
    $assigned_cats = $wpdb->get_col($wpdb->prepare("SELECT category_id FROM {$wpdb->prefix}hc_article_categories WHERE article_id = %d", $id));
    if (empty($assigned_cats) && !empty($article->category_id)) {
        $assigned_cats = array($article->category_id);
    }
}
?>

<div class="hc-admin-page-head">
    <a href="<?php echo esc_url(home_url('/helpcenter/admin/articles/')); ?>" class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm">
        <i class="fas fa-arrow-left"></i> Back
    </a>
    <h1><?php echo $is_edit ? 'Edit Article' : 'New Article'; ?></h1>
    <?php if ($is_edit): ?><a class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm" target="_blank" rel="noopener" href="<?php echo esc_url(add_query_arg(array('hc_preview'=>(int)$article->id,'hc_preview_token'=>wp_create_nonce('hc_preview_'.(int)$article->id)), home_url('/helpcenter/article/'.$article->slug.'/'))); ?>"><i class="fas fa-eye"></i> Preview</a><?php endif; ?>
</div>

<?php if ($is_edit): ?><a class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm" href="<?php echo esc_url(home_url('/helpcenter/admin/revisions/article/' . (int)$id . '/')); ?>"><i class="fas fa-clock-rotate-left"></i> Revision History</a><?php endif; ?>

<form id="hcArticleForm" class="hc-edit-form" data-id="<?php echo (int) $id; ?>">
    <div id="hcAutosaveStatus" class="hc-muted" role="status" style="margin:0 0 12px;text-align:right;font-size:12px;">Autosave is on</div>

    <div class="hc-edit-layout">

        <!-- ============ MAIN COLUMN ============ -->
        <div class="hc-edit-main">

            <?php /* HC_VISIBILITY_NOTICE */ ?>
            <?php if ($is_edit):
                $hc_why = HC_Lifecycle::article_hidden_reason($article);
                if ($hc_why !== ''): ?>
            <div class="hc-admin-notice" style="background:#FFFBEB;border:1px solid #FCD34D;color:#92400E;padding:12px 16px;border-radius:8px;margin-bottom:16px;">
                <i class="fas fa-eye-slash"></i> <strong>Not visible to visitors:</strong> <?php echo esc_html($hc_why); ?>.
            </div>
            <?php endif; endif; ?>

            <?php /* HC_ARTICLE_FAQ_REASONS */ ?>
            <?php if ($is_edit): ?>
            <?php
                $linked_faqs = HC_Core::get_faqs_admin((int) $id);
                $faqs_with_reasons = array();
                if (!empty($linked_faqs)) {
                    foreach ($linked_faqs as $lf) {
                        $reasons = HC_Core::get_faq_draft_reasons($lf->id);
                        if (!empty($reasons)) {
                            $lf->reasons = $reasons;
                            $faqs_with_reasons[] = $lf;
                        }
                    }
                }
            ?>
            <?php if (!empty($faqs_with_reasons)): ?>
            <div class="hc-admin-card hc-article-faq-reasons">
                <div class="hc-admin-card-head">
                    <h3><i class="fas fa-triangle-exclamation" style="color:#D97706;"></i> FAQ Status History</h3>
                    <span class="hc-muted" style="font-size:12px;">
                        These FAQs reference this article and had a status change
                    </span>
                </div>
                <div class="hc-admin-card-body">
                    <?php foreach ($faqs_with_reasons as $faq): ?>
                    <div class="hc-afr-item">
                        <div class="hc-afr-head">
                            <a href="<?php echo esc_url(home_url('/helpcenter/admin/faqs/edit/' . $faq->id . '/')); ?>" class="hc-admin-link">
                                <?php echo esc_html(wp_trim_words($faq->question, 12)); ?>
                            </a>
                            <span class="hc-status hc-status-<?php echo esc_attr($faq->status); ?>">
                                <?php echo esc_html($faq->status); ?>
                            </span>
                        </div>
                        <ul class="hc-afr-list">
                            <?php foreach ($faq->reasons as $r): ?>
                            <li>
                                <span class="hc-afr-date"><?php echo esc_html($r['at']); ?></span>
                                <?php echo esc_html($r['reason']); ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>

            <div class="hc-admin-card">
                <div class="hc-admin-card-body">

                    <div class="hc-admin-field">
                        <label>Title <span class="req">*</span></label>
                        <input type="text" name="title" id="hcTitle"  value="<?php echo $is_edit ? esc_attr($article->title) : ''; ?>" placeholder="Article title">
                    </div>

                    <div class="hc-admin-field">
                        <label>Slug</label>
                        <input type="text" name="slug" id="hcSlug" value="<?php echo $is_edit ? esc_attr($article->slug) : ''; ?>" placeholder="auto-generated from title">
                    </div>

                    <div class="hc-admin-field">
                        <label>Excerpt / Summary</label>
                        <textarea name="excerpt" rows="2" placeholder="Brief summary shown in listings"><?php echo $is_edit ? esc_textarea($article->excerpt) : ''; ?></textarea>
                    </div>

                    <div class="hc-admin-field">
                        <label>Content <span class="req">*</span></label>
                        <?php
                        $content = $is_edit ? $article->content : '';
                        wp_enqueue_media();
                        wp_enqueue_editor();

                        wp_editor($content, 'hcContent', array(
                            'textarea_name' => 'content',
                            'media_buttons' => true,
                            'textarea_rows' => 22,
                            'editor_height' => 520,
                            'teeny'         => false,
                        ));
                        ?>
                    </div>

                </div>
            </div>

        </div>

        <!-- ============ SIDEBAR ============ -->
        <aside class="hc-edit-side">
            <div class="hc-edit-side-inner">

                <div class="hc-admin-card">
                    <div class="hc-admin-card-head">
                        <h3><i class="fas fa-eye"></i> Publish</h3>
                    </div>
                    <div class="hc-admin-card-body">

                        <div class="hc-admin-field">
                            <label>Status</label>
                            <select name="status">
                                <option value="published" <?php selected($is_edit ? $article->status : 'published', 'published'); ?>>Published</option>
                                <option value="draft" <?php selected($is_edit ? $article->status : '', 'draft'); ?>>Draft</option>
                            </select>
                        </div>

                        <div class="hc-admin-field">
                            <label>Sort Order</label>
                            <input type="number" name="sort_order" value="<?php echo $is_edit ? (int) $article->sort_order : 0; ?>" min="0">
                        </div>

                        <button type="submit" class="hc-admin-btn hc-admin-btn-primary hc-admin-btn-lg hc-save-btn" id="hcArticleSaveBtn">
                            <i class="fas fa-save"></i> <?php echo $is_edit ? 'Update' : 'Create'; ?>
                        </button>
                        <a href="<?php echo esc_url(home_url('/helpcenter/admin/articles/')); ?>" class="hc-admin-btn hc-admin-btn-outline hc-save-btn" style="margin-top:8px;">
                            Cancel
                        </a>

                    </div>
                </div>

                <div class="hc-admin-card">
                    <div class="hc-admin-card-head">
                        <h3><i class="fas fa-folder-tree"></i> Category</h3>
                    </div>
                    <div class="hc-admin-card-body">
                        <div class="hc-admin-field">
                            <label>Category <span class="req">*</span></label>
                            <?php 
// Ensure all categories are loaded
$all_cats = HC_Core::get_categories(0, 'any', true); 
?>
<div style="display:flex;gap:6px;margin-bottom:8px"><input type="text" id="hcQuickCategoryName" placeholder="Add new category…" style="flex:1;min-width:0;padding:8px 10px;border:1px solid #CBD5E1;border-radius:6px"><button type="button" id="hcQuickAddCategory" class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm">Add</button></div><div id="hcQuickCategoryMessage" class="hc-muted" style="font-size:12px;margin-bottom:8px" aria-live="polite"></div>
<input type="text" id="hcCatSearch" placeholder="Search categories..." style="width: 100%; padding: 8px 12px; border: 1px solid #CBD5E1; border-radius: 6px; margin-bottom: 10px; font-size: 13px;">
<div class="hc-multi-cat-box" style="max-height: 250px; overflow-y: auto; border: 1px solid #CBD5E1; border-radius: 8px; padding: 12px; background: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
    <?php 
    // Helper function to render categories recursively
    if (!function_exists('hc_render_cat_tree')) {
        function hc_render_cat_tree($parent_id, $cats, $assigned_cats, $depth = 0) {
            // Find children of this parent
            $children = array_filter($cats, function($c) use ($parent_id) {
                return (int)$c->parent_id === (int)$parent_id;
            });

            foreach ($children as $cat) {
                $is_checked = in_array($cat->id, $assigned_cats);
                $is_draft = ($cat->status !== 'published');
                
                // Indentation
                $padding_left = 12 + ($depth * 24);
                ?>
                <label style="display: flex; align-items: center; padding: 8px; margin-bottom: 2px; border-radius: 4px; cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='#F1F5F9'" onmouseout="this.style.background='transparent'">
                    
                    <!-- Indentation Spacer -->
                    <div style="width: <?php echo $padding_left; ?>px; flex-shrink: 0;"></div>
                    
                    <!-- Checkbox -->
                    <input type="checkbox" name="category_ids[]" value="<?php echo (int) $cat->id; ?>" <?php echo $is_checked ? 'checked' : ''; ?> style="margin-right: 10px; width: 16px; height: 16px; cursor: pointer; flex-shrink: 0;">
                    
                    <!-- Icon -->
                    <?php if ($depth > 0): ?>
                        <i class="fas fa-level-up-alt fa-rotate-90" style="color: #94A3B8; margin-right: 8px; font-size: 12px; flex-shrink: 0;"></i>
                    <?php else: ?>
                        <i class="fas fa-folder" style="color: #4F46E5; margin-right: 8px; flex-shrink: 0;"></i>
                    <?php endif; ?>
                    
                    <!-- Name -->
                    <span style="font-size: 14px; color: #334155; font-weight: 500; flex-grow: 1;">
                        <?php echo esc_html($cat->name); ?>
                    </span>
                    
                    <!-- Draft Bubble -->
                    <?php if ($is_draft): ?>
                        <span style="background: #FEE2E2; color: #EF4444; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 12px; margin-left: 8px;">Hidden</span>
                    <?php endif; ?>
                    
                </label>
                <?php
                // Render children
                hc_render_cat_tree($cat->id, $cats, $assigned_cats, $depth + 1);
            }
        }
    }

    if (empty($cats)): ?>
        <span style="color: #94A3B8;">No categories found.</span>
    <?php else: ?>
        <?php hc_render_cat_tree(0, $cats, $assigned_cats); ?>
    <?php endif; ?>
</div>
                        </div>

                        
                    </div>
                </div>

                <div class="hc-admin-card">
                    <div class="hc-admin-card-head">
                        <h3><i class="fas fa-magnifying-glass-chart"></i> SEO</h3>
                    </div>
                    <div class="hc-admin-card-body">

                        <div class="hc-admin-field">
                            <label>Schema Type</label>
                            <select name="schema_type">
                                <option value="inherit" <?php selected($is_edit ? $article->schema_type : 'inherit', 'inherit'); ?>>Inherit from Settings</option>
                                <option value="Article" <?php selected($is_edit ? $article->schema_type : '', 'Article'); ?>>Article</option>
                                <option value="TechArticle" <?php selected($is_edit ? $article->schema_type : '', 'TechArticle'); ?>>TechArticle</option>
                                <option value="HowTo" <?php selected($is_edit ? $article->schema_type : '', 'HowTo'); ?>>HowTo</option>
                                <option value="FAQPage" <?php selected($is_edit ? $article->schema_type : '', 'FAQPage'); ?>>FAQPage</option>
                                <option value="none" <?php selected($is_edit ? $article->schema_type : '', 'none'); ?>>None</option>
                            </select>
                        </div>

                        <div class="hc-admin-field">
                            <label>Robots Meta</label>
                            <?php $robots = $is_edit ? ($article->robots_meta ?: 'inherit') : 'inherit'; ?>
                            <select name="robots_meta">
                                <option value="inherit" <?php selected($robots, 'inherit'); ?>>Inherit (index, follow)</option>
                                <option value="index,follow" <?php selected($robots, 'index,follow'); ?>>Index, Follow</option>
                                <option value="noindex,follow" <?php selected($robots, 'noindex,follow'); ?>>No Index, Follow</option>
                                <option value="noindex,nofollow" <?php selected($robots, 'noindex,nofollow'); ?>>No Index, No Follow</option>
                                <option value="noindex,nofollow,noarchive" <?php selected($robots, 'noindex,nofollow,noarchive'); ?>>No Index, No Follow, No Archive</option>
                            </select>
                        </div>

                        <div class="hc-admin-field">
                            <label>Meta Keywords</label>
                            <input type="text" name="meta_keywords" value="<?php echo $is_edit ? esc_attr($article->meta_keywords) : ''; ?>" placeholder="keyword1, keyword2">
                            <small>Comma separated.</small>
                        </div>

                    </div>
                </div>

            </div>
        </aside>

    </div>

</form>
