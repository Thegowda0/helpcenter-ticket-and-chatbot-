<?php
if (!defined('ABSPATH')) exit;
global $wpdb;
$t = $wpdb->prefix . 'hc_search_log';
$days = isset($_GET['days']) ? absint($_GET['days']) : 30;
if (!in_array($days, array(7, 30, 90, 365), true)) $days = 30;
$cutoff = date('Y-m-d H:i:s', current_time('timestamp') - ($days * DAY_IN_SECONDS));
$since = $wpdb->prepare('created_at >= %s', $cutoff);
$total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE {$since}");
$failed_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE {$since} AND results_count = 0");
$unique_queries = (int) $wpdb->get_var("SELECT COUNT(DISTINCT LOWER(TRIM(search_query))) FROM {$t} WHERE {$since}");
$success_rate = $total ? round((($total - $failed_total) / $total) * 100) : 0;
$top = $wpdb->get_results("SELECT MIN(search_query) AS search_query, COUNT(*) AS searches, ROUND(AVG(results_count),1) AS avg_results, MIN(results_count) AS min_results, MAX(created_at) AS last_searched FROM {$t} WHERE {$since} GROUP BY LOWER(TRIM(search_query)) ORDER BY searches DESC, last_searched DESC LIMIT 25");
$failed = $wpdb->get_results("SELECT MIN(search_query) AS search_query, COUNT(*) AS searches, MAX(created_at) AS last_searched FROM {$t} WHERE {$since} AND results_count = 0 GROUP BY LOWER(TRIM(search_query)) ORDER BY searches DESC, last_searched DESC LIMIT 25");
$recent = $wpdb->get_results("SELECT search_query, results_count, created_at FROM {$t} WHERE {$since} ORDER BY created_at DESC LIMIT 40");
$click_table = $wpdb->prefix . 'hc_search_clicks';
$click_total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$click_table} WHERE created_at >= %s", $cutoff));
$clicked_articles = $wpdb->get_results($wpdb->prepare("SELECT a.id,a.title,COUNT(c.id) AS clicks FROM {$click_table} c INNER JOIN {$wpdb->prefix}hc_articles a ON a.id=c.article_id WHERE c.created_at >= %s AND a.deleted_at IS NULL GROUP BY a.id,a.title ORDER BY clicks DESC LIMIT 10", $cutoff));
$no_click = $wpdb->get_results($wpdb->prepare(
    "SELECT MIN(l.search_query) AS search_query,COUNT(*) AS searches,MAX(l.created_at) AS last_searched FROM {$t} l LEFT JOIN (SELECT LOWER(TRIM(search_query)) AS query_key,COUNT(*) AS clicks FROM {$click_table} WHERE created_at >= %s GROUP BY LOWER(TRIM(search_query))) c ON c.query_key=LOWER(TRIM(l.search_query)) WHERE l.created_at >= %s AND l.results_count > 0 AND COALESCE(c.clicks,0)=0 GROUP BY LOWER(TRIM(l.search_query)) ORDER BY searches DESC,last_searched DESC LIMIT 20",
    $cutoff, $cutoff
));
$quality_table = $wpdb->prefix . 'hc_articles';
$quality_issues = $wpdb->get_results(
    "SELECT id,title,excerpt,content,meta_keywords,updated_at FROM {$quality_table} WHERE status='published' AND deleted_at IS NULL ORDER BY updated_at DESC LIMIT 300"
);
$quality_rows = array();
foreach ((array)$quality_issues as $article) {
    $issues = array();
    if (trim(wp_strip_all_tags((string)$article->excerpt)) === '') $issues[] = 'Missing summary';
    if (str_word_count(wp_strip_all_tags((string)$article->content)) < 80) $issues[] = 'Very short content';
    if (trim((string)$article->meta_keywords) === '') $issues[] = 'No keywords';
    if ($issues) $quality_rows[] = (object) array('id'=>$article->id,'title'=>$article->title,'issues'=>$issues);
    if (count($quality_rows) >= 20) break;
}
?>
<style>
.hc-search-analytics{display:grid;gap:20px}.hc-search-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.hc-search-kpi{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:18px;min-width:0}.hc-search-kpi strong{display:block;font-size:27px;line-height:1.2;color:#111827}.hc-search-kpi span{display:block;color:#64748b;font-size:12px;margin-top:7px}.hc-search-panels{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.hc-search-panel{min-width:0}.hc-search-filter{display:flex;align-items:center;gap:8px}.hc-search-filter select{min-height:34px;border:1px solid #d1d5db;border-radius:7px;padding:4px 28px 4px 9px;background:#fff}.hc-search-table-wrap{overflow:auto}.hc-search-query{font-weight:600;overflow-wrap:anywhere}.hc-search-muted{color:#64748b;font-size:12px}.hc-search-zero{color:#b91c1c;font-weight:700}.hc-search-good{color:#047857;font-weight:700}.hc-search-empty-note{padding:22px;color:#64748b;text-align:center}@media(max-width:900px){.hc-search-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.hc-search-panels{grid-template-columns:1fr}}@media(max-width:480px){.hc-search-kpis{gap:8px}.hc-search-kpi{padding:12px}.hc-search-kpi strong{font-size:22px}}
</style>
<div class="hc-admin-page-head">
 <div><h1>Search Analytics</h1><p class="hc-muted">Understand what visitors are looking for and identify missing help content.</p></div>
 <a class="hc-admin-btn hc-admin-btn-secondary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=hc_export_search_analytics&days=' . (int)$days), 'hc_export_search_analytics')); ?>"><i class="fas fa-download"></i> Export CSV</a><form method="get" class="hc-search-filter"><input type="hidden" name="page" value="hc-search-log"><label for="hcSearchDays" class="screen-reader-text">Date range</label><select id="hcSearchDays" name="days" onchange="this.form.submit()"><option value="7" <?php selected($days,7); ?>>Last 7 days</option><option value="30" <?php selected($days,30); ?>>Last 30 days</option><option value="90" <?php selected($days,90); ?>>Last 90 days</option><option value="365" <?php selected($days,365); ?>>Last 12 months</option></select></form>
</div>
<div class="hc-search-analytics">
 <div class="hc-search-kpis">
  <div class="hc-search-kpi"><strong><?php echo number_format($total); ?></strong><span>Total searches · <?php echo (int)$days; ?> days</span></div>
  <div class="hc-search-kpi"><strong><?php echo number_format($unique_queries); ?></strong><span>Distinct search phrases</span></div>
  <div class="hc-search-kpi"><strong><?php echo number_format($failed_total); ?></strong><span>Searches with no results</span></div>
  <div class="hc-search-kpi"><strong><?php echo (int)$success_rate; ?>%</strong><span>Searches returning at least one result</span></div>
  <div class="hc-search-kpi"><strong><?php echo number_format($click_total); ?></strong><span>Search-result clicks · <?php echo (int)$days; ?> days</span></div>
 </div>
 <div class="hc-search-panels">
  <section class="hc-admin-card hc-search-panel"><div class="hc-admin-card-head"><h3>Most searched phrases</h3><span class="hc-muted">Grouped without case differences</span></div><div class="hc-admin-card-body hc-flush hc-search-table-wrap">
   <?php if ($top): ?><table class="hc-admin-table"><thead><tr><th>Search phrase</th><th>Searches</th><th>Avg. results</th></tr></thead><tbody><?php foreach($top as $r): ?><tr><td class="hc-search-query"><?php echo esc_html($r->search_query); ?><div class="hc-search-muted">Last: <?php echo esc_html(HC_Core::time_ago($r->last_searched)); ?></div></td><td><?php echo number_format((int)$r->searches); ?></td><td><?php echo number_format((float)$r->avg_results,1); ?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="hc-search-empty-note">No search activity in this period.</div><?php endif; ?>
  </div></section>
  <section class="hc-admin-card hc-search-panel"><div class="hc-admin-card-head"><h3>Content gaps · zero results</h3><span class="hc-muted">Prioritize these topics</span></div><div class="hc-admin-card-body hc-flush hc-search-table-wrap">
   <?php if ($failed): ?><table class="hc-admin-table"><thead><tr><th>Unanswered phrase</th><th>Occurrences</th><th></th></tr></thead><tbody><?php foreach($failed as $r): ?><tr><td class="hc-search-query"><?php echo esc_html($r->search_query); ?><div class="hc-search-muted">Last: <?php echo esc_html(HC_Core::time_ago($r->last_searched)); ?></div></td><td class="hc-search-zero"><?php echo number_format((int)$r->searches); ?></td><td><a class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-primary" href="<?php echo esc_url(home_url('/helpcenter/admin/articles/new/')); ?>">Create article</a></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="hc-search-empty-note">No zero-result searches in this period. Great work.</div><?php endif; ?>
  </div></section>
 </div>
 <div class="hc-search-panels">
  <section class="hc-admin-card hc-search-panel"><div class="hc-admin-card-head"><h3>Searches with no clicks</h3><span class="hc-muted">Phrase-level signal: results appeared, but no matching click was recorded</span></div><div class="hc-admin-card-body hc-flush hc-search-table-wrap">
   <?php if ($no_click): ?><table class="hc-admin-table"><thead><tr><th>Search phrase</th><th>Searches</th></tr></thead><tbody><?php foreach($no_click as $r): ?><tr><td class="hc-search-query"><?php echo esc_html($r->search_query); ?><div class="hc-search-muted">Last: <?php echo esc_html(HC_Core::time_ago($r->last_searched)); ?></div></td><td><?php echo number_format((int)$r->searches); ?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="hc-search-empty-note">No no-click searches found for this period.</div><?php endif; ?>
  </div></section>
  <section class="hc-admin-card hc-search-panel"><div class="hc-admin-card-head"><h3>Article content checks</h3><span class="hc-muted">Published articles that may need improvement</span></div><div class="hc-admin-card-body hc-flush hc-search-table-wrap">
   <?php if ($quality_rows): ?><table class="hc-admin-table"><thead><tr><th>Article</th><th>Checks</th></tr></thead><tbody><?php foreach($quality_rows as $a): ?><tr><td><a class="hc-admin-link" href="<?php echo esc_url(home_url('/helpcenter/admin/articles/edit/' . (int)$a->id . '/')); ?>"><?php echo esc_html($a->title); ?></a></td><td><?php echo esc_html(implode(' · ', $a->issues)); ?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="hc-search-empty-note">No obvious content gaps found in the articles checked.</div><?php endif; ?>
  </div></section>
 </div>
 <section class="hc-admin-card"><div class="hc-admin-card-head"><h3>Recent search activity</h3><span class="hc-muted">Latest 40 recorded searches</span></div><div class="hc-admin-card-body hc-flush hc-search-table-wrap">
  <?php if ($recent): ?><table class="hc-admin-table"><thead><tr><th>Search phrase</th><th>Results returned</th><th>Time</th></tr></thead><tbody><?php foreach($recent as $r): ?><tr><td class="hc-search-query"><?php echo esc_html($r->search_query); ?></td><td class="<?php echo (int)$r->results_count === 0 ? 'hc-search-zero' : 'hc-search-good'; ?>"><?php echo number_format((int)$r->results_count); ?></td><td class="hc-search-muted"><?php echo esc_html(HC_Core::time_ago($r->created_at)); ?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="hc-search-empty-note">No recent searches.</div><?php endif; ?>
 </div></section>
 <section class="hc-admin-card"><div class="hc-admin-card-head"><h3>Most-clicked articles from search</h3><span class="hc-muted">Latest selected period</span></div><div class="hc-admin-card-body hc-flush hc-search-table-wrap">
  <?php if ($clicked_articles): ?><table class="hc-admin-table"><thead><tr><th>Article</th><th>Clicks</th></tr></thead><tbody><?php foreach($clicked_articles as $a): ?><tr><td><a class="hc-admin-link" href="<?php echo esc_url(home_url('/helpcenter/admin/articles/edit/' . (int)$a->id . '/')); ?>"><?php echo esc_html($a->title); ?></a></td><td><?php echo number_format((int)$a->clicks); ?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="hc-search-empty-note">No search-result clicks recorded yet. New clicks will appear here.</div><?php endif; ?>
 </div></section>
 <p class="hc-search-muted">No-click phrase analysis is aggregated by query and period; it cannot identify individual visitor intent. Content checks are heuristic and should be reviewed by an editor. Search counts are deduplicated per visitor and phrase within a short 20-second window. New entries store a site-salted visitor hash instead of a raw IP address. Historical entries are retained; older logs do not include the newer deduplication behaviour.</p>
</div>
