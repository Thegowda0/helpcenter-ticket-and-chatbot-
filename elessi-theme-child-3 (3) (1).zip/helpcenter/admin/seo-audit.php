<?php
if (!defined('ABSPATH')) exit;
global $wpdb;
$table = $wpdb->prefix . 'hc_articles';
$live = HC_Lifecycle::sql_article_live('a');
$articles = $wpdb->get_results("SELECT a.id,a.title,a.slug,a.excerpt,a.content,a.meta_keywords,a.schema_type,a.updated_at FROM {$table} a WHERE {$live} ORDER BY a.updated_at DESC");
$all = is_array($articles) ? $articles : array();
$issues = array(); $slugs = array(); $titles = array(); $known = array();
foreach ($all as $a) { $known[strtolower(trim($a->slug))] = true; $slugs[strtolower(trim($a->slug))][] = $a; $titles[strtolower(trim(wp_strip_all_tags($a->title)))][] = $a; }
$add = function($type,$article,$detail) use (&$issues) { $issues[] = array('type'=>$type,'id'=>(int)$article->id,'title'=>$article->title,'detail'=>$detail); };
foreach ($all as $a) {
    if (trim(wp_strip_all_tags((string)$a->excerpt)) === '') $add('Missing meta description',$a,'Add a concise summary/excerpt.');
    if (trim((string)$a->meta_keywords) === '') $add('Missing keywords',$a,'Add relevant tags or search keywords.');
    $plain = trim(preg_replace('/\s+/u',' ',wp_strip_all_tags((string)$a->content)));
    $words = $plain === '' ? 0 : count(preg_split('/\s+/u',$plain));
    if ($words === 0) $add('Empty article',$a,'Published article has no readable body text.');
    elseif ($words < 80) $add('Thin content',$a,'Only '.$words.' words; review whether the answer is complete.');
    if (in_array((string)$a->schema_type,array('none',''),true)) $add('Schema disabled',$a,'This article does not specify an article schema type.');
    if ($a->updated_at && strtotime($a->updated_at) < current_time('timestamp') - 365*DAY_IN_SECONDS) $add('Possibly outdated',$a,'Not updated in over 12 months; review for accuracy.');
    if (preg_match_all('/href=["\']([^"\']+)["\']/i',(string)$a->content,$matches)) {
        foreach ($matches[1] as $href) {
            $url = html_entity_decode(trim($href),ENT_QUOTES,'UTF-8');
            $path = (string)parse_url($url,PHP_URL_PATH);
            if (strpos($path,'/helpcenter/article/') === false) continue;
            if (preg_match('~/helpcenter/article/([^/]+)/?~',$path,$m)) {
                $slug = strtolower(rawurldecode($m[1]));
                if (!isset($known[$slug])) { $add('Broken internal article link',$a,'Link points to missing or unpublished slug: '.$slug); }
            }
        }
    }
}
foreach ($titles as $key=>$group) if ($key !== '' && count($group)>1) foreach ($group as $a) $add('Duplicate title',$a,'Shared by '.$group[0]->title.' and '.$group[1]->title.' ('.$group[0]->id.', '.$group[1]->id.').');
foreach ($slugs as $key=>$group) if ($key !== '' && count($group)>1) foreach ($group as $a) $add('Duplicate slug',$a,'Slug is used by more than one published article: '.$key);
$category_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_categories c WHERE ".HC_Lifecycle::sql_category_live('c'));
$schema_on = HC_Core::get_setting('hc_schema_enabled','1') === '1';
$schema_default = HC_Core::get_setting('hc_schema_article_type','TechArticle');
$counts = array(); foreach ($issues as $i) $counts[$i['type']] = ($counts[$i['type']] ?? 0)+1;
$issue_total = count($issues);
?>
<div class="hc-admin-page-head"><div><h1>SEO Audit</h1><p>Read-only checks for published Help Center articles. Nothing is changed automatically.</p></div><a class="hc-admin-link" href="<?php echo esc_url(home_url('/helpcenter-sitemap.xml')); ?>" target="_blank" rel="noopener">View XML Sitemap <i class="fas fa-arrow-up-right-from-square"></i></a></div>
<div class="hc-admin-stats">
 <div class="hc-admin-stat"><div><span class="hc-admin-stat-value"><?php echo number_format_i18n(count($all)); ?></span><span class="hc-admin-stat-label">Published articles</span></div></div>
 <div class="hc-admin-stat"><div><span class="hc-admin-stat-value"><?php echo number_format_i18n($category_count); ?></span><span class="hc-admin-stat-label">Published categories</span></div></div>
 <div class="hc-admin-stat"><div><span class="hc-admin-stat-value"><?php echo number_format_i18n($issue_total); ?></span><span class="hc-admin-stat-label">Audit findings</span></div></div>
 <div class="hc-admin-stat"><div><span class="hc-admin-stat-value"><?php echo $schema_on ? 'Enabled' : 'Disabled'; ?></span><span class="hc-admin-stat-label">Schema output</span></div></div>
</div>
<div class="hc-admin-card"><div class="hc-admin-card-head"><h3>Site-wide checks</h3></div><div class="hc-admin-card-body"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px">
 <div><strong>Sitemap endpoint</strong><p><a href="<?php echo esc_url(home_url('/helpcenter-sitemap.xml')); ?>" target="_blank" rel="noopener"><?php echo esc_html(home_url('/helpcenter-sitemap.xml')); ?></a></p><small>Generated dynamically from currently public categories and articles.</small></div>
 <div><strong>Article schema default</strong><p><?php echo esc_html($schema_default); ?></p><small>Per-article schema can override this setting.</small></div>
 <div><strong>LLMs discovery file</strong><p><a href="<?php echo esc_url(home_url('/llms.txt')); ?>" target="_blank" rel="noopener">Open llms.txt</a></p><small>Public content discovery endpoint.</small></div>
 <div><strong>Robots policy</strong><p>Admin paths disallowed; Help Center content allowed.</p><small>Verify the final combined robots.txt if another SEO plugin also modifies it.</small></div>
 </div></div></div>
<div class="hc-admin-card"><div class="hc-admin-card-head"><h3>Findings by type</h3><span><?php echo number_format_i18n($issue_total); ?> total</span></div><div class="hc-admin-card-body hc-flush">
<?php if (!$issues): ?><div class="hc-admin-empty"><i class="fas fa-circle-check"></i><p>No issues found in the checks that ran.</p></div><?php else: ?>
<table class="hc-admin-table"><thead><tr><th>Check</th><th>Count</th></tr></thead><tbody><?php foreach ($counts as $type=>$n): ?><tr><td><?php echo esc_html($type); ?></td><td><?php echo number_format_i18n($n); ?></td></tr><?php endforeach; ?></tbody></table>
<?php endif; ?></div></div>
<div class="hc-admin-card"><div class="hc-admin-card-head"><h3>Article-level findings</h3><span>Published articles only</span></div><div class="hc-admin-card-body hc-flush">
<?php if (!$issues): ?><div class="hc-admin-empty"><p>Nothing to review.</p></div><?php else: ?><div style="overflow-x:auto"><table class="hc-admin-table"><thead><tr><th>Article</th><th>Finding</th><th>Details</th><th>Action</th></tr></thead><tbody><?php foreach (array_slice($issues,0,500) as $i): ?><tr><td><?php echo esc_html($i['title']); ?><small>#<?php echo (int)$i['id']; ?></small></td><td><?php echo esc_html($i['type']); ?></td><td><?php echo esc_html($i['detail']); ?></td><td><a href="<?php echo esc_url(home_url('/helpcenter/admin/articles/edit/'.(int)$i['id'].'/')); ?>">Edit</a></td></tr><?php endforeach; ?></tbody></table></div><?php if ($issue_total>500): ?><p class="hc-admin-muted">Showing first 500 findings of <?php echo number_format_i18n($issue_total); ?>.</p><?php endif; ?><?php endif; ?></div></div>
<p class="hc-admin-muted">Audit notes: thin-content threshold is fewer than 80 words; outdated means no update in 365 days. Internal-link checks only inspect Help Center article URLs embedded in article HTML. Sitemap coverage is generated from the same live article/category rules shown above; this page does not make external HTTP requests or validate Google indexing.</p>
