<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// Read the current tab/view from URL
$view = isset($_GET['view']) ? sanitize_key($_GET['view']) : '';
if ($view === 'draft') $view = 'hidden'; // legacy link
$valid_views = array('', 'published', 'hidden', 'trash');
if (!in_array($view, $valid_views, true)) $view = '';

// Read search query from URL
$q = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';

// Build WHERE for initial render
$where  = array();
$params = array();

if ($view === 'trash') {
    $where[] = 'deleted_at IS NOT NULL';
} else {
    $where[] = 'deleted_at IS NULL';
    if ($view === 'published' || $view === 'hidden') {
        $where[] = 'status = %s';
        $params[] = $view;
    }
}

// Search filter (applies to all views)
if ($q !== '') {
    $like = '%' . $wpdb->esc_like($q) . '%';
    $where[] = '(name LIKE %s OR slug LIKE %s OR description LIKE %s)';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$where_sql = 'WHERE ' . implode(' AND ', $where);
$allowed_cats = array('name' => 'name', 'articles' => 'article_count', 'status' => 'status', 'last_action' => 'last_action_at', 'order' => 'sort_order');
$orderby = isset($_GET['orderby']) ? sanitize_key($_GET['orderby']) : '';
$sort = (isset($_GET['sort']) && strtolower($_GET['sort']) === 'asc') ? 'ASC' : 'DESC';
if (array_key_exists($orderby, $allowed_cats)) {
    $cat_order_sql = "ORDER BY {$allowed_cats[$orderby]} $sort, name ASC";
} else {
    // Match the frontend's persisted display order so drag-and-drop survives refresh.
    $cat_order_sql = "ORDER BY sort_order ASC, name ASC, id ASC";
}


// HC_CATS_DEDUPE_V2
if ($view === 'trash') {
    // Trash view: show all trashed (parents + subs) flat
    $sql = "SELECT * FROM {$wpdb->prefix}hc_categories $where_sql $cat_order_sql";
} elseif ($q !== '') {
    // Search mode: show matching categories (parents AND subcategories)
    $sql = "SELECT * FROM {$wpdb->prefix}hc_categories $where_sql $cat_order_sql";
} else {
    // Normal view: parents only (children rendered recursively)
    $sql = "SELECT * FROM {$wpdb->prefix}hc_categories $where_sql AND parent_id = 0 $cat_order_sql";
}
$cats = $params
    ? $wpdb->get_results($wpdb->prepare($sql, $params))
    : $wpdb->get_results($sql);

// Tab counts
$count_all       = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_categories WHERE deleted_at IS NULL");
$count_published = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_categories WHERE deleted_at IS NULL AND status='published'");
$count_draft     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_categories WHERE deleted_at IS NULL AND status='hidden'");
$count_trash     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_categories WHERE deleted_at IS NOT NULL");

$initial_count = ($view === 'published') ? $count_published
               : (($view === 'hidden')    ? $count_draft
               : (($view === 'trash')     ? $count_trash
               : $count_all));

$base_url = home_url('/helpcenter/admin/categories/');
?>

<!-- TABS -->
<nav class="hc-list-tabs">
    <a href="<?php echo esc_url($base_url); ?>" class="hc-list-tab <?php echo $view === '' ? 'active' : ''; ?>">
        <i class="fas fa-folder-tree"></i> All
        <span class="hc-tab-count"><?php echo $count_all; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=published'); ?>" class="hc-list-tab <?php echo $view === 'published' ? 'active' : ''; ?>">
        <i class="fas fa-circle-check"></i> Published
        <span class="hc-tab-count"><?php echo $count_published; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=hidden'); ?>" class="hc-list-tab <?php echo $view === 'hidden' ? 'active' : ''; ?>">
        <i class="fas fa-eye-slash"></i> Hidden
        <span class="hc-tab-count"><?php echo $count_draft; ?></span>
    </a>
    <a href="<?php echo esc_url($base_url . '?view=trash'); ?>" class="hc-list-tab hc-list-tab-trash <?php echo $view === 'trash' ? 'active' : ''; ?>">
        <i class="fas fa-trash-alt"></i> Trash
        <span class="hc-tab-count"><?php echo $count_trash; ?></span>
    </a>
</nav>

<!-- TOOLBAR -->
<div class="hc-admin-toolbar hc-cats-search" data-view="<?php echo esc_attr($view); ?>">
    <div class="hc-admin-filters">
        <div class="hc-search-wrap">
            <i class="fas fa-search hc-search-icon"></i>
            <input type="text" name="s" placeholder="Search categories..." autocomplete="off">
            <span class="hc-cats-spinner hc-search-spinner" style="display:none;">
                <i class="fas fa-circle-notch fa-spin"></i>
            </span>
        </div>

        <span class="hc-cats-count hc-search-count">
            <?php echo $initial_count; ?> <?php echo $initial_count === 1 ? 'result' : 'results'; ?>
        </span>

        <?php if ($view === 'trash'): ?>
        <button type="button" class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm hc-empty-trash-btn" data-trash-type="categories">
            <i class="fas fa-trash-alt"></i> Empty Trash
        </button>
        <?php endif; ?>
    </div>

    <?php if ($view !== 'trash'): ?>
    <a href="<?php echo esc_url(home_url('/helpcenter/admin/categories/new/')); ?>" class="hc-admin-btn hc-admin-btn-primary">
        <i class="fas fa-plus"></i> New Category
    </a>
    <?php endif; ?>
</div>

<div class="hc-admin-card">
    <div class="hc-admin-card-body hc-flush">
        <table class="hc-admin-table">
            <thead>
                <tr>
                    <th style="width:36px;"><input type="checkbox" class="hc-check-all" data-target=".hc-cats-tbody" id="hc-cats-select-all"></th>
                    <th style="width:42px;">Move</th>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Articles</th>
                    <th>Status</th>
                    <th>Last Action</th>
                    <th style="width:140px;">Actions</th>
                </tr>
            </thead>
            <tbody class="hc-cats-tbody">
                <?php if (!empty($cats)): ?>
                    <?php hc_render_cat_rows($cats, $view, 0, ($q !== ''), $sort); ?>
                <?php else: ?>
                    <tr><td colspan="9" style="text-align:center;padding:48px;color:#94A3B8;">
                        <?php echo $view === 'trash' ? 'Trash is empty.' : 'No categories yet.'; ?>
                    </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- BULK ACTION BAR -->
<div class="hc-bulk-bar" id="hcBulkBar" data-list="categories" data-view="<?php echo esc_attr($view); ?>">
    <div class="hc-bulk-bar-count"><span class="hc-bulk-count">0</span> selected</div>
    <div class="hc-bulk-bar-actions">
        <?php if ($view === 'trash'): ?>
        <button type="button" class="hc-bulk-btn" data-bulk-op="restore"><i class="fas fa-undo"></i> Restore</button>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-danger" data-bulk-op="hard_delete"><i class="fas fa-trash-alt"></i> Delete Permanently</button>
        <?php else: ?>
        <button type="button" class="hc-bulk-btn" data-bulk-op="publish"><i class="fas fa-eye"></i> Publish</button>
        <button type="button" class="hc-bulk-btn" data-bulk-op="hide"><i class="fas fa-eye-slash"></i> Hide</button>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-danger" data-bulk-op="delete"><i class="fas fa-trash"></i> Move to Trash</button>
        <?php endif; ?>
        <button type="button" class="hc-bulk-btn hc-bulk-btn-outline" data-bulk-clear><i class="fas fa-times"></i> Clear</button>
    </div>
</div>

<?php
function hc_render_cat_rows($cats, $view = '', $depth = 0, $search_mode = false, $sort_dir = 'ASC') {
    global $wpdb;
    foreach ($cats as $c):
        $icon = $c->icon_value ?: 'fa-folder';
        // In search mode, don't recurse into children (they're already in the flat list)
        $children = $search_mode ? array() : HC_Core::get_categories($c->id, 'any', false, $sort_dir);
    ?>
    <tr data-cat-row data-row-id="<?php echo (int) $c->id; ?>" data-status="<?php echo esc_attr($c->status); ?>" data-trashed="<?php echo !empty($c->deleted_at) ? '1' : '0'; ?>" data-parent-id="<?php echo (int) $c->parent_id; ?>" <?php echo $view === 'trash' ? 'style="opacity:0.65;"' : ''; ?>>
        <td class="hc-category-drag-cell"><?php if ($view !== 'trash' && !$search_mode && (int)$c->parent_id === 0): ?><button type="button" class="hc-category-drag" draggable="true" aria-label="Drag to reorder category" title="Drag to reorder"><i class="fas fa-grip-vertical"></i></button><?php endif; ?></td>
        <?php if ((int) $c->is_default === 1): ?>
                    <td></td>
                <?php else: ?>
                    <td><input type="checkbox" class="hc-row-check" value="<?php echo (int) $c->id; ?>"></td>
                <?php endif; ?>
        <td>
            <div style="display: flex; align-items: center; flex-wrap: nowrap;">
                <i class="fas <?php echo esc_attr($icon); ?>" style="color:#4F46E5; margin-right: 10px; flex-shrink: 0;"></i>
                <?php if ($view === 'trash' || !empty($c->deleted_at)): ?>
                    <span style="color:#64748B; white-space: nowrap;"><?php echo esc_html($c->name); ?></span>
                <?php else: ?>
                    <a href="<?php echo esc_url(home_url('/helpcenter/admin/categories/edit/' . $c->id . '/')); ?>" class="hc-admin-link" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        <?php echo esc_html($c->name); ?>
                    </a>
                <?php endif; ?>
                <?php
                if ((int) $c->parent_id > 0):
                    $parent_name = $wpdb->get_var($wpdb->prepare(
                        "SELECT name FROM {$wpdb->prefix}hc_categories WHERE id = %d",
                        $c->parent_id
                    ));
                    if ($parent_name):
                ?>
                    <span class="hc-parent-chip" title="Parent category" style="margin-left: 8px; flex-shrink: 0;">
                        <i class="fas fa-level-up-alt"></i> in <?php echo esc_html($parent_name); ?>
                    </span>
                <?php
                    endif;
                endif;
                ?>
            </div>
        </td>
        <td class="hc-muted"><?php echo esc_html($c->slug); ?></td>
        <td><?php echo (int) $c->article_count; ?></td>
        <td><?php if (!empty($c->deleted_at)): ?><span class="hc-status hc-status-trash">trashed</span><?php else: ?><span class="hc-status hc-status-<?php echo esc_attr($c->status); ?>"><?php echo esc_html($c->status); ?></span><?php endif; ?></td>
        <td class="hc-muted" title="<?php echo esc_attr($c->last_action_at); ?>"><?php echo esc_html(HC_Core::human_time($c->last_action_at)); ?><br><small style="font-size:11px;color:#94A3B8;"><?php echo esc_html($c->last_action ?: '—'); ?></small></td>
        <td>
            <div class="hc-admin-row-actions">
                <?php if ($view === 'trash'): ?>
                <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" data-hc-restore-category="<?php echo (int) $c->id; ?>" title="Restore"><i class="fas fa-undo"></i></button>
                <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-hard-delete-category="<?php echo (int) $c->id; ?>" title="Delete permanently"><i class="fas fa-trash-alt"></i></button>
                <?php else: ?>
                <?php if ($view !== 'trash' && empty($c->deleted_at)): ?><a href="<?php echo esc_url(home_url('/helpcenter/admin/categories/edit/' . $c->id . '/')); ?>" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline" title="Edit"><i class="fas fa-pen"></i></a><?php endif; ?>
                <?php if ((int) $c->is_default === 1): ?>
                <span class="hc-admin-badge-default" title="Default category — cannot be deleted"><i class="fas fa-lock"></i> Default</span>
                <?php else: ?>
                <?php if ((int) $c->is_default !== 1): ?>
                                <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-danger" data-hc-delete-category="<?php echo (int) $c->id; ?>" title="Move to trash"><i class="fas fa-trash"></i></button>
                            <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </td>
    </tr>
    <?php
        if (!empty($children)) hc_render_cat_rows($children, $view, $depth + 1, false, $sort_dir);
    endforeach;
}
?>


<?php if ($view !== 'trash' && $q === ''): ?>
<style>.hc-category-drag{border:0;background:#eef2ff;color:#64748b;border-radius:7px;padding:8px;cursor:grab}.hc-category-drag:active{cursor:grabbing}.hc-category-drag-cell{width:42px}.hc-category-sort-note{margin:12px 0;padding:10px 12px;border-radius:8px;background:#eef2ff;color:#4338ca;font-size:13px}</style>
<div class="hc-category-sort-note">Drag top-level category handles to change their order on the Help Center homepage and navigation. Changes save automatically.</div>
<script>
(function(){const body=document.querySelector('.hc-cats-tbody');if(!body||body.dataset.orderBound)return;body.dataset.orderBound='1';let dragged=null;
function topRows(){return Array.from(body.querySelectorAll(':scope > tr[data-cat-row][data-parent-id="0"]'));}
function save(){const rows=topRows();if(!rows.length)return;const fd=new FormData();fd.append('action','hc_save_category_order');fd.append('nonce',(window.hcAdmin||{}).nonce||'');rows.forEach(r=>fd.append('ids[]',r.dataset.rowId));const url=(window.hcAdmin||{}).ajaxUrl||'/wp-admin/admin-ajax.php';function send(retried){return fetch(url,{method:'POST',credentials:'same-origin',body:fd}).then(r=>r.text()).then(t=>{try{return JSON.parse(t)}catch(e){throw new Error('Server returned an invalid response while saving category order')}}).then(j=>{const msg=j?.data?.message||'';if(!j.success&&!retried&&/nonce failed|invalid nonce|security check/i.test(msg)){const nf=new FormData();nf.append('action','hc_refresh_nonce');return fetch(url,{method:'POST',credentials:'same-origin',body:nf}).then(r=>r.json()).then(n=>{if(!n.success||!n.data?.nonce)throw new Error('Could not refresh security token');window.hcAdmin=window.hcAdmin||{};window.hcAdmin.nonce=n.data.nonce;fd.set('nonce',n.data.nonce);return send(true);});}if(!j.success)throw new Error(msg||'Could not save category order');return j;});}send(false).then(()=>{const n=document.querySelector('.hc-category-sort-note');if(n)n.textContent='Category order saved successfully.';}).catch((err)=>{const n=document.querySelector('.hc-category-sort-note');if(n)n.textContent=err.message||'Could not save category order. Check that you are logged in as an administrator, then refresh and try again.';});}
body.addEventListener('dragstart',e=>{const handle=e.target.closest('.hc-category-drag');if(!handle)return;dragged=handle.closest('tr[data-cat-row]');e.dataTransfer.effectAllowed='move';});
body.addEventListener('dragover',e=>{if(!dragged)return;const target=e.target.closest('tr[data-cat-row][data-parent-id="0"]');if(!target||target===dragged)return;e.preventDefault();const rect=target.getBoundingClientRect();body.insertBefore(dragged,e.clientY<rect.top+rect.height/2?target:target.nextSibling);});
body.addEventListener('dragend',()=>{if(dragged){dragged=null;save();}});
})();
</script>
<?php endif; ?>
