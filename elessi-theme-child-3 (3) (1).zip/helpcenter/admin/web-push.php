<?php
/** HelpCenter administrator-only browser notification setup. */
if (!defined('ABSPATH') || !current_user_can('manage_options')) { return; }
$status = HC_Web_Push::dependency_status();
$keys = HC_Web_Push::keys();
global $wpdb;
$subscriptions = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . HC_Web_Push::table());
$last_delivery = get_option('hc_web_push_last_delivery', array());
$active_tabs = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . HC_Web_Push::presence_table() . ' WHERE is_visible=1 AND last_seen_at >= %s', wp_date('Y-m-d H:i:s', time()-45)));
$ready = !empty($status['installed']) && !empty($keys['publicKey']);
?>
<div class="hc-webpush-page">
    <div class="hc-webpush-hero">
        <div class="hc-webpush-hero-icon"><i class="fas fa-bell"></i></div>
        <div><span class="hc-webpush-eyebrow">CUSTOMER EXPERIENCE</span><h2>Browser notifications</h2><p>Let agents and customers receive important support alerts even when they are away from the HelpCenter tab.</p></div>
        <span class="hc-webpush-status <?php echo $ready ? 'is-ready' : 'is-pending'; ?>"><?php echo $ready ? 'Ready' : 'Setup required'; ?></span>
    </div>

    <div class="hc-webpush-grid">
        <section class="hc-webpush-card hc-webpush-main">
            <div class="hc-webpush-card-heading"><span class="hc-webpush-card-icon"><i class="fas fa-wand-magic-sparkles"></i></span><div><h3>Automatic setup</h3><p>No terminal, Composer commands, or manual VAPID configuration.</p></div></div>
            <ol class="hc-webpush-steps">
                <li class="<?php echo $status['installed'] ? 'is-done' : ''; ?>"><span>1</span><div><strong>Install the secure push engine</strong><small>HelpCenter downloads Composer and installs the required PHP library in its own folder.</small></div><em><?php echo $status['installed'] ? 'Installed' : 'Automatic'; ?></em></li>
                <li class="<?php echo !empty($keys['publicKey']) ? 'is-done' : ''; ?>"><span>2</span><div><strong>Create VAPID security keys</strong><small>Keys are generated automatically. The private key stays on your server.</small></div><em><?php echo !empty($keys['publicKey']) ? 'Generated' : 'Automatic'; ?></em></li>
                <li class="<?php echo $ready ? 'is-done' : ''; ?>"><span>3</span><div><strong>Activate browser push support</strong><small>HelpCenter registers its service worker and is ready to save browser subscriptions.</small></div><em><?php echo $ready ? 'Ready' : 'After setup'; ?></em></li>
            </ol>
            <div class="hc-webpush-action-row">
                <button type="button" class="hc-webpush-primary" id="hc-webpush-setup" <?php echo $ready ? 'disabled' : ''; ?>><i class="fas <?php echo $ready ? 'fa-check' : 'fa-wand-magic-sparkles'; ?>"></i><span><?php echo $ready ? 'Setup completed' : 'Set up notifications automatically'; ?></span></button>
                <span class="hc-webpush-action-note" id="hc-webpush-action-note"><?php echo $ready ? 'Your server-side push configuration is ready.' : 'Keep this page open while the one-time setup runs.'; ?></span>
            </div>
            <div id="hc-webpush-progress" class="hc-webpush-progress" hidden><span class="hc-webpush-spinner"></span><span>Preparing the push service. This can take a minute or two on shared hosting…</span></div>
            <div id="hc-webpush-result" class="hc-webpush-result" role="status" aria-live="polite" hidden></div>
        </section>

        <aside class="hc-webpush-card hc-webpush-side">
            <h3>System check</h3>
            <div class="hc-webpush-check"><span>PHP version</span><strong><?php echo esc_html(PHP_VERSION); ?></strong></div>
            <div class="hc-webpush-check"><span>OpenSSL</span><strong class="<?php echo $status['openssl'] ? 'ok' : 'bad'; ?>"><?php echo $status['openssl'] ? 'Available' : 'Required'; ?></strong></div>
            <div class="hc-webpush-check"><span>cURL</span><strong class="<?php echo $status['curl'] ? 'ok' : 'bad'; ?>"><?php echo $status['curl'] ? 'Available' : 'Required'; ?></strong></div>
            <div class="hc-webpush-check"><span>mbstring</span><strong class="<?php echo $status['mbstring'] ? 'ok' : 'bad'; ?>"><?php echo $status['mbstring'] ? 'Available' : 'Required'; ?></strong></div>
            <div class="hc-webpush-check"><span>HelpCenter folder writable</span><strong class="<?php echo $status['writable'] ? 'ok' : 'bad'; ?>"><?php echo $status['writable'] ? 'Yes' : 'No'; ?></strong></div>
            <div class="hc-webpush-check"><span>Automatic installer</span><strong class="<?php echo $status['process_runner'] ? 'ok' : 'bad'; ?>"><?php echo $status['process_runner'] ? 'Available' : 'Host restricted'; ?></strong></div>
            <div class="hc-webpush-check"><span>PHP command-line interpreter</span><strong class="<?php echo !empty($status['php_cli']) ? 'ok' : 'bad'; ?>"><?php echo !empty($status['php_cli']) ? 'Detected' : 'Not found'; ?></strong></div>
            <div class="hc-webpush-check"><span>Push engine</span><strong class="<?php echo $status['installed'] ? 'ok' : 'pending'; ?>"><?php echo $status['installed'] ? 'Installed' : 'Not installed'; ?></strong></div>
            <div class="hc-webpush-check"><span>VAPID keys</span><strong class="<?php echo !empty($keys['publicKey']) ? 'ok' : 'pending'; ?>"><?php echo !empty($keys['publicKey']) ? 'Generated' : 'Not generated'; ?></strong></div>
            <div class="hc-webpush-check"><span>Saved browser subscriptions</span><strong><?php echo number_format_i18n($subscriptions); ?></strong></div>
            <div class="hc-webpush-check"><span>Recently active browser tabs</span><strong><?php echo number_format_i18n($active_tabs); ?></strong></div>
            <?php if (!empty($last_delivery['time'])): ?>
            <div class="hc-webpush-last-delivery"><strong>Last push attempt</strong><span><?php echo esc_html($last_delivery['time']); ?></span><b><?php echo esc_html(str_replace('_',' ',(string)($last_delivery['status']??'unknown'))); ?></b><small>Attempted: <?php echo number_format_i18n((int)($last_delivery['attempted']??0)); ?> · Accepted: <?php echo number_format_i18n((int)($last_delivery['sent']??0)); ?> · Failed: <?php echo number_format_i18n((int)($last_delivery['failed']??0)); ?> · Suppressed (same ticket): <?php echo number_format_i18n((int)($last_delivery['suppressed']??0)); ?></small><?php if (!empty($last_delivery['error'])): ?><small><?php echo esc_html($last_delivery['error']); ?></small><?php endif; ?></div>
            <?php else: ?><div class="hc-webpush-last-delivery"><strong>Last push attempt</strong><small>No message-triggered push attempt has been recorded yet.</small></div><?php endif; ?>
            <p class="hc-webpush-security"><i class="fas fa-shield-halved"></i> The private VAPID key is never sent to the browser. Customers and agents still choose whether to allow notifications on their own devices.</p>
        </aside>
    </div>

    <section class="hc-webpush-card hc-webpush-how">
        <h3>How notifications work</h3>
        <div class="hc-webpush-how-grid">
            <div><i class="fas fa-headset"></i><strong>Agent alerts</strong><p>Separate alerts for a newly assigned conversation and a customer reply.</p></div>
            <div><i class="fas fa-comment-dots"></i><strong>Customer alerts</strong><p>One notification type for a new reply from the support agent.</p></div>
            <div><i class="fas fa-window-restore"></i><strong>Works away from the tab</strong><p>Push notifications are delivered by the browser's push service through the registered service worker.</p></div>
        </div>
        <p class="hc-webpush-footnote">Requirements: HTTPS, PHP 8.2 or newer, OpenSSL, cURL, mbstring, writable HelpCenter files, and hosting that permits PHP to run a background command for the one-time dependency installation. If the hosting provider blocks that operation, this screen will explain the exact restriction instead of asking you to guess.</p>
    </section>
</div>
<style>
.hc-webpush-page{max-width:1180px;margin:0 auto;color:#20243a}.hc-webpush-hero{display:flex;align-items:center;gap:16px;padding:22px 24px;margin-bottom:18px;border:1px solid #e7e9f2;border-radius:18px;background:linear-gradient(125deg,#fff 0%,#f7f8ff 100%)}.hc-webpush-hero-icon{width:52px;height:52px;display:grid;place-items:center;border-radius:15px;background:#eeedff;color:#5c52b5;font-size:21px;flex:0 0 52px}.hc-webpush-hero h2{font-size:23px;margin:3px 0 5px;color:#20243a}.hc-webpush-hero p{margin:0;color:#73798d;font-size:13px}.hc-webpush-eyebrow{font-size:9px;letter-spacing:1.4px;font-weight:800;color:#7770bf}.hc-webpush-status{margin-left:auto;padding:7px 11px;border-radius:99px;font-size:11px;font-weight:800;white-space:nowrap}.hc-webpush-status.is-ready{background:#e8f8ef;color:#18734a}.hc-webpush-status.is-pending{background:#fff4df;color:#9b6500}.hc-webpush-grid{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(270px,.8fr);gap:16px}.hc-webpush-card{background:#fff;border:1px solid #e7e9f1;border-radius:16px;padding:20px;box-shadow:0 3px 12px #1e244008;min-width:0}.hc-webpush-card-heading{display:flex;gap:12px;align-items:center;margin-bottom:15px}.hc-webpush-card-icon{width:40px;height:40px;display:grid;place-items:center;background:#f0efff;color:#5b52b5;border-radius:12px;font-size:16px}.hc-webpush-card h3{margin:0 0 4px;font-size:15px;color:#262944}.hc-webpush-card-heading p{margin:0;color:#858a9b;font-size:11px}.hc-webpush-steps{list-style:none;padding:0;margin:0}.hc-webpush-steps li{display:flex;align-items:center;gap:12px;padding:13px 0;border-bottom:1px solid #f0f1f5}.hc-webpush-steps li:last-child{border-bottom:0}.hc-webpush-steps li>span{width:27px;height:27px;display:grid;place-items:center;border-radius:9px;background:#f1f2f7;color:#656b7d;font-size:11px;font-weight:800;flex:0 0 27px}.hc-webpush-steps li.is-done>span{background:#e6f7ed;color:#16814d}.hc-webpush-steps li div{display:grid;gap:3px;min-width:0;flex:1}.hc-webpush-steps strong{font-size:12px;color:#30344b}.hc-webpush-steps small{font-size:10px;line-height:1.5;color:#858a9b}.hc-webpush-steps em{font-style:normal;font-size:10px;font-weight:700;color:#6d7185;white-space:nowrap}.hc-webpush-steps li.is-done em{color:#16814d}.hc-webpush-action-row{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:16px}.hc-webpush-primary{display:inline-flex;align-items:center;gap:9px;border:0;border-radius:10px;background:#5148a8;color:#fff;padding:12px 16px;font-weight:700;font-size:12px;cursor:pointer}.hc-webpush-primary:hover{background:#40388e}.hc-webpush-primary:disabled{background:#218451;cursor:default}.hc-webpush-action-note{font-size:10px;color:#7b8192}.hc-webpush-progress,.hc-webpush-result{display:flex;align-items:center;gap:10px;margin-top:13px;padding:12px;border-radius:10px;background:#f4f5fb;color:#555b72;font-size:11px;line-height:1.5}.hc-webpush-result.is-error{background:#fff0ef;color:#a42c24}.hc-webpush-result.is-success{background:#eaf8f0;color:#176d43}.hc-webpush-spinner{width:16px;height:16px;border:2px solid #d6d5ef;border-top-color:#5148a8;border-radius:50%;animation:hcwp-spin .8s linear infinite;flex:0 0 16px}@keyframes hcwp-spin{to{transform:rotate(360deg)}}.hc-webpush-side h3{margin-bottom:12px}.hc-webpush-check{display:flex;justify-content:space-between;gap:10px;padding:9px 0;border-bottom:1px solid #f0f1f5;font-size:11px}.hc-webpush-check span{color:#72788a}.hc-webpush-check strong{font-size:10px;color:#555b70;text-align:right}.hc-webpush-check strong.ok{color:#16814d}.hc-webpush-check strong.bad{color:#b42318}.hc-webpush-check strong.pending{color:#a36a09}.hc-webpush-last-delivery{display:grid;gap:5px;margin-top:12px;padding:11px;border:1px solid #e7e9f1;border-radius:10px;background:#fafaff;font-size:10px}.hc-webpush-last-delivery strong{font-size:11px;color:#30344b}.hc-webpush-last-delivery span,.hc-webpush-last-delivery small{color:#747a8d;line-height:1.5}.hc-webpush-last-delivery b{color:#5148a8;text-transform:capitalize}.hc-webpush-security{margin:14px 0 0;padding:11px;border-radius:10px;background:#f5f6fc;color:#666c81;font-size:10px;line-height:1.6}.hc-webpush-security i{color:#5148a8;margin-right:5px}.hc-webpush-how{margin-top:16px}.hc-webpush-how-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:14px}.hc-webpush-how-grid>div{padding:14px;border:1px solid #eceef4;border-radius:12px;display:grid;gap:6px}.hc-webpush-how-grid i{color:#6259b7;font-size:16px}.hc-webpush-how-grid strong{font-size:12px}.hc-webpush-how-grid p{margin:0;color:#7d8293;font-size:10px;line-height:1.6}.hc-webpush-footnote{margin:14px 0 0;color:#8a8fa0;font-size:10px;line-height:1.6}@media(max-width:800px){.hc-webpush-grid{grid-template-columns:1fr}.hc-webpush-how-grid{grid-template-columns:1fr}}@media(max-width:520px){.hc-webpush-hero{align-items:flex-start;flex-wrap:wrap;padding:16px}.hc-webpush-status{margin-left:0}.hc-webpush-card{padding:15px}.hc-webpush-action-row{align-items:stretch}.hc-webpush-primary{width:100%;justify-content:center}.hc-webpush-action-note{width:100%}.hc-webpush-steps li{align-items:flex-start}.hc-webpush-steps em{font-size:9px}}
</style>
<script>
(function(){
 var button=document.getElementById('hc-webpush-setup');if(!button)return;
 var progress=document.getElementById('hc-webpush-progress'),result=document.getElementById('hc-webpush-result'),note=document.getElementById('hc-webpush-action-note');
 var endpoint=<?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>,nonce=<?php echo wp_json_encode(wp_create_nonce('hc_web_push_admin')); ?>;
 button.addEventListener('click',function(){
  if(button.disabled)return;
  button.disabled=true;progress.hidden=false;result.hidden=true;note.textContent='Downloading and installing the Web Push components, then generating secure keys…';
  var body=new URLSearchParams({action:'hc_web_push_install_dependency',nonce:nonce});
  fetch(endpoint,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()})
   .then(function(response){return response.json().then(function(data){if(!response.ok||!data.success)throw new Error(data.data&&data.data.message?data.data.message:'Automatic setup failed.');return data;});})
   .then(function(data){progress.hidden=true;result.hidden=false;result.className='hc-webpush-result is-success';result.textContent=data.data.message||'Setup completed successfully.';note.textContent='Refreshing the setup status…';window.setTimeout(function(){window.location.reload();},1300);})
   .catch(function(error){progress.hidden=true;result.hidden=false;result.className='hc-webpush-result is-error';result.textContent=error.message;note.textContent='No settings were changed outside the HelpCenter folder. You can retry after resolving the server requirement.';button.disabled=false;});
 });
})();
</script>
