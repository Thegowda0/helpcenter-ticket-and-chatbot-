<?php
if (!defined('ABSPATH')) exit;
global $wpdb;
$tables = array('hc_articles','hc_categories','hc_faqs','hc_revisions','hc_helpful_votes','hc_search_log','hc_search_clicks','hc_settings');
$table_rows = array(); $total_rows = 0; $total_bytes = 0; $missing = array();
foreach ($tables as $suffix) {
    $name = $wpdb->prefix . $suffix;
    $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($name)));
    if ($exists !== $name) { $missing[] = $suffix; continue; }
    $status = $wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS WHERE Name = %s', $name));
    $rows = $status ? (int)$status->Rows : 0;
    $bytes = $status ? (int)$status->Data_length + (int)$status->Index_length : 0;
    $total_rows += $rows; $total_bytes += $bytes;
    $table_rows[] = array('name'=>$suffix,'rows'=>$rows,'bytes'=>$bytes);
}
$search_table = $wpdb->prefix . 'hc_search_log';
$old_search = 0; $search_total = 0;
if (!in_array('hc_search_log',$missing,true)) {
    $search_total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$search_table}");
    $old_search = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$search_table} WHERE created_at < %s", gmdate('Y-m-d H:i:s', time()-90*DAY_IN_SECONDS)));
}
$revision_table = $wpdb->prefix . 'hc_revisions';
$revision_total = !in_array('hc_revisions',$missing,true) ? (int)$wpdb->get_var("SELECT COUNT(*) FROM {$revision_table}") : 0;
$checks = array();
$checks[] = array('Database tables', empty($missing), empty($missing) ? 'All expected Help Center tables are present.' : 'Missing: '.implode(', ',$missing));
$checks[] = array('External object cache', wp_using_ext_object_cache(), wp_using_ext_object_cache() ? 'A persistent object-cache drop-in is active.' : 'No persistent object cache detected; this is optional but may help larger sites.');
$checks[] = array('WordPress debug mode', !defined('WP_DEBUG') || !WP_DEBUG, (defined('WP_DEBUG') && WP_DEBUG) ? 'WP_DEBUG is enabled. Disable on production unless actively debugging.' : 'WP_DEBUG is not enabled.');
$checks[] = array('Search-log retention', $old_search < 10000, number_format_i18n($old_search).' search records are older than 90 days. Review retention before cleanup.');
$checks[] = array('Revision growth', $revision_total < 50000, number_format_i18n($revision_total).' revision records exist. Keep history unless storage management is required.');
$checks[] = array('HTTPS', is_ssl(), is_ssl() ? 'The current admin request uses HTTPS.' : 'This request is not HTTPS. Ensure the production site and admin use HTTPS.');
$checks[] = array('PHP version', version_compare(PHP_VERSION,'8.0','>='), 'PHP '.PHP_VERSION.' detected. Use a currently supported PHP release from your hosting provider.');
$ok = 0; foreach ($checks as $c) if ($c[1]) $ok++;
function hc_perf_bytes($n) { if ($n >= 1073741824) return size_format($n,2); if ($n >= 1048576) return size_format($n,2); if ($n >= 1024) return size_format($n,1); return number_format_i18n($n).' B'; }
?>
<div class="hc-admin-page-head"><div><h1>Performance &amp; Security</h1><p>Read-only health checks for database growth, caching and basic production configuration.</p></div></div>
<div class="hc-admin-stats">
 <div class="hc-admin-stat"><div><span class="hc-admin-stat-value"><?php echo (int)$ok; ?>/<?php echo count($checks); ?></span><span class="hc-admin-stat-label">Checks passed</span></div></div>
 <div class="hc-admin-stat"><div><span class="hc-admin-stat-value"><?php echo number_format_i18n($total_rows); ?></span><span class="hc-admin-stat-label">Estimated table rows</span></div></div>
 <div class="hc-admin-stat"><div><span class="hc-admin-stat-value"><?php echo esc_html(hc_perf_bytes($total_bytes)); ?></span><span class="hc-admin-stat-label">Estimated DB footprint</span></div></div>
 <div class="hc-admin-stat"><div><span class="hc-admin-stat-value"><?php echo number_format_i18n($search_total); ?></span><span class="hc-admin-stat-label">Search log records</span></div></div>
</div>
<div class="hc-admin-card"><div class="hc-admin-card-head"><h3>Health checks</h3><span>Informational · no changes made</span></div><div class="hc-admin-card-body hc-flush"><table class="hc-admin-table"><thead><tr><th>Check</th><th>Status</th><th>Details</th></tr></thead><tbody>
<?php foreach ($checks as $c): ?><tr><td><strong><?php echo esc_html($c[0]); ?></strong></td><td><span class="hc-admin-status <?php echo $c[1]?'is-published':'is-draft'; ?>"><?php echo $c[1]?'OK':'Review'; ?></span></td><td><?php echo esc_html($c[2]); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<div class="hc-admin-card"><div class="hc-admin-card-head"><h3>Help Center database tables</h3><span><?php echo count($table_rows); ?> / <?php echo count($tables); ?> present</span></div><div class="hc-admin-card-body hc-flush"><div style="overflow-x:auto"><table class="hc-admin-table"><thead><tr><th>Table</th><th>Estimated rows</th><th>Data + indexes</th></tr></thead><tbody><?php foreach ($table_rows as $t): ?><tr><td><?php echo esc_html($t['name']); ?></td><td><?php echo number_format_i18n($t['rows']); ?></td><td><?php echo esc_html(hc_perf_bytes($t['bytes'])); ?></td></tr><?php endforeach; ?></tbody></table></div></div></div>
<div class="hc-admin-card"><div class="hc-admin-card-head"><h3>Recommended maintenance</h3></div><div class="hc-admin-card-body"><ul style="padding-left:20px;line-height:1.9"><li>Enable a reputable persistent object cache if your host supports it.</li><li>Keep WordPress, the active theme and PHP updated; take a database backup before major updates.</li><li>Review search-log retention and export analytics before deleting old records.</li><li>Do not delete revision history automatically; it is needed for recovery and restore.</li><li>Use HTTPS for the public Help Center and all administrator access.</li><li>Use your host's database tools to inspect slow queries and confirm indexes on large tables.</li></ul></div></div>
<p class="hc-admin-muted">Important: table row counts and storage sizes are database-engine estimates. This page does not run destructive cleanup, alter indexes, change settings, or perform external security scans. A passing check is not a full security certification.</p>
