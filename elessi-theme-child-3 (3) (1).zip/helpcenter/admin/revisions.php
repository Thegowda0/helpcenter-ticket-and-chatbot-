<?php
if (!defined('ABSPATH')) exit;
global $wpdb;
$type = sanitize_key(get_query_var('hc_revision_type'));
$id = absint(get_query_var('hc_id'));
if (!in_array($type, array('article','faq'), true) || !$id) wp_die('Invalid revision request.', 'Revision History', array('back_link'=>true));
$table = $type === 'article' ? $wpdb->prefix . 'hc_articles' : $wpdb->prefix . 'hc_faqs';
$item = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $id));
if (!$item) wp_die('Content item not found.', 'Revision History', array('back_link'=>true));
$revisions = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}hc_revisions WHERE item_type=%s AND item_id=%d ORDER BY id DESC LIMIT 200", $type, $id));
$selected_id = isset($_GET['revision']) ? absint($_GET['revision']) : (isset($revisions[0]) ? (int)$revisions[0]->id : 0);
$selected = null;
foreach ($revisions as $candidate) { if ((int)$candidate->id === $selected_id) { $selected = $candidate; break; } }
if (!$selected && !empty($revisions)) { $selected = $revisions[0]; $selected_id = (int)$selected->id; }
$back = $type === 'article' ? home_url('/helpcenter/admin/articles/edit/'.$id.'/') : home_url('/helpcenter/admin/faqs/edit/'.$id.'/');
$revision_url = home_url('/helpcenter/admin/revisions/'.$type.'/'.$id.'/');
$title = $type === 'article' ? $item->title : $item->question;
$hc_category_names = array();
if ($type === 'article') { $hc_category_rows=$wpdb->get_results("SELECT id,name FROM {$wpdb->prefix}hc_categories"); foreach((array)$hc_category_rows as $cr) $hc_category_names[(string)$cr->id]=$cr->name; }
$fields = $type === 'article' ? array('title'=>'Title','slug'=>'URL slug','excerpt'=>'Summary','content'=>'Article content','category_id'=>'Category','subcategory_id'=>'Subcategory','meta_keywords'=>'Tags / Keywords','schema_type'=>'Schema type','robots_meta'=>'Search engine visibility','status'=>'Status','is_popular'=>'Popular flag','sort_order'=>'Sort order') : array('question'=>'Question','answer'=>'Answer content','destination_type'=>'Destination type','destination_id'=>'Destination','status'=>'Status','sort_order'=>'Sort order');
?>
<?php
// Revision display is intentionally human-readable. Keep the original HTML in a
// collapsible source panel so advanced users can still inspect exact markup.
$hc_revision_display = function($value, $key) {
    $value = (string) $value;
    if (!in_array($key, array('content', 'answer'), true)) return $value;
    $text = preg_replace('/<\s*br\s*\/?\s*>/i', "\n", $value);
    $text = preg_replace('/<\/\s*(p|div|li|h[1-6]|blockquote|tr)\s*>/i', "\n", $text);
    $text = wp_strip_all_tags($text, true);
    $text = html_entity_decode($text, ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');
    $text = preg_replace("/\n{3,}/", "\n\n", $text);
    return trim($text);
};
$hc_revision_blocks = function($html) {
    $html=(string)$html; if(trim($html)==='') return array(); $items=array();
    if(class_exists('DOMDocument')) {
        $dom=new DOMDocument('1.0','UTF-8'); $prev=libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="UTF-8"><div id="hc-revision-root">'.$html.'</div>', LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD);
        libxml_clear_errors(); libxml_use_internal_errors($prev);
        $xp=new DOMXPath($dom); $roots=$xp->query('//*[@id="hc-revision-root"]'); $root=$roots && $roots->length?$roots->item(0):null;
        $labels=array('h1'=>'Heading 1','h2'=>'Heading 2','h3'=>'Heading 3','h4'=>'Heading 4','h5'=>'Heading 5','h6'=>'Heading 6','p'=>'Paragraph','ul'=>'Bulleted list','ol'=>'Numbered list','blockquote'=>'Quote','pre'=>'Code block','table'=>'Table','img'=>'Image','figure'=>'Media / figure','hr'=>'Divider','div'=>'Content section','section'=>'Content section');
        $walk=function($parent) use (&$walk,&$items,$labels) { foreach($parent->childNodes as $node){ if($node->nodeType===XML_TEXT_NODE){$v=trim($node->textContent);if($v!=='')$items[]=array('type'=>'Text','text'=>$v);continue;} if($node->nodeType!==XML_ELEMENT_NODE)continue; $tag=strtolower($node->nodeName); $semantic=array('p','h1','h2','h3','h4','h5','h6','ul','ol','blockquote','pre','table','img','figure','hr'); if(in_array($tag,$semantic,true)){ $value=trim($node->textContent); if($tag==='img')$value='Image: '.$node->getAttribute('alt').' '.$node->getAttribute('src'); if($tag==='figure'){$img=$node->getElementsByTagName('img')->item(0);if($img)$value='Image: '.$img->getAttribute('alt').' '.$img->getAttribute('src');} if($tag==='hr')$value='Horizontal divider'; if($tag==='ul'||$tag==='ol'){$lis=$node->getElementsByTagName('li');$parts=array();foreach($lis as $li)$parts[]=trim($li->textContent);$value=implode("\n",$parts);} if($value!==''||in_array($tag,array('img','figure','hr'),true))$items[]=array('type'=>$labels[$tag]??ucfirst($tag),'text'=>$value); } else { $walk($node); } } };
        if($root)$walk($root);
    }
    if(!$items){$plain=trim(wp_strip_all_tags($html));if($plain!=='')$items[]=array('type'=>'Content','text'=>$plain);}
    return $items;
};
$hc_pretty_html=function($html){$html=trim((string)$html);if($html==='')return '';return trim(preg_replace('/>\s*</',">\n<",$html));};
$hc_word_diff=function($before,$after){
  $a=preg_split('/(\\s+)/u',(string)$before,-1,PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY)?:array(); $b=preg_split('/(\\s+)/u',(string)$after,-1,PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY)?:array();
  $n=count($a);$m=count($b); if($n*$m>30000)return array('<del class="hc-revision-removed">'.esc_html($before).'</del>','<ins class="hc-revision-added">'.esc_html($after).'</ins>');
  $d=array_fill(0,$n+1,array_fill(0,$m+1,0)); for($i=$n-1;$i>=0;$i--)for($j=$m-1;$j>=0;$j--)$d[$i][$j]=$a[$i]===$b[$j]?1+$d[$i+1][$j+1]:max($d[$i+1][$j],$d[$i][$j+1]);
  $o='';$v='';$x='';$y='';$flush=function(&$out,&$buf,$tag){if($buf!==''){$out.='<'.$tag.'>'.esc_html($buf).'</'.$tag.'>';$buf='';}};$i=0;$j=0;
  while($i<$n||$j<$m){if($i<$n&&$j<$m&&$a[$i]===$b[$j]){$flush($o,$x,'del');$flush($v,$y,'ins');$o.=esc_html($a[$i]);$v.=esc_html($b[$j]);$i++;$j++;}elseif($j<$m&&($i===$n||$d[$i][$j+1]>=$d[$i+1][$j])){$flush($o,$x,'del');$y.=$b[$j++];}else{$flush($v,$y,'ins');$x.=$a[$i++];}}$flush($o,$x,'del');$flush($v,$y,'ins');return array($o,$v);
};
$hc_align_blocks=function($old_blocks,$new_blocks){
  $n=count($old_blocks);$m=count($new_blocks);$dp=array_fill(0,$n+1,array_fill(0,$m+1,0));
  for($i=$n-1;$i>=0;$i--)for($j=$m-1;$j>=0;$j--){$same=($old_blocks[$i]['type']===$new_blocks[$j]['type'] && trim($old_blocks[$i]['text'])===trim($new_blocks[$j]['text']));$dp[$i][$j]=$same?1+$dp[$i+1][$j+1]:max($dp[$i+1][$j],$dp[$i][$j+1]);}
  $ops=array();$i=0;$j=0;while($i<$n||$j<$m){if($i<$n&&$j<$m&&$old_blocks[$i]['type']===$new_blocks[$j]['type']&&trim($old_blocks[$i]['text'])===trim($new_blocks[$j]['text'])){$ops[]=array('kind'=>'same','old'=>$old_blocks[$i++],'new'=>$new_blocks[$j++]);}elseif($j<$m&&($i===$n||$dp[$i][$j+1]>=$dp[$i+1][$j])){$ops[]=array('kind'=>'add','new'=>$new_blocks[$j++]);}else{$ops[]=array('kind'=>'delete','old'=>$old_blocks[$i++]);}}
  // Pair a nearby deletion and insertion as an edited block, without shifting later blocks.
  for($k=0;$k<count($ops)-1;$k++){if($ops[$k]['kind']==='delete'&&$ops[$k+1]['kind']==='add'){$ops[$k]=array('kind'=>'edit','old'=>$ops[$k]['old'],'new'=>$ops[$k+1]['new']);array_splice($ops,$k+1,1);}}return $ops;
};
?>
<style>
.hc-revisions-wrap{max-width:1500px}.hc-revision-intro{color:#64748b;margin:8px 0 18px}.hc-revision-toolbar{display:flex;gap:16px;align-items:end;flex-wrap:wrap;background:#fff;border:1px solid #dbe2ea;border-radius:12px;padding:18px;margin:18px 0;box-shadow:0 2px 8px rgba(15,23,42,.04)}.hc-revision-toolbar label{display:block;font-weight:700;margin-bottom:7px;color:#334155}.hc-revision-toolbar select{min-width:min(560px,75vw);max-width:100%;padding:10px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#fff}.hc-revision-meta{color:#64748b;font-size:13px;margin-top:6px}.hc-revision-count{margin-left:auto;color:#64748b;font-size:12px}.hc-revision-summary{display:flex;gap:8px;flex-wrap:wrap;margin:16px 0}.hc-revision-pill{display:inline-flex;align-items:center;gap:6px;border:1px solid #e2e8f0;border-radius:999px;padding:6px 11px;background:#f8fafc;color:#334155;font-size:12px;font-weight:600}.hc-revision-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:0}.hc-revision-side{min-width:0;padding:18px;border-right:1px solid #e2e8f0;overflow-wrap:anywhere}.hc-revision-side:last-child{border-right:0}.hc-revision-side h3{margin:0 0 12px;font-size:13px;color:#334155}.hc-revision-side pre{white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.75 inherit;margin:0;min-height:28px;color:#334155}.hc-revision-old{background:#fffafa}.hc-revision-new{background:#f8fff9}.hc-revision-removed{background:#fee2e2;color:#991b1b;text-decoration:line-through;border-radius:3px}.hc-revision-added{background:#dcfce7;color:#166534;border-radius:3px}.hc-revision-field{border:1px solid #e2e8f0;border-radius:11px;margin:14px 0;overflow:hidden;background:#fff;box-shadow:0 1px 3px rgba(15,23,42,.035)}.hc-revision-field-name{display:flex;align-items:center;justify-content:space-between;gap:10px;font-size:12px;font-weight:700;letter-spacing:.02em;color:#334155;padding:12px 16px;background:#f8fafc;border-bottom:1px solid #e2e8f0}.hc-revision-source{border-top:1px solid #e2e8f0;background:#fff;padding:0 16px 12px}.hc-revision-source summary{cursor:pointer;color:#64748b;font-size:12px;padding:10px 0}.hc-revision-source pre{max-height:240px;overflow:auto;background:#f8fafc;border:1px solid #e2e8f0;border-radius:7px;padding:12px;font:12px/1.6 monospace}.hc-revision-blocks{padding:14px;display:grid;gap:10px}.hc-revision-block{border:1px solid #dbe2ea;border-radius:9px;overflow:hidden;background:#fff}.hc-revision-block-label{padding:8px 12px;background:#f1f5f9;border-bottom:1px solid #e2e8f0;font-size:11px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.04em}.hc-revision-block-body{padding:12px 14px;color:#1e293b;line-height:1.65;white-space:pre-wrap;overflow-wrap:anywhere}.hc-revision-source pre{white-space:pre;tab-size:2}.hc-revision-empty{padding:36px;color:#64748b;background:#fff;text-align:center}.hc-revision-nochange{padding:28px;background:#f8fafc;border:1px solid #dbe2ea;border-radius:10px;color:#475569}.hc-revision-card{overflow:hidden;border-radius:12px}.hc-revision-card-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:18px 20px;border-bottom:1px solid #e2e8f0}.hc-revision-restore-preview[hidden]{display:none!important}.hc-restore-preview[hidden]{display:none!important}.hc-restore-preview{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:24px}.hc-restore-preview-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.62)}.hc-restore-preview-panel{position:relative;width:min(960px,96vw);max-height:90vh;overflow:auto;background:#fff;border-radius:14px;padding:24px;box-shadow:0 24px 80px rgba(0,0,0,.32)}.hc-restore-preview-panel h2{margin-top:0}.hc-restore-warning{padding:12px 14px;background:#fffbeb;border:1px solid #fde68a;border-left:4px solid #d97706;border-radius:7px}.hc-restore-preview-field{border:1px solid #e2e8f0;border-radius:8px;margin:12px 0;overflow:hidden}.hc-restore-preview-field h3{margin:0;padding:10px 14px;background:#f8fafc;border-bottom:1px solid #e2e8f0;font-size:13px}.hc-restore-preview-field pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:240px;overflow:auto;margin:0;padding:14px;font:13px/1.6 inherit}.hc-restore-preview-actions{display:flex;justify-content:flex-end;gap:10px;position:sticky;bottom:-24px;background:#fff;padding:16px 0 0}
@media(max-width:760px){.hc-revision-grid{grid-template-columns:1fr}.hc-revision-side{border-right:0;border-bottom:1px solid #e2e8f0}.hc-revision-side:last-child{border-bottom:0}.hc-revision-toolbar select{min-width:0;width:100%}.hc-revision-count{margin-left:0;width:100%}}

.hc-revision-section-title{display:flex;align-items:baseline;justify-content:space-between;gap:12px;flex-wrap:wrap;margin:24px 2px 10px}.hc-revision-section-title h3{margin:0;font-size:16px}.hc-revision-section-title span{font-size:12px;color:#64748b}.hc-revision-meta-row{border-top:1px solid #e2e8f0}.hc-revision-meta-label{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 16px;background:#f8fafc;font-size:12px;font-weight:700;color:#334155}.hc-revision-meta-row .hc-revision-side{padding:12px 16px}.hc-revision-aligned-rows{display:grid;gap:0}.hc-revision-aligned-row{border-top:1px solid #e2e8f0}.hc-revision-aligned-row .hc-revision-side{padding:10px}.hc-revision-aligned-row .hc-revision-block{height:100%}.hc-revision-block-changed{border-color:#86efac;background:#f0fdf4}.hc-revision-block-added{border-color:#86efac;background:#f0fdf4}.hc-revision-block-deleted{border-color:#fca5a5;background:#fff1f2}.hc-revision-alignment-space{display:block;min-height:24px}.hc-revision-deleted-on-right{display:inline-block;padding:2px 4px}.hc-restore-preview-structured{padding:14px;line-height:1.65}.hc-restore-preview-block{border:1px solid #e2e8f0;border-radius:7px;margin:8px 0;overflow:hidden}.hc-restore-preview-block>span{display:block;padding:6px 10px;background:#f1f5f9;color:#475569;font-size:10px;font-weight:700;text-transform:uppercase}.hc-restore-preview-block>div{padding:10px 12px;white-space:pre-wrap}.hc-restore-preview-content{max-height:48vh;overflow:auto}
</style>
<div class="hc-admin-page-head hc-revisions-wrap">
  <a href="<?php echo esc_url($back); ?>" class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm"><i class="fas fa-arrow-left"></i> Back to editor</a>
  <h1>Revision History</h1>
</div>
<div class="hc-revisions-wrap">
  <p class="hc-revision-intro">Review the complete previous and updated snapshots for <strong><?php echo esc_html($title); ?></strong>. Added and deleted content is marked on the updated side; all metadata is visible below.</p>
  <?php if (!$revisions): ?><div class="hc-admin-card"><div class="hc-revision-empty">No revisions have been recorded yet. Make and save a meaningful change to create the first revision.</div></div><?php else: ?>
  <form class="hc-revision-toolbar" method="get" action="<?php echo esc_url($revision_url); ?>">
    <div><label for="hcRevisionSelect">Choose a revision</label><select id="hcRevisionSelect" name="revision" onchange="this.form.submit()">
    <?php foreach ($revisions as $rv): $user=get_userdata((int)$rv->user_id); $label=mysql2date(get_option('date_format').' '.get_option('time_format'), $rv->created_at).' — '.($user ? $user->display_name : 'Administrator').' — #'.$rv->id; ?>
      <option value="<?php echo (int)$rv->id; ?>" <?php selected($selected_id,(int)$rv->id); ?>><?php echo esc_html($label); ?></option>
    <?php endforeach; ?>
    </select></div><span class="hc-revision-count"><?php echo count($revisions); ?> recent revisions shown (maximum 200)</span>
  </form>
  <?php if ($selected): $old=json_decode($selected->before_data,true); $new=json_decode($selected->after_data,true); if(!is_array($old))$old=array();if(!is_array($new))$new=array();$user=get_userdata((int)$selected->user_id);$changed=0;foreach($fields as $key=>$label){if((string)($old[$key]??'')!==(string)($new[$key]??''))$changed++;} ?>
  <section class="hc-admin-card hc-revision-card">
    <div class="hc-revision-card-head">
      <div><h2 style="margin:0">Selected revision #<?php echo (int)$selected->id; ?></h2><div class="hc-revision-meta"><?php echo esc_html(mysql2date(get_option('date_format').' '.get_option('time_format'), $selected->created_at)); ?> · Edited by <?php echo esc_html($user ? $user->display_name : 'Administrator'); ?></div></div>
      <button type="button" class="hc-admin-btn hc-admin-btn-primary hc-restore-revision" data-revision-id="<?php echo (int)$selected->id; ?>" data-editor-url="<?php echo esc_url($back); ?>" data-revision-label="<?php echo esc_attr(mysql2date(get_option('date_format').' '.get_option('time_format'), $selected->created_at).' — #'.$selected->id); ?>">Review restore</button>
    </div>
    <?php
      $body_key=$type==='article'?'content':'answer';
      $old_body=(string)($old[$body_key]??'');$new_body=(string)($new[$body_key]??'');
      $old_blocks=$hc_revision_blocks($old_body);$new_blocks=$hc_revision_blocks($new_body);
      $block_ops=$hc_align_blocks($old_blocks,$new_blocks);
      $meta_fields=$fields;unset($meta_fields['content'],$meta_fields['answer']);
      $meta_changed=0;foreach($meta_fields as $mk=>$ml){if((string)($old[$mk]??'')!==(string)($new[$mk]??''))$meta_changed++;}
    ?>
    <div class="hc-revision-section-title"><h3>Metadata comparison</h3><span>All saved fields are shown; changed values are highlighted</span></div>
    <div class="hc-revision-field hc-revision-metadata">
      <div class="hc-revision-grid"><div class="hc-revision-side hc-revision-old"><h3>Previous version</h3></div><div class="hc-revision-side hc-revision-new"><h3>Updated version</h3></div></div>
      <?php foreach($meta_fields as $key=>$label):$ov=(string)($old[$key]??'');$nv=(string)($new[$key]??'');$same=$ov===$nv;$display_old=in_array($key,array('category_id','subcategory_id'),true)?($hc_category_names[$ov]??($ov==='0'?'None':($ov===''?'Not set':$ov))):$hc_revision_display($ov,$key);$display_new=in_array($key,array('category_id','subcategory_id'),true)?($hc_category_names[$nv]??($nv==='0'?'None':($nv===''?'Not set':$nv))):$hc_revision_display($nv,$key); ?>
        <div class="hc-revision-meta-row"><div class="hc-revision-meta-label"><?php echo esc_html($label); ?><?php if(!$same): ?><span class="hc-revision-pill">Changed</span><?php endif; ?></div><div class="hc-revision-grid"><div class="hc-revision-side hc-revision-old"><pre><?php echo esc_html($display_old===''?'—':$display_old); ?></pre></div><div class="hc-revision-side hc-revision-new"><pre><?php if($same){echo esc_html($display_new===''?'—':$display_new);}else{echo '<ins class="hc-revision-added">'.esc_html($display_new===''?'—':$display_new).'</ins>';} ?></pre></div></div></div>
      <?php endforeach; ?>
    </div>
    <div class="hc-revision-section-title"><h3>Content block comparison</h3><span>Previous content stays intact on the left; additions and deletions are marked on the right</span></div>
    <div class="hc-revision-field">
      <div class="hc-revision-grid"><div class="hc-revision-side hc-revision-old"><h3>Previous version</h3></div><div class="hc-revision-side hc-revision-new"><h3>Updated version — changes shown here</h3></div></div>
      <?php if(!$block_ops): ?><div class="hc-revision-empty">No body content in this version.</div><?php else: ?><div class="hc-revision-aligned-rows">
        <?php $rownum=0;foreach($block_ops as $op):$rownum++; ?>
          <div class="hc-revision-grid hc-revision-aligned-row">
            <div class="hc-revision-side hc-revision-old"><div class="hc-revision-block <?php echo $op['kind']==='edit'?'hc-revision-block-changed':''; ?>"><div class="hc-revision-block-label"><?php echo esc_html($op['old']['type']??''); ?><?php if(!empty($op['old'])): ?> · Previous<?php endif; ?></div><div class="hc-revision-block-body"><?php if(isset($op['old'])): ?><?php echo esc_html($op['old']['text']); ?><?php else: ?><span class="hc-revision-alignment-space" aria-label="No previous block"></span><?php endif; ?></div></div></div>
            <div class="hc-revision-side hc-revision-new"><div class="hc-revision-block <?php echo $op['kind']==='edit'?'hc-revision-block-changed':($op['kind']==='add'?'hc-revision-block-added':($op['kind']==='delete'?'hc-revision-block-deleted':'')); ?>"><div class="hc-revision-block-label"><?php echo esc_html($op['new']['type']??($op['old']['type']??'Content')); ?> · Updated</div><div class="hc-revision-block-body">
              <?php if($op['kind']==='same'): ?><?php echo esc_html($op['new']['text']); ?>
              <?php elseif($op['kind']==='add'): ?><ins class="hc-revision-added"><?php echo esc_html($op['new']['text']); ?></ins>
              <?php elseif($op['kind']==='delete'): ?><del class="hc-revision-removed hc-revision-deleted-on-right"><?php echo esc_html($op['old']['text']); ?></del>
              <?php else:$wd=$hc_word_diff($op['old']['text'],$op['new']['text']);echo $wd[1];endif; ?>
            </div></div></div>
          </div>
        <?php endforeach; ?></div><?php endif; ?>
      <details class="hc-revision-source"><summary>View formatted original HTML source (advanced)</summary><div class="hc-revision-grid"><div><strong>Previous HTML</strong><pre><?php echo esc_html($hc_pretty_html($old_body)); ?></pre></div><div><strong>Updated HTML</strong><pre><?php echo esc_html($hc_pretty_html($new_body)); ?></pre></div></div></details>
    </div>
  </section>
  <div id="hcRestorePreview" class="hc-restore-preview" hidden role="dialog" aria-modal="true" aria-labelledby="hcRestorePreviewTitle">
    <div class="hc-restore-preview-backdrop" data-hc-restore-cancel></div>
    <div class="hc-restore-preview-panel">
      <h2 id="hcRestorePreviewTitle">Confirm revision restore</h2>
      <p>You are about to restore the <strong>previous version</strong> from before revision #<?php echo (int)$selected->id; ?> (<?php echo esc_html(mysql2date(get_option('date_format').' '.get_option('time_format'), $selected->created_at)); ?>).</p>
      <p class="hc-restore-warning">The previous version below will replace the current saved content. Review it before confirming.</p>
      <div class="hc-restore-preview-field"><h3><?php echo esc_html($type==='article'?'Article title':'FAQ question'); ?></h3><div class="hc-restore-preview-structured"><?php echo esc_html((string)($old[$type==='article'?'title':'question']??'')); ?></div></div>
      <?php $restore_body=(string)($old[$type==='article'?'content':'answer']??'');$restore_blocks=$hc_revision_blocks($restore_body); ?>
      <div class="hc-restore-preview-field"><h3>Content — exact previous version structure</h3><div class="hc-restore-preview-structured hc-restore-preview-content"><?php echo $restore_body!==''?wp_kses_post($restore_body):'<p class="hc-muted">No content in this saved version.</p>'; ?></div></div>
      <p class="hc-revision-meta">This restore uses the complete saved previous snapshot, including metadata and content fields. Metadata is listed in the main comparison above.</p>
      <div class="hc-restore-preview-actions"><button type="button" class="hc-admin-btn hc-admin-btn-outline" data-hc-restore-cancel>Cancel</button><button type="button" class="hc-admin-btn hc-admin-btn-primary" id="hcConfirmRestore" data-revision-id="<?php echo (int)$selected->id; ?>" data-editor-url="<?php echo esc_url($back); ?>">Confirm restore</button></div>
    </div>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<style>
.hc-restore-preview[hidden]{display:none!important}.hc-restore-preview{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:24px}.hc-restore-preview-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.58)}.hc-restore-preview-panel{position:relative;width:min(900px,96vw);max-height:90vh;overflow:auto;background:#fff;border-radius:10px;padding:24px;box-shadow:0 20px 70px rgba(0,0,0,.3)}.hc-restore-preview-panel h2{margin-top:0}.hc-restore-warning{padding:12px;background:#fff8e5;border-left:4px solid #dba617}.hc-restore-preview-field{border:1px solid #dcdcde;border-radius:6px;margin:12px 0;overflow:hidden}.hc-restore-preview-field h3{margin:0;padding:10px 14px;background:#f6f7f7;border-bottom:1px solid #dcdcde;font-size:13px}.hc-restore-preview-field pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:240px;overflow:auto;margin:0;padding:14px;font:13px/1.6 inherit}.hc-restore-preview-actions{display:flex;justify-content:flex-end;gap:10px;position:sticky;bottom:-24px;background:#fff;padding:16px 0 0}
/* Keep revision text aligned like the normal article editor: flush left, not centered by admin theme styles. */
.hc-revision-side,.hc-revision-side h3,.hc-revision-side pre,.hc-revision-block-body,.hc-revision-meta-row pre,.hc-revision-source,.hc-revision-source pre{ text-align:left !important; }
.hc-revision-block-body{display:block;width:100%;box-sizing:border-box}
.hc-revision-aligned-row .hc-revision-side{ text-align:left !important; }
</style>
