<?php
if (!defined('ABSPATH')) exit;

$s = HC_Core::get_all_settings();
$hc_settings_section = sanitize_key(get_query_var('hc_settings_section') ?: 'general');
$hc_settings_sections = array('general'=>'General & Homepage','appearance'=>'Appearance','experience'=>'Article Experience','faq'=>'FAQs','seo'=>'SEO & Discovery','contact'=>'Contact & Uploads','search'=>'Search Analytics');
if (!isset($hc_settings_sections[$hc_settings_section])) $hc_settings_section = 'general';
?>

<div class="hc-settings-workspace-nav"><a href="<?php echo esc_url(home_url('/helpcenter/admin/section/settings/')); ?>">All settings</a><?php foreach ($hc_settings_sections as $key=>$label): ?><a class="<?php echo $hc_settings_section === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url(home_url('/helpcenter/admin/settings/' . $key . '/')); ?>"><?php echo esc_html($label); ?></a><?php endforeach; ?></div>
<div class="hc-settings-workspace-intro"><h2><?php echo esc_html($hc_settings_sections[$hc_settings_section]); ?></h2><p>Configure this area independently. Saving here will not change settings on other pages.</p></div>
<form id="hcSettingsForm" class="hc-admin-settings">
    <input type="hidden" name="hc_settings_scope" value="<?php echo esc_attr($hc_settings_section); ?>">

    <?php if ($hc_settings_section === 'general'): ?>
    <!-- GENERAL -->
    <div class="hc-admin-card" id="hc-setting-general">
        <div class="hc-admin-card-head"><h3><i class="fas fa-cog"></i> General</h3></div>
        <div class="hc-admin-card-body">
            <div class="hc-admin-field-row">
                <div class="hc-admin-field">
                    <label>Site Title</label>
                    <input type="text" name="settings[hc_site_title]" value="<?php echo esc_attr($s['hc_site_title'] ?? 'Help Center'); ?>">
                </div>
                <div class="hc-admin-field">
                    <label>Tagline</label>
                    <input type="text" name="settings[hc_tagline]" value="<?php echo esc_attr($s['hc_tagline'] ?? ''); ?>">
                </div>
            </div>
            <div class="hc-admin-field">
                <label>Hero Search Placeholder Phrases</label>
                <textarea name="settings[hc_hero_search_placeholders]" rows="4" placeholder="Search for answers...&#10;Search orders, refunds, and delivery...&#10;Type a keyword to find help..."><?php echo esc_textarea($s['hc_hero_search_placeholders'] ?? "Search for answers...\nSearch orders, refunds, and delivery...\nType a keyword to find help..."); ?></textarea>
                <small>Homepage hero search only. Enter one phrase per line. The placeholder will type, pause, erase and rotate while idle.</small>
            </div>
            <div class="hc-admin-field">
                <label>Homepage Categories Limit</label>
                <input type="number" name="settings[hc_home_category_limit]" value="<?php echo esc_attr($s['hc_home_category_limit'] ?? 6); ?>" min="1" max="100">
                <small>Maximum number of categories displayed on the homepage. A View all categories link appears when more categories exist.</small>
            </div>
            <div class="hc-admin-field">
                <label>Articles Per Page (search results and article lists)</label>
                <input type="number" name="settings[hc_articles_per_page]" value="<?php echo esc_attr($s['hc_articles_per_page'] ?? 12); ?>" min="5" max="1000">
            </div>
            <div class="hc-admin-field-row">
                <div class="hc-admin-field">
                    <label>Homepage Popular Articles</label>
                    <input type="number" name="settings[hc_popular_limit]" value="<?php echo esc_attr($s['hc_popular_limit'] ?? 6); ?>" min="1" max="100">
                </div>
                <div class="hc-admin-field">
                    <label>Homepage Latest Updates</label>
                    <input type="number" name="settings[hc_latest_limit]" value="<?php echo esc_attr($s['hc_latest_limit'] ?? 10); ?>" min="1" max="100">
                </div>
            </div>
            <div class="hc-admin-field-row">
                <div class="hc-admin-field"><label>Popular archive articles per page</label><input type="number" name="settings[hc_popular_archive_limit]" value="<?php echo esc_attr($s['hc_popular_archive_limit'] ?? 20); ?>" min="1" max="100"><small>Controls /helpcenter/popular/.</small></div>
                <div class="hc-admin-field"><label>Latest archive articles per page</label><input type="number" name="settings[hc_latest_archive_limit]" value="<?php echo esc_attr($s['hc_latest_archive_limit'] ?? 10); ?>" min="1" max="100"><small>Controls /helpcenter/latest/.</small></div>
                <div class="hc-admin-field"><label>Maximum manually selected Popular articles</label><input type="number" name="settings[hc_popular_manual_max]" value="<?php echo esc_attr($s['hc_popular_manual_max'] ?? 100); ?>" min="1" max="100"><small>Limits the curated list in the Popular Articles tab.</small></div>
            </div>
        </div>
    </div>

    <?php endif; ?>
    <?php if ($hc_settings_section === 'appearance'): ?>
    <!-- APPEARANCE -->
    <div class="hc-admin-card" id="hc-setting-appearance">
        <div class="hc-admin-card-head"><h3><i class="fas fa-palette"></i> Appearance</h3></div>
        <div class="hc-admin-card-body">
            <div class="hc-admin-field-row">
                <?php
                $colors = array(
                    'hc_primary_color' => array('Primary Color', '#6366F1'),
                    'hc_accent_color'  => array('Accent Color', '#F59E0B'),
                    'hc_bg_color'      => array('Background', '#F8FAFC'),
                    'hc_header_bg'     => array('Header Background', '#FFFFFF'),
                    'hc_header_text'   => array('Header Text', '#0F172A'),
                );
                foreach ($colors as $key => $meta):
                ?>
                <div class="hc-admin-field hc-color-setting">
                    <label><?php echo esc_html($meta[0]); ?></label>
                    <?php $color_value = sanitize_hex_color($s[$key] ?? $meta[1]) ?: $meta[1]; ?>
                    <div class="hc-color-controls"><input type="color" name="settings[<?php echo $key; ?>]" class="hc-color-picker" value="<?php echo esc_attr($color_value); ?>" aria-label="Choose <?php echo esc_attr($meta[0]); ?>"><input type="text" class="hc-color-hex" data-color-target="settings[<?php echo $key; ?>]" value="<?php echo esc_attr($color_value); ?>" pattern="^#[0-9A-Fa-f]{6}$" maxlength="7" aria-label="HEX value for <?php echo esc_attr($meta[0]); ?>"></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <?php endif; ?>
    <?php if ($hc_settings_section === 'experience'): ?>
    <!-- FEATURES -->
    <div class="hc-admin-card" id="hc-setting-experience">
        <div class="hc-admin-card-head"><h3><i class="fas fa-sliders"></i> Features</h3></div>
        <div class="hc-admin-card-body">
            <div class="hc-admin-field-row">
                <?php
                $features = array(
                    'hc_show_search'        => 'Show Search Bar',
                    'hc_show_live_search'   => 'Enable Live Search',
                    'hc_show_breadcrumbs'   => 'Show Breadcrumbs',
                    'hc_show_helpful'       => 'Enable Helpful Votes',
                    'hc_show_related'       => 'Show Related Articles',
                    'hc_show_faqs'          => 'Show FAQs',
                    'hc_show_toc'           => 'Show Table of Contents',
                    'hc_show_reading_time'  => 'Show Reading Time',
                    'hc_show_view_count'    => 'Show View Count',
                    'hc_show_share'         => 'Show Share Buttons',
                    'hc_show_print'         => 'Show Print Button',
                    'hc_enable_tickets'    => 'Enable Support Tickets',
                );
                foreach ($features as $key => $label):
                    $checked = ($s[$key] ?? '1') === '1';
                ?>
                <div class="hc-admin-field">
                    <label class="hc-admin-switch">
                        <input type="checkbox" name="settings[<?php echo $key; ?>]" value="1" <?php checked($checked); ?>>
                        <span></span>
                        <strong><?php echo esc_html($label); ?></strong>
                    </label>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <?php endif; ?>
    <?php if ($hc_settings_section === 'faq'): ?>
    <!-- FAQS -->
    <div class="hc-admin-card" id="hc-setting-faqs">
        <div class="hc-admin-card-head"><h3><i class="fas fa-circle-question"></i> FAQs</h3></div>
        <div class="hc-admin-card-body">
            <div class="hc-admin-field-row">
                <div class="hc-admin-field">
                    <label>Position on page</label>
                    <select name="settings[hc_faq_position]">
                        <option value="bottom" <?php selected($s['hc_faq_position'] ?? 'bottom', 'bottom'); ?>>Below content</option>
                        <option value="top" <?php selected($s['hc_faq_position'] ?? '', 'top'); ?>>Above content</option>
                    </select>
                </div>
                <div class="hc-admin-field">
                    <label>Max FAQs per page</label>
                    <input type="number" name="settings[hc_faq_max]" value="<?php echo esc_attr($s['hc_faq_max'] ?? 20); ?>" min="1" max="50">
                </div>
            </div>
        </div>
    </div>

    <?php endif; ?>
    <?php if ($hc_settings_section === 'seo'): ?>
    <!-- SEO / SCHEMA -->
    <div class="hc-admin-card" id="hc-setting-seo">
        <div class="hc-admin-card-head"><h3><i class="fas fa-magnifying-glass-chart"></i> SEO & Schema Markup</h3></div>
        <div class="hc-admin-card-body">
            <div class="hc-admin-field-row">
                <?php
                $schema = array(
                    'hc_schema_enabled'     => 'Enable Schema Markup',
                    'hc_schema_breadcrumbs' => 'Include Breadcrumbs Schema',
                    'hc_schema_faq'         => 'Include FAQ Schema',
                    'hc_schema_search'      => 'Include Search Action Schema',
                );
                foreach ($schema as $key => $label):
                    $checked = ($s[$key] ?? '1') === '1';
                ?>
                <div class="hc-admin-field">
                    <label class="hc-admin-switch">
                        <input type="checkbox" name="settings[<?php echo $key; ?>]" value="1" <?php checked($checked); ?>>
                        <span></span>
                        <strong><?php echo esc_html($label); ?></strong>
                    </label>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="hc-admin-field-row" style="margin-top:16px;">
                <div class="hc-admin-field">
                    <label>Organization Name</label>
                    <input type="text" name="settings[hc_schema_org_name]" value="<?php echo esc_attr($s['hc_schema_org_name'] ?? get_bloginfo('name')); ?>">
                </div>
                <div class="hc-admin-field">
                    <label>Author Name</label>
                    <input type="text" name="settings[hc_schema_author]" value="<?php echo esc_attr($s['hc_schema_author'] ?? 'Support Team'); ?>">
                </div>
            </div>

            <div class="hc-admin-field">
                <label>Organization Logo URL</label>
                <input type="url" name="settings[hc_schema_org_logo]" value="<?php echo esc_attr($s['hc_schema_org_logo'] ?? ''); ?>" placeholder="https://example.com/logo.png">
                <small>Used in schema publisher block.</small>
            </div>

            <div class="hc-admin-field">
                <label>Default Article Schema Type</label>
                <select name="settings[hc_schema_article_type]">
                    <?php foreach (array('Article', 'TechArticle', 'HowTo', 'FAQPage') as $t): ?>
                    <option value="<?php echo esc_attr($t); ?>" <?php selected($s['hc_schema_article_type'] ?? 'TechArticle', $t); ?>><?php echo $t; ?></option>
                    <?php endforeach; ?>
                </select>
                <small>Can be overridden per-article.</small>
            </div>
        </div>
    </div>

    <?php endif; ?>
    <?php if ($hc_settings_section === 'contact'): ?>
    <!-- CONTACT -->
    <div class="hc-admin-card" id="hc-setting-contact">
        <div class="hc-admin-card-head"><h3><i class="fas fa-envelope"></i> Contact</h3></div>
        <div class="hc-admin-card-body">
            <div class="hc-admin-field-row">
                <div class="hc-admin-field">
                    <label>Contact Email</label>
                    <input type="email" name="settings[hc_contact_email]" value="<?php echo esc_attr($s['hc_contact_email'] ?? get_option('admin_email')); ?>">
                </div>
                <div class="hc-admin-field">
                    <label>Contact Phone</label>
                    <input type="text" name="settings[hc_contact_phone]" value="<?php echo esc_attr($s['hc_contact_phone'] ?? ''); ?>" placeholder="+1 555 123 4567">
                </div>
            </div>

            <div class="hc-admin-field">
                <label>Live Chat URL (optional)</label>
                <input type="url" name="settings[hc_livechat_url]" value="<?php echo esc_attr($s['hc_livechat_url'] ?? ''); ?>" placeholder="https://tawk.to/...">
                <small>Leave empty to hide the Live Chat card on contact page.</small>
            </div>

            <div class="hc-admin-field-row" style="margin-top:12px;">
                <div class="hc-admin-field">
                    <label class="hc-admin-switch">
                        <input type="checkbox" name="settings[hc_contact_upload]" value="1" <?php checked(($s['hc_contact_upload'] ?? '1') === '1'); ?>>
                        <span></span>
                        <strong>Allow File Upload</strong>
                    </label>
                </div>
                <div class="hc-admin-field">
                    <label>Max Upload Size (MB)</label>
                    <input type="number" name="settings[hc_contact_max_mb]" value="<?php echo esc_attr($s['hc_contact_max_mb'] ?? 5); ?>" min="1" max="20">
                </div>
            </div>
        </div>
    </div>

    <?php endif; ?>
    <?php if ($hc_settings_section === 'search'): ?>
    <!-- ANALYTICS -->
    <div class="hc-admin-card" id="hc-setting-analytics">
        <div class="hc-admin-card-head"><h3><i class="fas fa-chart-line"></i> Search Analytics</h3></div>
        <div class="hc-admin-card-body">
            <div class="hc-admin-field-row">
                <div class="hc-admin-field">
                    <label class="hc-admin-switch">
                        <input type="checkbox" name="settings[hc_log_searches]" value="1" <?php checked(($s['hc_log_searches'] ?? '1') === '1'); ?>>
                        <span></span>
                        <strong>Log Search Queries</strong>
                    </label>
                </div>
                <div class="hc-admin-field">
                    <label>Log Retention (days)</label>
                    <input type="number" name="settings[hc_log_retention_days]" value="<?php echo esc_attr($s['hc_log_retention_days'] ?? 90); ?>" min="7" max="365">
                </div>
            </div>
            <div class="hc-admin-field" style="margin-top:16px;">
                <label for="hcSearchSynonyms">Additional search synonyms (optional)</label>
                <textarea id="hcSearchSynonyms" name="settings[hc_search_synonyms]" rows="5" placeholder="login=sign in|signin&#10;wifi=wireless|wi-fi&#10;refund=money back|reimbursement"><?php echo esc_textarea($s['hc_search_synonyms'] ?? ''); ?></textarea>
                <p class="hc-muted">Search now learns its vocabulary automatically from published article titles, summaries and keywords, and corrects likely spelling mistakes against that vocabulary. Add manual overrides here only for special business terms. One rule per line: <code>keyword=alternative|another alternative</code>.</p>
            </div>
        </div>
    </div>


    <?php endif; ?>
    <!-- SAVE -->
    <div class="hc-admin-settings-foot">
        <button type="submit" class="hc-admin-btn hc-admin-btn-primary hc-admin-btn-lg" id="hcSettingsSaveBtn">
            <i class="fas fa-save"></i> Save Changes
        </button>
    </div>

</form>

<style>.hc-color-controls{display:flex;align-items:center;gap:10px}.hc-color-picker{width:48px!important;height:42px;padding:4px!important;cursor:pointer}.hc-color-hex{max-width:130px;font-family:ui-monospace,monospace;text-transform:uppercase}.hc-color-setting{min-width:190px}</style>
<script>(function(){document.querySelectorAll('.hc-color-setting').forEach(function(w){var picker=w.querySelector('.hc-color-picker'),hex=w.querySelector('.hc-color-hex');if(!picker||!hex)return;picker.addEventListener('input',function(){hex.value=picker.value.toUpperCase()});hex.addEventListener('input',function(){if(/^#[0-9a-fA-F]{6}$/.test(hex.value))picker.value=hex.value});hex.addEventListener('blur',function(){if(!/^#[0-9a-fA-F]{6}$/.test(hex.value))hex.value=picker.value.toUpperCase()})})})();</script>

<style>.hc-settings-workspace-nav{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 18px}.hc-settings-workspace-nav a{display:inline-flex;padding:9px 13px;border:1px solid #e2e7f0;border-radius:9px;background:#fff;color:#475467;text-decoration:none;font-size:12px;font-weight:650}.hc-settings-workspace-nav a.is-active{background:#29265f;border-color:#29265f;color:#fff}.hc-settings-workspace-intro{margin:0 0 18px}.hc-settings-workspace-intro h2{margin:0 0 5px;font-size:21px}.hc-settings-workspace-intro p{margin:0;color:#778196;font-size:12px}.hc-admin-settings .hc-admin-card{scroll-margin-top:18px}</style>
