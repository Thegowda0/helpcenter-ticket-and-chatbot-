<?php
if (!defined('ABSPATH')) exit;
$ids = HC_Core::get_popular_article_ids();
$selected = array();
if ($ids) {
    global $wpdb;
    $rows = $wpdb->get_results("SELECT id,title,slug,view_count FROM {$wpdb->prefix}hc_articles WHERE id IN (" . implode(',', array_map('absint', $ids)) . ") AND status='published' AND deleted_at IS NULL");
    $map = array(); foreach ($rows as $row) $map[(int)$row->id] = $row;
    foreach ($ids as $id) if (isset($map[$id])) $selected[] = $map[$id];
}
$max = (int) HC_Core::get_setting('hc_popular_manual_max', 100);
?>
<div class="hc-popular-admin">
  <div class="hc-admin-card">
    <div class="hc-admin-card-head"><h3><i class="fas fa-fire"></i> Curated Popular Articles</h3><span class="hc-popular-count"><b id="hcPopularCount"><?php echo count($selected); ?></b> / <?php echo (int)$max; ?> selected</span></div>
    <div class="hc-admin-card-body">
      <p class="hc-admin-help">Search and add published articles, then drag them into the exact order you want. These articles appear first on the homepage and Popular archive. Remaining slots are filled by most-viewed articles.</p>
      <label class="hc-admin-label" for="hcPopularSearch">Find an article</label>
      <div class="hc-popular-search-wrap"><i class="fas fa-search"></i><input type="search" id="hcPopularSearch" placeholder="Search article titles…" autocomplete="off"><div id="hcPopularSearchResults" class="hc-popular-search-results" aria-live="polite"></div></div>
      <div class="hc-popular-list-head"><h4>Display order</h4><span>Drag using <i class="fas fa-grip-vertical"></i></span></div>
      <ol id="hcPopularSelected" class="hc-popular-selected">
      <?php foreach ($selected as $article): ?><li class="hc-popular-selected-item" draggable="true" data-id="<?php echo (int)$article->id; ?>"><span class="hc-popular-grip"><i class="fas fa-grip-vertical"></i></span><span class="hc-popular-position"></span><span class="hc-popular-title"><?php echo esc_html($article->title); ?><small><?php echo number_format_i18n((int)$article->view_count); ?> views</small></span><a class="hc-popular-open" href="<?php echo esc_url(home_url('/helpcenter/admin/articles/edit/' . (int)$article->id . '/')); ?>" title="Edit article"><i class="fas fa-pen"></i></a><button type="button" class="hc-popular-remove" aria-label="Remove <?php echo esc_attr($article->title); ?>" title="Remove from Popular"><i class="fas fa-times"></i></button></li><?php endforeach; ?>
      </ol>
      <div id="hcPopularEmpty" class="hc-popular-empty" <?php echo $selected ? 'hidden' : ''; ?>><i class="fas fa-list-ol"></i><strong>No curated articles yet</strong><span>Search above to add articles. Your most-viewed articles will still populate the frontend.</span></div>
      <div class="hc-popular-actions"><span id="hcPopularStatus" role="status"></span><button type="button" id="hcPopularSave" class="hc-admin-btn hc-admin-btn-primary"><i class="fas fa-save"></i> Save display order</button></div>
    </div>
  </div>
</div>
<style>
.hc-popular-admin{max-width:1000px}.hc-popular-count{font-size:13px;color:#64748b}.hc-admin-help{color:#64748b;line-height:1.6;margin:0 0 20px}.hc-admin-label{display:block;font-weight:700;margin-bottom:8px}.hc-popular-search-wrap{position:relative;max-width:680px}.hc-popular-search-wrap>i{position:absolute;left:14px;top:15px;color:#94a3b8}.hc-popular-search-wrap input{width:100%;padding:13px 15px 13px 42px;border:1px solid #dbe2ea;border-radius:12px;background:#fff}.hc-popular-search-results{display:none;position:absolute;z-index:30;top:calc(100% + 6px);left:0;right:0;background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 16px 38px #0f172a1a;overflow:hidden}.hc-popular-search-results.open{display:block}.hc-popular-result{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 15px;border-bottom:1px solid #f1f5f9}.hc-popular-result:last-child{border-bottom:0}.hc-popular-result strong{display:block}.hc-popular-result small{display:block;color:#64748b;margin-top:3px}.hc-popular-result button{border:0;background:#eef2ff;color:#4338ca;border-radius:8px;padding:8px 11px;font-weight:700;cursor:pointer}.hc-popular-list-head{display:flex;justify-content:space-between;align-items:center;margin-top:28px}.hc-popular-list-head h4{margin:0;font-size:15px}.hc-popular-list-head span{color:#64748b;font-size:12px}.hc-popular-selected{list-style:none;padding:0;margin:12px 0;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden}.hc-popular-selected-item{display:flex;align-items:center;gap:12px;padding:13px 15px;background:#fff;border-bottom:1px solid #edf1f5}.hc-popular-selected-item:last-child{border-bottom:0}.hc-popular-selected-item.dragging{opacity:.4}.hc-popular-selected-item.drag-over{box-shadow:inset 0 3px #6366f1}.hc-popular-grip{color:#94a3b8;cursor:grab;padding:6px}.hc-popular-position{width:28px;height:28px;display:grid;place-items:center;border-radius:8px;background:#f1f5f9;color:#475569;font-weight:800;font-size:12px}.hc-popular-title{font-weight:700;flex:1;min-width:0}.hc-popular-title small{display:block;font-weight:400;color:#64748b;margin-top:3px}.hc-popular-open,.hc-popular-remove{border:0;background:transparent;color:#64748b;padding:8px;cursor:pointer}.hc-popular-remove:hover{color:#dc2626;background:#fef2f2;border-radius:8px}.hc-popular-empty{padding:34px;text-align:center;border:1px dashed #cbd5e1;border-radius:12px;color:#64748b;display:flex;flex-direction:column;align-items:center;gap:8px}.hc-popular-empty[hidden]{display:none}.hc-popular-empty i{font-size:25px}.hc-popular-empty strong{color:#334155}.hc-popular-actions{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:18px}.hc-popular-actions #hcPopularStatus{color:#15803d;font-size:13px;overflow-wrap:anywhere}@media(max-width:600px){.hc-popular-selected-item{gap:6px;padding:10px}.hc-popular-actions{align-items:stretch;flex-direction:column}.hc-popular-actions button{width:100%}}
</style>
<script>
(function(){
 const ajax=window.hcAdmin||{}, list=document.getElementById('hcPopularSelected'), input=document.getElementById('hcPopularSearch'), results=document.getElementById('hcPopularSearchResults'), status=document.getElementById('hcPopularStatus'), save=document.getElementById('hcPopularSave'), empty=document.getElementById('hcPopularEmpty');
 if(!list||!input)return; let timer=null, dragging=null;
 function request(action, payload, retried){
   const url=ajax.ajaxUrl||window.ajaxurl||'/wp-admin/admin-ajax.php';
   const fd=new FormData();fd.append('action',action);fd.append('nonce',ajax.nonce||'');
   Object.keys(payload||{}).forEach(k=>{if(Array.isArray(payload[k]))payload[k].forEach(v=>fd.append(k+'[]',v));else fd.append(k,payload[k]);});
   return fetch(url,{method:'POST',credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'},body:fd})
    .then(async r=>{const body=await r.text();let json;try{json=JSON.parse(body)}catch(e){const snippet=body.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,180);throw new Error('Server returned non-JSON (HTTP '+r.status+'). '+(snippet||'Check login, AJAX URL, or PHP errors.'))}
      const msg=(json&&json.data&&json.data.message)||'';
      if(!retried && /nonce failed|invalid nonce|security check/i.test(msg)){
        const nf=new FormData();nf.append('action','hc_refresh_nonce');
        return fetch(url,{method:'POST',credentials:'same-origin',body:nf}).then(x=>x.json()).then(n=>{if(!n.success||!n.data||!n.data.nonce)throw new Error(n?.data?.message||'Could not refresh security token. Reload the page.');ajax.nonce=n.data.nonce;return request(action,payload,true);});
      }
      if(!r.ok && !json.success)throw new Error(msg||('Request failed (HTTP '+r.status+').'));return json;
    });
 }
 function ids(){return Array.from(list.querySelectorAll('[data-id]')).map(x=>x.dataset.id)}
 function refresh(){Array.from(list.children).forEach((li,i)=>{li.querySelector('.hc-popular-position').textContent=i+1});document.getElementById('hcPopularCount').textContent=list.children.length;empty.hidden=list.children.length>0;}
 function item(a){const li=document.createElement('li');li.className='hc-popular-selected-item';li.draggable=true;li.dataset.id=a.id;const title=document.createElement('span');title.className='hc-popular-title';title.append(document.createTextNode(a.title));const small=document.createElement('small');small.textContent=(Number(a.view_count)||0).toLocaleString()+' views';title.append(small);li.innerHTML='<span class="hc-popular-grip"><i class="fas fa-grip-vertical"></i></span><span class="hc-popular-position"></span>';li.append(title);const edit=document.createElement('a');edit.className='hc-popular-open';edit.href=(ajax.homeUrl||'/helpcenter/admin/').replace(/\/$/,'')+'/articles/edit/'+a.id+'/';edit.title='Edit article';edit.innerHTML='<i class="fas fa-pen"></i>';li.append(edit);const remove=document.createElement('button');remove.type='button';remove.className='hc-popular-remove';remove.title='Remove from Popular';remove.innerHTML='<i class="fas fa-times"></i>';li.append(remove);return li;}
 function renderResults(rows){results.innerHTML='';const current=ids();rows.filter(a=>!current.includes(String(a.id))).forEach(a=>{const row=document.createElement('div');row.className='hc-popular-result';const info=document.createElement('div');const title=document.createElement('strong');title.textContent=a.title;const meta=document.createElement('small');meta.textContent=(Number(a.view_count)||0).toLocaleString()+' views';info.append(title,meta);const btn=document.createElement('button');btn.type='button';btn.textContent='Add';btn.addEventListener('click',()=>request('hc_add_popular_article',{id:a.id}).then(r=>{if(!r.success)throw new Error(r.data?.message||'Unable to add article');list.append(item(a));refresh();renderResults(rows);status.textContent='Article added. Save the display order to publish the new order.';}).catch(e=>status.textContent=e.message));row.append(info,btn);results.append(row)});if(!results.children.length){const msg=document.createElement('div');msg.className='hc-popular-result';msg.textContent='No matching articles available to add.';results.append(msg)}results.classList.add('open');}
 input.addEventListener('input',()=>{clearTimeout(timer);const q=input.value.trim();if(q.length<2){results.classList.remove('open');results.innerHTML='';return}timer=setTimeout(()=>request('hc_popular_search',{q}).then(r=>renderResults(r.success?(r.data.rows||[]):[])).catch(()=>{results.innerHTML='<div class="hc-popular-result">Search failed. Please try again.</div>';results.classList.add('open')}),250)});
 document.addEventListener('click',e=>{if(!e.target.closest('.hc-popular-search-wrap'))results.classList.remove('open')});
 list.addEventListener('click',e=>{const btn=e.target.closest('.hc-popular-remove');if(!btn)return;const li=btn.closest('[data-id]');request('hc_remove_popular_article',{id:li.dataset.id}).then(r=>{if(r.success){li.remove();refresh();status.textContent='Removed from curated Popular list.'}})});
 list.addEventListener('dragstart',e=>{const li=e.target.closest('[data-id]');if(!li)return;dragging=li;li.classList.add('dragging');e.dataTransfer.effectAllowed='move'});
 list.addEventListener('dragend',()=>{if(dragging)dragging.classList.remove('dragging');list.querySelectorAll('.drag-over').forEach(x=>x.classList.remove('drag-over'));dragging=null;refresh()});
 list.addEventListener('dragover',e=>{e.preventDefault();const target=e.target.closest('[data-id]');if(!dragging||!target||target===dragging)return;target.classList.add('drag-over');const r=target.getBoundingClientRect();list.insertBefore(dragging,e.clientY<r.top+r.height/2?target:target.nextSibling)});
 list.addEventListener('dragleave',e=>{const li=e.target.closest('[data-id]');if(li)li.classList.remove('drag-over')});
 save.addEventListener('click',()=>{save.disabled=true;status.textContent='Saving…';request('hc_save_popular_order',{ids:ids()}).then(r=>{if(!r.success)throw new Error(r.data?.message||'Could not save order');status.textContent='Display order saved successfully.'}).catch(e=>status.textContent=e.message).finally(()=>save.disabled=false)});refresh();
})();
</script>
