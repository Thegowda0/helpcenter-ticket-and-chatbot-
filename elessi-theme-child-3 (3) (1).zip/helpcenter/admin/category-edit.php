<?php
if (!defined('ABSPATH')) exit;


// HC_TRASH_EDIT_GUARD: block editing trashed items
$id = (int) get_query_var('hc_id');
if ($id > 0) {
    global $wpdb;
    $is_trashed = $wpdb->get_var($wpdb->prepare("SELECT deleted_at FROM {$wpdb->prefix}hc_categories WHERE id = %d", $id));
    if ($is_trashed) {
        wp_die('This category is in the trash and cannot be edited. Restore it first.', 'Item in Trash', array('back_link' => true));
    }
}
$cat = $id ? HC_Core::get_category($id) : null;
$is_edit = $cat !== null;
$parents = HC_Core::get_categories(0, 'any');
$icon = $is_edit ? ($cat->icon_value ?: 'fa-folder') : 'fa-folder';

$quick_icons = array(
    'fa-folder', 'fa-rocket', 'fa-cog', 'fa-shield', 'fa-credit-card',
    'fa-truck', 'fa-user', 'fa-star', 'fa-heart', 'fa-envelope',
    'fa-phone', 'fa-comments', 'fa-book', 'fa-wrench', 'fa-key',
    'fa-life-ring', 'fa-question', 'fa-info-circle', 'fa-cart-shopping', 'fa-gift'
);
?>

<div class="hc-admin-page-head">
    <a href="<?php echo esc_url(home_url('/helpcenter/admin/categories/')); ?>" class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm">
        <i class="fas fa-arrow-left"></i> Back
    </a>
    <h1>
        <?php echo $is_edit ? 'Edit Category' : 'New Category'; ?>
        <?php if ($is_edit && (int) $cat->is_default === 1): ?>
            <span class="hc-admin-badge-default"><i class="fas fa-lock"></i> Default</span>
        <?php endif; ?>
    </h1>
</div>

<?php $is_default_locked = $is_edit && (int) $cat->is_default === 1; ?>
<form id="hcCategoryForm" class="hc-admin-card<?php echo $is_default_locked ? ' hc-cat-is-default' : ''; ?>" data-id="<?php echo (int) $id; ?>" data-is-default="<?php echo $is_default_locked ? 1 : 0; ?>">
    <div class="hc-admin-card-body">

        <div class="hc-admin-field">
            <label>Name <span class="req">*</span></label>
            <input type="text" name="name" id="hcCatName" required value="<?php echo $is_edit ? esc_attr($cat->name) : ''; ?>" placeholder="Category name"<?php echo $is_default_locked ? ' readonly class="hc-locked"' : ''; ?>>
            <?php if ($is_default_locked): ?><small class="hc-lock-hint"><i class="fas fa-lock"></i> Locked — cannot be changed for the default category</small><?php endif; ?>
        </div>

        <div class="hc-admin-field-row">
            <div class="hc-admin-field">
                <label>Slug</label>
                <input type="text" name="slug" id="hcCatSlug" value="<?php echo $is_edit ? esc_attr($cat->slug) : ''; ?>" placeholder="auto from name"<?php echo $is_default_locked ? ' readonly class="hc-locked"' : ''; ?>>
            </div>
            <div class="hc-admin-field">
                <label>Parent Category</label>
                <select name="parent_id"<?php echo $is_default_locked ? ' disabled class="hc-locked"' : ''; ?>>
                    <option value="0">None (top level)</option>
                    <?php foreach ($parents as $p):
                        if ($is_edit && $p->id == $cat->id) continue;
                        if ($p->parent_id > 0) continue; // only top-level can be parents
                    ?>
                    <option value="<?php echo (int) $p->id; ?>" <?php selected($is_edit ? $cat->parent_id : 0, $p->id); ?>>
                        <?php echo esc_html($p->name); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <small>Max 2 levels: category → subcategory</small>
            </div>
        </div>

        <div class="hc-admin-field">
            <label>
                Description
                <?php if ($is_default_locked): ?>
                <button type="button" class="hc-admin-btn hc-admin-btn-xs hc-admin-btn-outline hc-unlock-btn" id="hcUnlockDescription">
                    <i class="fas fa-lock"></i> Unlock
                </button>
                <?php endif; ?>
            </label>
            <textarea name="description" id="hcCategoryDescription" rows="3" placeholder="Brief description of this category"<?php echo $is_default_locked ? ' readonly disabled class="hc-locked"' : ''; ?>><?php echo $is_edit ? esc_textarea($cat->description) : ''; ?></textarea>
        </div>

        <div class="hc-admin-field">
            <label>Icon</label>
            <input type="hidden" name="icon_type" value="fontawesome">
            <input type="hidden" name="icon_value" id="hcIconValue" value="<?php echo esc_attr($icon); ?>">

            <div class="hc-icon-picker">
                <div class="hc-icon-preview">
                    <i class="fas <?php echo esc_attr($icon); ?>" id="hcIconPreview"></i>
                </div>
                <div class="hc-icon-grid">
                    <?php foreach ($quick_icons as $ic): ?>
                    <button type="button" class="hc-icon-btn <?php echo $ic === $icon ? 'active' : ''; ?>" data-icon="<?php echo esc_attr($ic); ?>">
                        <i class="fas <?php echo esc_attr($ic); ?>"></i>
                    </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="hc-icon-custom">
                <span class="hc-icon-custom-label">Custom FontAwesome Class</span>
                <input type="text"
                       class="hc-icon-custom-input"
                       id="hcIconCustomInput"
                       placeholder="rocket, fa-rocket, or fas fa-code"
                       autocomplete="off"
                       spellcheck="false">
                <span class="hc-icon-custom-preview fas fa-question" id="hcIconCustomPreview"></span>
                <span class="hc-icon-custom-status" id="hcIconCustomStatus"></span>
                <div class="hc-icon-custom-hint">
                    Type any FontAwesome icon name — <code>rocket</code>, <code>fa-rocket</code>, or <code>fas fa-rocket</code>. Press Enter to apply.
                    Browse icons at <a href="https://fontawesome.com/icons" target="_blank" rel="noopener">fontawesome.com/icons</a>.
                </div>
            </div>
        </div>

        <div class="hc-admin-field-row">
            <div class="hc-admin-field">
                <label>Sort Order</label>
                <input type="number" name="sort_order" value="<?php echo $is_edit ? (int) $cat->sort_order : 0; ?>" min="0"<?php echo $is_default_locked ? ' readonly class="hc-locked"' : ''; ?>>
            </div>
            <div class="hc-admin-field">
                <label>Status</label>
                <select name="status"<?php echo $is_default_locked ? ' disabled class="hc-locked"' : ''; ?>>
                    <option value="published" <?php selected($is_edit ? $cat->status : 'published', 'published'); ?>>Published</option>
                    <option value="hidden" <?php selected($is_edit ? $cat->status : '', 'hidden'); ?>>Hidden</option>
                </select>
                <small>Hidden categories (and the articles that are only in them) are not shown to visitors until published.</small>
            </div>
        </div>

    </div>

    <?php if ($is_default_locked): ?>
    <input type="hidden" name="is_default" value="1">
    <?php endif; ?>

    <div class="hc-admin-card-foot">
        <button type="submit" class="hc-admin-btn hc-admin-btn-primary hc-admin-btn-lg" id="hcCatSaveBtn">
            <i class="fas fa-save"></i> <?php echo $is_edit ? 'Update Category' : 'Create Category'; ?>
        </button>
        <a href="<?php echo esc_url(home_url('/helpcenter/admin/categories/')); ?>" class="hc-admin-btn hc-admin-btn-outline">Cancel</a>
    </div>
</form>
