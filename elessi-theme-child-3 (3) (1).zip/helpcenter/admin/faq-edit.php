<?php
if (!defined('ABSPATH')) exit;


// HC_TRASH_EDIT_GUARD: block editing trashed items
$id = (int) get_query_var('hc_id');
if ($id > 0) {
    global $wpdb;
    $is_trashed = $wpdb->get_var($wpdb->prepare("SELECT deleted_at FROM {$wpdb->prefix}hc_faqs WHERE id = %d", $id));
    if ($is_trashed) {
        wp_die('This FAQ is in the trash and cannot be edited. Restore it first.', 'Item in Trash', array('back_link' => true));
    }
}
$faq = $id ? HC_Core::get_faq($id) : null;
$is_edit = $faq !== null;

$cats = HC_Core::get_categories(0, 'any');
$arts = HC_Core::get_categories(0, 'any'); // placeholder — will fetch articles below
global $wpdb;
$all_articles = $wpdb->get_results("SELECT id, title FROM {$wpdb->prefix}hc_articles WHERE deleted_at IS NULL ORDER BY (status = 'published') DESC, title ASC LIMIT 500");

$dest_type = $is_edit ? $faq->destination_type : 'global';
$dest_id   = $is_edit ? (int) $faq->destination_id : 0;
?>

<div class="hc-admin-page-head">
    <a href="<?php echo esc_url(home_url('/helpcenter/admin/faqs/')); ?>" class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm">
        <i class="fas fa-arrow-left"></i> Back
    </a>
    <h1><?php echo $is_edit ? 'Edit FAQ' : 'New FAQ'; ?></h1>
</div>

<?php /* HC_VISIBILITY_NOTICE */ ?>
<?php if ($is_edit):
    $hc_why = HC_Lifecycle::faq_hidden_reason($faq);
    if ($hc_why !== ''): ?>
<div class="hc-admin-notice" style="background:#FFFBEB;border:1px solid #FCD34D;color:#92400E;padding:12px 16px;border-radius:8px;margin-bottom:16px;">
    <i class="fas fa-eye-slash"></i> <strong>Not visible to visitors:</strong> <?php echo esc_html($hc_why); ?>.
</div>
<?php endif; endif; ?>

<?php if ($is_edit): ?><div style="margin-bottom:14px"><a class="hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm" href="<?php echo esc_url(home_url('/helpcenter/admin/revisions/faq/' . (int)$id . '/')); ?>"><i class="fas fa-clock-rotate-left"></i> Revision History</a></div><?php endif; ?>

<form id="hcFaqForm" class="hc-admin-card" data-id="<?php echo (int) $id; ?>">
    <div class="hc-admin-card-body">

        <div class="hc-admin-field">
            <label>Question <span class="req">*</span></label>
            <input type="text" name="question" required value="<?php echo $is_edit ? esc_attr($faq->question) : ''; ?>" placeholder="Enter the question">
        </div>

        <div class="hc-admin-field">
            <label>Answer <span class="req">*</span></label>
            <?php
            $answer = $is_edit ? $faq->answer : '';
            wp_editor($answer, 'hcFaqAnswer', array(
                'textarea_name' => 'answer',
                'media_buttons' => false,
                'textarea_rows' => 8,
                'teeny'         => true,
            ));
            ?>
        </div>

        <div class="hc-admin-field">
            <label>Show this FAQ on <span class="req">*</span></label>
            <select name="destination_type" id="hcFaqDestType">
                <option value="global" <?php selected($dest_type, 'global'); ?>>Global — everywhere</option>
                <option value="home" <?php selected($dest_type, 'home'); ?>>Home page only</option>
                <option value="contact" <?php selected($dest_type, 'contact'); ?>>Contact page only</option>
                <option value="category" <?php selected($dest_type, 'category'); ?>>Specific Category</option>
                <option value="article" <?php selected($dest_type, 'article'); ?>>Specific Article</option>
            </select>
        </div>

        <div class="hc-admin-field" id="hcFaqDestCat" style="display:<?php echo $dest_type === 'category' ? 'block' : 'none'; ?>;">
            <label>Category</label>
            <select name="destination_id_cat">
                <option value="">Select category</option>
                <?php foreach ($cats as $c): ?>
                <option value="<?php echo (int) $c->id; ?>" <?php echo $dest_type === 'category' && $dest_id === (int) $c->id ? 'selected' : ''; ?>>
                    <?php echo esc_html($c->name); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="hc-admin-field" id="hcFaqDestArt" style="display:<?php echo $dest_type === 'article' ? 'block' : 'none'; ?>;">
            <label>Article</label>
            <select name="destination_id_art">
                <option value="">Select article</option>
                <?php foreach ($all_articles as $a): ?>
                <option value="<?php echo (int) $a->id; ?>" <?php echo $dest_type === 'article' && $dest_id === (int) $a->id ? 'selected' : ''; ?>>
                    <?php echo esc_html(wp_trim_words($a->title, 10)); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="hc-admin-field-row">
            <div class="hc-admin-field">
                <label>Sort Order</label>
                <input type="number" name="sort_order" value="<?php echo $is_edit ? (int) $faq->sort_order : 0; ?>" min="0">
            </div>
            <div class="hc-admin-field">
                <label>Status</label>
                <select name="status">
                    <option value="published" <?php selected($is_edit ? $faq->status : 'published', 'published'); ?>>Published</option>
                    <option value="draft" <?php selected($is_edit ? $faq->status : '', 'draft'); ?>>Draft</option>
                </select>
            </div>
        </div>

    </div>

    <div class="hc-admin-card-foot">
        <button type="submit" class="hc-admin-btn hc-admin-btn-primary hc-admin-btn-lg" id="hcFaqSaveBtn">
            <i class="fas fa-save"></i> <?php echo $is_edit ? 'Update FAQ' : 'Create FAQ'; ?>
        </button>
        <a href="<?php echo esc_url(home_url('/helpcenter/admin/faqs/')); ?>" class="hc-admin-btn hc-admin-btn-outline">Cancel</a>
    </div>
</form>
