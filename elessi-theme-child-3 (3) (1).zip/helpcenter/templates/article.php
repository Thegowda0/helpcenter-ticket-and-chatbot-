<?php
if (!defined('ABSPATH')) exit;

$slug = get_query_var('hc_article');
$article = HC_Core::get_article_by_slug($slug);

if (!$article) { status_header(404); include HC_TEMPLATES . '404.php'; return; }

$category = HC_Lifecycle::primary_category($article);
$subcategory = $article->subcategory_id ? HC_Core::get_category($article->subcategory_id) : null;
$related = HC_Core::get_related_articles($article->id, $category ? (int) $category->id : (int) $article->category_id, $article->subcategory_id, 5);
$faqs = HC_Core::get_faqs('article', $article->id);

// Sidebar: other categories
$all_categories = HC_Core::get_categories(0, 'published');

$reading = $article->reading_time ?: 1;
$votes_total = $article->helpful_yes + $article->helpful_no;
$helpful_pct = $votes_total > 0 ? round(($article->helpful_yes / $votes_total) * 100) : 0;

$show_toc     = HC_Core::get_setting('hc_show_toc', '1') === '1';
$show_helpful = HC_Core::get_setting('hc_show_helpful', '1') === '1';
$show_faqs    = HC_Core::get_setting('hc_show_faqs', '1') === '1';
$show_views   = HC_Core::get_setting('hc_show_view_count', '1') === '1';
$show_reading = HC_Core::get_setting('hc_show_reading_time', '1') === '1';
$show_breadcrumbs = HC_Core::get_setting('hc_show_breadcrumbs', '1') === '1';
$show_related = HC_Core::get_setting('hc_show_related', '1') === '1';
$show_toc = HC_Core::get_setting('hc_show_toc', '1') === '1';
$show_share = HC_Core::get_setting('hc_show_share', '1') === '1';
$show_print = HC_Core::get_setting('hc_show_print', '1') === '1';
$faq_position = HC_Core::get_setting('hc_faq_position', 'bottom');

$has_voted = !empty($_COOKIE['hc_voted_' . $article->id]);

// Use WP-aware time comparison to avoid timezone skew
$updated_ts = strtotime($article->updated_at . ' UTC'); // value is stored in UTC
$now_ts     = current_time('timestamp');                // WP-local now
$age_days   = ($now_ts - $updated_ts) / 86400;
$updated_display = $age_days < 7
    ? human_time_diff($updated_ts, $now_ts) . ' ago'
    : date_i18n('M j, Y', $updated_ts);

preg_match_all('/<h[23][^>]*>(.*?)<\/h[23]>/i', $article->content, $matches);
$heading_count = count($matches[0]);
?>

<!-- BREADCRUMB -->
<?php if ($show_breadcrumbs): ?><nav class="hc-breadcrumb" aria-label="Breadcrumb" itemscope itemtype="https://schema.org/BreadcrumbList">
    <ol>
<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="<?php echo esc_url(home_url('/helpcenter/')); ?>" aria-label="Help Center Home"><span itemprop="name"><i class="fas fa-home" aria-hidden="true"></i> Help Center</span></a><meta itemprop="position" content="1"></li>
        <?php $crumb_position = 2; ?>
        <?php if ($category): ?>
        <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="<?php echo esc_url(home_url('/helpcenter/category/' . $category->slug . '/')); ?>"><span itemprop="name"><?php echo esc_html($category->name); ?></span></a><meta itemprop="position" content="<?php echo $crumb_position++; ?>"></li>
        <?php endif; ?>
        <?php if ($subcategory && $category && (int)$subcategory->parent_id === (int)$category->id && $subcategory->status === 'published'): ?>
        <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="<?php echo esc_url(home_url('/helpcenter/category/' . $subcategory->slug . '/')); ?>"><span itemprop="name"><?php echo esc_html($subcategory->name); ?></span></a><meta itemprop="position" content="<?php echo $crumb_position++; ?>"></li>
        <?php endif; ?>
        <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><span itemprop="name"><?php echo esc_html(wp_trim_words($article->title, 6)); ?></span><meta itemprop="item" content="<?php echo esc_url(home_url('/helpcenter/article/' . $article->slug . '/')); ?>"><meta itemprop="position" content="<?php echo $crumb_position; ?>"></li>
    </ol>
</nav><?php endif; ?>

<!-- 2-COLUMN LAYOUT -->
<div class="hc-article-layout">

    <!-- MAIN COLUMN -->
    <div class="hc-article-main">

        <article class="hc-article">

            <!-- HEADER -->
            <header class="hc-article-header">
                <?php if ($category): ?>
                <a href="<?php echo esc_url(home_url('/helpcenter/category/' . $category->slug . '/')); ?>" class="hc-article-badge">
                    <i class="fas <?php echo esc_attr($category->icon_value ?: 'fa-folder'); ?>"></i>
                    <span><?php echo esc_html($category->name); ?></span>
                    <?php if ($subcategory): ?>
                    <span class="hc-article-badge-sep">/</span>
                    <span><?php echo esc_html($subcategory->name); ?></span>
                    <?php endif; ?>
                </a>
                <?php endif; ?>

                <h1 class="hc-article-title"><?php echo esc_html($article->title); ?></h1>

                <div class="hc-article-meta">
                    <span><i class="fas fa-headset"></i> Support Team</span>
                    <time datetime="<?php echo esc_attr(date('c', $updated_ts)); ?>">
                        <i class="fas fa-calendar-day"></i> Updated <?php echo esc_html($updated_display); ?>
                    </time>
                    <?php if ($show_reading): ?>
                    <span><i class="fas fa-clock"></i> <?php echo (int) $reading; ?> min read</span>
                    <?php endif; ?>
                    <?php if ($show_views): ?>
                    <span><i class="fas fa-eye"></i> <?php echo number_format((int) $article->view_count); ?> views</span>
                    <?php endif; ?>
                </div>

                <?php if ($article->excerpt): ?>
                <div class="hc-article-excerpt">
                    <i class="fas fa-quote-left hc-article-excerpt-icon"></i>
                    <?php echo esc_html($article->excerpt); ?>
                </div>
                <?php endif; ?>
            </header>

            <!-- TOC (collapsed by default) -->
            <?php if ($show_toc && $heading_count >= 2): ?>
            <div class="hc-toc" id="hcToc">
                <button type="button" class="hc-toc-toggle" id="hcTocToggle" aria-expanded="false">
                    <span><i class="fas fa-list-ul"></i> On this page</span>
                    <i class="fas fa-chevron-down hc-toc-arrow"></i>
                </button>
                <div class="hc-toc-body" id="hcTocBody">
                    <ul class="hc-toc-list" id="hcTocList"></ul>
                </div>
            </div>
            <?php endif; ?>

            <!-- CONTENT -->
            <div class="hc-article-tools" aria-label="Article tools">
                <?php if ($show_share): ?>
                <div class="hc-article-share-tools"><span>Share:</span><button type="button" data-hc-share="facebook" aria-label="Share on Facebook"><i class="fab fa-facebook-f"></i></button><button type="button" data-hc-share="twitter" aria-label="Share on X"><i class="fab fa-x-twitter"></i></button><button type="button" data-hc-share="linkedin" aria-label="Share on LinkedIn"><i class="fab fa-linkedin-in"></i></button><button type="button" data-hc-copy aria-label="Copy article link"><i class="fas fa-link"></i></button></div>
                <?php endif; ?>
                <?php if ($show_print): ?><button type="button" class="hc-article-print" data-hc-print><i class="fas fa-print"></i> Print article</button><?php endif; ?>
            </div>
            <div class="hc-article-content" id="hcArticleContent">
                <?php echo wp_kses_post($article->content); ?>
            </div>

            <!-- HELPFUL (bottom) -->
            <?php if ($show_helpful): ?>
            <div class="hc-helpful" id="hcHelpful">
                <div class="hc-helpful-head"><strong>Was this article helpful?</strong></div>
                <div class="hc-helpful-buttons" id="hcHelpfulButtons">
                    <button type="button" class="hc-helpful-btn hc-helpful-yes" data-hc-vote="yes" data-article="<?php echo (int) $article->id; ?>" <?php echo $has_voted ? 'disabled' : ''; ?>>
                        <i class="fas fa-thumbs-up"></i> Yes
                    </button>
                    <button type="button" class="hc-helpful-btn hc-helpful-no" data-hc-vote="no" data-article="<?php echo (int) $article->id; ?>" <?php echo $has_voted ? 'disabled' : ''; ?>>
                        <i class="fas fa-thumbs-down"></i> No
                    </button>
                </div>
                <div class="hc-helpful-stats" id="hcHelpfulStats">
                    <?php if ($votes_total > 0): ?>
                    <span><strong><?php echo (int) $article->helpful_yes; ?></strong> of <strong><?php echo (int) $votes_total; ?></strong> found this helpful</span>
                    <div class="hc-helpful-bar"><div class="hc-helpful-bar-fill" style="width:<?php echo $helpful_pct; ?>%"></div></div>
                    <span class="hc-helpful-pct"><?php echo $helpful_pct; ?>%</span>
                    <?php else: ?>
                    <span>Be the first to rate this article</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- FAQ (bottom) -->
            <?php if ($show_faqs && !empty($faqs) && $faq_position !== 'top'): ?>
            <section class="hc-section hc-article-faq">
                <div class="hc-section-head">
                    <h2><i class="fas fa-circle-question"></i> Frequently Asked Questions</h2>
                </div>
                <div class="hc-faq-list">
                    <?php foreach ($faqs as $faq): ?>
                    <div class="hc-faq-item">
                        <button type="button" class="hc-faq-q">
                            <span><?php echo esc_html($faq->question); ?></span>
                            <i class="fas fa-plus hc-faq-icon"></i>
                        </button>
                        <div class="hc-faq-a">
                            <div class="hc-faq-a-inner"><?php echo wp_kses_post($faq->answer); ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

        </article>

    </div>

    <!-- SIDEBAR (desktop only) -->
    <aside class="hc-article-sidebar">

        <?php if ($show_related && !empty($related)): ?>
        <div class="hc-sidebar-section">
            <h3 class="hc-sidebar-section-title">
                <i class="fas fa-link"></i> Related Articles
            </h3>
            <div class="hc-sidebar-cards">
                <?php foreach ($related as $r): ?>
                <a href="<?php echo esc_url(home_url('/helpcenter/article/' . $r->slug . '/')); ?>" class="hc-sidebar-card">
                    <div class="hc-sidebar-card-icon">
                        <i class="fas fa-file-lines"></i>
                    </div>
                    <div class="hc-sidebar-card-body">
                        <div class="hc-sidebar-card-title"><?php echo esc_html($r->title); ?></div>
                        <div class="hc-sidebar-card-meta">
                            <?php if ($r->reading_time): ?>
                            <span><i class="fas fa-clock"></i> <?php echo (int) $r->reading_time; ?> min</span>
                            <?php endif; ?>
                            <?php if (isset($r->view_count)): ?>
                            <span><i class="fas fa-eye"></i> <?php echo number_format((int) $r->view_count); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right hc-sidebar-card-arrow"></i>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php
        // Get categories excluding current one
        $other_cats = array();
        foreach ($all_categories as $c) {
            if ($c->id == $article->category_id) continue;
            $other_cats[] = $c;
        }
        ?>

        <?php if (!empty($other_cats)): ?>
        <div class="hc-sidebar-section">
            <h3 class="hc-sidebar-section-title">
                <i class="fas fa-folder-tree"></i> Browse Categories
            </h3>
            <div class="hc-sidebar-cards">
                <?php foreach ($other_cats as $c): ?>
                <a href="<?php echo esc_url(home_url('/helpcenter/category/' . $c->slug . '/')); ?>" class="hc-sidebar-card hc-sidebar-card-cat">
                    <div class="hc-sidebar-card-icon hc-sidebar-cat-icon">
                        <i class="fas <?php echo esc_attr($c->icon_value ?: 'fa-folder'); ?>"></i>
                    </div>
                    <div class="hc-sidebar-card-body">
                        <div class="hc-sidebar-card-title"><?php echo esc_html($c->name); ?></div>
                        <div class="hc-sidebar-card-meta">
                            <span><i class="fas fa-file-lines"></i> <?php echo (int) $c->article_count; ?> article<?php echo $c->article_count == 1 ? '' : 's'; ?></span>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right hc-sidebar-card-arrow"></i>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="hc-sidebar-section hc-sidebar-cta">
            <h3 class="hc-sidebar-cta-title">Still need help?</h3>
            <p>Our support team is ready to assist you.</p>
            <a href="<?php echo esc_url(home_url('/helpcenter/contact/')); ?>" class="hc-sidebar-cta-btn">
                Contact Support <i class="fas fa-arrow-right"></i>
            </a>
        </div>

    </aside>

</div>

<style>.hc-article-tools{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin:18px 0}.hc-article-share-tools{display:flex;align-items:center;gap:8px}.hc-article-share-tools span{font-size:13px;color:#64748b;font-weight:650}.hc-article-share-tools button,.hc-article-print{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid #dbe3ed;border-radius:9px;background:#fff;color:#475569;padding:9px 12px;cursor:pointer}.hc-article-share-tools button:hover,.hc-article-print:hover{color:var(--hc-primary);border-color:var(--hc-primary)}@media print{.hc-article-tools,.hc-header,.hc-article-sidebar{display:none!important}}</style>
