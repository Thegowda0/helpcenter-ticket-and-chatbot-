<?php
if (!defined('ABSPATH')) exit;
$categories = HC_Core::get_categories(0, 'published');
?>
<section class="hc-section hc-all-categories-page">
    <div class="hc-section-head">
        <h1>All Categories</h1>
        <p>Browse all available Help Center topics.</p>
    </div>
    <?php if (!empty($categories)): ?>
    <div class="hc-cat-grid">
        <?php foreach ($categories as $cat):
            $icon = $cat->icon_value ?: 'fa-folder';
            $subs = HC_Core::get_subcategories($cat->id);
        ?>
        <a href="<?php echo esc_url(home_url('/helpcenter/category/' . $cat->slug . '/')); ?>" class="hc-cat-card">
            <div class="hc-cat-card-icon"><i class="<?php echo esc_attr(strpos($icon, 'fa-') === 0 && strpos($icon, ' ') === false ? 'fas ' . $icon : $icon); ?>"></i></div>
            <div class="hc-cat-card-body">
                <h3><?php echo esc_html($cat->name); ?></h3>
                <?php if (!empty($cat->description)): ?><p><?php echo esc_html(wp_trim_words($cat->description, 18)); ?></p><?php endif; ?>
                <div class="hc-cat-card-meta">
                    <span><i class="fas fa-file-lines"></i> <?php echo (int) $cat->article_count; ?> articles</span>
                    <?php if (!empty($subs)): ?><span><i class="fas fa-folder-tree"></i> <?php echo count($subs); ?> subcategories</span><?php endif; ?>
                </div>
            </div>
            <i class="fas fa-arrow-right hc-cat-card-arrow" aria-hidden="true"></i>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <p>No categories are available yet.</p>
    <?php endif; ?>
</section>
