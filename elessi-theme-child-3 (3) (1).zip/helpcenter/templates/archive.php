<?php
if (!defined('ABSPATH')) exit;
$type = get_query_var('hc_page') === 'popular' ? 'popular' : 'latest';
$title = $type === 'popular' ? 'Popular Articles' : 'Latest Updates';
$page = max(1, absint($_GET['paged'] ?? 1));
$per_page = max(1, min(100, (int) HC_Core::get_setting($type === 'popular' ? 'hc_popular_archive_limit' : 'hc_latest_archive_limit', $type === 'popular' ? 20 : 10)));
global $wpdb;
$live_where = HC_Lifecycle::sql_article_live('a');
$total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles a WHERE {$live_where}");
$items = $type === 'popular' ? HC_Core::get_popular_articles($per_page, ($page - 1) * $per_page) : HC_Core::get_latest_articles($per_page, ($page - 1) * $per_page);
?>
<section class="hc-section hc-archive-page">
  <div class="hc-section-head"><h1 class="hc-archive-title"><i class="fas <?php echo $type === 'popular' ? 'fa-fire' : 'fa-clock'; ?>" aria-hidden="true"></i><?php echo esc_html($title); ?></h1><p><?php echo $type === 'popular' ? 'Articles selected as popular and frequently read.' : 'Recently updated help articles.'; ?></p></div>
  <?php if ($items): ?><div class="hc-popular-list">
    <?php foreach ($items as $i => $art): ?><a href="<?php echo esc_url(home_url('/helpcenter/article/' . $art->slug . '/')); ?>" class="hc-popular-item"><span class="hc-popular-num"><?php echo esc_html(str_pad((string)(($page - 1) * $per_page + $i + 1), 2, '0', STR_PAD_LEFT)); ?></span><div class="hc-popular-body"><h4><?php echo esc_html($art->title); ?></h4><?php if (!empty($art->excerpt)): ?><p><?php echo esc_html(wp_trim_words($art->excerpt, 20)); ?></p><?php endif; ?></div><i class="fas fa-chevron-right hc-popular-arrow"></i></a><?php endforeach; ?>
  </div><?php else: ?><p>No articles found.</p><?php endif; ?>
  <?php if ($total > $per_page): ?><nav class="hc-pagination" aria-label="Article pagination"><?php if ($page > 1): ?><a href="<?php echo esc_url(add_query_arg('paged', $page - 1)); ?>">← Previous</a><?php endif; ?> <span>Page <?php echo (int)$page; ?> of <?php echo (int)ceil($total / $per_page); ?></span> <?php if ($page < ceil($total / $per_page)): ?><a href="<?php echo esc_url(add_query_arg('paged', $page + 1)); ?>">Next →</a><?php endif; ?></nav><?php endif; ?>
</section>

<style>.hc-archive-title{display:flex;align-items:center;gap:12px}.hc-archive-title i{display:inline-flex;align-items:center;justify-content:center;line-height:1;flex:0 0 auto}.hc-archive-page .hc-pagination{display:flex;align-items:center;justify-content:center;gap:14px;flex-wrap:wrap;margin:28px auto}.hc-archive-page .hc-pagination a{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:10px 16px;border:1px solid #dbe3ed;border-radius:10px;background:#fff;text-decoration:none;font-weight:650}</style>
