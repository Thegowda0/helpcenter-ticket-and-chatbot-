<?php
if (!defined('ABSPATH')) exit;

$popular = HC_Core::get_popular_articles(4);
?>

<div class="hc-404">
    <div class="hc-404-icon"><i class="fas fa-compass"></i></div>
    <h1>Page not found</h1>
    <p>The page you're looking for doesn't exist or has been moved.</p>

    <div class="hc-404-actions">
        <a href="<?php echo esc_url(home_url('/helpcenter/')); ?>" class="hc-btn hc-btn-primary">
            <i class="fas fa-home"></i> Help Center
        </a>
        <a href="<?php echo esc_url(home_url('/helpcenter/contact/')); ?>" class="hc-btn hc-btn-outline">
            <i class="fas fa-headset"></i> Contact Support
        </a>
    </div>

    <form action="<?php echo esc_url(home_url('/helpcenter/search/')); ?>" method="get" class="hc-404-search">
        <div class="hc-search-page-wrap">
            <i class="fas fa-search"></i>
            <input type="text" name="q" placeholder="Or search for what you need..." autocomplete="off">
            <button type="submit">Search</button>
        </div>
    </form>

    <?php if (!empty($popular)): ?>
    <div class="hc-404-popular">
        <h3>Popular articles</h3>
        <div class="hc-404-popular-grid">
            <?php foreach ($popular as $p): ?>
            <a href="<?php echo esc_url(home_url('/helpcenter/article/' . $p->slug . '/')); ?>" class="hc-404-popular-card">
                <i class="fas fa-file-lines"></i>
                <span><?php echo esc_html($p->title); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
