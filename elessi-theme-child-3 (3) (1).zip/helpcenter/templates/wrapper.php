<?php
/**
 * Help Center - Frontend HTML Shell (fully isolated)
 */

if (!defined('ABSPATH')) exit;

$hc_page = get_query_var('hc_page') ?: '404';
$site_name = HC_Core::get_setting('hc_site_title', 'Help Center');
$tagline   = HC_Core::get_setting('hc_tagline', 'How can we help you today?');
$show_search = HC_Core::get_setting('hc_show_search', '1') === '1';

$primary = HC_Core::get_setting('hc_primary_color', '#6366F1');
$accent  = HC_Core::get_setting('hc_accent_color', '#F59E0B');
$bg      = HC_Core::get_setting('hc_bg_color', '#F8FAFC');
$header  = HC_Core::get_setting('hc_header_bg', '#FFFFFF');
$htext   = HC_Core::get_setting('hc_header_text', '#0F172A');

$nav_categories = HC_Core::get_categories(0, 'published');

// Cache-busted asset versions
$css_v = file_exists(HC_PATH . 'assets/css/frontend.css') ? filemtime(HC_PATH . 'assets/css/frontend.css') : HC_VERSION;
$js_v  = file_exists(HC_PATH . 'assets/js/frontend.js')  ? filemtime(HC_PATH . 'assets/js/frontend.js')  : HC_VERSION;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if (class_exists('HC_SEO')) HC_SEO::output_meta(); else echo '<title>' . esc_html($site_name) . '</title>'; ?>

<!-- Fonts / Icons (CDN only — no theme CSS) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.3.1/css/all.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">

<!-- Help Center CSS -->
<link rel="stylesheet" href="<?php echo esc_url(HC_ASSETS . 'css/frontend.css?v=' . $css_v); ?>">
<link rel="stylesheet" href="<?php echo esc_url(HC_ASSETS . 'css/frontend-cards.css?v=' . $css_v); ?>">
<link rel="stylesheet" href="<?php echo esc_url(HC_ASSETS . 'css/frontend-article.css?v=' . $css_v); ?>">

<!-- Dynamic colors -->
<style id="hc-dynamic-css">
:root {
    --hc-primary: <?php echo esc_html($primary); ?>;
    --hc-primary-hover: <?php echo esc_html(HC_Assets::shade($primary, -20)); ?>;
    --hc-primary-light: <?php echo esc_html(HC_Assets::shade($primary, 180)); ?>;
    --hc-accent: <?php echo esc_html($accent); ?>;
    --hc-bg: <?php echo esc_html($bg); ?>;
    --hc-header-bg: <?php echo esc_html($header); ?>;
    --hc-header-text: <?php echo esc_html($htext); ?>;
}
</style>

<?php if (class_exists('HC_Schema')) HC_Schema::output(); ?>
<!-- HC_INLINE_HEADER_V1: critical header CSS inline to bypass cache -->
<style id="hc-header-inline">
.hc-header-inner {
    max-width: 1600px !important;
    margin: 0 auto !important;
    padding: 0 48px !important;
    height: 72px !important;
    display: grid !important;
    grid-template-columns: auto auto !important;
    justify-content: space-between !important;
    align-items: center !important;
    gap: 40px !important;
}
.hc-logo {
    display: flex !important;
    align-items: center !important;
    gap: 11px !important;
    font-size: 17px !important;
    font-weight: 800 !important;
    color: #0F172A !important;
    letter-spacing: -0.02em !important;
    flex-shrink: 0 !important;
    text-decoration: none !important;
}
.hc-logo i {
    font-size: 24px !important;
    color: #FFFFFF !important;
    background: linear-gradient(135deg, #4F46E5 0%, #6366F1 100%) !important;
    padding: 8px !important;
    border-radius: 11px !important;
    box-shadow: 0 4px 12px rgba(79,70,229,0.28) !important;
}
.hc-header-search {
    max-width: none !important;
    width: 100% !important;
    margin: 0 !important;
    position: relative !important;
}
.hc-search-input-wrap input {
    width: 100% !important;
    padding: 12px 20px 12px 44px !important;
    font-size: 14.5px !important;
    background: #F4F6F8 !important;
    border: 1px solid #E2E8F0 !important;
    border-radius: 12px !important;
}
.hc-search-input-wrap i {
    left: 16px !important;
    color: #94A3B8 !important;
}
.hc-header-nav {
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
    flex-shrink: 0 !important;
}
.hc-nav-link {
    display: inline-flex !important;
    align-items: center !important;
    gap: 8px !important;
    padding: 9px 16px !important;
    border-radius: 10px !important;
    font-size: 14px !important;
    font-weight: 600 !important;
    color: #475569 !important;
    transition: all 180ms ease !important;
    text-decoration: none !important;
}
.hc-nav-link:hover {
    background: #F4F6F8 !important;
    color: #4F46E5 !important;
}
.hc-nav-link.active {
    background: #EEF2FF !important;
    color: #4F46E5 !important;
}
.hc-container {
    max-width: 1600px !important;
    margin: 0 auto !important;
    padding: 0 48px !important;
}
@media (max-width: 768px) {
    .hc-header-inner {
        padding: 0 16px !important;
        height: 60px !important;
        display: flex !important;
        gap: 10px !important;
    }
    .hc-logo span { display: none !important; }
    .hc-nav-link { font-size: 0 !important; padding: 8px 11px !important; gap: 0 !important; }
    .hc-nav-link i { font-size: 15px !important; }
    .hc-container { padding: 0 16px !important; max-width: 100% !important; }
}

/* Search stacking: the backdrop never covers the active search control or results. */
.hc-header{position:sticky!important;top:0!important;z-index:1300!important}.hc-header-inner{grid-template-columns:minmax(150px,1fr) minmax(180px,min(38vw,420px)) auto!important;gap:24px!important}.hc-header-nav{justify-self:end!important;margin-left:auto!important;justify-content:flex-end!important;width:max-content!important}.hc-header-nav .hc-nav-link:last-child{margin-left:0!important}
.hc-header-search{position:relative!important;z-index:1202!important}.hc-search-input-wrap{position:relative!important}.hc-search-dropdown{position:absolute!important;z-index:1204!important;top:calc(100% + 10px)!important;left:0!important;right:0!important;max-height:min(70vh,520px)!important;overflow:auto!important;background:rgba(255,255,255,.97)!important;backdrop-filter:blur(18px)!important;-webkit-backdrop-filter:blur(18px)!important;border:1px solid rgba(226,232,240,.9)!important;border-radius:16px!important;box-shadow:0 24px 60px rgba(15,23,42,.22)!important}
.hc-hero-search{position:relative!important;z-index:1202!important}.hc-hero-search .hc-search-dropdown{z-index:1204!important}
body.hc-search-active:before{content:'';position:fixed;inset:0;background:rgba(15,23,42,.20);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);z-index:1000!important;pointer-events:auto!important}
body.hc-search-active{overflow:hidden!important;overscroll-behavior:none!important}body.hc-search-active .hc-header{z-index:900!important;filter:blur(6px);pointer-events:none!important}body.hc-search-active .hc-hero{position:relative!important;z-index:1100!important}
body.hc-search-active .hc-hero-search,body.hc-search-active .hc-hero-search-wrap,body.hc-search-active .hc-search-input-wrap{position:relative;z-index:1205!important}body.hc-search-active .hc-search-dropdown-fixed{position:fixed!important;z-index:1206!important;display:block!important;overflow-y:auto!important;background:#fff!important}
body.hc-home-page .hc-header{display:block!important}body.hc-home-page .hc-header-inner{grid-template-columns:minmax(0,1fr) auto!important}body.hc-home-page .hc-header-nav{grid-column:2!important;justify-self:end!important;margin-left:auto!important}.admin-bar .hc-header{top:32px!important}@media(max-width:782px){.admin-bar .hc-header{top:46px!important}}
@media(max-width:850px){.hc-header-inner{grid-template-columns:1fr auto!important;gap:12px!important}.hc-header-search{grid-column:1/-1;grid-row:2;width:100%!important}.hc-header-nav{grid-column:2;grid-row:1}.hc-logo{grid-column:1;grid-row:1}}
</style>

</head>
<body class="hc-body <?php echo $hc_page === 'home' ? 'hc-home-page' : ''; ?>">

<header class="hc-header">
    <!-- HC_HEADER_CLEAN -->
    <div class="hc-header-inner">
        <a href="<?php echo esc_url(home_url('/helpcenter/')); ?>" class="hc-logo" aria-label="<?php echo esc_attr($site_name); ?> — Help Center Home">
            <i class="fas fa-circle-question" aria-hidden="true"></i>
            <span><?php echo esc_html($site_name); ?></span>
        </a>

        <?php if ($hc_page !== 'home' && $show_search): ?>
        <form action="<?php echo esc_url(home_url('/helpcenter/search/')); ?>" method="get" class="hc-header-search" role="search">
            <div class="hc-search-input-wrap"><i class="fas fa-search" aria-hidden="true"></i><input type="search" name="q" id="hcSearchInput" placeholder="Search help articles…" autocomplete="off" aria-label="Search help articles"></div>
            <div class="hc-search-dropdown" id="hcSearchDropdown" aria-live="polite"></div>
        </form>
        <?php endif; ?>

        <nav class="hc-header-nav">
            <a href="<?php echo esc_url(home_url('/helpcenter/')); ?>" class="hc-nav-link <?php echo $hc_page === 'home' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="<?php echo esc_url(home_url('/helpcenter/contact/')); ?>" class="hc-nav-link <?php echo $hc_page === 'contact' ? 'active' : ''; ?>">
                <i class="fas fa-headset"></i> Contact
            </a>
        </nav>
    </div>

    
</header>

<!-- HC_NAV_OUTSIDE: category nav moved outside sticky header -->
<!-- HC_NAV_REMOVED: category nav removed -->

<main class="hc-main">
    <div class="hc-container">
        <?php if (class_exists('HC_SEO')) HC_SEO::render_breadcrumbs(); ?>
        <?php
        switch ($hc_page) {
            case 'home':     include HC_TEMPLATES . 'home.php'; break;
            case 'categories-all': include HC_TEMPLATES . 'categories-all.php'; break;
            case 'category': include HC_TEMPLATES . 'category.php'; break;
            case 'article':  include HC_TEMPLATES . 'article.php'; break;
            case 'search':   include HC_TEMPLATES . 'search.php'; break;
            case 'latest':   include HC_TEMPLATES . 'archive.php'; break;
            case 'popular':  include HC_TEMPLATES . 'archive.php'; break;
            case 'contact':  include HC_TEMPLATES . 'contact.php'; break;
            default:         include HC_TEMPLATES . '404.php'; break;
        }
        ?>
    </div>
</main>

<footer class="hc-footer">
    <div class="hc-footer-inner">
        <p>&copy; <?php echo date('Y'); ?> <?php echo esc_html(get_bloginfo('name')); ?> &middot; <?php echo esc_html($site_name); ?></p>
        <div class="hc-footer-links">
            <a href="<?php echo esc_url(home_url('/helpcenter/')); ?>">Home</a>
            <a href="<?php echo esc_url(home_url('/helpcenter/contact/')); ?>">Contact</a>
        </div>
    </div>
</footer>

<button type="button" class="hc-back-top" id="hcBackTop" aria-label="Back to top">
    <i class="fas fa-arrow-up"></i>
</button>

<script src="<?php echo esc_url(includes_url('js/jquery/jquery.min.js')); ?>"></script>
<script>
var hcData = {
    ajaxUrl: <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>,
    nonce:   <?php echo wp_json_encode(wp_create_nonce('hc_nonce')); ?>,
    homeUrl: <?php echo wp_json_encode(home_url('/helpcenter/')); ?>,
    liveSearch: <?php echo HC_Core::get_setting('hc_show_live_search', '1') === '1' ? 'true' : 'false'; ?>,
    aiEnabled: <?php echo HC_Core::get_setting('hc_ai_enabled', '0') === '1' ? 'true' : 'false'; ?>
};
</script>
<script src="<?php echo esc_url(HC_ASSETS . 'js/frontend.js?v=' . $js_v); ?>"></script>

<?php
// Render the floating assistant inside the isolated Help Center document.
// Do not fire wp_footer: theme callbacks can inject the main site's footer widgets/content here.
if (class_exists('HC_AI')) { HC_AI::widget(); }
// Still print scripts explicitly enqueued for this request without firing theme footer callbacks.
if (function_exists('wp_print_footer_scripts')) { wp_print_footer_scripts(); }
?>

</body>
</html>
<?php
exit;
