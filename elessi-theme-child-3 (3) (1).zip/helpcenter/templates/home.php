<?php
if (!defined('ABSPATH')) exit;

$site_name = HC_Core::get_setting('hc_site_title', 'Help Center');
$tagline   = HC_Core::get_setting('hc_tagline', 'How can we help you today?');
$show_search = HC_Core::get_setting('hc_show_search', '1') === '1';
$hero_placeholders_raw = (string) HC_Core::get_setting('hc_hero_search_placeholders', "Search for answers...\nSearch orders, refunds, and delivery...\nType a keyword to find help...");
$hero_placeholders = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $hero_placeholders_raw))));
if (!$hero_placeholders) $hero_placeholders = array('Search for answers...');

// Top-level categories
$categories = HC_Core::get_categories(0, 'published');
$category_limit = max(1, min(100, (int) HC_Core::get_setting('hc_home_category_limit', 6)));
$has_more_categories = count($categories) > $category_limit;
$categories = array_slice($categories, 0, $category_limit);

// Popular articles
$popular = HC_Core::get_popular_articles();
$latest = HC_Core::get_latest_articles();

// FAQs (home context)
$faqs = HC_Core::get_faqs('home');
$show_faqs = HC_Core::get_setting('hc_show_faqs', '1') === '1';
?>

<!-- HERO -->
<section class="hc-hero">
    <div class="hc-hero-inner">
        <h1 class="hc-hero-title"><?php echo esc_html($site_name); ?></h1>
        <p class="hc-hero-subtitle"><?php echo esc_html($tagline); ?></p>

        <?php if ($show_search): ?>
        <form action="<?php echo esc_url(home_url('/helpcenter/search/')); ?>" method="get" class="hc-hero-search">
            <div class="hc-hero-search-wrap">
                <i class="fas fa-search"></i>
                <input type="text" name="q" id="hcHeroSearchInput" placeholder="<?php echo esc_attr($hero_placeholders[0]); ?>" data-hc-placeholders="<?php echo esc_attr(wp_json_encode(array_slice($hero_placeholders, 0, 8))); ?>" autocomplete="off">
                <button type="submit">Search</button>
            </div>
            <div class="hc-search-dropdown" id="hcHeroSearchDropdown"></div>
        </form>
        <?php endif; ?>
    </div>
</section>

<!-- CATEGORIES -->
<?php if (!empty($categories)): ?>
<section class="hc-section">
    <div class="hc-section-head">
        <h2>Browse by Category</h2>
        <?php if ($has_more_categories): ?>
        <a class="hc-section-view-all hc-category-view-all" href="<?php echo esc_url(home_url('/Categories/')); ?>">View all <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
        <?php endif; ?>
        <p>Pick a topic to find the answer you need</p>
    </div>

    <div class="hc-cat-grid">
        <?php foreach ($categories as $cat):
            $icon = $cat->icon_value ?: 'fa-folder';
            $subs = HC_Core::get_subcategories($cat->id);
        ?>
        <a href="<?php echo esc_url(home_url('/helpcenter/category/' . $cat->slug . '/')); ?>" class="hc-cat-card">
            <div class="hc-cat-card-icon">
                <i class="<?php echo esc_attr(strpos($icon, 'fa-') === 0 && strpos($icon, ' ' ) === false ? 'fas ' . $icon : $icon); ?>"></i>
            </div>
            <div class="hc-cat-card-body">
                <h3><?php echo esc_html($cat->name); ?></h3>
                <?php if ($cat->description): ?>
                <p><?php echo esc_html(wp_trim_words($cat->description, 12)); ?></p>
                <?php endif; ?>
                <div class="hc-cat-card-meta">
                    <span><i class="fas fa-file-lines"></i> <?php echo (int) $cat->article_count; ?> articles</span>
                    <?php if (!empty($subs)): ?>
                    <span><i class="fas fa-folder-tree"></i> <?php echo count($subs); ?> subcategories</span>
                    <?php endif; ?>
                </div>
            </div>
            <i class="fas fa-arrow-right hc-cat-card-arrow"></i>
        </a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- POPULAR -->
<?php if (!empty($popular)): ?>
<section class="hc-section">
    <div class="hc-section-head">
        <h2><i class="fas fa-fire" style="color:#F59E0B;"></i> Popular Articles</h2>
        <p>Hand-picked guides and frequently read answers</p>
        <a class="hc-section-view-all" href="<?php echo esc_url(home_url('/helpcenter/popular/')); ?>">View all <i class="fas fa-arrow-right"></i></a>
    </div>

    <div class="hc-popular-list">
        <?php foreach ($popular as $i => $art): ?>
        <a href="<?php echo esc_url(home_url('/helpcenter/article/' . $art->slug . '/')); ?>" class="hc-popular-item">
            <span class="hc-popular-num"><?php echo str_pad($i + 1, 2, '0', STR_PAD_LEFT); ?></span>
            <div class="hc-popular-body">
                <h4><?php echo esc_html($art->title); ?></h4>
                <?php if ($art->excerpt): ?>
                <p><?php echo esc_html(wp_trim_words($art->excerpt, 15)); ?></p>
                <?php endif; ?>
                <div class="hc-popular-meta">
                    <span><i class="fas fa-eye"></i> <?php echo (int) $art->view_count; ?> views</span>
                    <span><i class="fas fa-clock"></i> <?php echo (int) $art->reading_time ?: 1; ?> min</span>
                </div>
            </div>
            <i class="fas fa-chevron-right hc-popular-arrow"></i>
        </a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- LATEST UPDATES -->
<?php if (!empty($latest)): ?>
<section class="hc-section hc-latest-section">
    <div class="hc-section-head">
        <h2><i class="fas fa-clock" style="color:var(--hc-primary);"></i> Latest Updates</h2>
        <p>Recently updated help articles</p>
        <a class="hc-section-view-all" href="<?php echo esc_url(home_url('/helpcenter/latest/')); ?>">View all <i class="fas fa-arrow-right"></i></a>
    </div>
    <div class="hc-popular-list">
        <?php foreach ($latest as $i => $art): ?>
        <a href="<?php echo esc_url(home_url('/helpcenter/article/' . $art->slug . '/')); ?>" class="hc-popular-item">
            <span class="hc-popular-num"><i class="fas fa-file-lines"></i></span>
            <div class="hc-popular-body"><h4><?php echo esc_html($art->title); ?></h4>
            <?php if ($art->excerpt): ?><p><?php echo esc_html(wp_trim_words($art->excerpt, 15)); ?></p><?php endif; ?></div>
            <i class="fas fa-chevron-right hc-popular-arrow"></i>
        </a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- FAQS -->
<?php if ($show_faqs && !empty($faqs)): ?>
<section class="hc-section">
    <div class="hc-section-head">
        <h2><i class="fas fa-circle-question" style="color:var(--hc-primary);"></i> Frequently Asked Questions</h2>
    </div>

    <div class="hc-faq-list">
        <?php foreach ($faqs as $faq): ?>
        <div class="hc-faq-item">
            <button type="button" class="hc-faq-q">
                <span><?php echo esc_html($faq->question); ?></span>
                <i class="fas fa-plus hc-faq-icon"></i>
            </button>
            <div class="hc-faq-a">
                <div class="hc-faq-a-inner"><?php echo wp_kses_post($faq->answer); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- CONTACT CTA -->
<section class="hc-cta-section">
    <div class="hc-cta">
        <div class="hc-cta-icon"><i class="fas fa-headset"></i></div>
        <div class="hc-cta-body">
            <h3>Still need help?</h3>
            <p>Can't find what you're looking for? Our team is here to help.</p>
        </div>
        <a href="<?php echo esc_url(home_url('/helpcenter/contact/')); ?>" class="hc-btn hc-btn-primary">
            Contact Support <i class="fas fa-arrow-right"></i>
        </a>
    </div>
</section>
