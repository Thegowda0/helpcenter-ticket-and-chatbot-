<?php
if (!defined('ABSPATH')) exit;

$q = isset($_GET['q']) ? HC_Core::normalize_search_query(wp_unslash($_GET['q'])) : '';
$results = array();
$total = 0;

if (mb_strlen($q) >= 2) {
    $per_page = max(5, min(100, (int) HC_Core::get_setting('hc_articles_per_page', 12)));
    $page = max(1, absint($_GET['paged'] ?? 1));
    $results = HC_Core::search_articles($q, $per_page, ($page - 1) * $per_page);
    $total = HC_Core::count_search_articles($q);
    if ($page === 1) HC_Core::log_search($q, $total);
}

// Get categories for the "browse categories" strip when no results / always
$all_categories = HC_Core::get_categories(0, 'published');
$popular_articles = ($q && empty($results)) ? HC_Core::get_popular_articles(4) : array();
?>

<div class="hc-search-page">

    <!-- BACK LINK -->
    <a href="<?php echo esc_url(home_url('/helpcenter/')); ?>" class="hc-back-link">
        <i class="fas fa-arrow-left"></i> Help Center
    </a>

    <!-- HERO SEARCH -->
    <header class="hc-search-hero">
        <h1 class="hc-search-hero-title">
            <?php if ($q): ?>
                Results for &ldquo;<?php echo esc_html($q); ?>&rdquo;
            <?php else: ?>
                Search the Help Center
            <?php endif; ?>
        </h1>
        <p class="hc-search-hero-sub">
            <?php if ($q): ?>
                <strong><?php echo (int) $total; ?></strong> <?php echo $total === 1 ? 'result' : 'results'; ?> found
            <?php else: ?>
                Find answers, guides, and documentation.
            <?php endif; ?>
        </p>

        <form action="<?php echo esc_url(home_url('/helpcenter/search/')); ?>" method="get" class="hc-search-hero-form">
            <div class="hc-search-hero-wrap">
                <i class="fas fa-search"></i>
                <input type="text" name="q" value="<?php echo esc_attr($q); ?>" placeholder="Type keywords…" autocomplete="off" autofocus>
                <button type="submit">Search</button>
            </div>
        </form>
    </header>

    <!-- RESULTS -->
    <section class="hc-search-content">
        <?php if (HC_Core::get_setting('hc_ai_enabled','0') === '1' && $q !== ''): ?>
        <section class="hc-ai-search-summary hc-ai-search-summary-page" id="hcAiSearchSummaryPage" data-query="<?php echo esc_attr($q); ?>"><div class="hc-ai-search-kicker">✦ AI SUMMARY</div><div class="hc-ai-search-copy">Reading relevant Help Center articles…</div><div class="hc-ai-search-links"></div></section>
        <?php endif; ?>

        <?php if ($q && mb_strlen($q) < 2): ?>

            <div class="hc-search-empty">
                <div class="hc-search-empty-icon"><i class="fas fa-keyboard"></i></div>
                <h3>Keep typing…</h3>
                <p>Enter at least 2 characters to search.</p>
            </div>

        <?php elseif ($q && !empty($results)): ?>

            <div class="hc-search-results-new">
                <?php foreach ($results as $r):
                    $reading = $r->reading_time ?: 1;
                    $title_hl = HC_Core::highlight_search_terms($r->title, $q);
                    $excerpt_hl = HC_Core::highlight_search_terms(HC_Core::search_excerpt($r, $q, 28), $q);
                ?>
                <a href="<?php echo esc_url(home_url('/helpcenter/article/' . $r->slug . '/')); ?>" class="hc-result-card" data-hc-search-click="1" data-hc-article-id="<?php echo (int) $r->id; ?>" data-hc-search-query="<?php echo esc_attr($q); ?>">
                    <div class="hc-result-card-icon">
                        <i class="fas fa-file-lines"></i>
                    </div>
                    <div class="hc-result-card-body">
                        <h3 class="hc-result-card-title"><?php echo $title_hl; ?></h3>
                        <p class="hc-result-card-excerpt"><?php echo $excerpt_hl; ?></p>
                        <div class="hc-result-card-meta">
                            <?php if (!empty($r->category_name)): ?>
                            <span class="hc-result-chip">
                                <i class="fas fa-folder"></i> <?php echo esc_html($r->category_name); ?>
                            </span>
                            <?php endif; ?>
                            <span><i class="fas fa-clock"></i> <?php echo (int) $reading; ?> min read</span>
                            <?php if ($r->view_count): ?>
                            <span><i class="fas fa-eye"></i> <?php echo number_format((int) $r->view_count); ?> views</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <i class="fas fa-arrow-right hc-result-card-arrow"></i>
                </a>
                <?php endforeach; ?>
            </div>
            <?php if ($total > $per_page): ?><nav class="hc-pagination" aria-label="Search results pagination"><?php if ($page > 1): ?><a href="<?php echo esc_url(add_query_arg(array('q' => $q, 'paged' => $page - 1), home_url('/helpcenter/search/'))); ?>">← Previous</a><?php endif; ?><span>Page <?php echo (int)$page; ?> of <?php echo (int)ceil($total / $per_page); ?></span><?php if ($page < ceil($total / $per_page)): ?><a href="<?php echo esc_url(add_query_arg(array('q' => $q, 'paged' => $page + 1), home_url('/helpcenter/search/'))); ?>">Next →</a><?php endif; ?></nav><?php endif; ?>

        <?php elseif ($q): ?>

            <!-- NO RESULTS -->
            <div class="hc-search-empty">
                <div class="hc-search-empty-icon hc-search-empty-icon-warn">
                    <i class="fas fa-magnifying-glass"></i>
                </div>
                <h3>No results for &ldquo;<?php echo esc_html($q); ?>&rdquo;</h3>
                <p>Try a different keyword, or browse categories below.</p>
                <div class="hc-search-empty-actions">
                    <a href="<?php echo esc_url(home_url('/helpcenter/contact/')); ?>" class="hc-btn hc-btn-primary">
                        <i class="fas fa-headset"></i> Contact Support
                    </a>
                </div>
            </div>

            <?php if (!empty($popular_articles)): ?>
            <div class="hc-search-section">
                <h2 class="hc-search-section-title"><i class="fas fa-fire"></i> Popular Articles</h2>
                <div class="hc-search-popular">
                    <?php foreach ($popular_articles as $p): ?>
                    <a href="<?php echo esc_url(home_url('/helpcenter/article/' . $p->slug . '/')); ?>" class="hc-result-card">
                        <div class="hc-result-card-icon"><i class="fas fa-file-lines"></i></div>
                        <div class="hc-result-card-body">
                            <h3 class="hc-result-card-title"><?php echo esc_html($p->title); ?></h3>
                            <div class="hc-result-card-meta">
                                <span><i class="fas fa-eye"></i> <?php echo number_format((int) $p->view_count); ?> views</span>
                            </div>
                        </div>
                        <i class="fas fa-arrow-right hc-result-card-arrow"></i>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        <?php else: ?>

            <!-- BLANK STATE -->
            <div class="hc-search-empty">
                <div class="hc-search-empty-icon"><i class="fas fa-magnifying-glass"></i></div>
                <h3>What are you looking for?</h3>
                <p>Type a keyword above to search our knowledge base.</p>
            </div>

        <?php endif; ?>

        <!-- BROWSE CATEGORIES (always shown below results) -->
        <?php if (!empty($all_categories)): ?>
        <div class="hc-search-section">
            <h2 class="hc-search-section-title"><i class="fas fa-folder-tree"></i> Browse Categories</h2>
            <div class="hc-search-cats">
                <?php foreach ($all_categories as $c): ?>
                <a href="<?php echo esc_url(home_url('/helpcenter/category/' . $c->slug . '/')); ?>" class="hc-search-cat">
                    <div class="hc-search-cat-icon">
                        <i class="<?php $ci = $c->icon_value ?: 'fa-folder'; echo esc_attr(strpos($ci, 'fa-') === 0 && strpos($ci, ' ' ) === false ? 'fas ' . $ci : $ci); ?>"></i>
                    </div>
                    <div class="hc-search-cat-body">
                        <div class="hc-search-cat-name"><?php echo esc_html($c->name); ?></div>
                        <div class="hc-search-cat-count">
                            <?php echo (int) $c->article_count; ?> article<?php echo $c->article_count == 1 ? '' : 's'; ?>
                        </div>
                    </div>
                    <i class="fas fa-arrow-right hc-search-cat-arrow"></i>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </section>

</div>
