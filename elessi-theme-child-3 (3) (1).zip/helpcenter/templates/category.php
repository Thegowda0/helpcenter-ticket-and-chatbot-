<?php
if (!defined('ABSPATH')) exit;

$slug = get_query_var('hc_category');
$category = HC_Core::get_category_by_slug($slug);

if (!$category) {
    status_header(404);
    include HC_TEMPLATES . '404.php';
    return;
}

$icon = $category->icon_value ?: 'fa-folder';
$subs = HC_Core::get_subcategories($category->id);
$article_page = max(1, absint($_GET['paged'] ?? 1));
$article_per_page = 10;
$articles = HC_Core::get_articles_by_category($category->id, $article_per_page, ($article_page - 1) * $article_per_page);
global $wpdb;
$article_total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT a.id) FROM {$wpdb->prefix}hc_articles a JOIN {$wpdb->prefix}hc_article_categories ac ON ac.article_id = a.id WHERE ac.category_id = %d AND " . HC_Lifecycle::sql_article_live('a'), $category->id));
$parent = $category->parent_id ? HC_Core::get_category($category->parent_id) : null;

$faqs = HC_Core::get_faqs('category', $category->id);
$faq_position = HC_Core::get_setting('hc_faq_position', 'bottom');
$show_faqs = HC_Core::get_setting('hc_show_faqs', '1') === '1';
$show_breadcrumbs = HC_Core::get_setting('hc_show_breadcrumbs', '1') === '1';
$show_views = HC_Core::get_setting('hc_show_view_count', '1') === '1';
$show_reading = HC_Core::get_setting('hc_show_reading_time', '1') === '1';
?>

<!-- BREADCRUMB -->
<?php if ($show_breadcrumbs): ?><nav class="hc-breadcrumb" aria-label="Breadcrumb" itemscope itemtype="https://schema.org/BreadcrumbList">
    <ol>
        <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="<?php echo esc_url(home_url('/helpcenter/')); ?>"><span itemprop="name">Help Center</span></a><meta itemprop="position" content="1"></li>
        <?php if ($parent): ?>
        <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="<?php echo esc_url(home_url('/helpcenter/category/' . $parent->slug . '/')); ?>"><span itemprop="name"><?php echo esc_html($parent->name); ?></span></a><meta itemprop="position" content="2"></li>
        <?php endif; ?>
        <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><span itemprop="name"><?php echo esc_html($category->name); ?></span><meta itemprop="item" content="<?php echo esc_url(home_url('/helpcenter/category/' . $category->slug . '/')); ?>"><meta itemprop="position" content="<?php echo $parent ? 3 : 2; ?>"></li>
    </ol>
</nav><?php endif; ?>

<!-- HEADER -->
<div class="hc-cat-header">
    <div class="hc-cat-header-icon"><i class="<?php echo esc_attr(strpos($icon, 'fa-') === 0 && strpos($icon, ' ' ) === false ? 'fas ' . $icon : $icon); ?>"></i></div>
    <div class="hc-cat-header-body">
        <h1><?php echo esc_html($category->name); ?></h1>
        <?php if ($category->description): ?>
        <p><?php echo esc_html($category->description); ?></p>
        <?php endif; ?>
        <div class="hc-cat-header-meta">
            <span><i class="fas fa-file-lines"></i> <?php echo (int) $article_total; ?> article<?php echo $article_total === 1 ? '' : 's'; ?></span>
            <?php if (!empty($subs)): ?>
            <span><i class="fas fa-folder-tree"></i> <?php echo count($subs); ?> subcategor<?php echo count($subs) === 1 ? 'y' : 'ies'; ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- SUBCATEGORIES -->
<?php if (!empty($subs)): ?>
<section class="hc-section">
    <div class="hc-section-head">
        <h2><i class="fas fa-folder-tree"></i> Subcategories</h2>
    </div>
    <div class="hc-subcat-grid">
        <?php foreach ($subs as $sub):
            $sub_icon = $sub->icon_value ?: 'fa-folder-open';
        ?>
        <a href="<?php echo esc_url(home_url('/helpcenter/category/' . $sub->slug . '/')); ?>" class="hc-subcat-card">
            <i class="<?php echo esc_attr(strpos($sub_icon, 'fa-') === 0 && strpos($sub_icon, ' ' ) === false ? 'fas ' . $sub_icon : $sub_icon); ?>"></i>
            <div>
                <h4><?php echo esc_html($sub->name); ?></h4>
                <span><?php echo (int) $sub->article_count; ?> article<?php echo $sub->article_count == 1 ? '' : 's'; ?></span>
            </div>
            <i class="fas fa-arrow-right"></i>
        </a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- FAQS TOP -->
<?php if ($show_faqs && !empty($faqs) && $faq_position === 'top'): ?>
<section class="hc-section hc-faq-position-top"><div class="hc-section-head"><h2>Frequently Asked Questions</h2></div><div class="hc-faq-list">
<?php foreach ($faqs as $faq): ?><div class="hc-faq-item"><button type="button" class="hc-faq-q"><span><?php echo esc_html($faq->question); ?></span><i class="fas fa-plus hc-faq-icon"></i></button><div class="hc-faq-a"><div class="hc-faq-a-inner"><?php echo wp_kses_post($faq->answer); ?></div></div></div><?php endforeach; ?>
</div></section>
<?php endif; ?>

<!-- ARTICLES -->
<section class="hc-section">
    <div class="hc-section-head">
        <h2><i class="fas fa-list"></i> Articles in this category</h2>
    </div>

    <?php if (!empty($articles)): ?>
    <div class="hc-article-list">
        <?php foreach ($articles as $a):
            $reading = $a->reading_time ?: 1;
        ?>
        <a href="<?php echo esc_url(home_url('/helpcenter/article/' . $a->slug . '/')); ?>" class="hc-article-row">
            <div class="hc-article-row-icon"><i class="fas fa-file-lines"></i></div>
            <div class="hc-article-row-body">
                <h3><?php echo esc_html($a->title); ?></h3>
                <?php if ($a->excerpt): ?>
                <p><?php echo esc_html(wp_trim_words($a->excerpt, 18)); ?></p>
                <?php endif; ?>
                <div class="hc-article-row-meta">
                    <span><i class="fas fa-clock"></i> <?php echo $reading; ?> min read</span>
                    <?php if ($show_views): ?><span><i class="fas fa-eye"></i> <?php echo (int) $a->view_count; ?> views</span><?php endif; ?>
                    <span><i class="fas fa-calendar"></i> <?php echo esc_html(HC_Core::time_ago($a->updated_at)); ?></span>
                </div>
            </div>
            <i class="fas fa-chevron-right hc-article-row-arrow"></i>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="hc-empty">
        <i class="fas fa-inbox"></i>
        <h3>No articles yet</h3>
        <p>This category doesn't have any articles published yet.</p>
        <a href="<?php echo esc_url(home_url('/helpcenter/')); ?>" class="hc-btn hc-btn-outline">
            Back to Help Center
        </a>
    </div>
    <?php endif; ?>
    <?php if ($article_total > $article_per_page): ?><nav class="hc-pagination" aria-label="Category article pagination"><?php if ($article_page > 1): ?><a href="<?php echo esc_url(add_query_arg('paged', $article_page - 1)); ?>">← Previous</a><?php endif; ?><span>Page <?php echo (int)$article_page; ?> of <?php echo (int)ceil($article_total / $article_per_page); ?></span><?php if ($article_page < ceil($article_total / $article_per_page)): ?><a href="<?php echo esc_url(add_query_arg('paged', $article_page + 1)); ?>">Next →</a><?php endif; ?></nav><?php endif; ?>
</section>

<!-- FAQS -->
<?php if ($show_faqs && !empty($faqs) && $faq_position !== 'top'): ?>
<section class="hc-section">
    <div class="hc-section-head">
        <h2><i class="fas fa-circle-question"></i> Frequently Asked Questions</h2>
    </div>
    <div class="hc-faq-list">
        <?php foreach ($faqs as $faq): ?>
        <div class="hc-faq-item">
            <button type="button" class="hc-faq-q">
                <span><?php echo esc_html($faq->question); ?></span>
                <i class="fas fa-plus hc-faq-icon"></i>
            </button>
            <div class="hc-faq-a">
                <div class="hc-faq-a-inner"><?php echo wp_kses_post($faq->answer); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- CONTACT CTA -->
<section class="hc-cta-section">
    <div class="hc-cta">
        <div class="hc-cta-icon"><i class="fas fa-headset"></i></div>
        <div class="hc-cta-body">
            <h3>Still need help?</h3>
            <p>Can't find what you're looking for? Contact our team.</p>
        </div>
        <a href="<?php echo esc_url(home_url('/helpcenter/contact/')); ?>" class="hc-btn hc-btn-primary">
            Contact Support <i class="fas fa-arrow-right"></i>
        </a>
    </div>
</section>
