<?php
if (!defined('ABSPATH')) exit;

$email       = HC_Core::get_setting('hc_contact_email', get_option('admin_email'));
$phone       = HC_Core::get_setting('hc_contact_phone', '');
$chat        = HC_Core::get_setting('hc_livechat_url', '');
$can_upload  = HC_Core::get_setting('hc_contact_upload', '1') === '1';
$max_mb      = (int) HC_Core::get_setting('hc_contact_max_mb', 5);
$faqs        = HC_Core::get_faqs('contact');
$show_faqs   = HC_Core::get_setting('hc_show_faqs', '1') === '1';
$show_tickets = HC_Core::get_setting('hc_enable_tickets', '1') === '1';

// Ticket system
$tickets_on  = HC_Core::get_setting('hc_enable_tickets', '0') === '1';
$ticket_url  = home_url('/ticket/');
$ticket_new  = home_url('/ticket/new/');  // fallback if no /ticket/new/, the JS will redirect to /ticket/

// Count active method cards
$active_count = 1; // email always shows
if ($tickets_on) $active_count++;
if ($chat)       $active_count++;
if ($phone)      $active_count++;
?>

<div class="hc-contact-page">

    <!-- BACK -->
    <a href="<?php echo esc_url(home_url('/helpcenter/')); ?>" class="hc-back-link">
        <i class="fas fa-arrow-left"></i> Help Center
    </a>

    <!-- HERO -->
    <header class="hc-contact-hero">
        <div class="hc-contact-hero-icon"><i class="fas fa-headset"></i></div>
        <h1>Contact Support</h1>
        <p>Pick the fastest way to reach us — we usually reply within 24 hours.</p>
    </header>

    <!-- METHOD CARDS -->
    <section class="hc-contact-methods" data-count="<?php echo (int) $active_count; ?>">

        <?php if ($tickets_on): ?>
        <a href="<?php echo esc_url($ticket_url); ?>" target="_blank" rel="noopener noreferrer" class="hc-method-card">
            <div class="hc-method-card-icon">
                <i class="fas fa-ticket"></i>
            </div>
            <div class="hc-method-card-body">
                <h3>Submit a Ticket</h3>
                <p>Track your request with a ticket ID</p>
            </div>
            <i class="fas fa-arrow-right hc-method-card-arrow"></i>
        </a>
        <?php endif; ?>

        <?php if ($chat): ?>
        <a href="<?php echo esc_url($chat); ?>" target="_blank" rel="noopener noreferrer" class="hc-method-card">
            <div class="hc-method-card-icon">
                <i class="fas fa-comments"></i>
            </div>
            <div class="hc-method-card-body">
                <h3>
                    Live Chat
                    <span class="hc-online-dot" title="Available now"></span>
                </h3>
                <p>Chat with us in real time</p>
            </div>
            <i class="fas fa-arrow-right hc-method-card-arrow"></i>
        </a>
        <?php endif; ?>

        <!-- Email card — triggers form reveal (no link navigation) -->
        <button type="button" class="hc-method-card hc-method-card-email" data-hc-show-form>
            <div class="hc-method-card-icon">
                <i class="fas fa-envelope"></i>
            </div>
            <div class="hc-method-card-body">
                <h3>Email Us</h3>
                <p>Fill the form and we'll reply by email</p>
            </div>
            <i class="fas fa-arrow-down hc-method-card-arrow"></i>
        </button>

        <?php if ($phone): ?>
        <a href="tel:<?php echo esc_attr($phone); ?>" class="hc-method-card">
            <div class="hc-method-card-icon">
                <i class="fas fa-phone"></i>
            </div>
            <div class="hc-method-card-body">
                <h3>Call Us</h3>
                <p><?php echo esc_html($phone); ?></p>
            </div>
            <i class="fas fa-arrow-right hc-method-card-arrow"></i>
        </a>
        <?php endif; ?>

    </section>

    <!-- FORM (hidden by default) -->
    <section class="hc-contact-form-section" id="hcContactFormSection" style="display:none;">
        <div class="hc-contact-form-header">
            <button type="button" class="hc-contact-form-close" id="hcContactFormClose" aria-label="Close form">
                <i class="fas fa-times"></i>
            </button>
            <h2><i class="fas fa-paper-plane"></i> Send us a message</h2>
            <p>Fill in the form below and we'll get back to you by email.</p>
        </div>

        <form id="hcContactForm" enctype="multipart/form-data" class="hc-contact-form" novalidate>
            <div class="hc-form-group">
                <label for="hc-c-name">Your Name <span class="req">*</span></label>
                <input type="text" id="hc-c-name" name="name" required placeholder="John Doe">
            </div>

            <div class="hc-form-group">
                <label for="hc-c-email">Email Address <span class="req">*</span></label>
                <input type="email" id="hc-c-email" name="email" required placeholder="you@example.com">
            </div>

            <div class="hc-form-group">
                <label for="hc-c-subject">Subject <span class="req">*</span></label>
                <input type="text" id="hc-c-subject" name="subject" required placeholder="Briefly describe your issue">
            </div>

            <div class="hc-form-group">
                <label for="hc-c-message">Message <span class="req">*</span></label>
                <textarea id="hc-c-message" name="message" rows="6" required placeholder="Tell us what you need help with…"></textarea>
            </div>

            <?php if ($can_upload): ?>
            <div class="hc-form-group">
                <label for="hc-c-attachment">Attachment (optional)</label>
                <input type="file" id="hc-c-attachment" name="attachment" accept=".jpg,.jpeg,.png,.pdf">
                <small>Max <?php echo $max_mb; ?>MB · JPG, PNG, PDF only</small>
            </div>
            <?php endif; ?>

            <button type="submit" class="hc-contact-submit" id="hcContactSubmit">
                <i class="fas fa-paper-plane"></i> Send Message
            </button>

            <div class="hc-contact-form-msg" id="hcContactMsg"></div>
        </form>
    </section>

    <!-- FAQs -->
    <?php if ($show_faqs && !empty($faqs)): ?>
    <section class="hc-contact-faq">
        <h2 class="hc-contact-faq-title"><i class="fas fa-circle-question"></i> Frequently Asked Questions</h2>
        <div class="hc-faq-list">
            <?php foreach ($faqs as $faq): ?>
            <div class="hc-faq-item">
                <button type="button" class="hc-faq-q">
                    <span><?php echo esc_html($faq->question); ?></span>
                    <i class="fas fa-plus hc-faq-icon"></i>
                </button>
                <div class="hc-faq-a">
                    <div class="hc-faq-a-inner"><?php echo wp_kses_post($faq->answer); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

</div>
