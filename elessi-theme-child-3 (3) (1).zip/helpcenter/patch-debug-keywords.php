<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/class-hc-ajax.php';
$src = file_get_contents($file);

if (strpos($src, 'HC_DEBUG_KEYWORDS') !== false) {
    echo "SKIP: debug already added\n";
    exit(0);
}

$needle = "\$meta_keywords  = sanitize_text_field(\$_POST['meta_keywords'] ?? '');";
if (strpos($src, $needle) === false) {
    echo "ERROR: needle not found\n";
    exit(1);
}

$addition = $needle . "\n        // HC_DEBUG_KEYWORDS — temporary logging\n        error_log('[HC KEYWORDS] POST[meta_keywords]=' . (isset(\$_POST['meta_keywords']) ? \$_POST['meta_keywords'] : '(not set)') . ' | sanitized=' . \$meta_keywords);";

$src = str_replace($needle, $addition, $src, $count);
file_put_contents($file, $src);
echo "OK: debug logging added\n";
