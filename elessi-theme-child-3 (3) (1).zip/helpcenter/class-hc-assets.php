<?php
/**
 * Help Center - Frontend Asset Loader
 */

if (!defined('ABSPATH')) exit;

class HC_Assets {

    public static function init() {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue'), 20);
    }

    public static function enqueue() {
        if (!self::is_hc_page()) return;

        // Clean theme assets
        self::strip_theme_assets();

        // Font Awesome
        wp_enqueue_style(
            'hc-fontawesome',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.3.1/css/all.min.css',
            array(),
            '7.3.1'
        );

        // Google Fonts
        wp_enqueue_style(
            'hc-google-fonts',
            'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
            array(),
            null
        );

        // Frontend CSS
        $css_file = HC_PATH . 'assets/css/frontend.css';
        if (file_exists($css_file)) {
            wp_enqueue_style(
                'hc-frontend',
                HC_ASSETS . 'css/frontend.css',
                array('hc-fontawesome', 'hc-google-fonts'),
                filemtime($css_file)
            );
        }

        // jQuery (WordPress default)
        wp_enqueue_script('jquery');

        // Frontend JS
        $js_file = HC_PATH . 'assets/js/frontend.js';
        if (file_exists($js_file)) {
            wp_enqueue_script(
                'hc-frontend',
                HC_ASSETS . 'js/frontend.js',
                array('jquery'),
                filemtime($js_file),
                true
            );

            wp_localize_script('hc-frontend', 'hcData', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('hc_nonce'),
                'homeUrl' => home_url('/helpcenter/'),
            ));
        }

        // Dynamic colors from settings
        add_action('wp_head', array(__CLASS__, 'output_dynamic_css'), 999);
    }

    public static function is_hc_page() {
        return (bool) get_query_var('hc_page');
    }

    private static function strip_theme_assets() {
        global $wp_styles, $wp_scripts;

        $keep_styles = array('hc-fontawesome', 'hc-google-fonts', 'hc-frontend', 'admin-bar', 'dashicons');
        $keep_scripts = array('jquery', 'jquery-core', 'jquery-migrate', 'admin-bar', 'hc-frontend');

        if (isset($wp_styles->queue) && is_array($wp_styles->queue)) {
            foreach ($wp_styles->queue as $h) {
                if (!in_array($h, $keep_styles)) {
                    wp_dequeue_style($h);
                    wp_deregister_style($h);
                }
            }
        }
        if (isset($wp_scripts->queue) && is_array($wp_scripts->queue)) {
            foreach ($wp_scripts->queue as $h) {
                if (!in_array($h, $keep_scripts)) {
                    wp_dequeue_script($h);
                    wp_deregister_script($h);
                }
            }
        }

    }

    public static function output_dynamic_css() {
        if (!self::is_hc_page()) return;

        $primary = HC_Core::get_setting('hc_primary_color', '#6366F1');
        $accent  = HC_Core::get_setting('hc_accent_color', '#F59E0B');
        $bg      = HC_Core::get_setting('hc_bg_color', '#F8FAFC');
        $header  = HC_Core::get_setting('hc_header_bg', '#FFFFFF');
        $htext   = HC_Core::get_setting('hc_header_text', '#0F172A');

        ?>
        <style id="hc-dynamic-css">
            :root {
                --hc-primary: <?php echo esc_html($primary); ?>;
                --hc-primary-hover: <?php echo esc_html(self::adjust($primary, -20)); ?>;
                --hc-primary-light: <?php echo esc_html(self::adjust($primary, 180)); ?>;
                --hc-accent: <?php echo esc_html($accent); ?>;
                --hc-bg: <?php echo esc_html($bg); ?>;
                --hc-header-bg: <?php echo esc_html($header); ?>;
                --hc-header-text: <?php echo esc_html($htext); ?>;
            }
        </style>
        <?php
    }

    public static function shade($hex, $steps) {
        $hex = ltrim($hex, '#');
        if (strlen($hex) == 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        }
        $r = max(0, min(255, hexdec(substr($hex, 0, 2)) + $steps));
        $g = max(0, min(255, hexdec(substr($hex, 2, 2)) + $steps));
        $b = max(0, min(255, hexdec(substr($hex, 4, 2)) + $steps));
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }
}

// HC_Assets::init(); // assets now printed manually in templates/wrapper.php
