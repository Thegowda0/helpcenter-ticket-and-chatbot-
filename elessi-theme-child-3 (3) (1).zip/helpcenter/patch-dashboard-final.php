<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/assets/css/admin.css';
$src = file_get_contents($file);

// Remove every previous dashboard-table CSS block
$markers = array(
    'Dashboard cards — table containment (v8.1)',
    'Dashboard — wider title column (v8.2)',
    'Dashboard cards — clean layout (v9.0)',
    'Dashboard — cards (v10.0)',
    'Dashboard — MOBILE-FIRST fix (v11.0)',
);

foreach ($markers as $m) {
    $needle = '/* =============================================
   ' . $m;
    $start = strpos($src, $needle);
    if ($start === false) continue;
    $end = strpos($src, '/*', $start + 50);
    if ($end === false) $end = strlen($src);
    $src = substr($src, 0, $start) . substr($src, $end);
}

file_put_contents($file, $src);
echo "OK: old dashboard CSS wiped\n";
