<?php
/** Database-driven public SEO endpoints and metadata for Help Center. */
if (!defined('ABSPATH')) exit;

class HC_SEO {
    public static function register() {
        add_filter('robots_txt', array(__CLASS__, 'robots_txt'), 20, 2);
        add_action('template_redirect', array(__CLASS__, 'dispatch'), 0);
    }

    public static function robots_txt($output, $public) {
        $rules = "\n# Help Center: public documentation is crawlable; private administration stays closed.\n";
        $rules .= "User-agent: *\nAllow: /helpcenter/\nDisallow: /helpcenter/admin/\nDisallow: /wp-admin/\nDisallow: /wp-login.php\n";
        $rules .= "Sitemap: " . home_url('/helpcenter-sitemap.xml') . "\n";
        // Explicitly allow public help content for common AI answer/search crawlers.
        foreach (array('GPTBot','OAI-SearchBot','ChatGPT-User','ClaudeBot','Claude-SearchBot','PerplexityBot','Google-Extended','Applebot-Extended','Amazonbot','Meta-ExternalAgent','Bytespider','CCBot') as $bot) {
            $rules .= "\nUser-agent: {$bot}\nAllow: /helpcenter/\nDisallow: /helpcenter/admin/\n";
        }
        return rtrim($output) . "\n" . $rules;
    }

    public static function dispatch() {
        $page = get_query_var('hc_page');
        if ($page === 'sitemap') self::sitemap();
        if ($page === 'llms') self::llms();
    }

    private static function public_articles() {
        global $wpdb;
        return $wpdb->get_results("SELECT a.id,a.title,a.slug,a.excerpt,a.updated_at FROM {$wpdb->prefix}hc_articles a WHERE " . HC_Lifecycle::sql_article_live('a') . " ORDER BY a.updated_at DESC, a.id DESC");
    }

    private static function public_categories() {
        global $wpdb;
        return $wpdb->get_results("SELECT c.id,c.name,c.slug,c.updated_at FROM {$wpdb->prefix}hc_categories c WHERE " . HC_Lifecycle::sql_category_live('c') . " ORDER BY c.parent_id ASC,c.sort_order ASC,c.name ASC");
    }

    public static function sitemap() {
        $urls = array(
            array(home_url('/helpcenter/'), current_time('mysql')),
            array(home_url('/helpcenter/latest/'), current_time('mysql')),
            array(home_url('/helpcenter/popular/'), current_time('mysql')),
            array(home_url('/helpcenter/contact/'), current_time('mysql')),
            array(home_url('/categories/'), current_time('mysql')),
        );
        foreach (self::public_categories() as $c) $urls[] = array(home_url('/helpcenter/category/' . $c->slug . '/'), $c->updated_at ?: current_time('mysql'));
        foreach (self::public_articles() as $a) $urls[] = array(home_url('/helpcenter/article/' . $a->slug . '/'), $a->updated_at ?: current_time('mysql'));
        status_header(200); header('Content-Type: application/xml; charset=UTF-8'); header('X-Robots-Tag: noindex, follow', true);
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($urls as $u) {
            echo '<url><loc>' . esc_url($u[0]) . '</loc><lastmod>' . esc_html(mysql2date('c', $u[1], false)) . '</lastmod></url>' . "\n";
        }
        echo '</urlset>'; exit;
    }

    public static function llms() {
        $site = HC_Core::get_setting('hc_site_title', 'Help Center');
        status_header(200); header('Content-Type: text/plain; charset=UTF-8'); header('X-Robots-Tag: noindex, follow', true);
        echo '# ' . sanitize_text_field($site) . "\n\n";
        echo '> Official public help documentation. Pages listed below are generated from published database records. Private administration and unpublished content are excluded.\n\n';
        echo '## Help Center\n- ' . home_url('/helpcenter/') . "\n- " . home_url('/helpcenter/latest/') . "\n- " . home_url('/helpcenter/popular/') . "\n\n";
        echo "## Categories\n";
        foreach (self::public_categories() as $c) echo '- [' . str_replace(array('[',']'), '', $c->name) . '](' . home_url('/helpcenter/category/' . $c->slug . '/') . ")\n";
        echo "\n## Articles\n";
        foreach (self::public_articles() as $a) echo '- [' . str_replace(array('[',']'), '', $a->title) . '](' . home_url('/helpcenter/article/' . $a->slug . '/') . ')' . ($a->excerpt ? ' — ' . wp_strip_all_tags($a->excerpt) : '') . "\n";
        exit;
    }

    public static function page_meta() {
        $page = get_query_var('hc_page');
        $title = HC_Core::get_setting('hc_site_title', 'Help Center');
        $description = HC_Core::get_setting('hc_tagline', 'Find answers, guides, and documentation.');
        $url = home_url('/helpcenter/'); $type = 'website'; $image = ''; $not_found = false;
        if ($page === 'article') {
            $a = HC_Core::get_article_by_slug(get_query_var('hc_article'));
            if ($a) { $title = $a->title . ' | ' . $title; $description = $a->excerpt ?: wp_trim_words(wp_strip_all_tags($a->content), 30); $url = home_url('/helpcenter/article/' . $a->slug . '/'); $type = 'article'; if (preg_match('/<img[^>]+src=["\']([^"\']+)/i', $a->content, $m)) $image = $m[1]; } else { $not_found = true; }
        } elseif ($page === 'category') {
            $c = HC_Core::get_category_by_slug(get_query_var('hc_category'));
            if ($c) { $title = $c->name . ' | ' . $title; $description = $c->description ?: 'Browse help articles in ' . $c->name . '.'; $url = home_url('/helpcenter/category/' . $c->slug . '/'); } else { $not_found = true; }
        } elseif ($page === 'search') {
            $q = sanitize_text_field(wp_unslash($_GET['q'] ?? '')); $title = ($q ? 'Search: ' . $q . ' | ' : '') . $title; $description = 'Search the Help Center for answers and guides.'; $url = home_url('/helpcenter/search/');
        } elseif ($page === 'contact') { $title = 'Contact Support | ' . $title; $description = 'Contact the support team for help.'; $url = home_url('/helpcenter/contact/'); }
        elseif ($page === 'latest') { $title = 'Latest Articles | ' . $title; $description = 'Recently updated help articles.'; $url = home_url('/helpcenter/latest/'); }
        elseif ($page === 'popular') { $title = 'Popular Articles | ' . $title; $description = 'Most useful and popular help articles.'; $url = home_url('/helpcenter/popular/'); }
        elseif ($page === 'categories-all') { $title = 'All Categories | ' . $title; $description = 'Browse all Help Center categories.'; $url = home_url('/categories/'); }
        if (!$image) $image = HC_Core::get_setting('hc_schema_org_logo', '');
        $robots = ($page === 'search' || $page === '404' || $not_found || strpos((string)$page, 'admin-') === 0) ? 'noindex,follow' : 'index,follow,max-image-preview:large';
        if ($page === 'article' && isset($a) && $a) {
            if (!empty($a->robots_meta) && $a->robots_meta !== 'inherit') $robots = $a->robots_meta;
            if ($a->status !== 'published') $robots = 'noindex,nofollow';
        }
        return compact('title','description','url','type','image','robots','not_found');
    }

    public static function render_breadcrumbs() {
        $page = get_query_var('hc_page');
        $labels = array('search'=>'Search','latest'=>'Latest Articles','popular'=>'Popular Articles','contact'=>'Contact','categories-all'=>'All Categories');
        if (!isset($labels[$page]) || HC_Core::get_setting('hc_show_breadcrumbs', '1') !== '1') return;
        $path = $page === 'categories-all' ? '/categories/' : '/helpcenter/' . $page . '/';
        echo '<nav class="hc-breadcrumb" aria-label="Breadcrumb" itemscope itemtype="https://schema.org/BreadcrumbList"><ol>';
        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url(home_url('/helpcenter/')) . '"><span itemprop="name">Help Center</span></a><meta itemprop="position" content="1"></li>';
        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><span itemprop="name">' . esc_html($labels[$page]) . '</span><meta itemprop="item" content="' . esc_url(home_url($path)) . '"><meta itemprop="position" content="2"></li>';
        echo '</ol></nav>';
    }

    public static function output_meta() {
        $m = self::page_meta();
        echo '<title>' . esc_html($m['title']) . "</title>\n";
        echo '<meta name="description" content="' . esc_attr(wp_trim_words($m['description'], 32, '')) . '">' . "\n";
        echo '<meta name="robots" content="' . esc_attr($m['robots']) . '">' . "\n";
        if (get_query_var('hc_page') !== '404' && empty($m['not_found'])) echo '<link rel="canonical" href="' . esc_url($m['url']) . '">' . "\n";
        echo '<meta property="og:type" content="' . esc_attr($m['type']) . '">' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr(HC_Core::get_setting('hc_site_title', get_bloginfo('name'))) . '">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($m['title']) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr(wp_trim_words($m['description'], 32, '')) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url($m['url']) . '">' . "\n";
        if ($m['image']) { echo '<meta property="og:image" content="' . esc_url($m['image']) . '">' . "\n"; echo '<meta name="twitter:image" content="' . esc_url($m['image']) . '">' . "\n"; }
        echo '<meta name="twitter:card" content="' . ($m['image'] ? 'summary_large_image' : 'summary') . '">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($m['title']) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr(wp_trim_words($m['description'], 32, '')) . '">' . "\n";
    }
}
