<?php
/**
 * Help Center AI Platform Foundation (v45)
 * Persistent conversations, message history, opt-in memory, feedback and job ledger.
 */
if (!defined('ABSPATH')) exit;

class HC_AI_Platform {
    const DB_VERSION = '1.0.4';

    public static function init() {
        self::install();
        add_action('wp_ajax_hc_ai_feedback', array(__CLASS__, 'feedback'));
        add_action('wp_ajax_nopriv_hc_ai_feedback', array(__CLASS__, 'feedback'));
        add_action('admin_post_hc_ai_feedback_status', array(__CLASS__, 'feedback_status'));
        add_action('hc_ai_cleanup_conversations', array(__CLASS__, 'cleanup_conversations'));
        $cleanup_event = wp_next_scheduled('hc_ai_cleanup_conversations');
        if ($cleanup_event && function_exists('wp_get_schedule') && wp_get_schedule($cleanup_event, 'hc_ai_cleanup_conversations') !== 'hourly') {
            wp_unschedule_event($cleanup_event, 'hc_ai_cleanup_conversations');
            $cleanup_event = false;
        }
        if (!$cleanup_event) wp_schedule_event(time() + 300, 'hourly', 'hc_ai_cleanup_conversations');
    }

    public static function install() {
        if (get_option('hc_ai_platform_db_version') === self::DB_VERSION) return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix;
        dbDelta("CREATE TABLE {$p}hc_ai_conversations (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_hash char(64) NOT NULL,
            visitor_hash char(64) NOT NULL DEFAULT '',
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            title varchar(255) NOT NULL DEFAULT 'New conversation',
            status varchar(20) NOT NULL DEFAULT 'active',
            message_count int(10) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY session_lookup (session_hash, status),
            KEY visitor_lookup (visitor_hash, updated_at),
            KEY user_lookup (user_id, updated_at),
            KEY updated_at (updated_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$p}hc_ai_messages (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            conversation_id bigint(20) unsigned NOT NULL,
            role varchar(20) NOT NULL,
            content longtext NOT NULL,
            sources longtext DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY conversation_order (conversation_id, id),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$p}hc_ai_memories (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            session_hash char(64) NOT NULL,
            memory_key varchar(100) NOT NULL,
            memory_value text NOT NULL,
            approved tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY session_memory (session_hash, approved),
            KEY user_memory (user_id, approved)
        ) {$charset};");
        dbDelta("CREATE TABLE {$p}hc_ai_feedback (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            conversation_id bigint(20) unsigned NOT NULL DEFAULT 0,
            message_id bigint(20) unsigned NOT NULL DEFAULT 0,
            session_hash char(64) NOT NULL,
            rating varchar(20) NOT NULL,
            comment text DEFAULT NULL,
            question longtext DEFAULT NULL,
            answer longtext DEFAULT NULL,
            source_urls longtext DEFAULT NULL,
            source_details longtext DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'new',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY status_created (status, created_at),
            KEY conversation_lookup (conversation_id)
        ) {$charset};");
        dbDelta("CREATE TABLE {$p}hc_ai_jobs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            job_type varchar(60) NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'queued',
            payload longtext DEFAULT NULL,
            attempts smallint(5) unsigned NOT NULL DEFAULT 0,
            last_error text DEFAULT NULL,
            run_after datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY job_status (status, run_after)
        ) {$charset};");
        update_option('hc_ai_platform_db_version', self::DB_VERSION, false);
    }

    /** Remove expired conversations and enforce per-session history limits. */
    public static function cleanup_conversations() {
        global $wpdb;
        $conversations = $wpdb->prefix . 'hc_ai_conversations';
        $messages = $wpdb->prefix . 'hc_ai_messages';
        $feedback = $wpdb->prefix . 'hc_ai_feedback';
        $short_hours = max(1, min(720, absint(HC_Core::get_setting('hc_ai_retention_hours', '24'))));
        $max_age_days = max(1, min(365, absint(HC_Core::get_setting('hc_ai_max_age_days', '7'))));
        $keep = max(1, min(100, absint(HC_Core::get_setting('hc_ai_max_conversations', '10'))));
        // Short/incomplete chats (0–2 stored messages) expire after the short-chat window.
        // Substantive conversations (>2 messages) may remain available up to the separate maximum age.
        // These are independent cohorts; the 24-hour rule no longer overrides the 7-day rule.
        $short_cutoff = wp_date('Y-m-d H:i:s', time() - ($short_hours * HOUR_IN_SECONDS));
        $long_cutoff = wp_date('Y-m-d H:i:s', time() - ($max_age_days * DAY_IN_SECONDS));
        $ticket_table = $wpdb->prefix . 'hc_ai_escalations';
        $has_tickets = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $ticket_table)) === $ticket_table;
        $protected_sql = $has_tickets ? " AND id NOT IN (SELECT DISTINCT conversation_id FROM {$ticket_table} WHERE conversation_id>0)" : '';
        $expired = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$conversations} WHERE ((message_count <= 2 AND updated_at < %s) OR (message_count > 2 AND updated_at < %s)) {$protected_sql}",
            $short_cutoff, $long_cutoff
        ));
        $expired = array_map('intval', is_array($expired) ? $expired : array());

        // Keep only the newest N conversations for each visitor browser identity.
        $visitor_groups = $wpdb->get_col("SELECT DISTINCT CASE WHEN visitor_hash<>'' THEN visitor_hash ELSE session_hash END AS visitor_group FROM {$conversations}");
        foreach ((array) $visitor_groups as $visitor_group) {
            $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM {$conversations} WHERE (visitor_hash=%s OR (visitor_hash='' AND session_hash=%s)) {$protected_sql} ORDER BY updated_at DESC, id DESC", $visitor_group, $visitor_group));
            if (count($ids) > $keep) {
                foreach (array_slice($ids, $keep) as $id) $expired[] = (int) $id;
            }
        }
        $expired = array_values(array_unique(array_filter($expired)));
        foreach (array_chunk($expired, 200) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));
            $sql = $wpdb->prepare("DELETE FROM {$messages} WHERE conversation_id IN ({$placeholders})", $chunk);
            $wpdb->query($sql);
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $feedback)) === $feedback) {
                $session_hashes = $wpdb->get_col($wpdb->prepare("SELECT session_hash FROM {$conversations} WHERE id IN ({$placeholders})", $chunk));
                // Delete only feedback attached to the expired conversation IDs. Do not erase
                // feedback from a different retained conversation belonging to the same visitor.
                $feedback_sql = $wpdb->prepare("DELETE FROM {$feedback} WHERE conversation_id IN ({$placeholders})", $chunk);
                $wpdb->query($feedback_sql);
            }
            $wpdb->query($wpdb->prepare("DELETE FROM {$conversations} WHERE id IN ({$placeholders})", $chunk));
        }
        // Legacy feedback without a conversation link follows the substantive maximum age.
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $feedback)) === $feedback) {
            $wpdb->query($wpdb->prepare("DELETE FROM {$feedback} WHERE conversation_id=0 AND created_at < %s", $long_cutoff));
        }
        // Clean up any orphaned messages left by interrupted/older plugin versions.
        $wpdb->query("DELETE m FROM {$messages} m LEFT JOIN {$conversations} c ON c.id=m.conversation_id WHERE c.id IS NULL");
        return count($expired);
    }

    public static function session_hash($raw) {
        $raw = is_string($raw) ? trim($raw) : '';
        if (!preg_match('/^[a-f0-9-]{32,64}$/i', $raw)) return '';
        return hash_hmac('sha256', strtolower($raw), wp_salt('auth'));
    }

    public static function conversation($session_hash, $visitor_hash = '') {
        if (!$session_hash) return 0;
        // Cleanup runs on its scheduled job, never in the synchronous chat request.
        // Avoids a full retention scan delaying every visitor message.
        global $wpdb;
        $table = $wpdb->prefix . 'hc_ai_conversations';
        $id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE session_hash=%s ORDER BY updated_at DESC,id DESC LIMIT 1",
            $session_hash
        ));
        if ($id) { $update=array('status'=>'active','user_id'=>get_current_user_id(),'updated_at'=>current_time('mysql'));$formats=array('%s','%d','%s');if($visitor_hash){$update['visitor_hash']=$visitor_hash;$formats[]='%s';}$wpdb->update($table,$update,array('id'=>$id),$formats,array('%d')); return $id; }
        $now = current_time('mysql');
        $wpdb->insert($table, array(
            'session_hash' => $session_hash,
            'visitor_hash' => $visitor_hash,
            'user_id' => get_current_user_id(),
            'title' => 'New conversation',
            'status' => 'active',
            'message_count' => 0,
            'created_at' => $now,
            'updated_at' => $now
        ), array('%s','%s','%d','%s','%s','%d','%s','%s'));
        $new_id = (int) $wpdb->insert_id;
        // Retention cleanup is handled by the scheduled maintenance job. Never run a
        // full-table cleanup scan inside a visitor's message-send request.
        return $new_id;
    }

    public static function history($conversation_id, $limit = 8) {
        global $wpdb;
        $table = $wpdb->prefix . 'hc_ai_messages';
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT role, content FROM {$table} WHERE conversation_id=%d AND role IN ('user','assistant') ORDER BY id DESC LIMIT %d",
            $conversation_id, max(2, min(40, (int)$limit))
        ), ARRAY_A);
        return array_reverse(is_array($rows) ? $rows : array());
    }

    public static function client_history($session_hash, $limit = 80, $visitor_hash = '') {
        if (!$session_hash && !$visitor_hash) return array('conversation_id' => 0, 'messages' => array());
        global $wpdb;
        $conversations = $wpdb->prefix . 'hc_ai_conversations';
        $messages = $wpdb->prefix . 'hc_ai_messages';
        $conversation_id = $session_hash ? (int) $wpdb->get_var($wpdb->prepare(
            "SELECT c.id FROM {$conversations} c WHERE c.session_hash=%s AND EXISTS (SELECT 1 FROM {$messages} m WHERE m.conversation_id=c.id AND m.role IN ('user','assistant')) ORDER BY c.updated_at DESC,c.id DESC LIMIT 1",
            $session_hash
        )) : 0;
        if (!$conversation_id && $visitor_hash) {
            $conversation_id = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT c.id FROM {$conversations} c WHERE c.visitor_hash=%s AND EXISTS (SELECT 1 FROM {$messages} m WHERE m.conversation_id=c.id AND m.role IN ('user','assistant')) ORDER BY c.updated_at DESC,c.id DESC LIMIT 1",
                $visitor_hash
            ));
        }
        if (!$conversation_id) return array('conversation_id' => 0, 'messages' => array());
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, role, content, sources, created_at FROM {$messages} WHERE conversation_id=%d AND role IN ('user','assistant') ORDER BY id DESC LIMIT %d",
            $conversation_id, max(2, min(100, (int) $limit))
        ), ARRAY_A);
        $rows = array_reverse(is_array($rows) ? $rows : array());
        $out = array();
        foreach ($rows as $row) {
            $decoded = !empty($row['sources']) ? json_decode($row['sources'], true) : array();
            $out[] = array(
                'id' => (int) $row['id'],
                'role' => $row['role'] === 'user' ? 'user' : 'assistant',
                'content' => (string) $row['content'],
                'sources' => is_array($decoded) ? array_values(array_filter($decoded, function($source) {
                    return is_array($source) && !empty($source['title']) && !empty($source['url']) && wp_http_validate_url($source['url']);
                })) : array(),
                'created_at' => (string) $row['created_at'],
            );
        }
        return array('conversation_id' => $conversation_id, 'messages' => $out);
    }

    public static function save_message($conversation_id, $role, $content, $sources = array(), $session_hash = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'hc_ai_messages';
        $safe_content = sanitize_textarea_field((string) $content);
        $wpdb->insert($table, array(
            'conversation_id' => (int)$conversation_id,
            'role' => $role,
            'content' => $safe_content,
            'sources' => $sources ? wp_json_encode($sources) : null,
            'created_at' => current_time('mysql')
        ), array('%d','%s','%s','%s','%s'));
        $message_id = (int) $wpdb->insert_id;
        if (!$message_id) return 0;
        $conversations = $wpdb->prefix . 'hc_ai_conversations';
        if ($role === 'user') {
            $existing_title = (string) $wpdb->get_var($wpdb->prepare("SELECT title FROM {$conversations} WHERE id=%d", (int) $conversation_id));
            if ($existing_title === '' || $existing_title === 'New conversation') {
                $title = wp_trim_words($safe_content, 9, '…');
                $wpdb->update($conversations, array('title' => $title ?: 'New conversation'), array('id' => (int) $conversation_id), array('%s'), array('%d'));
            }
        }
        // Increment atomically instead of counting every row on every message.
        $wpdb->query($wpdb->prepare(
            "UPDATE {$conversations} SET message_count=message_count+1,updated_at=%s WHERE id=%d",
            current_time('mysql'), (int)$conversation_id
        ));
        if ($session_hash && class_exists('HC_Realtime') && $role === 'assistant') {
            HC_Realtime::publish_ai_message_event($session_hash, (int)$conversation_id, $message_id, $role);
        }
        return $message_id;
    }

    public static function feedback() {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'hc_ai_public')) {
            wp_send_json_error(array('message' => 'Please refresh and try again.'), 403);
        }
        $hash = self::session_hash(sanitize_text_field(wp_unslash($_POST['session_id'] ?? '')));
        $rating = sanitize_key(wp_unslash($_POST['rating'] ?? ''));
        if (!$hash || !in_array($rating, array('helpful','not_helpful'), true)) {
            wp_send_json_error(array('message' => 'Invalid feedback.'));
        }
        global $wpdb;
        $conversation_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}hc_ai_conversations WHERE session_hash=%s ORDER BY updated_at DESC,id DESC LIMIT 1",
            $hash
        ));
        if (!$conversation_id) wp_send_json_error(array('message' => 'Conversation not found. Please refresh and try again.'), 404);
        $question = sanitize_textarea_field(wp_unslash($_POST['question'] ?? ''));
        $answer = sanitize_textarea_field(wp_unslash($_POST['answer'] ?? ''));
        $sources_raw = sanitize_textarea_field(wp_unslash($_POST['source_urls'] ?? ''));
        $source_details_raw = wp_unslash($_POST['sources_json'] ?? '[]');
        $source_details_input = json_decode(is_string($source_details_raw) ? $source_details_raw : '[]', true);
        // Keep only validated HTTP(S) source URLs, capped to avoid oversized feedback payloads.
        $source_urls = array();
        $source_details = array();
        if (is_array($source_details_input)) {
            foreach (array_slice($source_details_input, 0, 8) as $source) {
                if (!is_array($source) || empty($source['url'])) continue;
                $url = esc_url_raw((string)$source['url']);
                if (!$url || !wp_http_validate_url($url) || !preg_match('#^https?://#i', $url)) continue;
                $source_details[] = array('title' => sanitize_text_field($source['title'] ?? 'Help article'), 'url' => $url, 'score' => isset($source['score']) && is_numeric($source['score']) ? round((float)$source['score'], 5) : null);
            }
        }
        foreach (array_slice(preg_split('/\r\n|\r|\n/', $sources_raw), 0, 8) as $url) {
            $url = esc_url_raw(trim($url));
            if ($url && wp_http_validate_url($url) && preg_match('#^https?://#i', $url)) $source_urls[] = $url;
        }
        $wpdb->insert($wpdb->prefix . 'hc_ai_feedback', array(
            'conversation_id' => $conversation_id,
            'session_hash' => $hash,
            'rating' => $rating,
            'comment' => sanitize_textarea_field(wp_unslash($_POST['comment'] ?? '')),
            'question' => mb_substr($question, 0, 1200),
            'answer' => mb_substr($answer, 0, 12000),
            'source_urls' => wp_json_encode(array_values(array_unique($source_urls))),
            'source_details' => wp_json_encode($source_details),
            'status' => 'new',
            'created_at' => current_time('mysql')
        ), array('%d','%s','%s','%s','%s','%s','%s','%s','%s'));
        if (!$wpdb->insert_id) wp_send_json_error(array('message' => 'Feedback could not be saved. Please try again.'), 500);
        wp_send_json_success(array('message' => 'Thank you for your feedback.'));
    }

    /** Admin-only workflow for triaging feedback and marking improvements. */
    public static function feedback_status() {
        if (!current_user_can('manage_options')) wp_die('You are not allowed to update AI feedback.', 403);
        $id = absint($_GET['id'] ?? 0);
        $status = sanitize_key(wp_unslash($_GET['status'] ?? ''));
        check_admin_referer('hc_ai_feedback_status_' . $id);
        if (!$id || !in_array($status, array('new','reviewed','improved'), true)) wp_die('Invalid feedback status.', 400);
        global $wpdb;
        $wpdb->update($wpdb->prefix . 'hc_ai_feedback', array('status' => $status), array('id' => $id), array('%s'), array('%d'));
        $redirect = wp_get_referer();
        if (!$redirect) $redirect = admin_url();
        wp_safe_redirect($redirect . '#hc-ai-feedback-review');
        exit;
    }
}
