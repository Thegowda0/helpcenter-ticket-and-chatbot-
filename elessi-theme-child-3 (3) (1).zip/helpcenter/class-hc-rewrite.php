<?php
/**
 * Help Center - URL Routing (frontend + admin)
 */

if (!defined('ABSPATH')) exit;

class HC_Rewrite {

    public static function register() {

        // ============================================
        // FRONTEND
        // ============================================
        // Generated public discovery endpoints.
        add_rewrite_rule('^helpcenter-sitemap\.xml$', 'index.php?hc_page=sitemap', 'top');
        add_rewrite_rule('^llms\.txt$', 'index.php?hc_page=llms', 'top');

        // Public all-categories page (must be registered before the Help Center fallback).
        add_rewrite_rule('(?i)^categories/?$', 'index.php?hc_page=categories-all', 'top');
        add_rewrite_rule('^helpcenter/?$', 'index.php?hc_page=home', 'top');
        add_rewrite_rule('^helpcenter/category/([^/]+)/?$', 'index.php?hc_page=category&hc_category=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/article/([^/]+)/?$',  'index.php?hc_page=article&hc_article=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/search/?$',           'index.php?hc_page=search', 'top');
        add_rewrite_rule('^helpcenter/latest/?$',           'index.php?hc_page=latest', 'top');
        add_rewrite_rule('^helpcenter/popular/?$',          'index.php?hc_page=popular', 'top');
        add_rewrite_rule('^helpcenter/contact/?$',          'index.php?hc_page=contact', 'top');

        // ============================================
        // ADMIN
        // ============================================
        add_rewrite_rule('^helpcenter/admin/?$', 'index.php?hc_page=admin-dashboard', 'top');
        add_rewrite_rule('^helpcenter/admin/section/([a-z0-9-]+)/?$', 'index.php?hc_page=admin-hub&hc_hub=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/admin/articles/?$', 'index.php?hc_page=admin-articles', 'top');
        add_rewrite_rule('^helpcenter/admin/articles/new/?$', 'index.php?hc_page=admin-article-edit', 'top');
        add_rewrite_rule('^helpcenter/admin/revisions/article/([0-9]+)/?$', 'index.php?hc_page=admin-revisions&hc_revision_type=article&hc_id=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/admin/revisions/faq/([0-9]+)/?$', 'index.php?hc_page=admin-revisions&hc_revision_type=faq&hc_id=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/admin/articles/edit/([0-9]+)/?$', 'index.php?hc_page=admin-article-edit&hc_id=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/admin/popular/?$', 'index.php?hc_page=admin-popular', 'top');
        add_rewrite_rule('^helpcenter/admin/categories/?$', 'index.php?hc_page=admin-categories', 'top');
        add_rewrite_rule('^helpcenter/admin/categories/new/?$', 'index.php?hc_page=admin-category-edit', 'top');
        add_rewrite_rule('^helpcenter/admin/categories/edit/([0-9]+)/?$', 'index.php?hc_page=admin-category-edit&hc_id=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/admin/faqs/?$', 'index.php?hc_page=admin-faqs', 'top');
        add_rewrite_rule('^helpcenter/admin/faqs/new/?$', 'index.php?hc_page=admin-faq-edit', 'top');
        add_rewrite_rule('^helpcenter/admin/faqs/edit/([0-9]+)/?$', 'index.php?hc_page=admin-faq-edit&hc_id=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/admin/search-log/?$', 'index.php?hc_page=admin-search-log', 'top');
        add_rewrite_rule('^helpcenter/admin/seo-audit/?$', 'index.php?hc_page=admin-seo-audit', 'top');
        add_rewrite_rule('^helpcenter/admin/performance-audit/?$', 'index.php?hc_page=admin-performance-audit', 'top');
        add_rewrite_rule('^helpcenter/admin/ai-platform/?$', 'index.php?hc_page=admin-ai-platform', 'top');
        add_rewrite_rule('^helpcenter/admin/human-support/?$', 'index.php?hc_page=admin-human-support', 'top');
        add_rewrite_rule('^helpcenter/admin/agents/?$', 'index.php?hc_page=admin-agents', 'top');
        add_rewrite_rule('^helpcenter/agent/?$', 'index.php?hc_page=agent-portal', 'top');
        add_rewrite_rule('^helpcenter/agent/login/?$', 'index.php?hc_page=agent-login', 'top');
        add_rewrite_rule('^helpcenter/agent/forgot-password/?$', 'index.php?hc_page=agent-forgot', 'top');
        add_rewrite_rule('^helpcenter/agent/reset-password/?$', 'index.php?hc_page=agent-reset', 'top');
        add_rewrite_rule('^support-agent/?$', 'index.php?hc_page=agent-portal', 'top');
        add_rewrite_rule('^support-agent/login/?$', 'index.php?hc_page=agent-login', 'top');
        add_rewrite_rule('^support-agent/forgot-password/?$', 'index.php?hc_page=agent-forgot', 'top');
        add_rewrite_rule('^support-agent/reset-password/?$', 'index.php?hc_page=agent-reset', 'top');
        add_rewrite_rule('^helpcenter/admin/settings/([a-z0-9-]+)/?$', 'index.php?hc_page=admin-settings&hc_settings_section=$matches[1]', 'top');
        add_rewrite_rule('^helpcenter/admin/settings/?$',   'index.php?hc_page=admin-settings&hc_settings_section=general', 'top');
        add_rewrite_rule('^helpcenter/admin/web-push/?$', 'index.php?hc_page=admin-web-push', 'top');

        // Fallback
        add_rewrite_rule('^helpcenter/(.*)/?$', 'index.php?hc_page=404', 'top');
    }

    public static function add_query_vars($vars) {
        $vars[] = 'hc_page';
        $vars[] = 'hc_category';
        $vars[] = 'hc_article';
        $vars[] = 'hc_id';
        $vars[] = 'hc_revision_type';
        $vars[] = 'hc_endpoint';
        $vars[] = 'hc_hub';
        $vars[] = 'hc_settings_section';
        return $vars;
    }
}

// Register query vars filter
add_filter('query_vars', array('HC_Rewrite', 'add_query_vars'));
