<?php
/**
 * Help Center - Admin Assets Loader
 * Loads only on /helpcenter/admin/* pages.
 */

if (!defined('ABSPATH')) exit;

class HC_Admin_Assets {

    public static function init() {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue'), 999);
    }

    public static function enqueue() {
        if (!self::is_admin_page()) return;

        self::strip_theme_assets();

        // Font Awesome
        wp_enqueue_style(
            'hc-fontawesome-admin',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.3.1/css/all.min.css',
            array(),
            '7.3.1'
        );

        // Google Fonts — Inter
        wp_enqueue_style(
            'hc-google-fonts-admin',
            'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
            array(),
            null
        );

        // Admin CSS
        $css_file = HC_PATH . 'assets/css/admin.css';
        if (file_exists($css_file)) {
            wp_enqueue_style(
                'hc-admin-css',
                HC_ASSETS . 'css/admin.css',
                array('hc-fontawesome-admin', 'hc-google-fonts-admin'),
                filemtime($css_file)
            );
        }

        wp_enqueue_script('jquery');

        // Admin JS
        $js_file = HC_PATH . 'assets/js/admin.js';
        if (file_exists($js_file)) {
            wp_enqueue_script(
                'hc-admin-js',
                HC_ASSETS . 'js/admin.js',
                array('jquery'),
                filemtime($js_file),
                true
            );

            wp_localize_script('hc-admin-js', 'hcAdmin', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('hc_nonce'),
                'homeUrl' => home_url('/helpcenter/admin/'),
            ));
        }
    }

    public static function is_admin_page() {
        $page = get_query_var('hc_page');
        return $page && strpos($page, 'admin-') === 0;
    }

    private static function strip_theme_assets() {
        global $wp_styles, $wp_scripts;

        $keep_styles = array('hc-fontawesome-admin', 'hc-google-fonts-admin', 'hc-admin-css', 'admin-bar', 'dashicons');
        $keep_scripts = array('jquery', 'jquery-core', 'jquery-migrate', 'admin-bar', 'hc-admin-js');

        if (isset($wp_styles->queue) && is_array($wp_styles->queue)) {
            foreach ($wp_styles->queue as $h) {
                if (!in_array($h, $keep_styles)) {
                    wp_dequeue_style($h);
                    wp_deregister_style($h);
                }
            }
        }
        if (isset($wp_scripts->queue) && is_array($wp_scripts->queue)) {
            foreach ($wp_scripts->queue as $h) {
                if (!in_array($h, $keep_scripts)) {
                    wp_dequeue_script($h);
                    wp_deregister_script($h);
                }
            }
        }

    }
}

HC_Admin_Assets::init();
