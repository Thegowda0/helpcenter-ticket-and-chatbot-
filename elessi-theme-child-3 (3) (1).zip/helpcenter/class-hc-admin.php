<?php
/**
 * Help Center - Admin Router (loads admin templates + handles redirects)
 */

if (!defined('ABSPATH')) exit;

class HC_Admin {

    public static function init() {
        // Nothing to hook — routing handled by HC_Rewrite + main router in helpcenter.php
        // This class exists so admin templates can call helper methods
    }

    // =============================================
    // MENU ITEMS (rendered inside admin/wrapper.php)
    // =============================================
    public static function menu_items() {
        return array(
            array(
                'id'    => 'dashboard',
                'label' => 'Dashboard',
                'url'   => home_url('/helpcenter/admin/'),
                'icon'  => 'fa-chart-pie',
                'pages' => array('admin-dashboard'),
            ),
            array(
                'id'    => 'articles',
                'label' => 'Articles',
                'url'   => home_url('/helpcenter/admin/articles/'),
                'icon'  => 'fa-file-lines',
                'pages' => array('admin-articles', 'admin-article-edit'),
            ),
            array(
                'id'    => 'popular',
                'label' => 'Popular Articles',
                'url'   => home_url('/helpcenter/admin/popular/'),
                'icon'  => 'fa-fire',
                'pages' => array('admin-popular'),
            ),
            array(
                'id'    => 'categories',
                'label' => 'Categories',
                'url'   => home_url('/helpcenter/admin/categories/'),
                'icon'  => 'fa-folder-tree',
                'pages' => array('admin-categories', 'admin-category-edit'),
            ),
            array(
                'id'    => 'faqs',
                'label' => 'FAQs',
                'url'   => home_url('/helpcenter/admin/faqs/'),
                'icon'  => 'fa-circle-question',
                'pages' => array('admin-faqs', 'admin-faq-edit'),
            ),
            array(
                'id'    => 'search-log',
                'label' => 'Search Log',
                'url'   => home_url('/helpcenter/admin/search-log/'),
                'icon'  => 'fa-magnifying-glass-chart',
                'pages' => array('admin-search-log'),
            ),
            array(
                'id'    => 'seo-audit',
                'label' => 'SEO Audit',
                'url'   => home_url('/helpcenter/admin/seo-audit/'),
                'icon'  => 'fa-clipboard-check',
                'pages' => array('admin-seo-audit'),
            ),
            array(
                'id'    => 'performance-audit',
                'label' => 'Performance & Security',
                'url'   => home_url('/helpcenter/admin/performance-audit/'),
                'icon'  => 'fa-shield-halved',
                'pages' => array('admin-performance-audit'),
            ),
            array(
                'id'    => 'ai-platform',
                'label' => 'AI Platform',
                'url'   => home_url('/helpcenter/admin/ai-platform/'),
                'icon'  => 'fa-brain',
                'pages' => array('admin-ai-platform'),
            ),
            array(
                'id'    => 'human-support',
                'label' => 'Human Support',
                'url'   => home_url('/helpcenter/admin/human-support/'),
                'icon'  => 'fa-headset',
                'pages' => array('admin-human-support'),
            ),
            array(
                'id'    => 'agents',
                'label' => 'Support Agents',
                'url'   => home_url('/helpcenter/admin/agents/'),
                'icon'  => 'fa-users',
                'pages' => array('admin-agents'),
            ),
            array(
                'id'    => 'settings',
                'label' => 'Settings',
                'url'   => home_url('/helpcenter/admin/settings/'),
                'icon'  => 'fa-cog',
                'pages' => array('admin-settings'),
            ),
        );
    }

    // =============================================
    // ADMIN COUNTS (sidebar badges)
    // =============================================
    public static function get_counts() {
        global $wpdb;
        $support_table = $wpdb->prefix . 'hc_ai_escalations';
        $support_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $support_table)) === $support_table;
        return array(
            'articles'   => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles"),
            'categories' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_categories"),
            'faqs'       => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hc_faqs"),
            'support'    => $support_exists ? (int) $wpdb->get_var("SELECT COUNT(*) FROM {$support_table} WHERE status IN ('queued','active','waiting_agent','waiting_customer','pending_email')") : 0,
        );
    }

    // =============================================
    // NOTICES (from ?msg= query param)
    // =============================================
    public static function render_notice() {
        if (empty($_GET['msg'])) return;
        $msg  = sanitize_text_field($_GET['msg']);
        $type = sanitize_text_field($_GET['type'] ?? 'success');
        $class = $type === 'error' ? 'hc-notice-error' : 'hc-notice-success';
        echo '<div class="hc-admin-notice ' . esc_attr($class) . '">' . esc_html($msg) . '</div>';
    }
}

HC_Admin::init();
