<?php
/**
 * Help Center - AJAX Handlers (frontend + admin, single file)
 */

if (!defined('ABSPATH')) exit;

class HC_Ajax {

    public static function register() {
        add_action('admin_post_hc_export_search_analytics', array(__CLASS__, 'export_search_analytics'));
        // Public
        add_action('wp_ajax_nopriv_hc_search',         array(__CLASS__, 'search'));
        add_action('wp_ajax_hc_search',                array(__CLASS__, 'search'));
        add_action('wp_ajax_nopriv_hc_track_search_click', array(__CLASS__, 'track_search_click'));
        add_action('wp_ajax_hc_track_search_click', array(__CLASS__, 'track_search_click'));
        add_action('wp_ajax_nopriv_hc_helpful_vote',   array(__CLASS__, 'helpful_vote'));
        add_action('wp_ajax_hc_helpful_vote',          array(__CLASS__, 'helpful_vote'));
        add_action('wp_ajax_nopriv_hc_contact_submit', array(__CLASS__, 'contact_submit'));
        add_action('wp_ajax_hc_contact_submit',        array(__CLASS__, 'contact_submit'));

        // Admin
        add_action('wp_ajax_hc_refresh_nonce', array(__CLASS__, 'refresh_admin_nonce'));
        add_action('wp_ajax_hc_save_category',  array(__CLASS__, 'save_category'));
        add_action('wp_ajax_hc_save_category_order', array(__CLASS__, 'save_category_order'));
        add_action('wp_ajax_hc_delete_category',array(__CLASS__, 'delete_category'));
        add_action('wp_ajax_hc_check_bulk_articles_categories', array(__CLASS__, 'check_bulk_articles_categories'));
        add_action('wp_ajax_hc_check_categories_status', array(__CLASS__, 'check_categories_status'));
        add_action('wp_ajax_hc_save_article',   array(__CLASS__, 'save_article'));
        add_action('wp_ajax_hc_autosave_article', array(__CLASS__, 'autosave_article'));
        add_action('wp_ajax_hc_autosave_faq', array(__CLASS__, 'autosave_faq'));
        add_action('wp_ajax_hc_restore_revision', array(__CLASS__, 'restore_revision'));
        add_action('wp_ajax_hc_delete_article', array(__CLASS__, 'delete_article'));
        add_action('wp_ajax_hc_save_faq',       array(__CLASS__, 'save_faq'));
        add_action('wp_ajax_hc_delete_faq',     array(__CLASS__, 'delete_faq'));
        add_action('wp_ajax_hc_save_settings',  array(__CLASS__, 'save_settings'));
        add_action('wp_ajax_hc_save_popular_order', array(__CLASS__, 'save_popular_order'));
        add_action('wp_ajax_hc_popular_search', array(__CLASS__, 'popular_search'));
        add_action('wp_ajax_hc_add_popular_article', array(__CLASS__, 'add_popular_article'));
        add_action('wp_ajax_hc_remove_popular_article', array(__CLASS__, 'remove_popular_article'));
        add_action('wp_ajax_hc_delete_search_log', array(__CLASS__, 'delete_search_log'));
        add_action('wp_ajax_hc_get_subcategories', array(__CLASS__, 'get_subcategories'));
        add_action('wp_ajax_hc_admin_search_articles', array(__CLASS__, 'admin_search_articles'));
        add_action('wp_ajax_hc_admin_tab_counts', array(__CLASS__, 'admin_tab_counts'));
        add_action('wp_ajax_hc_admin_search_faqs',     array(__CLASS__, 'admin_search_faqs'));
        add_action('wp_ajax_hc_admin_search_categories', array(__CLASS__, 'admin_search_categories'));
        add_action('wp_ajax_hc_bulk_articles',   array(__CLASS__, 'bulk_articles'));
        add_action('wp_ajax_hc_bulk_faqs',       array(__CLASS__, 'bulk_faqs'));
        add_action('wp_ajax_hc_bulk_categories', array(__CLASS__, 'bulk_categories'));
        // Trash: restore + hard delete + empty trash
        add_action('wp_ajax_hc_restore_article',   array(__CLASS__, 'restore_article'));
        add_action('wp_ajax_hc_restore_faq',       array(__CLASS__, 'restore_faq'));
        add_action('wp_ajax_hc_restore_category',  array(__CLASS__, 'restore_category'));
        add_action('wp_ajax_hc_hard_delete_article',  array(__CLASS__, 'hard_delete_article'));
        add_action('wp_ajax_hc_hard_delete_faq',      array(__CLASS__, 'hard_delete_faq'));
        add_action('wp_ajax_hc_hard_delete_category', array(__CLASS__, 'hard_delete_category'));
        add_action('wp_ajax_hc_empty_trash',       array(__CLASS__, 'empty_trash'));
    }


    /** Export selected-period search activity as CSV (administrator only). */
    public static function export_search_analytics() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized', 403);
        check_admin_referer('hc_export_search_analytics');
        global $wpdb;
        $days = absint($_GET['days'] ?? 30);
        if (!in_array($days, array(7, 30, 90, 365), true)) $days = 30;
        $cutoff = date('Y-m-d H:i:s', current_time('timestamp') - ($days * DAY_IN_SECONDS));
        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT MIN(l.search_query) AS search_query,COUNT(*) AS searches,ROUND(AVG(l.results_count),1) AS avg_results,MAX(l.created_at) AS last_searched,COALESCE(c.clicks,0) AS clicks FROM {$wpdb->prefix}hc_search_log l LEFT JOIN (SELECT LOWER(TRIM(search_query)) AS query_key,COUNT(*) AS clicks FROM {$wpdb->prefix}hc_search_clicks WHERE created_at >= %s GROUP BY LOWER(TRIM(search_query))) c ON c.query_key=LOWER(TRIM(l.search_query)) WHERE l.created_at >= %s GROUP BY LOWER(TRIM(l.search_query)),c.clicks ORDER BY searches DESC,last_searched DESC",
            $cutoff, $cutoff
        ), ARRAY_A);
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="help-center-search-analytics-' . $days . '-days.csv"');
        $out = fopen('php://output', 'w');
        // UTF-8 BOM improves compatibility with Excel.
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, array('Search phrase','Searches','Average results','Search-result clicks','Last searched'));
        foreach ((array) $logs as $row) {
            $cells = array($row['search_query'], (int)$row['searches'], (float)$row['avg_results'], (int)$row['clicks'], $row['last_searched']);
            // Prevent spreadsheet formula execution from visitor-supplied search text.
            if (isset($cells[0][0]) && in_array($cells[0][0], array('=', '+', '-', '@', "\t", "\r"), true)) $cells[0] = "'" . $cells[0];
            fputcsv($out, $cells);
        }
        fclose($out);
        exit;
    }

    /** Return a fresh admin nonce to recover from cached admin pages. */
    public static function refresh_admin_nonce() {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You must be logged in as an administrator. Please reload the page.'), 403);
        }
        wp_send_json_success(array('nonce' => wp_create_nonce('hc_nonce')));
    }

    // =============================================
    // HELPERS
    // =============================================
    private static function check_public() {
        check_ajax_referer('hc_nonce', 'nonce');
    }

    private static function check_admin() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized'), 403);
        }
        if (!wp_verify_nonce($_REQUEST['nonce'] ?? '', 'hc_nonce')) {
            wp_send_json_error(array('message' => 'Nonce failed. Please refresh the page and try again.'), 403);
        }
    }

    // =============================================
    // FRONTEND: LIVE SEARCH
    // =============================================
    public static function search() {
        // Public, read-only search: do not reject cached pages whose public nonce expired.
        // Rate limiting and query sanitization remain in place; no data is mutated.
        $q = isset($_POST['query']) ? HC_Core::normalize_search_query(wp_unslash($_POST['query'])) : '';

        if ((function_exists('mb_strlen') ? mb_strlen(trim($q)) : strlen(trim($q))) < 2) {
            wp_send_json_success(array('results' => array()));
        }

        $results = HC_Core::search_articles($q, 6, 0);
        // Live suggestions are not logged: only an explicit search submission represents intent.

        $formatted = array();
        foreach ($results as $r) {
            $formatted[] = array(
                'id'            => (int) $r->id,
                'title'         => $r->title,
                'excerpt'       => wp_trim_words($r->excerpt, 15),
                'slug'          => $r->slug,
                'category_name' => $r->category_name ?: 'General',
                'url'           => home_url('/helpcenter/article/' . $r->slug . '/'),
            );
        }

        wp_send_json_success(array('results' => $formatted));
    }

    /** Record a result click without storing raw visitor IP addresses. */
    public static function track_search_click() {
        global $wpdb;
        $article_id = absint($_POST['article_id'] ?? 0);
        $query = HC_Core::normalize_search_query(wp_unslash($_POST['query'] ?? ''));
        if (!$article_id || mb_strlen($query) < 2) wp_send_json_error(array('message' => 'Invalid click data'), 400);
        $article = HC_Core::get_article($article_id);
        if (!$article || !HC_Lifecycle::article_is_live($article_id)) wp_send_json_error(array('message' => 'Article unavailable'), 404);
        $raw_ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');
        $visitor = $raw_ip ? substr(hash_hmac('sha256', $raw_ip, wp_salt('auth')), 0, 40) : '';
        $dedupe = 'hc_click_' . md5($visitor . '|' . $article_id . '|' . strtolower($query));
        if (!get_transient($dedupe)) {
            $wpdb->insert($wpdb->prefix . 'hc_search_clicks', array(
                'article_id' => $article_id,
                'search_query' => $query,
                'visitor_hash' => $visitor,
                'created_at' => current_time('mysql'),
            ));
            set_transient($dedupe, 1, 30);
        }
        wp_send_json_success(array('recorded' => true));
    }

    // =============================================
    // FRONTEND: HELPFUL VOTE
    // =============================================
    public static function helpful_vote() {
        self::check_public();

        $article_id = isset($_POST['article_id']) ? (int) $_POST['article_id'] : 0;
        $vote       = isset($_POST['vote']) ? sanitize_text_field($_POST['vote']) : '';
        $reason     = isset($_POST['reason']) ? sanitize_text_field($_POST['reason']) : '';

        if (!$article_id || !in_array($vote, array('yes', 'no'))) {
            wp_send_json_error(array('message' => 'Invalid input'));
        }

        $article = HC_Core::get_article($article_id);
        if (!$article) wp_send_json_error(array('message' => 'Article not found'));

        global $wpdb;
        $table = $wpdb->prefix . 'hc_helpful_votes';
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';

        // One vote per IP per article
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE article_id = %d AND user_ip = %s",
            $article_id, $ip
        ));
        if ($existing) {
            wp_send_json_error(array('message' => 'You have already voted'));
        }

        $wpdb->insert($table, array(
            'article_id' => $article_id,
            'user_ip'    => $ip,
            'user_id'    => get_current_user_id(),
            'vote'       => $vote,
            'reason'     => $reason ?: null,
            'created_at' => current_time('mysql'),
        ));

        $col = $vote === 'yes' ? 'helpful_yes' : 'helpful_no';
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}hc_articles SET $col = $col + 1 WHERE id = %d",
            $article_id
        ));

        $updated = HC_Core::get_article($article_id);

        wp_send_json_success(array(
            'new_counts' => array(
                'yes' => (int) $updated->helpful_yes,
                'no'  => (int) $updated->helpful_no,
            ),
        ));
    }

    // =============================================
    // FRONTEND: CONTACT FORM
    // =============================================
    public static function contact_submit() {
        self::check_public();

        $name     = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        $email    = sanitize_email($_POST['email'] ?? '');
        $subject  = sanitize_text_field(wp_unslash($_POST['subject'] ?? ''));
        $message  = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));

        if (!$name || !$email || !$subject || !$message) {
            wp_send_json_error(array('message' => 'Please fill in all required fields'));
        }
        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email address'));
        }

        // Double-submit guard: same email + subject within 30s → skip
        $dedup_key = 'hc_contact_dedup_' . md5(strtolower($email) . '|' . $subject . '|' . md5($message));
        if (get_transient($dedup_key)) {
            wp_send_json_success(array(
                'message' => 'Your message has already been received. We\'ll reply within 24 hours.'
            ));
        }
        set_transient($dedup_key, 1, 30);

        // Attachment
        $attachment_path = '';
        $attachment_url  = '';
        if (!empty($_FILES['attachment']['name']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            $max_mb   = (int) HC_Core::get_setting('hc_contact_max_mb', 5);
            $max_size = $max_mb * 1024 * 1024;
            $allowed  = array('image/jpeg', 'image/png', 'application/pdf');

            if ($_FILES['attachment']['size'] > $max_size) {
                wp_send_json_error(array('message' => 'File exceeds ' . $max_mb . 'MB limit'));
            }
            if (!in_array($_FILES['attachment']['type'], $allowed)) {
                wp_send_json_error(array('message' => 'Only JPG, PNG, PDF allowed'));
            }

            require_once ABSPATH . 'wp-admin/includes/file.php';
            $upload = wp_handle_upload($_FILES['attachment'], array('test_form' => false));
            if ($upload && !isset($upload['error'])) {
                $attachment_url  = $upload['url'];
                $attachment_path = $upload['file'];
            }
        }

        // Admin email — prefer ticket system, fallback to HC setting
        global $wpdb;
        $admin_to   = '';
        $ticket_tbl = $wpdb->prefix . 'hck_ticket_settings';
        if ($wpdb->get_var("SHOW TABLES LIKE '$ticket_tbl'") === $ticket_tbl) {
            $admin_to = (string) $wpdb->get_var(
                "SELECT setting_value FROM $ticket_tbl
                 WHERE setting_key IN ('hck_support_email','support_email')
                 ORDER BY id ASC LIMIT 1"
            );
        }
        if (!$admin_to || !is_email($admin_to)) {
            $admin_to = HC_Core::get_setting('hc_contact_email', get_option('admin_email'));
        }

        $site_name  = get_bloginfo('name');
        $from_name  = $site_name . ' Support';
        $from_email = 'no-reply@' . preg_replace('#^https?://#', '', home_url('/'));
        $from_email = str_replace('/', '', $from_email);

        // ---- EMAIL 1: CUSTOMER confirmation (HTML) ----
        $cust_subject = 'We received your message — ' . $site_name;

        $safe_name    = esc_html($name);
        $safe_subject = esc_html($subject);
        $safe_message = nl2br(esc_html($message));
        $safe_site    = esc_html($site_name);

        $attachment_row = '';
        if ($attachment_url) {
            $attachment_row = '
              <tr>
                <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%">Attachment</td>
                <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px"><a href="' . esc_url($attachment_url) . '" style="color:#4F46E5;text-decoration:none">View file</a></td>
              </tr>';
        }

        $cust_body = '<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#F1F5F9;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F1F5F9;padding:40px 16px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;background:#FFFFFF;border-radius:16px;overflow:hidden;box-shadow:0 4px 12px rgba(15,23,42,0.06)">
  <tr><td style="background:linear-gradient(135deg,#4F46E5 0%,#6366F1 100%);padding:32px 28px;text-align:center">
    <table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto 12px">
      <tr><td style="background:rgba(255,255,255,0.15);border-radius:12px;padding:10px;text-align:center">
        <span style="font-size:22px;color:#FFFFFF">✉</span>
      </td></tr>
    </table>
    <h1 style="color:#FFFFFF;margin:0 0 6px;font-size:22px;font-weight:700;letter-spacing:-0.3px">We received your message</h1>
    <p style="color:#E0E7FF;margin:0;font-size:14px">Our team will reply within 24 hours</p>
  </td></tr>
  <tr><td style="padding:36px 32px">

<p style="font-size:16px;color:#0F172A;margin:0 0 8px;font-weight:600">Hi ' . $safe_name . ',</p>
<p style="font-size:14px;color:#475569;line-height:1.6;margin:0 0 24px">Thanks for contacting us. We\'ve received your message and will get back to you shortly. Here\'s a copy of what you sent:</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;margin:0 0 24px;border-collapse:separate;overflow:hidden">
  <tr>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;width:42%">Subject</td>
    <td style="padding:14px 18px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:14px;font-weight:600">' . $safe_subject . '</td>
  </tr>
  <tr>
    <td style="padding:14px 18px;' . ($attachment_row ? 'border-bottom:1px solid #E2E8F0;' : '') . 'font-weight:600;color:#64748B;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">Message</td>
    <td style="padding:14px 18px;' . ($attachment_row ? 'border-bottom:1px solid #E2E8F0;' : '') . 'color:#0F172A;font-size:14px;line-height:1.6">' . $safe_message . '</td>
  </tr>' . $attachment_row . '
</table>

<p style="font-size:13px;color:#64748B;line-height:1.6;margin:0 0 24px">Please do not reply to this email — it was sent from an unmonitored inbox. Our support team will respond to your message within 24 hours.</p>

<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto 8px">
  <tr><td style="border-radius:10px;background:#4F46E5">
    <a href="' . esc_url(home_url('/helpcenter/')) . '" style="display:inline-block;color:#FFFFFF;padding:14px 32px;text-decoration:none;font-weight:600;font-size:14px;border-radius:10px">Visit Help Center</a>
  </td></tr>
</table>

  </td></tr>
  <tr><td style="padding:20px 32px 24px;text-align:center;border-top:1px solid #F1F5F9">
    <p style="margin:0 0 6px;font-size:12px;color:#94A3B8;line-height:1.5">This email was sent by <strong style="color:#64748B">' . $safe_site . '</strong>. If you didn\'t request this, you can safely ignore it.</p>
    <p style="margin:0;font-size:11px;color:#CBD5E1">&copy; ' . date('Y') . ' ' . $safe_site . '. All rights reserved.</p>
  </td></tr>
</table>
</td></tr>
</table>
</body>
</html>';

        $cust_headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
            'Reply-To: ' . $from_email, // don't expose admin; replies go to no-reply
        );

        // ---- EMAIL 2: ADMIN notification (compact internal) ----
        $admin_subject = '[New Inquiry] ' . $subject;

        $safe_name_a    = esc_html($name);
        $safe_email_a   = esc_html($email);
        $safe_subject_a = esc_html($subject);
        $safe_message_a = nl2br(esc_html($message));
        $safe_site_a    = esc_html($site_name);

        $attachment_row_a = '';
        if ($attachment_url) {
            $attachment_row_a = '
                <tr>
                    <td style="padding:10px 0;color:#52525B;font-size:13px;width:100px;vertical-align:top">Attachment</td>
                    <td style="padding:10px 0;color:#0F172A;font-size:13px"><a href="' . esc_url($attachment_url) . '" style="color:#4F46E5;text-decoration:none">Download file</a></td>
                </tr>';
        }

        $admin_body = '<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#F4F4F5;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F4F4F5;padding:32px 16px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;background:#FFFFFF;border-radius:10px;overflow:hidden;border:1px solid #E4E4E7">
  <tr><td style="background:#0F172A;padding:14px 24px">
    <table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
      <td style="color:#FFFFFF;font-size:13px;font-weight:600;letter-spacing:0.3px">
        <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#EF4444;margin-right:8px;vertical-align:middle"></span>
        New Help Center Inquiry
      </td>
      <td align="right" style="color:#71717A;font-size:12px">' . date('M j, Y · H:i') . ' UTC</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:28px 24px 8px">

<table width="100%" cellpadding="0" cellspacing="0" border="0">
  <tr>
    <td style="padding:8px 0;color:#52525B;font-size:13px;width:100px;vertical-align:top">From</td>
    <td style="padding:8px 0;color:#0F172A;font-size:13px;font-weight:600">' . $safe_name_a . '</td>
  </tr>
  <tr>
    <td style="padding:8px 0;color:#52525B;font-size:13px;vertical-align:top">Email</td>
    <td style="padding:8px 0;color:#0F172A;font-size:13px"><a href="mailto:' . $safe_email_a . '" style="color:#4F46E5;text-decoration:none">' . $safe_email_a . '</a></td>
  </tr>
  <tr>
    <td style="padding:8px 0;color:#52525B;font-size:13px;vertical-align:top">Subject</td>
    <td style="padding:8px 0;color:#0F172A;font-size:13px;font-weight:600">' . $safe_subject_a . '</td>
  </tr>' . $attachment_row_a . '
</table>

  </td></tr>
  <tr><td style="padding:16px 24px 24px">
    <div style="font-size:11px;font-weight:700;color:#71717A;letter-spacing:0.5px;text-transform:uppercase;margin-bottom:8px">Message</div>
    <div style="background:#FAFAFA;border-left:3px solid #E4E4E7;border-radius:0 6px 6px 0;padding:14px 18px;font-size:14px;color:#3F3F46;line-height:1.7;white-space:pre-wrap">' . $safe_message_a . '</div>
  </td></tr>
  <tr><td style="padding:14px 24px 20px;border-top:1px solid #F1F5F9">
    <p style="margin:0;font-size:12px;color:#71717A;line-height:1.55">
      Reply from your mail client — your response goes to ' . $safe_email_a . '.
    </p>
  </td></tr>
</table>
</td></tr>
</table>
</body>
</html>';

        $admin_headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
            'Reply-To: ' . $name . ' <' . $email . '>',
        );

        $admin_attachments = array();
        if ($attachment_path && file_exists($attachment_path)) {
            $admin_attachments[] = $attachment_path;
        }

        $sent_admin    = wp_mail($admin_to, $admin_subject, $admin_body, $admin_headers, $admin_attachments);
        $sent_customer = wp_mail($email,     $cust_subject,  $cust_body,  $cust_headers);

        if ($sent_admin || $sent_customer) {
            wp_send_json_success(array(
                'message' => 'Your message has been sent. Check your inbox for a confirmation — we\'ll reply within 24 hours.'
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to send. Please try again or email us directly.'));
        }
    }

    // =============================================
    // ADMIN: SAVE CATEGORY
    // =============================================
    public static function save_category() {
        self::check_admin();
        global $wpdb;
        $t = $wpdb->prefix . 'hc_categories';

        $id          = (int) ($_POST['id'] ?? 0);
        $name        = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        $slug_in     = sanitize_title(wp_unslash($_POST['slug'] ?? ''));
        $slug        = ($slug_in !== '') ? $slug_in : sanitize_title($name);
        $description = sanitize_textarea_field(wp_unslash($_POST['description'] ?? ''));
        $icon_value  = sanitize_text_field(wp_unslash($_POST['icon_value'] ?? 'fa-folder'));
        $parent_id   = (int) ($_POST['parent_id'] ?? 0);
        $sort_order  = (int) ($_POST['sort_order'] ?? 0);
        $status      = sanitize_key(wp_unslash($_POST['status'] ?? 'published'));
        if ($status === 'draft') $status = 'hidden';
        if (!in_array($status, array('published', 'hidden'), true)) $status = 'published';

        $existing = null;
        if ($id > 0) {
            $existing = HC_Core::get_category($id);
            if (!$existing) {
                wp_send_json_error(array('message' => 'This category was not found or is in the trash. Restore it first.'));
            }
        }

        // The default (Uncategorized) category is locked: only description and icon can change.
        $is_default_cat = ($existing && (int) $existing->is_default === 1);
        if ($is_default_cat) {
            $name       = $existing->name;
            $slug       = $existing->slug;
            $parent_id  = 0;
            $status     = 'published';
            $sort_order = 999;
        }

        if ($name === '') wp_send_json_error(array('message' => 'Name is required'));
        if ($slug === '') wp_send_json_error(array('message' => 'Please use a name or slug that contains letters or numbers'));
        if ($icon_value === '') $icon_value = 'fa-folder';

        // Parent rules (max 2 levels)
        if ($parent_id > 0 && !$is_default_cat) {
            if ($parent_id === $id) {
                wp_send_json_error(array('message' => 'A category cannot be its own parent'));
            }
            $parent = HC_Core::get_category($parent_id);
            if (!$parent) {
                wp_send_json_error(array('message' => 'The selected parent category was not found'));
            }
            if ((int) $parent->parent_id !== 0) {
                wp_send_json_error(array('message' => 'Subcategories cannot have children (max 2 levels)'));
            }
            if ((int) $parent->is_default === 1) {
                wp_send_json_error(array('message' => 'The Uncategorized category cannot have subcategories'));
            }
            if ($id > 0) {
                $kids = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM $t WHERE parent_id = %d AND deleted_at IS NULL", $id
                ));
                if ($kids > 0) {
                    wp_send_json_error(array('message' => 'This category has subcategories, so it cannot become a subcategory itself (max 2 levels)'));
                }
            }
        } else {
            $parent_id = 0;
        }

        // Slug must be unique among active categories (a trashed one is renamed out of the way)
        $base_slug = $slug;
        $suffix = 2;
        while (!HC_Lifecycle::claim_slug('categories', $slug, $id)) {
            $slug = $base_slug . '-' . $suffix;
            $suffix++;
            if ($suffix > 1000) wp_send_json_error(array('message' => 'Could not generate a unique category slug. Please enter a different slug.'));
        }

        $data = array(
            'name'        => $name,
            'slug'        => $slug,
            'description' => $description,
            'icon_type'   => 'fontawesome',
            'icon_value'  => $icon_value,
            'parent_id'   => $parent_id,
            'sort_order'  => $sort_order,
            'status'      => $status,
            'updated_at'  => current_time('mysql'),
        );

        $is_new = ($id === 0);
        if ($is_new) {
            $ok = $wpdb->insert($t, $data);
            $id = (int) $wpdb->insert_id;
        } else {
            $ok = $wpdb->update($t, $data, array('id' => $id));
        }

        if ($ok === false || $wpdb->last_error || $id <= 0) {
            wp_send_json_error(array('message' => 'Could not save the category. ' . $wpdb->last_error));
        }

        // Keep article status aligned when this category's visibility changes.
        HC_Lifecycle::sync_articles_for_category_visibility(HC_Lifecycle::tree_ids($id));
        HC_Lifecycle::recount_categories();

        if ($is_new) {
            $label = 'Created';
        } elseif ($existing && $existing->status !== $status) {
            $label = ($status === 'published') ? 'Published' : 'Hidden';
        } else {
            $label = 'Edited';
        }
        HC_Core::log_action('category', $id, $label);

        $message = 'Category saved';
        if ($status === 'hidden') {
            $message .= ' (hidden: articles that are only in this category are not visible until it is published)';
        }
        wp_send_json_success(array('id' => $id, 'message' => $message));
    }

    public static function delete_category() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));

        $cat = HC_Core::get_category($id);
        if (!$cat) wp_send_json_error(array('message' => 'Not found'));

        if ((int) $cat->is_default === 1) {
            wp_send_json_error(array('message' => 'This is the default category and cannot be deleted. Rename it instead.'));
        }

        $res = HC_Lifecycle::trash_categories(array($id));

        $msg = 'Category moved to trash';
        if ($res['reassigned'] > 0) {
            $msg .= ' (' . $res['reassigned'] . ' article(s) moved to Uncategorized)';
        }
        wp_send_json_success(array('message' => $msg));
    }


    // Save meaningful before/after revisions for articles and FAQs only.
    private static function save_revision($type, $id, $before, $after) {
        global $wpdb;
        if (!$before || !$after) return;
        $keys = $type === 'article' ? array('title','slug','excerpt','content','status','category_id','subcategory_id','meta_keywords','schema_type','robots_meta','is_popular','sort_order') : array('question','answer','destination_type','destination_id','status','sort_order');
        $old = array(); $new = array();
        foreach ($keys as $key) { $old[$key] = isset($before->$key) ? $before->$key : null; $new[$key] = isset($after[$key]) ? $after[$key] : null; }
        if (wp_json_encode($old) === wp_json_encode($new)) return;
        $wpdb->insert($wpdb->prefix . 'hc_revisions', array('item_type'=>$type,'item_id'=>(int)$id,'user_id'=>get_current_user_id(),'before_data'=>wp_json_encode($old),'after_data'=>wp_json_encode($new),'created_at'=>current_time('mysql')));
    }

    public static function autosave_article() {
        self::check_admin(); global $wpdb; $t=$wpdb->prefix.'hc_articles';
        $id=(int)($_POST['id']??0); $title=sanitize_text_field(wp_unslash($_POST['title']??'')); $slug=sanitize_title(wp_unslash($_POST['slug']??'')); $excerpt=sanitize_textarea_field(wp_unslash($_POST['excerpt']??'')); $content=wp_kses_post(wp_unslash($_POST['content']??''));
        $status='draft';
        if ($id) { $row=$wpdb->get_row($wpdb->prepare("SELECT id,status,deleted_at FROM $t WHERE id=%d",$id)); if(!$row || $row->deleted_at) wp_send_json_error(array('message'=>'Article not available for autosave')); $status=$row->status; }
        if ($title==='' && $content==='' && $excerpt==='') wp_send_json_success(array('id'=>$id,'message'=>'Nothing to save'));
        if ($title==='') $title='Untitled article'; if ($slug==='') $slug=sanitize_title($title); if ($slug==='') $slug='untitled-article';
        if (!$id) { $slug .= '-draft-' . get_current_user_id() . '-' . wp_rand(1000,9999); $wpdb->insert($t,array('title'=>$title,'slug'=>$slug,'excerpt'=>$excerpt,'content'=>$content,'category_id'=>0,'status'=>'draft','updated_at'=>current_time('mysql'))); $id=(int)$wpdb->insert_id; }
        else { if ($status === 'published') { update_user_meta(get_current_user_id(), 'hc_autosave_article_' . $id, array('title'=>$title,'excerpt'=>$excerpt,'content'=>$content,'saved_at'=>current_time('mysql'))); } else { $wpdb->update($t,array('title'=>$title,'excerpt'=>$excerpt,'content'=>$content,'updated_at'=>current_time('mysql')),array('id'=>$id)); } }
        if (!$id || $wpdb->last_error) wp_send_json_error(array('message'=>'Autosave failed: '.$wpdb->last_error));
        wp_send_json_success(array('id'=>$id,'message'=>'Autosaved','status'=>$status));
    }

    public static function autosave_faq() {
        self::check_admin(); global $wpdb; $t=$wpdb->prefix.'hc_faqs';
        $id=(int)($_POST['id']??0); $question=sanitize_text_field(wp_unslash($_POST['question']??'')); $answer=wp_kses_post(wp_unslash($_POST['answer']??''));
        if ($question==='' && trim(wp_strip_all_tags($answer))==='') wp_send_json_success(array('id'=>$id,'message'=>'Nothing to save'));
        if ($question==='') $question='Untitled FAQ';
        if ($id) { $row=$wpdb->get_row($wpdb->prepare("SELECT id,status,deleted_at FROM $t WHERE id=%d",$id)); if(!$row || $row->deleted_at) wp_send_json_error(array('message'=>'FAQ not available for autosave')); if ($row->status === 'published') { update_user_meta(get_current_user_id(), 'hc_autosave_faq_' . $id, array('question'=>$question,'answer'=>$answer,'saved_at'=>current_time('mysql'))); } else { $wpdb->update($t,array('question'=>$question,'answer'=>$answer,'updated_at'=>current_time('mysql')),array('id'=>$id)); } }
        else { $wpdb->insert($t,array('question'=>$question,'answer'=>$answer,'destination_type'=>'global','status'=>'draft','updated_at'=>current_time('mysql'))); $id=(int)$wpdb->insert_id; }
        if (!$id || $wpdb->last_error) wp_send_json_error(array('message'=>'Autosave failed: '.$wpdb->last_error));
        wp_send_json_success(array('id'=>$id,'message'=>'Autosaved'));
    }

    /** Restore a selected article/FAQ revision, recording the restore as a new revision. */
    public static function restore_revision() {
        self::check_admin();
        global $wpdb;
        $revision_id = absint($_POST['revision_id'] ?? 0);
        $rev = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}hc_revisions WHERE id=%d", $revision_id));
        if (!$rev || !in_array($rev->item_type, array('article','faq'), true)) wp_send_json_error(array('message'=>'Revision not found'));
        // A revision represents the transition from before_data to after_data.
        // Restoring the selected version means returning to the state immediately BEFORE that edit.
        $target = json_decode($rev->before_data, true);
        if (!is_array($target)) wp_send_json_error(array('message'=>'Revision data is invalid'));
        $table = $wpdb->prefix . ($rev->item_type === 'article' ? 'hc_articles' : 'hc_faqs');
        $current = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d AND deleted_at IS NULL", (int)$rev->item_id));
        if (!$current) wp_send_json_error(array('message'=>'The item no longer exists'));
        $allowed = $rev->item_type === 'article'
            ? array('title','slug','excerpt','content','status','category_id','subcategory_id','meta_keywords','schema_type','robots_meta','is_popular','sort_order')
            : array('question','answer','destination_type','destination_id','status','sort_order');
        $update = array();
        $has_changes = false;
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $target)) continue;
            $update[$key] = $target[$key];
            $current_value = isset($current->$key) ? (string)$current->$key : '';
            $target_value = is_null($target[$key]) ? '' : (string)$target[$key];
            if ($current_value !== $target_value) $has_changes = true;
        }
        // A refresh or restoring content that is already current must not create a duplicate revision.
        if ($has_changes) {
            $update['updated_at'] = current_time('mysql');
            $ok = $wpdb->update($table, $update, array('id'=>(int)$rev->item_id));
            if ($ok === false || $wpdb->last_error) wp_send_json_error(array('message'=>'Could not restore revision: '.$wpdb->last_error));
            self::save_revision($rev->item_type, (int)$rev->item_id, $current, $update);
        }
        if ($rev->item_type === 'article') {
            delete_user_meta(get_current_user_id(), 'hc_autosave_article_' . (int)$rev->item_id);
            HC_Lifecycle::normalize_article((int)$rev->item_id);
        } else {
            delete_user_meta(get_current_user_id(), 'hc_autosave_faq_' . (int)$rev->item_id);
        }
        wp_send_json_success(array('message'=>$has_changes ? 'Revision restored. A revision was recorded because the content changed.' : 'This version already matches the current content. Nothing changed and no duplicate revision was created.', 'changed'=>$has_changes, 'type'=>$rev->item_type, 'id'=>(int)$rev->item_id));
    }

    // =============================================
    // ADMIN: SAVE ARTICLE
    // =============================================
    public static function save_article() {
        self::check_admin();
        global $wpdb;
        $t = $wpdb->prefix . 'hc_articles';

        $id       = (int) ($_POST['id'] ?? 0);
        $title    = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
        $slug_in  = sanitize_title(wp_unslash($_POST['slug'] ?? ''));
        $slug     = ($slug_in !== '') ? $slug_in : sanitize_title($title);
        $excerpt  = sanitize_textarea_field(wp_unslash($_POST['excerpt'] ?? ''));
        $content  = wp_kses_post(wp_unslash($_POST['content'] ?? ''));
        $is_new   = ($id === 0);

        // Categories (multi-select)
        $category_ids = array();
        if (!empty($_POST['category_ids_string'])) {
            $ids_str = sanitize_text_field(wp_unslash($_POST['category_ids_string']));
            $category_ids = array_map('intval', explode(',', $ids_str));
        } elseif (!empty($_POST['category_ids'])) {
            $category_ids = array_map('intval', (array) $_POST['category_ids']);
        } elseif (!empty($_POST['category_id'])) {
            $category_ids = array((int) $_POST['category_id']);
        }
        $category_ids = array_values(array_unique(array_filter($category_ids)));

        // Keep only real, non-trashed categories
        if (!empty($category_ids)) {
            $in = implode(',', array_map('intval', $category_ids));
            $valid = array_map('intval', (array) $wpdb->get_col(
                "SELECT id FROM {$wpdb->prefix}hc_categories WHERE id IN ($in) AND deleted_at IS NULL"
            ));
            $category_ids = array_values(array_intersect($category_ids, $valid));
        }

        $popular_ids = HC_Core::get_popular_article_ids();
        $is_popular = in_array($id, $popular_ids, true) ? 1 : 0; // Popular status is managed only in the dedicated Popular tab.
        $sort_order    = (int) ($_POST['sort_order'] ?? 0);
        $status        = sanitize_key(wp_unslash($_POST['status'] ?? 'published'));
        $meta_keywords = sanitize_text_field(wp_unslash($_POST['meta_keywords'] ?? ''));
        $schema_type   = sanitize_text_field(wp_unslash($_POST['schema_type'] ?? 'inherit'));
        $robots_meta   = sanitize_text_field(wp_unslash($_POST['robots_meta'] ?? 'inherit'));

        if (!in_array($status, array('published', 'draft'), true)) $status = 'draft';
        if (!in_array($robots_meta, array('inherit', 'index,follow', 'noindex,follow', 'noindex,nofollow', 'noindex,nofollow,noarchive'), true)) {
            $robots_meta = 'inherit';
        }

        if ($title === '')  wp_send_json_error(array('message' => 'Title required'));
        if ($slug === '')   wp_send_json_error(array('message' => 'Please use a title or slug that contains letters or numbers'));
        if (empty($category_ids)) wp_send_json_error(array('message' => 'Please select at least one category'));

        if ($id > 0) {
            $old = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id = %d", $id));
            if (!$old) wp_send_json_error(array('message' => 'Article not found'));
            if (!empty($old->deleted_at)) {
                wp_send_json_error(array('message' => 'This article is in the trash. Restore it first.'));
            }
        }

        // Match WordPress slug behaviour: preserve the requested slug when free,
        // otherwise generate a unique numeric suffix instead of blocking the save.
        $base_slug = $slug;
        $suffix = 2;
        while (!HC_Lifecycle::claim_slug('articles', $slug, $id)) {
            $slug = $base_slug . '-' . $suffix;
            $suffix++;
            if ($suffix > 1000) wp_send_json_error(array('message' => 'Could not generate a unique article slug. Please enter a different slug.'));
        }

        $category_id    = $category_ids[0];
        $subcategory_id = (int) ($_POST['subcategory_id'] ?? 0);
        if (!in_array($subcategory_id, $category_ids, true)) $subcategory_id = 0;

        $reading_time = HC_Core::calculate_reading_time($content);

        $data = array(
            'title'          => $title,
            'slug'           => $slug,
            'excerpt'        => $excerpt,
            'content'        => $content,
            'category_id'    => $category_id,
            'subcategory_id' => $subcategory_id ? $subcategory_id : null,
            'is_popular'     => $is_popular,
            'sort_order'     => $sort_order,
            'status'         => $status,
            'category_hidden_status' => null,
            'meta_keywords'  => $meta_keywords,
            'schema_type'    => $schema_type,
            'robots_meta'    => $robots_meta,
            'reading_time'   => $reading_time,
            'updated_at'     => current_time('mysql'),
        );

        $was_status = '';
        if ($id > 0) {
            $was_status = (string) $wpdb->get_var($wpdb->prepare("SELECT status FROM $t WHERE id = %d", $id));
            $ok = $wpdb->update($t, $data, array('id' => $id));
            if ($ok !== false) self::save_revision('article', $id, $old, $data);
        } else {
            $ok = $wpdb->insert($t, $data);
            $id = (int) $wpdb->insert_id;
        }

        if ($ok === false || $wpdb->last_error || $id <= 0) {
            wp_send_json_error(array('message' => 'DB: ' . $wpdb->last_error));
        }

        delete_user_meta(get_current_user_id(), 'hc_autosave_article_' . $id);
        HC_Lifecycle::set_article_categories($id, $category_ids);
        HC_Lifecycle::normalize_article($id);
        HC_Lifecycle::recount_categories();

        if ($is_new) {
            $label = ($status === 'published') ? 'Published' : 'Created as Draft';
        } elseif ($was_status !== '' && $was_status !== $status) {
            $label = ($status === 'published') ? 'Published' : 'Moved to Draft';
        } else {
            $label = 'Edited';
        }
        HC_Core::log_action('article', $id, $label);

        $message = 'Article saved';
        if ($status === 'published') {
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id = %d", $id));
            $why = HC_Lifecycle::article_hidden_reason($row);
            if ($why !== '') $message .= ' (not visible on the site yet: ' . $why . ')';
        }
        delete_transient('hc_search_vocabulary_v1');
        wp_send_json_success(array('id' => $id, 'message' => $message));
    }

    public static function delete_article() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));

        $article = HC_Core::get_article($id);
        if (!$article) wp_send_json_error(array('message' => 'Article not found'));

        // FAQs linked to this article stay as they are; they simply stop being visible.
        HC_Lifecycle::trash_articles(array($id));
        delete_transient('hc_search_vocabulary_v1');

        wp_send_json_success(array('message' => 'Article moved to trash'));
    }


    // =============================================
    // ADMIN: SAVE FAQ
    // =============================================
    public static function save_faq() {
        self::check_admin();
        global $wpdb;
        $t = $wpdb->prefix . 'hc_faqs';

        $id               = (int) ($_POST['id'] ?? 0);
        $question         = sanitize_text_field(wp_unslash($_POST['question'] ?? ''));
        $answer           = wp_kses_post(wp_unslash($_POST['answer'] ?? ''));
        $destination_type = sanitize_key(wp_unslash($_POST['destination_type'] ?? 'global'));
        $destination_id   = (int) ($_POST['destination_id'] ?? 0);
        $sort_order       = (int) ($_POST['sort_order'] ?? 0);
        $status           = sanitize_key(wp_unslash($_POST['status'] ?? 'published'));
        if (!in_array($status, array('published', 'draft'), true)) $status = 'draft';

        if ($question === '' || trim(wp_strip_all_tags($answer)) === '') {
            wp_send_json_error(array('message' => 'Question and answer required'));
        }

        if (!in_array($destination_type, array('global', 'home', 'contact', 'category', 'article'), true)) {
            wp_send_json_error(array('message' => 'Invalid destination'));
        }

        if (in_array($destination_type, array('category', 'article'), true)) {
            if (!$destination_id) {
                wp_send_json_error(array('message' => 'Please select a destination'));
            }
            if ($destination_type === 'article' && !HC_Core::get_article($destination_id)) {
                wp_send_json_error(array('message' => 'The selected article no longer exists. Please pick another one.'));
            }
            if ($destination_type === 'category' && !HC_Core::get_category($destination_id)) {
                wp_send_json_error(array('message' => 'The selected category no longer exists. Please pick another one.'));
            }
        } else {
            $destination_id = null;
        }

        $old = null;
        if ($id > 0) {
            $old = HC_Core::get_faq($id);
            if (!$old) {
                wp_send_json_error(array('message' => 'FAQ not found or is in the trash. Restore it first.'));
            }
        }

        $data = array(
            'question'         => $question,
            'answer'           => $answer,
            'destination_type' => $destination_type,
            'destination_id'   => $destination_id,
            'sort_order'       => $sort_order,
            'status'           => $status,
            'updated_at'       => current_time('mysql'),
        );

        $is_new = ($id === 0);
        if ($is_new) {
            $ok = $wpdb->insert($t, $data);
            $id = (int) $wpdb->insert_id;
        } else {
            $ok = $wpdb->update($t, $data, array('id' => $id));
            if ($ok !== false) self::save_revision('faq', $id, $old, $data);
        }

        if ($ok === false || $wpdb->last_error || $id <= 0) {
            wp_send_json_error(array('message' => 'DB: ' . $wpdb->last_error));
        }

        delete_user_meta(get_current_user_id(), 'hc_autosave_faq_' . $id);
        $was_status = $old ? $old->status : '';
        if ($was_status === 'published' && $status === 'draft') {
            HC_Core::log_faq_draft_reason($id, 'Manually set to draft by admin');
        } elseif ($was_status === 'draft' && $status === 'published') {
            HC_Core::log_faq_draft_reason($id, 'Re-published manually on ' . current_time('mysql'));
        }

        if ($is_new) {
            $label = ($status === 'published') ? 'Published' : 'Created as Draft';
        } elseif ($was_status !== $status) {
            $label = ($status === 'published') ? 'Published' : 'Moved to Draft';
        } else {
            $label = 'Edited';
        }
        HC_Core::log_action('faq', $id, $label);

        $message = 'FAQ saved';
        if ($status === 'published') {
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id = %d", $id));
            $why = HC_Lifecycle::faq_hidden_reason($row);
            if ($why !== '') $message .= ' (not visible on the site yet: ' . $why . ')';
        }
        wp_send_json_success(array('id' => $id, 'message' => $message));
    }


    // =============================================
    // ADMIN: DELETE FAQ
    // =============================================
    public static function delete_faq() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));
        HC_Lifecycle::trash_faqs(array($id));
        wp_send_json_success(array('message' => 'FAQ moved to trash'));
    }



    // =============================================
    // ADMIN: CURATED POPULAR ARTICLES
    // =============================================
    public static function popular_search() {
        self::check_admin();
        global $wpdb;
        $q = sanitize_text_field(wp_unslash($_POST['q'] ?? ''));
        if (mb_strlen(trim($q)) < 2) wp_send_json_success(array('rows' => array()));
        $like = '%' . $wpdb->esc_like($q) . '%';
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id,title,slug,view_count FROM {$wpdb->prefix}hc_articles WHERE status='published' AND deleted_at IS NULL AND title LIKE %s ORDER BY title ASC LIMIT 20", $like
        ));
        wp_send_json_success(array('rows' => $rows));
    }

    public static function add_popular_article() {
        self::check_admin();
        $id = absint($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid article.'));
        global $wpdb;
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}hc_articles WHERE id=%d AND status='published' AND deleted_at IS NULL", $id));
        if (!$exists) wp_send_json_error(array('message' => 'Only published articles can be added.'));
        $ids = HC_Core::get_popular_article_ids();
        if (!in_array($id, $ids, true)) $ids[] = $id;
        $max = max(1, min(100, (int) HC_Core::get_setting('hc_popular_manual_max', 100)));
        if (count($ids) > $max) wp_send_json_error(array('message' => 'Popular list limit reached. Increase the maximum in Settings.'));
        update_option('hc_popular_article_ids', array_values($ids), false);
        wp_send_json_success(array('message' => 'Article added to Popular.', 'ids' => $ids));
    }

    public static function remove_popular_article() {
        self::check_admin();
        $id = absint($_POST['id'] ?? 0);
        $ids = array_values(array_diff(HC_Core::get_popular_article_ids(), array($id)));
        update_option('hc_popular_article_ids', $ids, false);
        wp_send_json_success(array('message' => 'Article removed from the curated list.', 'ids' => $ids));
    }

    public static function save_popular_order() {
        self::check_admin();
        $raw = isset($_POST['ids']) ? (array) $_POST['ids'] : array();
        $ids = array_values(array_unique(array_filter(array_map('absint', $raw))));
        $max = max(1, min(100, (int) HC_Core::get_setting('hc_popular_manual_max', 100)));
        if (count($ids) > $max) wp_send_json_error(array('message' => 'The list exceeds the configured maximum.'));
        global $wpdb;
        if ($ids) {
            $valid_ids = array_map('absint', $wpdb->get_col("SELECT id FROM {$wpdb->prefix}hc_articles WHERE status='published' AND deleted_at IS NULL AND id IN (" . implode(',', array_map('absint', $ids)) . ")"));
            // SQL IN does not preserve the submitted order; filter the submitted sequence instead.
            $valid_map = array_fill_keys($valid_ids, true);
            $ids = array_values(array_filter($ids, static function($id) use ($valid_map) { return isset($valid_map[$id]); }));
        }
        update_option('hc_popular_article_ids', array_values($ids), false);
        // Keep the legacy flag synchronized for backwards compatibility.
        $wpdb->query("UPDATE {$wpdb->prefix}hc_articles SET is_popular = 0");
        if ($ids) $wpdb->query("UPDATE {$wpdb->prefix}hc_articles SET is_popular = 1 WHERE id IN (" . implode(',', array_map('absint', $ids)) . ")");
        wp_send_json_success(array('message' => 'Popular article order saved.', 'ids' => $ids));
    }


    /** Save the explicit display order of categories (drag-and-drop admin list). */
    public static function save_category_order() {
        self::check_admin();
        $raw = isset($_POST['ids']) ? (array) $_POST['ids'] : array();
        $ids = array_values(array_unique(array_filter(array_map('absint', $raw))));
        if (!$ids) wp_send_json_error(array('message' => 'No categories were provided.'));
        global $wpdb;
        $table = $wpdb->prefix . 'hc_categories';
        foreach ($ids as $position => $id) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE id=%d AND deleted_at IS NULL", $id));
            if ($exists) $wpdb->update($table, array('sort_order' => $position + 1, 'updated_at' => current_time('mysql')), array('id' => $id), array('%d','%s'), array('%d'));
        }
        wp_send_json_success(array('message' => 'Category order saved.'));
    }

    // =============================================
    // ADMIN: SAVE SETTINGS
    // =============================================
    public static function save_settings() {
        self::check_admin();

        // An all-disabled form can legitimately submit no checked checkbox values.
        // Treat a missing settings payload as an empty array so unchecked features are saved as off.
        if (!isset($_POST['settings']) || !is_array($_POST['settings'])) {
            $_POST['settings'] = array();
        }

        $allowed = array(
            'hc_site_title', 'hc_tagline', 'hc_hero_search_placeholders', 'hc_home_category_limit', 'hc_articles_per_page', 'hc_popular_limit', 'hc_latest_limit', 'hc_popular_archive_limit', 'hc_latest_archive_limit', 'hc_popular_manual_max',
            'hc_primary_color', 'hc_accent_color', 'hc_bg_color',
            'hc_header_bg', 'hc_header_text', 'hc_dark_mode',
            'hc_show_search', 'hc_show_live_search', 'hc_show_breadcrumbs',
            'hc_show_helpful', 'hc_show_related', 'hc_show_faqs',
            'hc_show_toc', 'hc_show_reading_time', 'hc_show_view_count',
            'hc_show_share', 'hc_show_print', 'hc_enable_tickets',
            'hc_faq_position', 'hc_faq_max',
            'hc_schema_enabled', 'hc_schema_breadcrumbs', 'hc_schema_faq',
            'hc_schema_search', 'hc_schema_author', 'hc_schema_org_name',
            'hc_schema_org_logo', 'hc_schema_article_type',
            'hc_contact_email', 'hc_contact_phone', 'hc_livechat_url',
            'hc_contact_upload', 'hc_contact_max_mb',
            'hc_log_searches', 'hc_log_retention_days', 'hc_search_synonyms',
            'hc_debug',
            'hc_ai_enabled','hc_ai_chatbot_enabled','hc_ai_embedding_provider','hc_ai_chat_provider','hc_ai_gemini_key','hc_ai_openai_key','hc_ai_deepseek_key','hc_ai_pinecone_key','hc_ai_pinecone_host','hc_ai_index_name','hc_ai_namespace','hc_ai_vector_dimension','hc_ai_gemini_embedding_model','hc_ai_openai_embedding_model','hc_ai_gemini_chat_model','hc_ai_openai_chat_model','hc_ai_deepseek_chat_model','hc_ai_min_score','hc_ai_daily_token_limit','hc_ai_monthly_token_limit','hc_ai_daily_spend_limit','hc_ai_monthly_spend_limit','hc_ai_welcome_title','hc_ai_welcome_text','hc_ai_quick_prompts','hc_ai_bot_name','hc_ai_bot_subtitle','hc_ai_launcher_label','hc_ai_bot_logo','hc_ai_bot_icon','hc_ai_input_placeholder','hc_ai_footer_text','hc_ai_primary_color','hc_ai_accent_color','hc_ai_panel_color','hc_ai_retention_hours','hc_ai_max_conversations','hc_ai_max_age_days','hc_ai_followup_context_messages','hc_ai_max_output_tokens','hc_ai_persona_instructions','hc_ai_persona_limitations','hc_ai_escalation_wait_minutes','hc_ai_escalation_recipients','hc_ai_escalation_offline_email','hc_ai_escalation_max_wait_messages','hc_ai_support_poll_seconds','hc_ai_support_agent_ids','hc_ai_support_agent_capacity_json','hc_ai_support_assignment_strategy','hc_ai_support_assignment_interval_minutes','hc_ai_support_show_ai_history','hc_ai_support_ai_overview_enabled','hc_ai_support_media_enabled','hc_ai_support_notifications_enabled','hc_ai_support_browser_notifications','hc_ai_support_alert_sound','hc_ai_support_alert_volume','hc_ai_support_image_max_mb','hc_ai_support_video_max_mb','hc_ai_support_text_max_mb','hc_ai_support_file_max_mb','hc_ai_support_zip_max_mb','hc_ai_support_max_files_per_message','hc_realtime_ably_key',
        );

        // Forms are scoped so saving one settings page never disables options on another page.
        $scope = sanitize_key(wp_unslash($_POST['hc_settings_scope'] ?? 'general'));
        $scope_keys = array(
            'general' => array('hc_site_title','hc_tagline'),
            'appearance' => array('hc_primary_color','hc_accent_color','hc_bg_color','hc_header_bg','hc_header_text','hc_dark_mode'),
            'faq' => array('hc_faq_position','hc_faq_max'),
            'experience' => array('hc_show_search','hc_show_live_search','hc_show_breadcrumbs','hc_show_helpful','hc_show_related','hc_show_faqs','hc_show_toc','hc_show_reading_time','hc_show_view_count','hc_show_share','hc_show_print','hc_enable_tickets'),
            'seo' => array('hc_schema_enabled','hc_schema_breadcrumbs','hc_schema_faq','hc_schema_search','hc_schema_author','hc_schema_org_name','hc_schema_org_logo','hc_schema_article_type'),
            'contact' => array('hc_contact_email','hc_contact_phone','hc_livechat_url','hc_contact_upload','hc_contact_max_mb'),
            'search' => array('hc_log_searches','hc_log_retention_days','hc_search_synonyms'),
            'ai_platform' => array(),
            'support' => array(),
        );
        // AI Platform and Human Support used to share the same `ai` scope.
        // That meant saving either form treated every checkbox on the other form as
        // unchecked and silently disabled unrelated features. Keep their allowlists
        // and checkbox-reset sets completely separate.
        $support_settings_keys = array(
            'hc_ai_escalation_wait_minutes','hc_ai_escalation_recipients','hc_ai_escalation_offline_email','hc_ai_escalation_max_wait_messages',
            'hc_ai_support_poll_seconds','hc_ai_support_agent_ids','hc_ai_support_agent_capacity_json','hc_ai_support_assignment_strategy','hc_ai_support_assignment_interval_minutes',
            'hc_ai_support_show_ai_history','hc_ai_support_ai_overview_enabled','hc_ai_support_media_enabled','hc_ai_support_notifications_enabled','hc_ai_support_browser_notifications',
            'hc_ai_support_alert_sound','hc_ai_support_alert_volume','hc_ai_support_image_max_mb','hc_ai_support_video_max_mb','hc_ai_support_text_max_mb',
            'hc_ai_support_file_max_mb','hc_ai_support_zip_max_mb','hc_ai_support_max_files_per_message','hc_realtime_ably_key'
        );
        $ai_platform_keys = array_values(array_diff($ai_keys = array(
            'hc_ai_enabled','hc_ai_chatbot_enabled','hc_ai_embedding_provider','hc_ai_chat_provider','hc_ai_gemini_key','hc_ai_openai_key','hc_ai_deepseek_key',
            'hc_ai_pinecone_key','hc_ai_pinecone_host','hc_ai_index_name','hc_ai_namespace','hc_ai_vector_dimension','hc_ai_gemini_embedding_model',
            'hc_ai_openai_embedding_model','hc_ai_gemini_chat_model','hc_ai_openai_chat_model','hc_ai_deepseek_chat_model','hc_ai_min_score',
            'hc_ai_daily_token_limit','hc_ai_monthly_token_limit','hc_ai_daily_spend_limit','hc_ai_monthly_spend_limit','hc_ai_welcome_title','hc_ai_welcome_text',
            'hc_ai_quick_prompts','hc_ai_bot_name','hc_ai_bot_subtitle','hc_ai_launcher_label','hc_ai_bot_logo','hc_ai_bot_icon','hc_ai_input_placeholder',
            'hc_ai_footer_text','hc_ai_primary_color','hc_ai_accent_color','hc_ai_panel_color','hc_ai_retention_hours','hc_ai_max_conversations','hc_ai_max_age_days',
            'hc_ai_followup_context_messages','hc_ai_max_output_tokens','hc_ai_persona_instructions','hc_ai_persona_limitations'
        ), $support_settings_keys));
        $checkbox_by_scope = array(
            'general' => array(),
            'appearance' => array(),
            'faq' => array(),
            'experience' => array('hc_show_search','hc_show_live_search','hc_show_breadcrumbs','hc_show_helpful','hc_show_related','hc_show_faqs','hc_show_toc','hc_show_reading_time','hc_show_view_count','hc_show_share','hc_show_print','hc_enable_tickets'),
            'seo' => array('hc_schema_enabled','hc_schema_breadcrumbs','hc_schema_faq','hc_schema_search'),
            'contact' => array('hc_contact_upload'),
            'search' => array('hc_log_searches'),
            'ai_platform' => array('hc_ai_enabled','hc_ai_chatbot_enabled'),
            'support' => array('hc_ai_escalation_offline_email','hc_ai_support_media_enabled','hc_ai_support_show_ai_history','hc_ai_support_notifications_enabled','hc_ai_support_browser_notifications'),
        );
        if (!isset($scope_keys[$scope])) wp_send_json_error(array('message' => 'Invalid settings section. Reload the page and try again.'));
        foreach (($checkbox_by_scope[$scope] ?? array()) as $checkbox_key) {
            if (!isset($_POST['settings'][$checkbox_key])) HC_Core::update_setting($checkbox_key, '0');
        }
        foreach ($_POST['settings'] as $key => $raw_value) {
            // FIX: Unwrap WordPress magic-quote backslashes on every value
            $value = wp_unslash($raw_value);
            $key   = sanitize_text_field($key);
            if (!in_array($key, $allowed)) continue;
            $scope_allowed = array(
                'general' => array('hc_site_title','hc_tagline','hc_hero_search_placeholders','hc_home_category_limit','hc_articles_per_page','hc_popular_limit','hc_latest_limit','hc_popular_archive_limit','hc_latest_archive_limit','hc_popular_manual_max'),
                'appearance' => array('hc_primary_color','hc_accent_color','hc_bg_color','hc_header_bg','hc_header_text','hc_dark_mode'),
                'experience' => array('hc_show_search','hc_show_live_search','hc_show_breadcrumbs','hc_show_helpful','hc_show_related','hc_show_faqs','hc_show_toc','hc_show_reading_time','hc_show_view_count','hc_show_share','hc_show_print','hc_enable_tickets'),
                'faq' => array('hc_faq_position','hc_faq_max'),
                'seo' => array('hc_schema_enabled','hc_schema_breadcrumbs','hc_schema_faq','hc_schema_search','hc_schema_author','hc_schema_org_name','hc_schema_org_logo','hc_schema_article_type'),
                'contact' => array('hc_contact_email','hc_contact_phone','hc_livechat_url','hc_contact_upload','hc_contact_max_mb'),
                'search' => array('hc_log_searches','hc_log_retention_days','hc_search_synonyms'),
                'ai_platform' => $ai_platform_keys,
                'support' => $support_settings_keys,
            );
            if (in_array($scope, array('ai_platform','support'), true)) {
                if (!in_array($key, $scope_allowed[$scope], true)) continue;
            } elseif (!in_array($key, $scope_allowed[$scope], true)) {
                continue;
            }
            if (in_array($key, array('hc_ai_gemini_key','hc_ai_openai_key','hc_ai_deepseek_key','hc_ai_pinecone_key','hc_realtime_ably_key'), true) && $value === '') continue;
            if ($key === 'hc_realtime_ably_key') {
                if (!class_exists('HC_Realtime') || !HC_Realtime::save_api_key($value)) wp_send_json_error(array('message' => 'The Ably API key format is invalid or secure encryption is unavailable.'));
                continue;
            }

            // Email fields
            if ($key === 'hc_search_synonyms' || $key === 'hc_hero_search_placeholders' || $key === 'hc_ai_quick_prompts' || $key === 'hc_ai_persona_instructions' || $key === 'hc_ai_persona_limitations') {
                $value = sanitize_textarea_field($value);
            } elseif ($key === 'hc_ai_welcome_title') {
                $value = sanitize_text_field($value);
                $value = mb_substr($value, 0, 90);
            } elseif ($key === 'hc_ai_welcome_text') {
                $value = sanitize_text_field($value);
                $value = mb_substr($value, 0, 180);
            } elseif (in_array($key, array('hc_ai_bot_name','hc_ai_bot_subtitle','hc_ai_launcher_label','hc_ai_input_placeholder','hc_ai_footer_text'), true)) {
                $value = mb_substr(sanitize_text_field($value), 0, 140);
            } elseif ($key === 'hc_ai_bot_logo') {
                $value = esc_url_raw($value);
            } elseif ($key === 'hc_ai_bot_icon') {
                $allowed_icons = array('fa-comments','fa-robot','fa-headset','fa-sparkles','fa-life-ring','fa-message','fa-circle-question','fa-lightbulb','fa-wand-magic-sparkles','fa-brain','fa-book-open','fa-circle-info');
                $value = sanitize_key($value);
                if (!in_array($value, $allowed_icons, true)) $value = 'fa-comments';
            } elseif (in_array($key, array('hc_ai_primary_color','hc_ai_accent_color','hc_ai_panel_color'), true)) {
                $value = sanitize_hex_color($value) ?: '#29265f';
            } elseif ($key === 'hc_ai_followup_context_messages') {
                $value = (string) max(2, min(30, absint($value)));
            } elseif ($key === 'hc_ai_max_output_tokens') {
                $value = (string) max(256, min(4096, absint($value)));
            } elseif ($key === 'hc_ai_escalation_wait_minutes') {
                $value = (string) max(1, min(30, absint($value)));
            } elseif ($key === 'hc_ai_escalation_recipients') {
                $emails = array_filter(array_map('sanitize_email', preg_split('/[,;\s]+/', (string) $value)));
                $value = implode(', ', array_unique(array_filter($emails, 'is_email')));
            } elseif ($key === 'hc_ai_escalation_max_wait_messages') {
                $value = (string) max(0, min(10, absint($value)));
            } elseif ($key === 'hc_ai_support_poll_seconds') {
                $value = (string) max(1, min(3, absint($value)));
            } elseif ($key === 'hc_ai_support_assignment_interval_minutes') {
                $value = (string) max(0, min(240, absint($value)));
            } elseif ($key === 'hc_ai_support_assignment_strategy') {
                $value = 'least_workload';
            } elseif ($key === 'hc_ai_escalation_offline_email' || $key === 'hc_ai_support_media_enabled' || $key === 'hc_ai_support_show_ai_history' || $key === 'hc_ai_support_ai_overview_enabled') {
                $value = $value === '1' ? '1' : '0';
            } elseif ($key === 'hc_ai_support_agent_ids') {
                $ids = is_array($value) ? $value : preg_split('/[,;\s]+/', (string)$value);
                $ids = array_values(array_unique(array_filter(array_map('absint', $ids))));
                $ids = array_filter($ids, function($id) { return get_user_by('id', $id) !== false; });
                $value = implode(',', $ids);
            } elseif ($key === 'hc_ai_support_agent_capacity_json') {
                $decoded = json_decode((string)$value, true); $clean = array();
                if (is_array($decoded)) foreach ($decoded as $agent_id => $limit) { $agent_id = absint($agent_id); if ($agent_id && get_user_by('id', $agent_id)) $clean[(string)$agent_id] = max(1, min(100, absint($limit))); }
                $value = wp_json_encode($clean);
            } elseif ($key === 'hc_ai_support_notifications_enabled' || $key === 'hc_ai_support_browser_notifications') {
                $value = $value === '1' ? '1' : '0';
            } elseif ($key === 'hc_ai_support_alert_sound') {
                $value = sanitize_key($value); if (!in_array($value, array('urgent','bell','classic','digital','chime','soft'), true)) $value = 'urgent';
            } elseif ($key === 'hc_ai_support_alert_volume') {
                $value = (string) max(0.2, min(1, (float) $value));
            } elseif ($key === 'hc_ai_support_max_files_per_message') {
                $value = (string) max(1, min(3, absint($value)));
            } elseif (preg_match('/^hc_ai_support_(image|video|text|file|zip)_max_mb$/', $key)) {
                $value = (string) max(1, min(100, absint($value)));
            } elseif ($key === 'hc_ai_retention_hours') {
                $value = (string) max(1, min(720, absint($value)));
            } elseif ($key === 'hc_ai_max_conversations') {
                $value = (string) max(1, min(100, absint($value)));
            } elseif ($key === 'hc_ai_max_age_days') {
                $value = (string) max(1, min(365, absint($value)));
            } elseif ($key === 'hc_contact_email') {
                $value = sanitize_email($value);
            } elseif ($key === 'hc_schema_org_logo' || $key === 'hc_livechat_url' || $key === 'hc_ai_pinecone_host') {
                $value = esc_url_raw($value);
            } elseif ($key === 'hc_ai_vector_dimension') {
                $value = (string) max(1, min(20000, absint($value)));
            } elseif (in_array($key, array('hc_ai_daily_token_limit','hc_ai_monthly_token_limit'), true)) {
                $value = (string) max(0, min(1000000000, absint($value))); 
            } elseif (in_array($key, array('hc_articles_per_page','hc_popular_limit','hc_latest_limit','hc_popular_archive_limit','hc_latest_archive_limit','hc_popular_manual_max','hc_faq_max'), true)) {
                $value = (string) max(1, min(($key === 'hc_articles_per_page' ? 1000 : 100), absint($value)));
            } elseif (in_array($key, array('hc_primary_color','hc_accent_color','hc_bg_color','hc_header_bg','hc_header_text'), true)) {
                $value = sanitize_hex_color($value) ?: $value;
            } else {
                $value = sanitize_text_field($value);
            }

            HC_Core::update_setting($key, $value);
        }

        // Clear settings and auto-search vocabulary caches
        delete_transient('hc_search_vocabulary_v1');
        wp_cache_flush();

        wp_send_json_success(array('message' => 'Settings saved'));
    }

    // =============================================
    // ADMIN: DELETE SEARCH LOG ROW
    // =============================================
    public static function delete_search_log() {
        self::check_admin();
        global $wpdb;
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));
        $wpdb->delete($wpdb->prefix . 'hc_search_log', array('id' => $id));
        wp_send_json_success(array('message' => 'Log entry deleted'));
    }

    // =============================================
    // INTERNAL HELPERS
    // =============================================
    private static function recount_category($cat_id = 0) {
        // The relation table is the source of truth, so every count is refreshed together.
        HC_Lifecycle::recount_categories();
    }

    private static function posted_ids() {
        return isset($_POST['ids']) ? array_values(array_filter(array_map('intval', (array) $_POST['ids']))) : array();
    }


    // =============================================
    // ADMIN: GET SUBCATEGORIES (for article editor)
    // =============================================
    public static function get_subcategories() {
        self::check_admin();

        $parent_id = isset($_POST['category_id']) ? (int) $_POST['category_id'] : 0;
        $selected  = isset($_POST['selected_id']) ? (int) $_POST['selected_id'] : 0;

        if (!$parent_id) {
            wp_send_json_success(array('subcategories' => array()));
        }

        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name FROM {$wpdb->prefix}hc_categories
             WHERE parent_id = %d AND status = 'published'
             ORDER BY sort_order ASC, name ASC",
            $parent_id
        ));

        $out = array();
        foreach ($rows as $r) {
            $out[] = array(
                'id'    => (int) $r->id,
                'name'  => $r->name,
                'selected' => ((int) $r->id === $selected),
            );
        }

        wp_send_json_success(array('subcategories' => $out));
    }

    // =============================================
    // ADMIN SEARCH — Articles
    // =============================================
    public static function admin_search_articles() {
        self::check_admin();

        global $wpdb;
        $t = $wpdb->prefix . 'hc_articles';

        $q        = isset($_POST['q']) ? sanitize_text_field($_POST['q']) : '';
        $status   = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        $view     = isset($_POST['view']) ? sanitize_key($_POST['view']) : ''; // HC_HANDLER_VIEW
        $cat      = isset($_POST['cat']) ? (int) $_POST['cat'] : 0;
        // Search mode intentionally returns every matching row; pagination is hidden in the UI while searching.
        $page = 1;

        $where = array('1=1');
        $params = array();

        // HC_TRASH_FILTER_ARTICLES — trash mode vs normal mode (driven by $view)
        if ($view === 'trash') {
            $where[] = 'a.deleted_at IS NOT NULL';
        } else {
            $where[] = 'a.deleted_at IS NULL';
            if ($view === 'published' || $view === 'draft' || $view === 'hidden') {
                $where[] = 'a.status = %s';
                $params[] = $view;
            } elseif ($status !== '' && $status !== 'trash') {
                $where[] = 'a.status = %s';
                $params[] = $status;
            }
        }

        if ($q !== '') {
            $like = '%' . $wpdb->esc_like($q) . '%';
            $where[] = '(a.title LIKE %s OR a.excerpt LIKE %s OR a.meta_keywords LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        if ($cat > 0) {
            $where[] = 'EXISTS (SELECT 1 FROM ' . $wpdb->prefix . 'hc_article_categories hcac WHERE hcac.article_id = a.id AND hcac.category_id = %d)';
            $params[] = $cat;
        }

        $where_sql = implode(' AND ', $where);

        // Total count
        $count_sql = "SELECT COUNT(*) FROM {$t} a WHERE $where_sql";
        $total = $params
            ? (int) $wpdb->get_var($wpdb->prepare($count_sql, $params))
            : (int) $wpdb->get_var($count_sql);

        // Rows
        $sql = "SELECT a.*, (SELECT GROUP_CONCAT(DISTINCT cc.name ORDER BY cc.name SEPARATOR ', ') FROM {$wpdb->prefix}hc_article_categories ac JOIN {$wpdb->prefix}hc_categories cc ON cc.id = ac.category_id AND cc.deleted_at IS NULL WHERE ac.article_id = a.id) AS category_name
                FROM {$t} a
                WHERE $where_sql
                ORDER BY a.updated_at DESC";
        $rows = $params ? $wpdb->get_results($wpdb->prepare($sql, $params)) : $wpdb->get_results($sql);

        $out = array();
        foreach ($rows as $a) {
            $out[] = array(
                'id'             => (int) $a->id,
                'title'          => $a->title,
                'slug'           => $a->slug,
                'category_name'  => $a->category_name ?: 'Uncategorized',
                'status'         => $a->status,
                'is_trashed'     => !empty($a->deleted_at),
                'view_count'     => (int) $a->view_count,
                'updated_human'  => human_time_diff(strtotime($a->updated_at . ' UTC'), current_time('timestamp')) . ' ago',
                'last_action'     => $a->last_action ?? '',
                'last_action_at'  => $a->last_action_at ?? '',
                'last_action_human' => !empty($a->last_action_at) ? human_time_diff(strtotime($a->last_action_at . ' UTC'), current_time('timestamp')) . ' ago' : '—',
                'edit_url'       => home_url('/helpcenter/admin/articles/edit/' . $a->id . '/'),
                'view_url'       => home_url('/helpcenter/article/' . $a->slug . '/'),
            );
        }

        wp_send_json_success(array(
            'rows'      => $out,
            'total'     => $total,
            'page'      => 1,
            'per_page'  => $total,
            'has_more'  => false,
        ));
    }

    // =============================================
    // ADMIN SEARCH — FAQs
    // =============================================
    public static function admin_search_faqs() {
        self::check_admin();
        global $wpdb;
        $t = $wpdb->prefix . 'hc_faqs';

        $q      = isset($_POST['q']) ? sanitize_text_field($_POST['q']) : '';
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        $view   = isset($_POST['view']) ? sanitize_key($_POST['view']) : ''; // HC_FAQ_VIEW_FILTER
        $sort_dir = (isset($_POST['sort']) && strtolower($_POST['sort']) === 'desc') ? 'DESC' : 'ASC';
        $page     = max(1, (int) ($_POST['page'] ?? 1));
        $per_page = 50;
        $offset   = ($page - 1) * $per_page;

        $where = array('1=1');
        $params = array();

        // HC_FAQ_VIEW_FILTER
        if ($view === 'trash') {
            $where[] = 'deleted_at IS NOT NULL';
        } else {
            $where[] = 'deleted_at IS NULL';
            if ($view === 'published' || $view === 'draft' || $view === 'hidden') {
                $where[] = 'status = %s';
                $params[] = ($view === 'published') ? 'published' : 'hidden';
            } elseif ($status !== '' && $status !== 'trash') {
                $where[] = 'status = %s';
                $params[] = $status;
            }
        }

        if ($q !== '') {
            $like = '%' . $wpdb->esc_like($q) . '%';
            $where[] = '(question LIKE %s OR answer LIKE %s)';
            $params[] = $like;
            $params[] = $like;
        }
        $where_sql = implode(' AND ', $where);

        $count_sql = "SELECT COUNT(*) FROM {$t} WHERE $where_sql";
        $total = $params
            ? (int) $wpdb->get_var($wpdb->prepare($count_sql, $params))
            : (int) $wpdb->get_var($count_sql);

        $allowed_faq = array('question' => 'question', 'order' => 'sort_order', 'status' => 'status', 'last_action' => 'last_action_at');
$orderby = isset($_POST['orderby']) ? sanitize_key($_POST['orderby']) : '';
$faq_order_sql = array_key_exists($orderby, $allowed_faq) ? "ORDER BY {$allowed_faq[$orderby]} $sort_dir" : "ORDER BY sort_order $sort_dir";
        $sql = "SELECT * FROM {$t} WHERE $where_sql $faq_order_sql, created_at DESC LIMIT %d OFFSET %d";
        $params_with_limit = array_merge($params, array($per_page, $offset));
        $rows = $wpdb->get_results($wpdb->prepare($sql, $params_with_limit));

        $out = array();
        foreach ($rows as $f) {
            $dest = '—';
            switch ($f->destination_type) {
                case 'global':  $dest = 'Global'; break;
                case 'home':    $dest = 'Home'; break;
                case 'contact': $dest = 'Contact'; break;
                case 'category':
                    $c = HC_Core::get_category($f->destination_id);
                    $dest = 'Category: ' . ($c ? $c->name : 'Unknown');
                    break;
                case 'article':
                    $a = HC_Core::get_article($f->destination_id);
                    $dest = 'Article: ' . ($a ? wp_trim_words($a->title, 6) : 'Unknown');
                    break;
            }
            // HC_FAQ_REASONS_RESPONSE
            $reasons = array();
            if (!empty($f->draft_reasons)) {
                $decoded = json_decode($f->draft_reasons, true);
                if (is_array($decoded)) $reasons = $decoded;
            }
            $hidden_reason = HC_Lifecycle::faq_hidden_reason($f);
            $out[] = array(
                'id'                => (int) $f->id,
                'dest' => $dest,
                'question'          => $f->question,
                'status'            => $f->status,
                'hidden_reason'     => ($f->status === 'published' && empty($f->deleted_at)) ? $hidden_reason : '',
                'is_trashed'        => !empty($f->deleted_at),
                'sort'              => (int) $f->sort_order,
                'last_action'       => $f->last_action ?? '',
                'last_action_at'    => $f->last_action_at ?? '',
                'last_action_human' => !empty($f->last_action_at) ? HC_Core::human_time($f->last_action_at) : '—',
                'edit_url'          => home_url('/helpcenter/admin/faqs/edit/' . $f->id . '/'),
                'draft_reasons'     => $reasons,
            );
        }

        wp_send_json_success(array(
            'rows'      => $out,
            'total'     => $total,
            'page'      => $page,
            'per_page'  => $per_page,
            'has_more'  => ($offset + count($out)) < $total,
        ));
    }

    // =============================================
    // ADMIN SEARCH — Categories
    // =============================================
    
    public static function check_categories_status() {
        self::check_admin();
        global $wpdb;

        $cat_ids = isset($_POST['category_ids']) ? array_values(array_filter(array_map('intval', (array) $_POST['category_ids']))) : array();
        if (empty($cat_ids)) {
            wp_send_json_success(array('has_draft' => false, 'draft_names' => array()));
        }

        $placeholders = implode(',', array_fill(0, count($cat_ids), '%d'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name, status, deleted_at FROM {$wpdb->prefix}hc_categories WHERE id IN ($placeholders)",
            $cat_ids
        ));

        $names = array();
        foreach ((array) $rows as $row) {
            if ($row->status !== 'published' || !empty($row->deleted_at)) {
                $names[] = $row->name;
            }
        }

        // Kept under the old key names so existing callers keep working.
        wp_send_json_success(array('has_draft' => !empty($names), 'draft_names' => $names));
    }


    
    public static function check_bulk_articles_categories() {
        self::check_admin();
        global $wpdb;

        $article_ids = isset($_POST['article_ids']) ? array_values(array_filter(array_map('intval', (array) $_POST['article_ids']))) : array();
        if (empty($article_ids)) {
            wp_send_json_success(array('blocked_articles' => array()));
        }

        $in   = implode(',', $article_ids);
        $arts = $wpdb->prefix . 'hc_articles';
        $cats = $wpdb->prefix . 'hc_categories';
        $rel  = $wpdb->prefix . 'hc_article_categories';

        // Articles that would NOT be visible even once published (none of their categories is live)
        $rows = $wpdb->get_results(
            "SELECT a.id, a.title FROM {$arts} a
             WHERE a.id IN ({$in}) AND a.deleted_at IS NULL
             AND NOT EXISTS (
                 SELECT 1 FROM {$rel} r JOIN {$cats} c ON c.id = r.category_id
                 WHERE r.article_id = a.id AND " . HC_Lifecycle::sql_category_live('c') . "
             )"
        );

        $list = array();
        foreach ((array) $rows as $row) {
            $list[] = array('id' => (int) $row->id, 'title' => $row->title);
        }
        wp_send_json_success(array('blocked_articles' => $list));
    }


    public static function admin_search_categories() {
        self::check_admin();
        global $wpdb;
        $t = $wpdb->prefix . 'hc_categories';

        $q      = isset($_POST['q']) ? sanitize_text_field($_POST['q']) : '';
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        $view   = isset($_POST['view']) ? sanitize_key($_POST['view']) : ''; // HC_FAQ_VIEW_FILTER
        $sort_dir = (isset($_POST['sort']) && strtolower($_POST['sort']) === 'desc') ? 'DESC' : 'ASC';
        $page     = max(1, (int) ($_POST['page'] ?? 1));
        $per_page = 100;
        $offset   = ($page - 1) * $per_page;

        $where = array('1=1');
        $params = array();

        // HC_CATS_VIEW_FILTER
        if ($view === 'trash') {
            $where[] = 'deleted_at IS NOT NULL';
        } else {
            $where[] = 'deleted_at IS NULL';
            if ($view === 'published' || $view === 'draft' || $view === 'hidden') {
                $where[] = 'status = %s';
                $params[] = ($view === 'published') ? 'published' : 'hidden';
            } elseif ($status !== '' && $status !== 'trash') {
                $where[] = 'status = %s';
                $params[] = $status;
            }
        }

        if ($q !== '') {
            $like = '%' . $wpdb->esc_like($q) . '%';
            $where[] = '(name LIKE %s OR slug LIKE %s OR description LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        $where_sql = implode(' AND ', $where);

        $count_sql = "SELECT COUNT(*) FROM {$t} WHERE $where_sql";
        $total = $params
            ? (int) $wpdb->get_var($wpdb->prepare($count_sql, $params))
            : (int) $wpdb->get_var($count_sql);

        $allowed_cats = array('name' => 'name', 'articles' => 'article_count', 'status' => 'status', 'last_action' => 'last_action_at', 'order' => 'sort_order');
$orderby = isset($_POST['orderby']) ? sanitize_key($_POST['orderby']) : '';
$cat_order_sql = array_key_exists($orderby, $allowed_cats) ? "ORDER BY {$allowed_cats[$orderby]} $sort_dir" : "ORDER BY sort_order $sort_dir";
        $sql = "SELECT * FROM {$t} WHERE $where_sql $cat_order_sql, parent_id ASC, name ASC LIMIT %d OFFSET %d";
        $params_with_limit = array_merge($params, array($per_page, $offset));
        $rows = $wpdb->get_results($wpdb->prepare($sql, $params_with_limit));

        $out = array();
        foreach ($rows as $c) {
            // Look up parent name if this is a subcategory
            $parent_name = '';
            if ((int) $c->parent_id > 0) {
                $parent_name = (string) $wpdb->get_var($wpdb->prepare(
                    "SELECT name FROM {$t} WHERE id = %d",
                    $c->parent_id
                ));
            }
            $out[] = array(
                'id'           => (int) $c->id,
                'name'         => $c->name,
                'slug'         => $c->slug,
                'is_trashed'   => !empty($c->deleted_at),
                'is_default'   => (int) ($c->is_default ?? 0),
                'icon_value'   => $c->icon_value ?: 'fa-folder',
                'parent_id'    => (int) $c->parent_id,
                'parent_name' => $parent_name,
                'parent_name'  => $parent_name,
                'article_count' => (int) $c->article_count,
                'status'       => $c->status,
                'sort'         => (int) $c->sort_order,
                'edit_url'     => home_url('/helpcenter/admin/categories/edit/' . $c->id . '/'),
                'last_action'       => $c->last_action ?? '',
                'last_action_at'    => $c->last_action_at ?? '',
                'last_action_human' => !empty($c->last_action_at) ? human_time_diff(strtotime($c->last_action_at . ' UTC'), current_time('timestamp')) . ' ago' : '—',
            );
        }

        wp_send_json_success(array(
            'rows'      => $out,
            'total'     => $total,
            'page'      => $page,
            'per_page'  => $per_page,
            'has_more'  => ($offset + count($out)) < $total,
        ));
    }

    // =============================================
    // BULK ACTIONS
    // =============================================
    public static function bulk_articles() {
        self::check_admin();

        $ids = self::posted_ids();
        $op  = isset($_POST['op']) ? sanitize_key($_POST['op']) : '';
        if (empty($ids) || $op === '') {
            wp_send_json_error(array('message' => 'Nothing selected'));
        }

        switch ($op) {
            case 'delete':      $n = HC_Lifecycle::trash_articles($ids);               $what = 'moved to trash'; break;
            case 'publish':     $n = HC_Lifecycle::set_articles_status($ids, 'published'); $what = 'published'; break;
            case 'draft':       $n = HC_Lifecycle::set_articles_status($ids, 'draft');     $what = 'moved to draft'; break;
            case 'restore':     $n = HC_Lifecycle::restore_articles($ids);             $what = 'restored as draft'; break;
            case 'hard_delete': $n = HC_Lifecycle::hard_delete_articles($ids);         $what = 'permanently deleted'; break;
            default:
                wp_send_json_error(array('message' => 'Unknown action'));
        }

        wp_send_json_success(array('message' => $n . ' article(s) ' . $what, 'count' => $n));
    }


    public static function bulk_faqs() {
        self::check_admin();

        $ids = self::posted_ids();
        $op  = isset($_POST['op']) ? sanitize_key($_POST['op']) : '';
        if (empty($ids) || $op === '') {
            wp_send_json_error(array('message' => 'Nothing selected'));
        }

        switch ($op) {
            case 'delete':      $n = HC_Lifecycle::trash_faqs($ids);                    $what = 'moved to trash'; break;
            case 'publish':     $n = HC_Lifecycle::set_faqs_status($ids, 'published');  $what = 'published'; break;
            case 'draft':       $n = HC_Lifecycle::set_faqs_status($ids, 'draft');      $what = 'moved to draft'; break;
            case 'restore':     $n = HC_Lifecycle::restore_faqs($ids);                  $what = 'restored as draft'; break;
            case 'hard_delete': $n = HC_Lifecycle::hard_delete_faqs($ids);              $what = 'permanently deleted'; break;
            default:
                wp_send_json_error(array('message' => 'Unknown action'));
        }

        wp_send_json_success(array('message' => $n . ' FAQ(s) ' . $what, 'count' => $n));
    }


    public static function bulk_categories() {
        self::check_admin();

        $ids = self::posted_ids();
        $op  = isset($_POST['op']) ? sanitize_key($_POST['op']) : '';
        if (empty($ids) || $op === '') {
            wp_send_json_error(array('message' => 'Nothing selected'));
        }

        // The default (Uncategorized) category can never be changed in bulk.
        $default_id = HC_Lifecycle::ensure_default_category();
        $ids = array_values(array_diff($ids, array($default_id)));
        if (empty($ids)) {
            wp_send_json_error(array('message' => 'The default (Uncategorized) category cannot be modified.'));
        }

        $extra = '';
        switch ($op) {
            case 'delete':
                $res = HC_Lifecycle::trash_categories($ids);
                $n = $res['trashed']; $what = 'moved to trash';
                if ($res['reassigned'] > 0) $extra = ' (' . $res['reassigned'] . ' article(s) moved to Uncategorized)';
                break;
            case 'draft':
            case 'hide':
                $n = HC_Lifecycle::set_categories_status($ids, 'hidden');    $what = 'hidden'; break;
            case 'publish':
                $n = HC_Lifecycle::set_categories_status($ids, 'published'); $what = 'published'; break;
            case 'restore':
                $res = HC_Lifecycle::restore_categories($ids);
                $n = $res['restored']; $what = 'restored as hidden';
                if ($res['relinked'] > 0) $extra = ' (' . $res['relinked'] . ' article(s) moved back from Uncategorized)';
                break;
            case 'hard_delete':
                $n = HC_Lifecycle::hard_delete_categories($ids);             $what = 'permanently deleted'; break;
            default:
                wp_send_json_error(array('message' => 'Unknown action'));
        }

        wp_send_json_success(array('message' => $n . ' categor' . ($n === 1 ? 'y ' : 'ies ') . $what . $extra, 'count' => $n));
    }


    // =============================================
    // TRASH: restore + hard delete + empty
    // =============================================
    public static function restore_article() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));
        HC_Lifecycle::restore_articles(array($id));
        wp_send_json_success(array('message' => 'Article restored as draft'));
    }


    public static function restore_faq() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));
        HC_Lifecycle::restore_faqs(array($id));
        wp_send_json_success(array('message' => 'FAQ restored as draft'));
    }


    public static function restore_category() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));
        $res = HC_Lifecycle::restore_categories(array($id));
        $msg = 'Category restored as hidden. Publish it to show it on the site.';
        if ($res['relinked'] > 0) $msg = 'Category restored as hidden (' . $res['relinked'] . ' article(s) moved back from Uncategorized). Publish it to show it on the site.';
        wp_send_json_success(array('message' => $msg));
    }


    public static function hard_delete_article() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));
        HC_Lifecycle::hard_delete_articles(array($id));
        wp_send_json_success(array('message' => 'Article permanently deleted'));
    }


    public static function hard_delete_faq() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));
        HC_Lifecycle::hard_delete_faqs(array($id));
        wp_send_json_success(array('message' => 'FAQ permanently deleted'));
    }


    public static function hard_delete_category() {
        self::check_admin();
        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(array('message' => 'Invalid ID'));

        if ($id === HC_Lifecycle::ensure_default_category()) {
            wp_send_json_error(array('message' => 'This is the default category and cannot be deleted.'));
        }

        HC_Lifecycle::hard_delete_categories(array($id));
        wp_send_json_success(array('message' => 'Category permanently deleted'));
    }


    public static function empty_trash() {
        self::check_admin();
        $type = sanitize_key($_POST['type'] ?? '');
        if (!in_array($type, array('articles', 'faqs', 'categories', 'all'), true)) {
            wp_send_json_error(array('message' => 'Unknown trash type'));
        }
        $count = HC_Lifecycle::empty_trash($type);
        wp_send_json_success(array('message' => "Emptied $count item(s) from trash"));
    }



    // =============================================
    // TAB COUNTS (for live refresh after delete)
    // =============================================
    public static function admin_tab_counts() {
        self::check_admin();
        global $wpdb;

        $list = isset($_POST['list']) ? sanitize_key($_POST['list']) : '';
        $table = '';
        switch ($list) {
            case 'articles':   $table = $wpdb->prefix . 'hc_articles'; break;
            case 'faqs':       $table = $wpdb->prefix . 'hc_faqs'; break;
            case 'categories': $table = $wpdb->prefix . 'hc_categories'; break;
            default: wp_send_json_error(array('message' => 'Invalid list'));
        }

        $counts = array(
            'all'       => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE deleted_at IS NULL"),
            'published' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE deleted_at IS NULL AND status='published'"),
            'draft'     => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE deleted_at IS NULL AND status='" . ($list === 'categories' ? 'hidden' : 'draft') . "'"),
            'trash'     => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE deleted_at IS NOT NULL"),
        );

        wp_send_json_success($counts);
    }

}
