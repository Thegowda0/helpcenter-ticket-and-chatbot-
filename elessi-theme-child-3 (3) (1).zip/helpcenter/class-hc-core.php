<?php
/**
 * Help Center - Core Helpers (queries + utilities)
 */

if (!defined('ABSPATH')) exit;

class HC_Core {

    // =============================================
    // SETTINGS
    // =============================================
    public static function get_setting($key, $default = '') {
        global $wpdb;
        static $cache = null;
        if ($cache === null) {
            $cache = array();
            $rows = $wpdb->get_results("SELECT setting_key, setting_value FROM {$wpdb->prefix}hc_settings");
            foreach ($rows as $r) $cache[$r->setting_key] = $r->setting_value;
        }
        return isset($cache[$key]) && $cache[$key] !== '' ? $cache[$key] : $default;
    }

    public static function get_all_settings() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT setting_key, setting_value FROM {$wpdb->prefix}hc_settings");
        $out = array();
        foreach ($rows as $r) $out[$r->setting_key] = $r->setting_value;
        return $out;
    }

    public static function update_setting($key, $value) {
        global $wpdb;
        $table = $wpdb->prefix . 'hc_settings';
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE setting_key = %s", $key));
        if ($exists) {
            $wpdb->update($table, array('setting_value' => $value), array('setting_key' => $key));
        } else {
            $wpdb->insert($table, array('setting_key' => $key, 'setting_value' => $value));
        }
    }

    // =============================================
    // CATEGORIES
    // =============================================
    public static function get_categories($parent_id = 0, $status = 'published', $include_default = false, $sort_dir = 'ASC') {
        global $wpdb;
        $t = $wpdb->prefix . 'hc_categories';
        $default_filter = $include_default ? '' : ' AND (is_default = 0 OR is_default IS NULL)';
        $sort_dir = (!empty($sort_dir) && strtoupper($sort_dir) === 'DESC') ? 'DESC' : 'ASC';
        
        if ($status === 'any') {
            return $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $t WHERE parent_id = %d AND deleted_at IS NULL{$default_filter} ORDER BY sort_order $sort_dir, name ASC",
                $parent_id
            ));
        }
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $t WHERE parent_id = %d AND status = %s AND deleted_at IS NULL{$default_filter} ORDER BY sort_order $sort_dir, name ASC",
            $parent_id, $status
        ));
    }

    public static function get_category($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hc_categories WHERE id = %d AND deleted_at IS NULL", $id
        ));
    }

    public static function get_category_by_slug($slug) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT c.* FROM {$wpdb->prefix}hc_categories c WHERE c.slug = %s AND " . HC_Lifecycle::sql_category_live('c'),
            $slug
        ));
    }


    /**
     * Get the hidden Uncategorized (default fallback) category.
     * Used internally by trash/delete handlers.
     */
    public static function get_uncategorized_category() {
        global $wpdb;
        return $wpdb->get_row(
            "SELECT * FROM {$wpdb->prefix}hc_categories
             WHERE is_default = 1 AND deleted_at IS NULL
             LIMIT 1"
        );
    }

    public static function get_subcategories($parent_id) {
        return self::get_categories($parent_id, 'published');
    }

    // =============================================
    // ARTICLES
    // =============================================
    public static function get_article_by_slug($slug) {
        global $wpdb;
        $preview_id = isset($_GET['hc_preview']) ? absint($_GET['hc_preview']) : 0;
        $preview_ok = $preview_id > 0 && is_user_logged_in() && current_user_can('manage_options')
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['hc_preview_token'] ?? '')), 'hc_preview_' . $preview_id);
        if ($preview_ok) {
            $article = $wpdb->get_row($wpdb->prepare("SELECT a.* FROM {$wpdb->prefix}hc_articles a WHERE a.id = %d AND a.slug = %s AND a.deleted_at IS NULL", $preview_id, $slug));
        } else {
            $article = $wpdb->get_row($wpdb->prepare(
                "SELECT a.* FROM {$wpdb->prefix}hc_articles a WHERE a.slug = %s AND " . HC_Lifecycle::sql_article_live('a'),
                $slug
            ));
        }

        if ($article && $preview_ok) {
            // Admin preview must reflect the latest autosaved working copy, not only the last manual save.
            $autosaved = get_user_meta(get_current_user_id(), 'hc_autosave_article_' . (int) $article->id, true);
            if (is_array($autosaved)) {
                foreach (array('title', 'excerpt', 'content') as $field) {
                    if (array_key_exists($field, $autosaved)) $article->$field = $autosaved[$field];
                }
            }
        }

        if ($article) {
            // Only count real page views (not AJAX, not bots)
            if (!wp_doing_ajax() && self::is_real_visitor() && self::should_count_view($article->id)) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}hc_articles SET view_count = view_count + 1 WHERE id = %d",
                    $article->id
                ));
                $article->view_count++;
            }
        }
        return $article;
    }

    private static function is_real_visitor() {
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
        if ($ua === '') return false;
        // Common bot patterns
        $bots = array('bot', 'crawl', 'spider', 'slurp', 'curl', 'wget', 'headless', 'facebook', 'preview');
        foreach ($bots as $b) {
            if (strpos($ua, $b) !== false) return false;
        }
        return true;
    }

    private static function should_count_view($article_id) {
        // Cookie-less view dedup: use a transient keyed on IP + article.
        // No setcookie(), no session_start() — 100% safe for AJAX.
        $ip  = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
        $key = 'hc_view_' . (int) $article_id . '_' . md5($ip);

        if (get_transient($key)) {
            return false;
        }
        set_transient($key, 1, 1800); // 30 minutes
        return true;
    }
    

    public static function get_article($id) {
        global $wpdb;
        $article = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hc_articles WHERE id = %d AND deleted_at IS NULL", $id
        ));
        
        if (!$article) return null;
        
        // Get ONLY published categories for this article
        $article->categories = $wpdb->get_results($wpdb->prepare(
            "SELECT c.* FROM {$wpdb->prefix}hc_categories c
             JOIN {$wpdb->prefix}hc_article_categories ac ON c.id = ac.category_id
             WHERE ac.article_id = %d AND c.deleted_at IS NULL AND c.status = 'published'", $id
        ));
        
        // Set primary category_id to first published category (or Uncategorized)
        if (!empty($article->categories)) {
            $article->category_id = $article->categories[0]->id;
            $article->category_name = $article->categories[0]->name;
        } else {
            $article->category_id = 0;
            $article->category_name = 'Uncategorized';
        }
        
        return $article;
    }
    public static function get_articles_by_category($category_id, $limit = 10, $offset = 0) {
        global $wpdb;
        $t = $wpdb->prefix . 'hc_articles';
        $rel = $wpdb->prefix . 'hc_article_categories';
        $limit = max(1, min(100, (int) $limit));
        $offset = max(0, (int) $offset);
        
        // Use the relationship table to find all articles linked to this category
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.* FROM $t a
             JOIN $rel ac ON a.id = ac.article_id
             WHERE ac.category_id = %d
             AND " . HC_Lifecycle::sql_article_live('a') . "
             ORDER BY a.updated_at DESC, a.created_at DESC
             LIMIT %d OFFSET %d",
            $category_id, $limit, $offset
        ));
    }

    public static function get_popular_article_ids() {
        $stored = get_option('hc_popular_article_ids', null);
        if (is_array($stored)) {
            return array_values(array_unique(array_filter(array_map('absint', $stored))));
        }
        $ids = array();
        // Migrate legacy article-level popular flags only before the curated option exists.
        if ($stored === null) {
            global $wpdb;
            $legacy = $wpdb->get_col("SELECT id FROM {$wpdb->prefix}hc_articles WHERE is_popular = 1 AND status = 'published' AND deleted_at IS NULL ORDER BY sort_order ASC, updated_at DESC, id DESC");
            if ($legacy) {
                $ids = array_values(array_unique(array_map('absint', $legacy)));
                update_option('hc_popular_article_ids', $ids, false);
            }
        }
        return $ids;
    }

    public static function get_popular_articles($limit = null, $offset = 0) {
        global $wpdb;
        if ($limit === null) $limit = (int) self::get_setting('hc_popular_limit', 6);
        $limit = max(1, min(100, (int) $limit));
        $offset = max(0, (int) $offset);
        $ids = self::get_popular_article_ids();
        $selected = array();
        if ($ids) {
            $ids_sql = implode(',', array_map('absint', $ids));
            $rows = $wpdb->get_results("SELECT a.* FROM {$wpdb->prefix}hc_articles a WHERE a.id IN ($ids_sql) AND " . HC_Lifecycle::sql_article_live('a'));
            $by_id = array();
            foreach ($rows as $row) $by_id[(int) $row->id] = $row;
            foreach ($ids as $id) if (isset($by_id[$id])) $selected[] = $by_id[$id];
        }
        // Fill the remaining list with the most-viewed live articles, excluding curated picks.
        $remaining = max(0, $limit + $offset - count($selected));
        if ($remaining > 0) {
            $exclude = $ids ? ' AND a.id NOT IN (' . implode(',', array_map('absint', $ids)) . ')' : '';
            $fallback = $wpdb->get_results($wpdb->prepare(
                "SELECT a.* FROM {$wpdb->prefix}hc_articles a WHERE " . HC_Lifecycle::sql_article_live('a') . "$exclude ORDER BY a.view_count DESC, a.updated_at DESC, a.id DESC LIMIT %d",
                $remaining
            ));
            $selected = array_merge($selected, $fallback);
        }
        return array_slice($selected, $offset, $limit);
    }

    public static function get_latest_articles($limit = null, $offset = 0) {
        global $wpdb;
        if ($limit === null) $limit = (int) self::get_setting('hc_latest_limit', 10);
        $limit = max(1, min(100, (int) $limit));
        $offset = max(0, (int) $offset);
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.* FROM {$wpdb->prefix}hc_articles a
             WHERE " . HC_Lifecycle::sql_article_live('a') . "
             ORDER BY a.updated_at DESC, a.created_at DESC
             LIMIT %d OFFSET %d", $limit, $offset
        ));
    }

    public static function get_related_articles($article_id, $category_id, $subcategory_id = null, $limit = 3) {
        global $wpdb;
        
        // Get related articles from the same published categories
        $related = $wpdb->get_results($wpdb->prepare(
            "SELECT DISTINCT a.* FROM {$wpdb->prefix}hc_articles a
             JOIN {$wpdb->prefix}hc_article_categories ac ON a.id = ac.article_id
             JOIN {$wpdb->prefix}hc_categories c ON ac.category_id = c.id
             WHERE ac.category_id = %d 
             AND a.id != %d 
             AND " . HC_Lifecycle::sql_article_live('a') . "
             AND " . HC_Lifecycle::sql_category_live('c') . "
             ORDER BY a.view_count DESC
             LIMIT %d",
            $category_id, $article_id, $limit
        ));
        
        return $related;
    }

    /** Normalize a public search phrase without losing meaningful words. */
    public static function normalize_search_query($query) {
        $query = wp_strip_all_tags((string) $query);
        $query = html_entity_decode($query, ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');
        $query = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $query);
        $query = preg_replace('/\s+/u', ' ', trim($query));
        return mb_substr($query, 0, 160);
    }

    /** Build a cached vocabulary from live article titles, summaries and keywords. */
    private static function search_vocabulary() {
        global $wpdb;
        $cached = get_transient('hc_search_vocabulary_v1');
        if (is_array($cached)) return $cached;
        $rows = $wpdb->get_results("SELECT a.title,a.excerpt,a.meta_keywords FROM {$wpdb->prefix}hc_articles a WHERE " . HC_Lifecycle::sql_article_live('a') . " ORDER BY a.updated_at DESC LIMIT 3000");
        $vocab = array();
        foreach ((array)$rows as $row) {
            $source = strtolower(wp_strip_all_tags((string)$row->title . ' ' . (string)$row->excerpt . ' ' . (string)$row->meta_keywords));
            $tokens = preg_split('/[^a-z0-9]+/i', $source, -1, PREG_SPLIT_NO_EMPTY);
            foreach ($tokens as $token) {
                if (strlen($token) < 3 || strlen($token) > 24) continue;
                $vocab[$token] = isset($vocab[$token]) ? $vocab[$token] + 1 : 1;
            }
        }
        set_transient('hc_search_vocabulary_v1', $vocab, 6 * HOUR_IN_SECONDS);
        return $vocab;
    }

    /** Correct likely misspellings only when the original token is absent from the article vocabulary. */
    private static function correct_search_terms($terms) {
        $vocab = self::search_vocabulary();
        if (!$vocab) return $terms;
        $corrected = array();
        foreach ($terms as $term) {
            if (isset($vocab[$term]) || strlen($term) < 4) continue;
            $best = ''; $best_distance = 3;
            foreach ($vocab as $candidate => $frequency) {
                if (abs(strlen($candidate) - strlen($term)) > 2) continue;
                $distance = levenshtein($term, $candidate);
                if ($distance < $best_distance || ($distance === $best_distance && $frequency > ($vocab[$best] ?? 0))) {
                    $best = $candidate; $best_distance = $distance;
                }
                if ($best_distance === 1 && $frequency > 8) break;
            }
            // Only use a confident correction; retain the visitor's original query for display/logging.
            if ($best !== '' && $best_distance <= (strlen($term) >= 8 ? 2 : 1)) $corrected[$term] = $best;
        }
        return $corrected;
    }

    /** Build the shared relevance query so result lists and totals cannot disagree. */
    private static function search_query_parts($query) {
        global $wpdb;
        $query = self::normalize_search_query($query);
        if ($query === '' || mb_strlen($query) < 2) return false;
        $stop = array('the','and','for','with','from','that','this','are','was','you','your','how','what','where','when','why','can','does','into','in','on','of','to','is','a','an','or','by','at','be','it');
        $terms = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($query), -1, PREG_SPLIT_NO_EMPTY);
        $terms = array_values(array_unique(array_filter($terms, function($term) use ($stop) {
            return mb_strlen($term) >= 2 && !in_array($term, $stop, true);
        })));
        // Keep the visitor's actual terms separate: aliases must broaden matching, not
        // make an article earn full-term coverage for words the visitor never typed.
        $required_terms = $terms;
        // Automatically correct likely misspellings using vocabulary extracted from published article titles, summaries and keywords.
        $auto_corrections = self::correct_search_terms($terms);
        foreach ($auto_corrections as $wrong => $right) { $terms[] = $right; }
        // Expand common support-language synonyms and optional administrator-defined aliases.
        // Custom format: login=sign in|signin;wifi=wireless|wi-fi (one mapping per line).
        $synonyms = array(
            'login' => array('sign in','signin'), 'signin' => array('login','sign in'),
            'logout' => array('sign out','logoff'), 'password' => array('passcode','credentials'),
            'wifi' => array('wi-fi','wireless'), 'internet' => array('broadband','connection'),
            'cancel' => array('cancellation','stop'), 'refund' => array('reimbursement','money back'),
            'billing' => array('payment','invoice','bill'), 'payment' => array('billing','invoice'),
        );
        $custom = (string) self::get_setting('hc_search_synonyms', '');
        foreach (preg_split('/\r?\n/', $custom) as $line) {
            if (strpos($line, '=') === false) continue;
            list($key, $values) = array_map('trim', explode('=', $line, 2));
            $key = sanitize_title($key);
            $aliases = preg_split('/[|,]+/', strtolower($values), -1, PREG_SPLIT_NO_EMPTY);
            if ($key && $aliases) $synonyms[$key] = array_slice(array_map('sanitize_text_field', $aliases), 0, 8);
        }
        $expanded = $terms;
        foreach ($auto_corrections as $wrong => $right) { $expanded[] = $right; }
        foreach ($terms as $term) {
            if (isset($synonyms[$term])) {
                foreach ($synonyms[$term] as $alias) {
                    $alias_parts = preg_split('/[^a-z0-9]+/i', strtolower($alias), -1, PREG_SPLIT_NO_EMPTY);
                    foreach ($alias_parts as $alias_part) if (strlen($alias_part) >= 2 && !in_array($alias_part, $stop, true)) $expanded[] = $alias_part;
                }
            }
        }
        $terms = array_values(array_unique($expanded));
        // For stop-word-only queries, search the whole phrase rather than returning unrelated rows.
        if (!$terms) $terms = array(mb_strtolower($query));
        $or = array(); $params = array(); $score = array(); $score_params = array(); $coverage = array(); $coverage_params = array();
        foreach ($terms as $term) {
            $like = '%' . $wpdb->esc_like($term) . '%';
            $or[] = '(LOWER(a.title) LIKE %s OR LOWER(COALESCE(a.excerpt,\'\')) LIKE %s OR LOWER(COALESCE(a.meta_keywords,\'\')) LIKE %s OR LOWER(COALESCE(a.content,\'\')) LIKE %s)';
            array_push($params, $like, $like, $like, $like);
            // Weighted term scoring: title > keywords > excerpt > body.
            $score[] = '(CASE WHEN LOWER(a.title) LIKE %s THEN 12 ELSE 0 END + CASE WHEN LOWER(COALESCE(a.meta_keywords,\'\')) LIKE %s THEN 7 ELSE 0 END + CASE WHEN LOWER(COALESCE(a.excerpt,\'\')) LIKE %s THEN 5 ELSE 0 END + CASE WHEN LOWER(COALESCE(a.content,\'\')) LIKE %s THEN 2 ELSE 0 END)';
            array_push($score_params, $like, $like, $like, $like);
        }
        // Coverage is based only on the original query terms, not synonym aliases.
        foreach ($required_terms as $required_term) {
            $required_like = '%' . $wpdb->esc_like($required_term) . '%';
            $coverage[] = '(CASE WHEN (LOWER(a.title) LIKE %s OR LOWER(COALESCE(a.excerpt,\'\')) LIKE %s OR LOWER(COALESCE(a.meta_keywords,\'\')) LIKE %s OR LOWER(COALESCE(a.content,\'\')) LIKE %s) THEN 1 ELSE 0 END)';
            array_push($coverage_params, $required_like, $required_like, $required_like, $required_like);
        }
        $phrase = '%' . $wpdb->esc_like(mb_strtolower($query)) . '%';
        $where = '(' . implode(' OR ', $or) . ')';
        $coverage_bonus = $required_terms ? '(CASE WHEN (' . implode(' + ', $coverage) . ') = ' . (int) count($required_terms) . ' THEN 100 ELSE 0 END)' : '0';
        $relevance = '(' . $coverage_bonus . ' + (' . implode(' + ', $score) . ') + CASE WHEN LOWER(a.title) = %s THEN 100 ELSE 0 END + CASE WHEN LOWER(a.title) LIKE %s THEN 55 ELSE 0 END + CASE WHEN LOWER(a.title) LIKE %s THEN 24 ELSE 0 END + CASE WHEN LOWER(COALESCE(a.meta_keywords,\'\')) LIKE %s THEN 8 ELSE 0 END)';
        $relevance_params = array_merge($coverage_params, $score_params, array(mb_strtolower($query), $phrase, $wpdb->esc_like(mb_strtolower($query)) . '%', $phrase));
        return array($where, $params, $relevance, $relevance_params, $query);
    }

    public static function search_articles($query, $limit = 20, $offset = 0) {
        global $wpdb;
        $parts = self::search_query_parts($query);
        if (!$parts) return array();
        list($where, $params, $relevance, $relevance_params, $clean) = $parts;
        $limit = max(1, min(100, (int) $limit));
        $offset = max(0, (int) $offset);
        $category_name = "COALESCE((SELECT c.name FROM {$wpdb->prefix}hc_article_categories ac JOIN {$wpdb->prefix}hc_categories c ON c.id=ac.category_id WHERE ac.article_id=a.id AND " . HC_Lifecycle::sql_category_live('c') . " ORDER BY (c.id=a.category_id) DESC,c.sort_order ASC,c.id ASC LIMIT 1),(SELECT c.name FROM {$wpdb->prefix}hc_categories c WHERE c.id=a.category_id AND " . HC_Lifecycle::sql_category_live('c') . " LIMIT 1))";
        $category_slug = "COALESCE((SELECT c.slug FROM {$wpdb->prefix}hc_article_categories ac JOIN {$wpdb->prefix}hc_categories c ON c.id=ac.category_id WHERE ac.article_id=a.id AND " . HC_Lifecycle::sql_category_live('c') . " ORDER BY (c.id=a.category_id) DESC,c.sort_order ASC,c.id ASC LIMIT 1),(SELECT c.slug FROM {$wpdb->prefix}hc_categories c WHERE c.id=a.category_id AND " . HC_Lifecycle::sql_category_live('c') . " LIMIT 1))";
        $sql = "SELECT a.*, {$category_name} AS category_name, {$category_slug} AS category_slug, {$relevance} AS relevance
                FROM {$wpdb->prefix}hc_articles a
                WHERE " . HC_Lifecycle::sql_article_live('a') . " AND {$where}
                ORDER BY relevance DESC, a.updated_at DESC, a.view_count DESC, a.id DESC
                LIMIT %d OFFSET %d";
        $all = array_merge($relevance_params, $params, array($limit, $offset));
        return $wpdb->get_results($wpdb->prepare($sql, $all));
    }

    /** Build a readable excerpt around the first matching search term. */
    public static function search_excerpt($article, $query, $words = 30) {
        $excerpt = !empty($article->excerpt) ? wp_strip_all_tags($article->excerpt) : '';
        $body = wp_strip_all_tags($article->content ?? '');
        $terms = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower(self::normalize_search_query($query)), -1, PREG_SPLIT_NO_EMPTY);
        $source = $excerpt;
        $matched = false;
        foreach ($terms as $term) {
            if (mb_strlen($term) < 2) continue;
            if ($source !== '' && mb_stripos($source, $term) !== false) { $matched = true; break; }
        }
        if (!$matched && $body !== '') $source = $body;
        if ($source === '') return '';
        $position = false;
        foreach ($terms as $term) {
            if (mb_strlen($term) < 2) continue;
            $found = mb_stripos($source, $term);
            if ($found !== false && ($position === false || $found < $position)) $position = $found;
        }
        if ($position !== false && $position > 120) {
            $start = max(0, $position - 100);
            $source = ($start > 0 ? '…' : '') . mb_substr($source, $start);
        }
        return wp_trim_words($source, max(10, (int)$words), '…');
    }

    /** Highlight individual query words after escaping all source content. */
    public static function highlight_search_terms($text, $query) {
        $safe = esc_html((string)$text);
        $terms = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower(self::normalize_search_query($query)), -1, PREG_SPLIT_NO_EMPTY);
        $terms = array_values(array_unique(array_filter($terms, function($term) { return mb_strlen($term) >= 2; })));
        usort($terms, function($a,$b) { return mb_strlen($b) - mb_strlen($a); });
        foreach ($terms as $term) {
            $safe = preg_replace('/(' . preg_quote(esc_html($term), '/') . ')/iu', '<mark>$1</mark>', $safe);
        }
        return $safe;
    }

    public static function count_search_articles($query) {
        global $wpdb;
        $parts = self::search_query_parts($query);
        if (!$parts) return 0;
        list($where, $params) = $parts;
        $sql = "SELECT COUNT(*) FROM {$wpdb->prefix}hc_articles a WHERE " . HC_Lifecycle::sql_article_live('a') . " AND {$where}";
        return (int) $wpdb->get_var($wpdb->prepare($sql, $params));
    }

    public static function log_search($query, $count) {
        if (self::get_setting('hc_log_searches', '1') !== '1') return;
        global $wpdb;
        $query = self::normalize_search_query($query);
        if (mb_strlen($query) < 2) return;
        $ua = strtolower(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '');
        if ($ua === '' || preg_match('/bot|crawl|spider|slurp|preview|facebookexternalhit|headless/i', $ua)) return;
        $raw_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
        // Store a site-salted, non-reversible visitor key instead of the raw IP address.
        $ip = $raw_ip !== '' ? substr(hash_hmac('sha256', $raw_ip, wp_salt('auth')), 0, 40) : '';
        $table = $wpdb->prefix . 'hc_search_log';
        // Prevent refreshes and overlapping live-search/page-search requests from inflating analytics.
        $dedupe_cutoff = date('Y-m-d H:i:s', current_time('timestamp') - 20);
        $recent = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE LOWER(search_query) = LOWER(%s) AND user_ip = %s AND created_at >= %s LIMIT 1",
            $query, $ip, $dedupe_cutoff
        ));
        if ($recent) return;
        $wpdb->insert($table, array(
            'search_query' => $query,
            'results_count' => max(0, (int) $count),
            'user_ip' => $ip,
            'user_id' => 0,
            'created_at' => current_time('mysql'),
        ));
    }

    // =============================================
    // FAQs
    // =============================================
    /**
     * Get FAQs for a specific context.
     *
     * @param string $context  'home' | 'category' | 'article' | 'contact'
     * @param int    $context_id  Category ID or Article ID (when relevant)
     */
        public static function get_faqs($context = 'home', $context_id = 0) {
        global $wpdb;
        $t = $wpdb->prefix . 'hc_faqs';

        // Base: always allow global
        $where = "status = 'published' AND deleted_at IS NULL AND (destination_type = 'global'";

        if ($context === 'home') {
            $where .= " OR destination_type = 'home'";
        } elseif ($context === 'contact') {
            $where .= " OR destination_type = 'contact'";
        } elseif ($context === 'category' && $context_id) {
            $where .= $wpdb->prepare(
                " OR (destination_type = 'category' AND destination_id = %d)",
                $context_id
            );
        } elseif ($context === 'article' && $context_id) {
            $where .= $wpdb->prepare(
                " OR (destination_type = 'article' AND destination_id = %d)",
                $context_id
            );
        }

        $where .= ")";

        $sql = "SELECT * FROM $t WHERE $where
                ORDER BY sort_order ASC, created_at DESC
                LIMIT " . intval(self::get_setting('hc_faq_max', 20));

        return $wpdb->get_results($sql);
    }

    public static function get_faq($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hc_faqs WHERE id = %d AND deleted_at IS NULL", $id
        ));
    }

    // =============================================
    // HELPERS
    // =============================================
    public static function calculate_reading_time($content) {
        $words = str_word_count(wp_strip_all_tags($content));
        return max(1, (int) ceil($words / 200));
    }

    public static function time_ago($datetime) {
        // DB stores UTC; compare against WP-local now, both UTC-corrected
        $ts = strtotime($datetime . ' UTC');
        return human_time_diff($ts, current_time('timestamp')) . ' ago';
    }

    public static function format_date($datetime, $format = 'M j, Y') {
        return date($format, strtotime($datetime));
    }

    public static function get_avatar_url($user_id, $size = 40) {
        return get_avatar_url($user_id, array('size' => $size));
    }

    // =============================================
    // SCHEMA HELPERS
    // =============================================
    public static function column_exists($table, $column) {
        global $wpdb;
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
            DB_NAME, $table, $column
        ));
        return $found > 0;
    }

    /**
     * Append a draft reason to a FAQ. Keeps only the last 3 entries.
     * $reason: string like 'Article "test" was moved to trash'
     */
    public static function log_faq_draft_reason($faq_id, $reason) {
        global $wpdb;
        $t = $wpdb->prefix . 'hc_faqs';
        $row = $wpdb->get_var($wpdb->prepare("SELECT draft_reasons FROM $t WHERE id = %d", $faq_id));
        $history = array();
        if (!empty($row)) {
            $decoded = json_decode($row, true);
            if (is_array($decoded)) $history = $decoded;
        }
        // Newest first
        array_unshift($history, array(
            'at'     => current_time('mysql'),
            'reason' => (string) $reason,
        ));
        // Keep last 3
        $history = array_slice($history, 0, 3);
        $wpdb->update($t, array('draft_reasons' => wp_json_encode($history)), array('id' => (int) $faq_id));
    }

    /**
     * Return the draft history array for a FAQ (newest first).
     */
    public static function get_faq_draft_reasons($faq_id) {
        global $wpdb;
        $row = $wpdb->get_var($wpdb->prepare(
            "SELECT draft_reasons FROM {$wpdb->prefix}hc_faqs WHERE id = %d",
            (int) $faq_id
        ));
        if (empty($row)) return array();
        $decoded = json_decode($row, true);
        return is_array($decoded) ? $decoded : array();
    }

    /**
     * Get ALL FAQs (draft + published) linked to an article — admin use only.
     */
    public static function get_faqs_admin($article_id) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hc_faqs
             WHERE destination_type = 'article' AND destination_id = %d AND deleted_at IS NULL
             ORDER BY sort_order ASC, created_at DESC",
            (int) $article_id
        ));
    }

    // =============================================
    // FAQ CASCADE HELPERS
    // =============================================

    /**
     * Draft all published FAQs attached to a category (or its subcategories).
     * Called when a category is trashed/drafted/hidden.
     */
    public static function draft_faqs_for_category($cat_id, $reason = 'Parent category unavailable') {
        global $wpdb;
        $cat_id = (int) $cat_id;
        if (!$cat_id) return 0;

        // Draft ALL non-trashed FAQs under this category (regardless of current status)
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}hc_faqs
             WHERE destination_type = 'category' AND destination_id = %d
               AND deleted_at IS NULL",
            $cat_id
        ));
        $count = 0;
        foreach ($ids as $fid) {
            $wpdb->update(
                $wpdb->prefix . 'hc_faqs',
                array('status' => 'draft'),
                array('id' => $fid)
            );
            if (method_exists(__CLASS__, 'log_faq_draft_reason')) {
                self::log_faq_draft_reason($fid, $reason);
            }
            $count++;
        }
        return $count;
    }

    /**
     * Draft FAQs for a category AND all its subcategories.
     * Returns total count drafted.
     */
    public static function draft_faqs_for_category_tree($cat_id, $reason = 'Parent category unavailable') {
        global $wpdb;
        $cat_id = (int) $cat_id;
        if (!$cat_id) return 0;

        $count = self::draft_faqs_for_category($cat_id, $reason);

        // Subcategories
        $subs = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}hc_categories WHERE parent_id = %d",
            $cat_id
        ));
        foreach ($subs as $sub_id) {
            $count += self::draft_faqs_for_category($sub_id, $reason);
        }
        return $count;
    }

    /**
     * Reassign FAQs attached to a category (or its subcategories) to global + draft.
     * Called when a category is permanently deleted.
     */
    public static function detach_faqs_from_category($cat_id, $reason = 'Parent category permanently deleted') {
        global $wpdb;
        $cat_id = (int) $cat_id;
        if (!$cat_id) return 0;

        $count = 0;

        // Direct FAQs
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}hc_faqs
             WHERE destination_type = 'category' AND destination_id = %d AND deleted_at IS NULL",
            $cat_id
        ));
        foreach ($ids as $fid) {
            $wpdb->update(
                $wpdb->prefix . 'hc_faqs',
                array(
                    'status'     => 'draft',
                    'deleted_at' => current_time('mysql'),
                ),
                array('id' => $fid)
            );
            if (method_exists(__CLASS__, 'log_faq_draft_reason')) {
                self::log_faq_draft_reason($fid, $reason);
            }
            $count++;
        }

        // Subcategory FAQs
        $subs = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}hc_categories WHERE parent_id = %d",
            $cat_id
        ));
        foreach ($subs as $sub_id) {
            $sub_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}hc_faqs
                 WHERE destination_type = 'category' AND destination_id = %d AND deleted_at IS NULL",
                $sub_id
            ));
            foreach ($sub_ids as $fid) {
                $wpdb->update(
                    $wpdb->prefix . 'hc_faqs',
                    array(
                        'status'     => 'draft',
                        'deleted_at' => current_time('mysql'),
                    ),
                    array('id' => $fid)
                );
                if (method_exists(__CLASS__, 'log_faq_draft_reason')) {
                    self::log_faq_draft_reason($fid, $reason);
                }
                $count++;
            }
        }

        return $count;
    }


    /**
     * Log an action on any HC entity.
     * $type = 'article' | 'faq' | 'category'
     * $action = 'Saved' | 'Published' | 'Drafted' | 'Trashed' | 'Restored' | 'Deleted' | 'Bulk-edited' etc.
     */
    public static function log_action($type, $id, $action) {
        global $wpdb;
        $id = (int) $id;
        if (!$id) return;

        $tables = array(
            'article'  => $wpdb->prefix . 'hc_articles',
            'faq'      => $wpdb->prefix . 'hc_faqs',
            'category' => $wpdb->prefix . 'hc_categories',
        );
        if (!isset($tables[$type])) return;

        $wpdb->update(
            $tables[$type],
            array(
                'last_action_at' => current_time('mysql'),
                'last_action'    => substr((string) $action, 0, 50),
            ),
            array('id' => $id)
        );
    }

    /**
     * Return human-readable "X ago" from a timestamp.
     */
    public static function human_time($timestamp) {
        if (empty($timestamp)) return '—';
        // HC_TIMEZONE_FIX: do not append ' UTC' — timestamp is already in local WP timezone
        $ts = strtotime($timestamp);
        if (!$ts) return '—';
        // If the resulting diff is negative (timestamp is in the future), show "just now"
        $diff = $ts - current_time('timestamp');
        if ($diff > 0) {
            return 'just now';
        }
        return human_time_diff($ts, current_time('timestamp')) . ' ago';
    }

}
