<?php
$file = '/var/www/hckimg.site/public/wp-content/themes/elessi-theme-child/helpcenter/assets/js/admin.js';
$src = file_get_contents($file);

if (strpos($src, 'HC_TABS_AJAX') !== false) {
    echo "SKIP: tabs ajax already present\n";
    exit(0);
}

$addition = <<<'JS'

/* =============================================
   HC_TABS_AJAX — instant tab switching via AJAX
   ============================================= */
(function() {
    'use strict';

    // Map tab href → view param
    function extractView(href) {
        var m = href.match(/[?&]view=([^&]*)/);
        return m ? decodeURIComponent(m[1]) : '';
    }

    document.addEventListener('click', function(e) {
        var tab = e.target.closest('.hc-list-tab');
        if (!tab) return;

        // Only handle clicks on our own admin pages
        if (!tab.href || tab.href.indexOf('/helpcenter/admin/') === -1) return;

        e.preventDefault();

        var view = extractView(tab.getAttribute('href') || '');

        // Figure out which list we're on
        var wrap = document.querySelector('.hc-articles-search') ||
                   document.querySelector('.hc-faqs-search') ||
                   document.querySelector('.hc-cats-search');
        if (!wrap) { window.location.href = tab.href; return; }

        // Update the tab active state
        document.querySelectorAll('.hc-list-tab').forEach(function(t) {
            t.classList.remove('active');
        });
        tab.classList.add('active');

        // Update the wrapper's data-view
        wrap.setAttribute('data-view', view);

        // Update the bulk bar's data-view (so the correct bulk ops show)
        var bulkBar = document.getElementById('hcBulkBar');
        if (bulkBar) {
            bulkBar.setAttribute('data-view', view);

            // Swap the bulk action buttons for trash vs normal view
            var actions = bulkBar.querySelector('.hc-bulk-bar-actions');
            if (actions) {
                if (view === 'trash') {
                    actions.innerHTML =
                        '<button type="button" class="hc-bulk-btn" data-bulk-op="restore"><i class="fas fa-undo"></i> Restore</button>' +
                        '<button type="button" class="hc-bulk-btn hc-bulk-btn-danger" data-bulk-op="hard_delete"><i class="fas fa-trash-alt"></i> Delete Permanently</button>' +
                        '<button type="button" class="hc-bulk-btn hc-bulk-btn-outline" data-bulk-clear><i class="fas fa-times"></i> Clear</button>';
                } else {
                    actions.innerHTML =
                        '<button type="button" class="hc-bulk-btn" data-bulk-op="publish"><i class="fas fa-eye"></i> Publish</button>' +
                        '<button type="button" class="hc-bulk-btn" data-bulk-op="draft"><i class="fas fa-pen"></i> Draft</button>' +
                        '<button type="button" class="hc-bulk-btn hc-bulk-btn-danger" data-bulk-op="delete"><i class="fas fa-trash"></i> Move to Trash</button>' +
                        '<button type="button" class="hc-bulk-btn hc-bulk-btn-outline" data-bulk-clear><i class="fas fa-times"></i> Clear</button>';
                }
            }
        }

        // Show or hide the "Empty Trash" and "New Article" buttons
        var toolbar = wrap;
        var emptyTrashBtn = toolbar.querySelector('.hc-empty-trash-btn');
        var newBtn = toolbar.querySelector('.hc-admin-btn-primary');

        // Handle empty trash button dynamically
        if (view === 'trash') {
            if (!emptyTrashBtn) {
                // create it
                emptyTrashBtn = document.createElement('button');
                emptyTrashBtn.type = 'button';
                emptyTrashBtn.className = 'hc-admin-btn hc-admin-btn-outline hc-admin-btn-sm hc-empty-trash-btn';
                emptyTrashBtn.setAttribute('data-trash-type', 'articles');
                emptyTrashBtn.innerHTML = '<i class="fas fa-trash-alt"></i> Empty Trash';
                var filters = toolbar.querySelector('.hc-admin-filters');
                if (filters) filters.appendChild(emptyTrashBtn);
            }
            if (newBtn) newBtn.style.display = 'none';
        } else {
            if (emptyTrashBtn) emptyTrashBtn.style.display = 'none';
            if (newBtn) newBtn.style.display = '';
        }

        // Clear any checkbox selection
        document.querySelectorAll('.hc-row-check:checked').forEach(function(c) { c.checked = false; });
        var bar = document.getElementById('hcBulkBar');
        if (bar) bar.classList.remove('open');

        // Re-run the search
        if (wrap._hcSearch) {
            wrap._hcSearch(true);
        }

        // Update URL without reload
        if (window.history && window.history.pushState) {
            var url = tab.href;
            // normalize — strip double ?
            window.history.pushState({ view: view }, '', url);
        }
    });
})();
JS;

file_put_contents($file, $src . "\n" . $addition);
echo "OK: tab ajax handler appended\n";
