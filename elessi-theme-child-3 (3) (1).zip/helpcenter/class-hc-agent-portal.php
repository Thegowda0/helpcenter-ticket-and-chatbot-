<?php
/** Dedicated HelpCenter agent accounts and isolated agent workspace. */
if (!defined('ABSPATH')) exit;
class HC_Agent_Portal {
    public static function register() {
        add_rewrite_rule('^helpcenter/agent/?$', 'index.php?hc_page=agent-portal', 'top');
        add_rewrite_rule('^helpcenter/agent/login/?$', 'index.php?hc_page=agent-login', 'top');
        add_rewrite_rule('^helpcenter/agent/forgot-password/?$', 'index.php?hc_page=agent-forgot', 'top');
        add_rewrite_rule('^helpcenter/agent/reset-password/?$', 'index.php?hc_page=agent-reset', 'top');
        add_rewrite_rule('^support-agent/?$', 'index.php?hc_page=agent-portal', 'top');
        add_rewrite_rule('^support-agent/login/?$', 'index.php?hc_page=agent-login', 'top');
        add_rewrite_rule('^support-agent/forgot-password/?$', 'index.php?hc_page=agent-forgot', 'top');
        add_rewrite_rule('^support-agent/reset-password/?$', 'index.php?hc_page=agent-reset', 'top');
        add_action('init', array(__CLASS__,'ensure_role'), 15);
        add_action('init', array(__CLASS__,'ensure_workspace_tables'), 30);
        add_action('init', array(__CLASS__,'ensure_availability_session_table'), 31);
        add_action('wp_ajax_hc_agent_workspace_data', array(__CLASS__,'workspace_data'));
        add_action('wp_ajax_hc_agent_workspace_note', array(__CLASS__,'workspace_note'));
        add_action('wp_ajax_hc_agent_workspace_note_edit', array(__CLASS__,'workspace_note_edit'));
        add_action('wp_ajax_hc_agent_workspace_note_delete', array(__CLASS__,'workspace_note_delete'));
        add_action('wp_ajax_hc_agent_workspace_side_create', array(__CLASS__,'workspace_side_create'));
        add_action('wp_ajax_hc_agent_workspace_side_reply', array(__CLASS__,'workspace_side_reply'));
        add_action('wp_ajax_hc_agent_workspace_side_get', array(__CLASS__,'workspace_side_get'));
        add_action('wp_ajax_hc_agent_workspace_update', array(__CLASS__,'workspace_update'));
        add_action('wp_ajax_hc_agent_hck_ticket', array(__CLASS__,'hck_previous_ticket_detail'));
        add_action('wp_ajax_hc_agent_hck_claim', array(__CLASS__,'hck_previous_ticket_claim'));
        add_action('wp_login', array(__CLASS__,'agent_login_offline'), 20, 2);
        add_action('wp_logout', array(__CLASS__,'agent_logout_offline'), 20);
        add_action('wp_ajax_hc_agent_directory', array(__CLASS__,'agent_directory'));
        add_action('wp_ajax_hc_agent_bulk_delete', array(__CLASS__,'bulk_delete_agents'));
        add_action('template_redirect', array(__CLASS__,'disable_cache'), -1000);
        add_action('template_redirect', array(__CLASS__,'route'), 0);
        add_action('admin_init', array(__CLASS__,'restrict_agent_admin'));
        add_action('admin_notices', array(__CLASS__,'support_role_admin_notice'));
        add_filter('show_admin_bar', array(__CLASS__,'hide_admin_bar'));
        add_filter('retrieve_password_title', array(__CLASS__,'reset_subject'), 10, 3);
        add_filter('retrieve_password_message', array(__CLASS__,'reset_message'), 10, 4);
        add_action('wp_ajax_hc_agent_create', array(__CLASS__,'create_agent'));
        add_action('wp_ajax_hc_agent_generate_password', array(__CLASS__,'generate_password'));
        add_action('wp_ajax_hc_agent_search', array(__CLASS__,'search_agents'));
        add_action('wp_ajax_hc_agent_manage', array(__CLASS__,'manage_agent'));
        add_action('wp_ajax_hc_agent_list', array(__CLASS__,'list_tickets'));
        add_action('wp_ajax_hc_agent_global_search', array(__CLASS__,'global_search'));
        add_action('wp_ajax_hc_agent_live_list', array(__CLASS__,'list_live_conversations'));
        add_action('wp_ajax_hc_agent_live_ticket', array(__CLASS__,'live_ticket_detail'));
        add_action('wp_ajax_hc_agent_live_convert', array(__CLASS__,'convert_live_conversation'));
        add_action('wp_ajax_hc_agent_ticket', array(__CLASS__,'ticket_detail'));
        add_action('wp_ajax_hc_agent_title_update', array(__CLASS__,'update_ticket_title'));
        add_action('wp_ajax_hc_agent_send_followup_email', array(__CLASS__,'send_followup_email'));
        add_action('wp_ajax_hc_agent_reply', array(__CLASS__,'reply'));
        add_action('wp_ajax_hc_agent_realtime_relay', array(__CLASS__,'realtime_relay'));
        add_action('wp_ajax_hc_agent_close', array(__CLASS__,'close'));
        add_action('wp_ajax_hc_agent_claim', array(__CLASS__,'claim'));
        add_action('wp_ajax_hc_agent_presence', array(__CLASS__,'presence'));
        add_action('wp_ajax_hc_agent_text_assist', array(__CLASS__,'text_assist'));
        add_action('wp_ajax_hc_agent_transfer', array(__CLASS__,'transfer'));
        add_action('wp_ajax_hc_agent_summary', array(__CLASS__,'generate_summary'));
        add_action('hc_agent_generate_handover_summary', array(__CLASS__,'generate_handover_summary_job'), 10, 1);
        add_action('hc_agent_generate_ticket_title', array(__CLASS__,'generate_ticket_title_job'), 10, 1);
    }

    public static function support_role_admin_notice() {
        if (!current_user_can('create_users') && !current_user_can('edit_users')) return;
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || !in_array($screen->id, array('user-new','user-edit'), true)) return;
        echo '<div class="notice notice-info"><p><strong>HelpCenter Support Agent:</strong> Select this role in the WordPress Role dropdown to add this user to Support Agents and make them available for selection in Human Support settings.</p></div>';
    }

    public static function ensure_role() {
        $role = get_role('hc_support_agent');
        if (!$role) {
            add_role('hc_support_agent','HelpCenter Support Agent',array('read'=>true,'hc_agent_portal_access'=>true,'hc_manage_ai_escalations'=>true));
            $role = get_role('hc_support_agent');
        }
        if ($role) {
            $role->add_cap('read');
            $role->add_cap('hc_agent_portal_access');
            $role->add_cap('hc_manage_ai_escalations');
            $role->add_cap('hck_reply_tickets');
            $role->add_cap('hck_view_tickets');
        }
    }
    private static function agent() { $u=wp_get_current_user(); return $u && $u->exists() && (in_array('hc_support_agent',(array)$u->roles,true) || user_can($u,'hc_agent_portal_access') || user_can($u,'hc_manage_ai_escalations')); }
    private static function supervisor() { return current_user_can('manage_options'); }
    private static function workspace_note_supervisor() { return self::supervisor() || (function_exists('hck_is_supervisor_user') && hck_is_supervisor_user()); }
    private static function guard() { if (!self::agent() && !self::supervisor()) wp_send_json_error(array('message'=>'Agent portal access required.'),403); if (!wp_verify_nonce($_POST['nonce']??'','hc_agent_portal')) wp_send_json_error(array('message'=>'Session expired. Refresh and sign in again.'),403); }
    public static function restrict_agent_admin() {
        if (!is_admin() || wp_doing_ajax() || !self::agent()) {
            return;
        }

        $user = wp_get_current_user();

        // Keep the WordPress backend available to site administrators.
        if (in_array('administrator', (array) $user->roles, true)
            || current_user_can('manage_options')) {
            return;
        }

        wp_safe_redirect(home_url('/support-agent/'));
        exit;
    }
    public static function hide_admin_bar($show) { return self::agent() ? false : $show; }
    public static function disable_cache() {
        if (!in_array(get_query_var('hc_page'), array('agent-portal','agent-login','agent-forgot','agent-reset'), true)) return;
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        if (!defined('DONOTCACHEOBJECT')) define('DONOTCACHEOBJECT', true);
        if (!defined('DONOTCACHEDB')) define('DONOTCACHEDB', true);
        nocache_headers();
        if (!headers_sent()) header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    }
    public static function route() {
        $page=get_query_var('hc_page');
        if ($page==='agent-login') { self::login_page(); exit; }
        if ($page==='agent-forgot') { self::forgot_password_page(); exit; }
        if ($page==='agent-reset') { self::reset_password_page(); exit; }
        if ($page==='agent-portal') { if (!self::agent()) { wp_safe_redirect(home_url('/support-agent/login/')); exit; } self::portal_page(); exit; }
    }

    public static function agent_login_offline($login,$user) {
        if(!$user || !in_array('hc_support_agent',(array)$user->roles,true)) return;
        global $wpdb; $presence=$wpdb->prefix.'hc_ai_support_presence'; $now=current_time('mysql');
        // A new login does not reset an active availability session (another device may be in use).
        $wpdb->query($wpdb->prepare("INSERT INTO {$presence} (user_id,is_available,last_seen,force_logged_out) VALUES (%d,0,%s,0) ON DUPLICATE KEY UPDATE last_seen=VALUES(last_seen),force_logged_out=0",(int)$user->ID,$now));
    }
    public static function agent_logout_offline() {
        $uid=get_current_user_id(); if(!$uid) return; $u=get_userdata($uid);
        if(!$u || !in_array('hc_support_agent',(array)$u->roles,true)) return;
        self::set_availability_session($uid,'offline','logout');
        global $wpdb; $wpdb->update($wpdb->prefix.'hc_ai_support_presence',array('is_available'=>0,'last_seen'=>current_time('mysql'),'force_logged_out'=>1),array('user_id'=>$uid),array('%d','%s','%d'),array('%d'));
        if(class_exists('HC_Realtime')) HC_Realtime::publish_agent_event($uid,'agent.presence',array('available'=>false));
    }

    public static function ensure_availability_session_table() {
        global $wpdb; $table=$wpdb->prefix.'support_agent_availability_sessions';
        $found=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)));
        if($found===$table) return;
        require_once ABSPATH.'wp-admin/includes/upgrade.php'; $charset=$wpdb->get_charset_collate();
        $sql="CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'offline',
            started_at datetime NOT NULL,
            ended_at datetime NULL,
            source varchar(30) NOT NULL DEFAULT 'helpcenter',
            PRIMARY KEY  (id),
            KEY user_status (user_id,status),
            KEY user_started (user_id,started_at),
            KEY ended_at (ended_at)
        ) {$charset};";
        dbDelta($sql);
    }

    private static function set_availability_session($user_id,$status,$source='helpcenter') {
        global $wpdb; $table=$wpdb->prefix.'support_agent_availability_sessions';
        self::ensure_availability_session_table();
        $now=current_time('mysql');
        $current=$wpdb->get_row($wpdb->prepare("SELECT id,status FROM {$table} WHERE user_id=%d AND ended_at IS NULL ORDER BY id DESC LIMIT 1",$user_id));
        if($current && $current->status===$status) return;
        $wpdb->query('START TRANSACTION');
        if($current) $wpdb->update($table,array('ended_at'=>$now),array('id'=>(int)$current->id),array('%s'),array('%d'));
        if($status!=='offline') $wpdb->insert($table,array('user_id'=>(int)$user_id,'status'=>$status,'started_at'=>$now,'ended_at'=>null,'source'=>sanitize_key($source)),array('%d','%s','%s','%s','%s'));
        if($wpdb->last_error) { $wpdb->query('ROLLBACK'); error_log('[Support Availability] Session transition failed: '.$wpdb->last_error); return false; }
        $wpdb->query('COMMIT'); return true;
    }

    private static function availability_totals($user_id) {
        global $wpdb; $table=$wpdb->prefix.'support_agent_availability_sessions'; $today=current_time('Y-m-d'); $now=current_time('mysql');
        $seconds=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(0,TIMESTAMPDIFF(SECOND,GREATEST(started_at,%s),LEAST(COALESCE(ended_at,%s),%s)))),0) FROM {$table} WHERE user_id=%d AND status='available' AND started_at<%s AND (ended_at IS NULL OR ended_at>%s)",$today.' 00:00:00',$now,$now,$user_id,$now,$today.' 00:00:00'));
        $active=$wpdb->get_row($wpdb->prepare("SELECT started_at FROM {$table} WHERE user_id=%d AND status='available' AND ended_at IS NULL ORDER BY id DESC LIMIT 1",$user_id));
        return array('available_seconds_today'=>max(0,$seconds),'available_since'=>$active?$active->started_at:null);
    }
    private static function auth_card($title,$subtitle,$body) { status_header(200);nocache_headers();?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?php echo esc_html($title); ?></title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:radial-gradient(circle at 15% 10%,#e9e7ff,transparent 35%),linear-gradient(135deg,#f6f7fb,#edf1f8);font:15px Inter,system-ui;color:#20283b}.auth{width:min(440px,100%);padding:34px;background:#fff;border:1px solid #e6e9f1;border-radius:22px;box-shadow:0 24px 80px #24304a18}.brand{display:flex;align-items:center;gap:11px;margin-bottom:26px;font-weight:750}.mark{width:42px;height:42px;display:grid;place-items:center;border-radius:14px;background:#eeedff;color:#5146bd;font-size:21px}.eyebrow{color:#746bc9;font-size:10px;font-weight:800;letter-spacing:1.5px}h1{font-size:25px;letter-spacing:-.6px;margin:7px 0}.muted{color:#748096;line-height:1.6;margin:0 0 22px}label{display:block;font-weight:650;font-size:12px;margin:15px 0 7px}input{width:100%;height:47px;border:1px solid #dfe4ee;border-radius:11px;padding:0 13px;font:inherit;outline:none}input:focus{border-color:#8e85df;box-shadow:0 0 0 3px #786ce51b}button{width:100%;height:47px;margin-top:20px;border:0;border-radius:11px;background:#5146b8;color:#fff;font-weight:700;font-size:14px;cursor:pointer}button:hover{background:#40369e}.notice{padding:12px 14px;border-radius:10px;background:#f2f0ff;color:#4b438e;line-height:1.5;margin:16px 0}.error{background:#fff0f0;color:#a92f38}.links{display:flex;justify-content:space-between;gap:12px;margin-top:20px;font-size:12px}.links a{color:#5146b8;text-decoration:none;font-weight:650}
 



/* v124: conversation-first layout refinement and unmistakable original concern */
.layout{grid-template-columns:minmax(270px,300px) minmax(0,1fr) 0!important;position:relative!important;gap:0!important;background:#f4f6fb!important}
.details{position:fixed!important;z-index:80!important;top:72px!important;right:0!important;bottom:0!important;width:min(390px,92vw)!important;max-width:100%!important;transform:translateX(105%)!important;visibility:hidden!important;transition:transform .24s ease,visibility .24s ease!important;box-shadow:-18px 0 55px rgba(20,32,58,.16)!important;border-left:1px solid #e4e9f2!important}
.layout.details-open .details{transform:translateX(0)!important;visibility:visible!important}
.details-scrim{position:fixed!important;z-index:79!important;inset:72px 0 0!important;background:rgba(20,28,45,.28)!important;backdrop-filter:blur(2px)!important}
.layout.details-open+.details-scrim{display:block!important}
.main{background:#f4f6fb!important;min-width:0!important}
.chathead{position:relative!important;z-index:3!important;min-height:76px!important;padding:12px clamp(14px,2.4vw,30px)!important;background:#fff!important;border-bottom:1px solid #e8edf4!important;box-shadow:0 3px 14px rgba(22,34,58,.035)!important}
.chatbody{padding:24px clamp(14px,4vw,64px)!important;gap:18px!important;background:#f4f6fb!important}
.msg{max-width:min(820px,90%)!important;gap:9px!important;align-items:flex-end!important}
.msg-content{padding:14px 17px!important;border-radius:16px!important;border:1px solid #e6ebf2!important;box-shadow:0 4px 14px rgba(27,43,71,.045)!important;font-size:13px!important;line-height:1.7!important}
.msg.visitor .msg-content{background:#fff!important;border-top-left-radius:5px!important}
.msg.agent .msg-content{background:#eaf1ff!important;border-color:#dce7fb!important;border-top-right-radius:5px!important;color:#25395c!important}
.msg.ai .msg-content{background:#f1efff!important;border-color:#e4e0fb!important}
.msg.initial-concern .msg-content{border:1px solid #b9c9ec!important;box-shadow:0 0 0 3px rgba(91,126,190,.09),0 6px 18px rgba(27,43,71,.06)!important;background:linear-gradient(145deg,#fff,#f7faff)!important}
.initial-concern-label{display:inline-flex;align-items:center;padding:3px 7px;border-radius:6px;background:#e8efff;color:#345a9d;font-size:9px;font-weight:850;letter-spacing:.07em}
.compose{position:relative!important;z-index:4!important;background:#fff!important;border-top:1px solid #e6ebf2!important;box-shadow:0 -6px 20px rgba(25,39,65,.045)!important;padding:12px clamp(12px,2vw,26px) max(14px,env(safe-area-inset-bottom))!important}
.compose textarea{min-height:76px!important;max-height:150px!important;background:#f8faff!important;border:1px solid #e1e8f2!important;border-radius:13px!important}
.compose .actions{display:flex!important;justify-content:flex-end!important;gap:9px!important}
.compose .actions #send{min-width:150px!important;min-height:43px!important}
.side{border-right:1px solid #e7ecf3!important;background:#fff!important}
.ticket{border:1px solid transparent!important;border-radius:13px!important;margin:4px 2px!important}
.ticket.sel{background:#eef3ff!important;border-color:#dce6fa!important;box-shadow:inset 3px 0 #5278c7!important}
.detail-card{border-radius:13px!important;border-color:#e7ecf3!important;box-shadow:0 3px 12px rgba(22,34,58,.035)!important}
@media(max-width:1050px){.layout{grid-template-columns:280px minmax(0,1fr) 0!important}.details{top:65px!important}.details-scrim{inset:65px 0 0!important}}
@media(max-width:760px){.layout{display:block!important;position:relative!important;height:calc(100dvh - 64px)!important}.side{position:absolute!important;inset:0!important;width:100%!important;z-index:5!important;transform:translateX(0)!important;transition:transform .22s ease!important}.layout.open .side{transform:translateX(-102%)!important}.main{position:absolute!important;inset:0!important;width:100%!important}.chathead{min-height:64px!important;padding:8px 10px!important;gap:6px!important}.chathead>div:first-child{min-width:0!important}.chathead strong{font-size:13px!important}.chatbody{padding:14px 10px!important;gap:13px!important}.msg{max-width:96%!important}.msg-content{padding:11px 12px!important;font-size:12px!important}.compose{max-height:43dvh!important;padding:8px 9px calc(8px + env(safe-area-inset-bottom))!important}.compose textarea{min-height:58px!important;max-height:100px!important;font-size:16px!important}.compose .assist{display:flex!important;overflow-x:auto!important;flex-wrap:nowrap!important;gap:6px!important}.compose .assist .btn{flex:0 0 auto!important}.compose .actions{position:static!important;padding-top:7px!important}.compose .actions #send{width:100%!important}.details{top:0!important;bottom:0!important;width:min(92vw,390px)!important}.details-scrim{inset:0!important}.layout.details-open .details{transform:translateX(0)!important}}

/* v136: repair upload cleanup and make queue transitions visibly asynchronous */
.hc-queue-loading{min-height:86px;display:flex;align-items:center;justify-content:center;gap:10px;color:#64748b;font-size:12px;padding:20px}.hc-queue-loading i{color:#6255ed;font-size:16px}.tab[disabled]{opacity:.65;cursor:wait}.home-ticket-list[aria-busy="true"],.list[aria-busy="true"]{cursor:progress}.hc-composer-loading{opacity:.72}.hc-composer-loading textarea{cursor:wait}
/* v140: compact icon-only composer tools with hover/focus tooltips */
.assist{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin:7px 0}
.assist .hc-tool-icon{position:relative;display:inline-grid;place-items:center;width:36px;min-width:36px;height:34px;min-height:34px;padding:0;border:1px solid #e1e6ef;border-radius:8px;background:#fff;color:#64748b;font-size:14px;cursor:pointer}
.assist .hc-tool-icon:hover,.assist .hc-tool-icon:focus-visible{color:#5146c8;border-color:#c9c6fa;background:#f7f6ff;outline:none}
.assist .hc-tool-icon:after{content:attr(data-tooltip);position:absolute;left:50%;bottom:calc(100% + 9px);z-index:90;transform:translate(-50%,4px);padding:7px 9px;border-radius:6px;background:#20283a;color:#fff;font-size:10px;font-weight:650;line-height:1.2;white-space:nowrap;box-shadow:0 5px 16px #17243a2b;opacity:0;visibility:hidden;pointer-events:none;transition:opacity .14s ease,transform .14s ease,visibility .14s}
.assist .hc-tool-icon:hover:after,.assist .hc-tool-icon:focus-visible:after{opacity:1;visibility:visible;transform:translate(-50%,0)}
.hc-live-info-card{display:none;margin:12px 0 4px;padding:11px 12px;border:1px solid #dce7f4;border-left:3px solid #4385bd;border-radius:9px;background:linear-gradient(135deg,#f5f9ff,#fbfdff);color:#33465c;font-size:10px;line-height:1.55}
.hc-live-info-card.is-visible{display:block;animation:hcInfoIn .2s ease-out}
.hc-live-info-card .hc-live-info-title{display:flex;align-items:center;gap:7px;margin:0 0 5px;font-size:11px;font-weight:800;color:#264e76}
.hc-live-info-card .hc-live-info-title i{color:#4385bd}
.hc-live-info-card p{margin:0;color:#6c7d91}
@keyframes hcInfoIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
@media(max-width:760px){.assist .hc-tool-icon{width:34px;min-width:34px;height:34px}}

.assist{display:flex;align-items:center;gap:7px;flex-wrap:nowrap}.assist .btn{width:36px;min-width:36px;height:34px;min-height:34px;padding:0!important;display:inline-flex;align-items:center;justify-content:center;overflow:hidden;font-size:0!important;white-space:nowrap;position:relative}.assist .btn i{font-size:14px!important;line-height:1}.assist .btn:hover,.assist .btn:focus-visible{width:auto;min-width:36px;padding:0 10px!important;gap:7px;font-size:10px!important;z-index:4}.assist .btn:hover i,.assist .btn:focus-visible i{font-size:13px!important}.assist .btn:focus-visible{outline:2px solid #7770ef;outline-offset:2px}

/* v137: calm loading state and clear handoff receipt. */
.hc-chat-loading{align-self:center!important;width:min(390px,calc(100% - 28px))!important;min-height:188px!important;margin:auto!important;padding:25px 24px!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:10px!important;text-align:center!important;background:#fff!important;border:1px solid #e2e8f2!important;border-radius:16px!important;box-shadow:0 12px 34px rgba(28,43,72,.08)!important;color:#2b3b53!important}
.hc-chat-loading .hc-chat-spinner{width:34px!important;height:34px!important;display:block!important;border:3px solid #e8eaff!important;border-top-color:#554de8!important;border-right-color:#8b87f5!important;border-radius:50%!important;animation:hcChatSpin .8s linear infinite!important}
.hc-chat-loading strong{font-size:13px!important;font-weight:800!important;letter-spacing:.01em!important}
.hc-chat-loading small{max-width:290px!important;color:#7a879b!important;font-size:11px!important;line-height:1.55!important}
@keyframes hcChatSpin{to{transform:rotate(360deg)}}
.hc-handoff-banner[hidden]{display:none!important}
.hc-handoff-banner{position:relative;z-index:3;display:flex;align-items:center;gap:13px;margin:12px 16px 0;padding:13px 16px;border:1px solid #cfe8dc;border-radius:13px;background:linear-gradient(110deg,#f1fbf6 0%,#f7fbff 100%);box-shadow:0 5px 16px rgba(24,67,52,.045);color:#24483d}
.hc-handoff-mark{width:38px;height:38px;flex:0 0 38px;display:grid;place-items:center;border-radius:11px;background:#d8f2e5;color:#16845c;font-size:17px}
.hc-handoff-copy{min-width:0;flex:1}
.hc-handoff-copy .eyebrow{display:block;margin:0 0 3px;color:#16845c;font-size:9px;font-weight:850;letter-spacing:.08em}
.hc-handoff-copy strong{display:block;color:#203c35;font-size:12px;font-weight:850}
.hc-handoff-copy p{margin:3px 0 0;color:#5c756b;font-size:10px;line-height:1.5}
.hc-handoff-meta{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:0 0 auto;color:#58776b;font-size:9px;text-align:right}
.hc-handoff-meta span{display:inline-flex;align-items:center;gap:5px}
.hc-handoff-retry{border:1px solid #b9decd;border-radius:8px;padding:7px 10px;background:#fff;color:#176b4e;font-size:10px;font-weight:750;cursor:pointer}
.layout.ticket-mode .chatbody{min-height:0}
.msg.system{align-self:center!important;max-width:min(720px,92%)!important;justify-content:center!important}
.msg.system .msg-avatar{display:none!important}
.msg.system .msg-content{min-width:0!important;padding:8px 13px!important;border:1px solid #dfe5ef!important;border-radius:999px!important;background:#edf1f7!important;color:#61718a!important;box-shadow:none!important;text-align:center!important;font-size:10px!important}
.msg.system .who{display:none!important}
.msg.system .msg-text{font-size:10px!important;line-height:1.45!important}
@media(max-width:760px){.hc-handoff-banner{margin:8px 8px 0;padding:10px;gap:9px;align-items:flex-start}.hc-handoff-mark{width:32px;height:32px;flex-basis:32px;font-size:14px}.hc-handoff-meta{display:none}.hc-chat-loading{min-height:154px!important;padding:19px!important}}


/* v138: pinned case brief for every authorized agent; quiet queue/loading states. */
.hc-handoff-brief-panel[hidden]{display:none!important}
.hc-handoff-brief-panel{flex:0 0 auto;margin:10px 14px 0;border:1px solid #d9e2f2;border-radius:13px;background:#f8faff;box-shadow:0 4px 15px rgba(26,43,77,.045);overflow:hidden;color:#273958}
.hc-handoff-brief-panel>summary{display:flex;align-items:center;gap:10px;min-height:42px;padding:10px 13px;list-style:none;cursor:pointer;user-select:none}
.hc-handoff-brief-panel>summary::-webkit-details-marker{display:none}
.hc-handoff-brief-panel>summary>span{display:flex;align-items:center;gap:8px;font-size:11px;font-weight:850;color:#354a70}
.hc-handoff-brief-panel>summary>span i{color:#554de8;font-size:13px}
.hc-handoff-brief-panel>summary>small{margin-left:auto;display:flex;align-items:center;gap:5px;color:#75829a;font-size:9px;font-weight:700}
.hc-handoff-brief-panel>summary>small i{color:#8b94a7}
.hc-handoff-brief-panel .hc-brief-chevron{color:#8b94a7;font-size:10px;transition:transform .18s ease}
.hc-handoff-brief-panel[open] .hc-brief-chevron{transform:rotate(180deg)}
.hc-handoff-brief-body{padding:12px 15px 14px;border-top:1px solid #e5eaf3;color:#40516d;font-size:11px;line-height:1.7;white-space:pre-wrap;overflow-wrap:anywhere;max-height:230px;overflow:auto}
.hc-queue-loading{display:flex;align-items:center;justify-content:center;gap:9px;min-height:74px;padding:16px;color:#74829a;font-size:11px;font-weight:650}
.hc-queue-loading i{color:#5b55e8;font-size:15px}
@media(max-width:760px){.hc-handoff-brief-panel{margin:8px 8px 0}.hc-handoff-brief-panel>summary{padding:9px 10px;gap:7px}.hc-handoff-brief-panel>summary>small{font-size:8px}.hc-handoff-brief-body{max-height:190px;padding:10px 11px;font-size:10px}}


/* v139: polished first-load skeletons, quiet assistant controls and live status card */
.home-ticket-list{grid-template-columns:minmax(0,1fr)!important}
.hc-chat-loading{width:min(520px,calc(100% - 36px))!important;min-height:220px!important;gap:18px!important;padding:28px!important}
.hc-chat-loading .hc-loading-orbit{position:relative;width:48px;height:48px;border:3px solid #e7eaff;border-top-color:#6258ed;border-radius:50%;animation:hcChatSpin .9s linear infinite}
.hc-chat-loading .hc-loading-orbit:after{content:"";position:absolute;width:8px;height:8px;left:17px;top:17px;border-radius:50%;background:#8c86fa;box-shadow:0 0 0 6px #efeeff}
.hc-loading-bubbles{width:min(310px,100%);display:grid;gap:9px}
.hc-loading-bubbles span{height:11px;border-radius:20px;background:linear-gradient(90deg,#edf0f8 20%,#f8f9fd 40%,#edf0f8 60%);background-size:220% 100%;animation:hcSkeletonShimmer 1.25s ease-in-out infinite}
.hc-loading-bubbles span:nth-child(1){width:82%}.hc-loading-bubbles span:nth-child(2){width:100%}.hc-loading-bubbles span:nth-child(3){width:64%;justify-self:end}
@keyframes hcSkeletonShimmer{0%{background-position:100% 0}100%{background-position:-120% 0}}
.hc-chat-loading strong,.hc-chat-loading small{display:none!important}
.assist .btn{font-size:0!important;width:36px!important;min-width:36px!important;height:34px!important;padding:0!important;overflow:visible!important;position:relative!important}
.assist .btn i{font-size:14px!important}
.assist .btn:hover,.assist .btn:focus-visible{width:36px!important;min-width:36px!important;padding:0!important;font-size:0!important}
.assist .btn:after{content:attr(data-tooltip);position:absolute;left:50%;bottom:calc(100% + 9px);transform:translate(-50%,4px);opacity:0;visibility:hidden;white-space:nowrap;padding:7px 9px;border-radius:7px;background:#18253d;color:#fff;font-size:10px;font-weight:650;line-height:1;box-shadow:0 5px 16px #17233b30;pointer-events:none;transition:.15s ease;z-index:30}
.assist .btn:hover:after,.assist .btn:focus-visible:after{opacity:1;visibility:visible;transform:translate(-50%,0)}
.hc-live-info-card{display:flex!important;align-items:flex-start;gap:9px;margin:10px 12px 0!important;padding:11px 13px!important;border:1px solid #dbe6f5!important;border-radius:11px!important;background:linear-gradient(120deg,#f5f8ff,#fff)!important;color:#52637c!important;font-size:10px!important;line-height:1.55!important}
.hc-live-info-card:before{content:"\f05a";font-family:"Font Awesome 6 Free";font-weight:900;color:#655ce8;font-size:14px;flex:0 0 auto;margin-top:1px}
.hc-agent-toast-host{position:fixed;right:20px;top:82px;z-index:999999;display:grid;gap:9px;width:min(360px,calc(100vw - 28px));pointer-events:none}
.hc-agent-toast{display:flex;gap:11px;align-items:flex-start;padding:13px 15px;border:1px solid #d9e2f0;border-radius:12px;background:#fff;color:#24344e;box-shadow:0 12px 36px #17233b22;animation:hcToastIn .22s ease both;pointer-events:auto}
.hc-agent-toast .toast-icon{width:31px;height:31px;flex:0 0 31px;display:grid;place-items:center;border-radius:9px;background:#eeedff;color:#5d55df}
.hc-agent-toast strong{display:block;font-size:11px}.hc-agent-toast small{display:block;margin-top:3px;color:#728099;font-size:10px;line-height:1.45}
.hc-agent-toast button{margin-left:auto;border:0;background:transparent;color:#8793a6;cursor:pointer;font-size:16px}
@keyframes hcToastIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
@media(max-width:760px){.hc-agent-toast-host{right:10px;top:65px}}

/* v142: concise case titles, live relative timestamps and subtle first-concern treatment */
/* v145: stable title editor, summary card and hard two-line preview clamp */
.hc-title-edit[hidden]{display:none!important}.hc-summary-generating{position:relative;min-height:116px!important;overflow:hidden!important;border-radius:9px;background:linear-gradient(100deg,#f4f6fb 20%,#fff 38%,#f4f6fb 58%)!important;background-size:220% 100%!important;animation:hc-summary-shimmer 1.35s ease-in-out infinite;color:#64748b!important}.hc-summary-generating:before{content:'';display:block;width:26px;height:26px;margin:5px auto 12px;border:3px solid #dbe3f5;border-top-color:#5968bd;border-radius:50%;animation:hc-title-spin .75s linear infinite}.hc-summary-generating:after{content:'Analysing the customer issue, agent actions and final outcome…';display:block;text-align:center;font-size:10px;font-weight:700;color:#65739a;line-height:1.5}@keyframes hc-summary-shimmer{to{background-position:-220% 0}}#tickets .ticket small.hc-ticket-preview,#tickets .ticket>small.hc-ticket-preview{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;white-space:normal!important;overflow:hidden!important;text-overflow:ellipsis!important;overflow-wrap:anywhere!important;word-break:break-word!important;line-height:1.4!important;height:2.8em!important;max-height:2.8em!important;min-height:0!important}.hc-title-edit{display:inline-grid;place-items:center;width:25px;height:25px;margin-left:5px;border:1px solid #dfe5f1;border-radius:6px;background:#f7f8fc;color:#6574bd;cursor:pointer;vertical-align:middle}.hc-title-edit:hover{background:#edf1ff;border-color:#c7d0f1}.hc-title-pending{min-height:34px;display:inline-flex;align-items:center;gap:8px}.hc-title-pending:before{content:'';width:9px;height:9px;border:2px solid #cbd3f0;border-top-color:#5968bd;border-radius:50%;animation:hc-title-spin .8s linear infinite;box-shadow:none}@keyframes hc-title-spin{to{transform:rotate(360deg)}}.hc-ticket-preview,.ticket .hc-ticket-preview{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;white-space:normal!important;overflow:hidden!important;text-overflow:ellipsis!important;overflow-wrap:anywhere!important;word-break:break-word!important;line-height:1.4!important;max-height:2.8em!important}
/* Hard cap: sidebar previews must never expand beyond exactly two text lines. */
#tickets .ticket>small.hc-ticket-preview,#tickets .ticket small.hc-ticket-preview,#tickets small.hc-ticket-preview,.ticket small.hc-ticket-preview,small.hc-ticket-preview{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;white-space:normal!important;overflow:hidden!important;text-overflow:ellipsis!important;overflow-wrap:anywhere!important;word-break:break-word!important;line-height:1.4em!important;height:2.8em!important;min-height:2.8em!important;max-height:2.8em!important;block-size:2.8em!important;contain:paint!important}
.summary-side{padding:0!important;border:0!important;background:transparent!important}.hc-ai-summary-card{padding:12px;border:1px solid #dce5f2;border-radius:10px;background:linear-gradient(145deg,#f7f9ff,#fff 65%);box-shadow:0 4px 14px rgba(40,62,110,.06)}.hc-ai-summary-card-head{display:flex;align-items:center;gap:8px;margin-bottom:9px;color:#4356a0;font-size:10px;font-weight:850}.hc-ai-summary-card-head i{display:grid;place-items:center;width:25px;height:25px;border-radius:7px;background:#e9edff;color:#5869bd}.hc-ai-summary-content{padding:10px;border:1px solid #e8edf5;border-radius:8px;background:#fff;color:#39485d;font-size:10px;line-height:1.65;overflow-wrap:anywhere}.hc-ai-summary-content h1,.hc-ai-summary-content h2,.hc-ai-summary-content h3{margin:10px 0 5px;color:#2e4375;font-size:11px}.hc-ai-summary-content ul{padding-left:17px;margin:5px 0}.hc-ai-summary-content li{margin:3px 0}.hc-ai-summary-content p{margin:5px 0}.hc-ai-summary-content strong{color:#2e4375}.hc-ai-summary-content pre{white-space:pre-wrap;background:#f4f6fb;padding:8px;border-radius:6px}

.hc-ticket-card-heading{display:flex;flex-direction:column;min-width:0;gap:4px;flex:1}.hc-title-pending{display:inline-flex;align-items:center;gap:7px;min-height:34px;color:#7b8799;font-weight:650}.hc-title-pending:before{content:'';width:7px;height:7px;border-radius:50%;background:#6477c8;box-shadow:0 0 0 4px #edf0fb;animation:hc-title-pulse 1.1s ease-in-out infinite}@keyframes hc-title-pulse{50%{opacity:.35;box-shadow:0 0 0 7px #edf0fb}}.hc-ticket-card-heading>strong,.hc-ticket-list-heading>strong,.hc-history-card-main>strong,.hc-agent-toast small{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;text-overflow:ellipsis;overflow-wrap:anywhere;line-height:1.4}.hc-ticket-card-heading>small,.hc-ticket-list-customer{font-size:9px;color:#8995a5}.hc-ticket-list-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:7px;min-width:0}.hc-ticket-list-heading>strong{min-width:0;flex:1;font-size:10px}.ticket>small{display:block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ticket>small.hc-ticket-preview,.ticket .hc-ticket-preview{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;white-space:normal!important;overflow:hidden!important;text-overflow:ellipsis!important;overflow-wrap:anywhere!important;line-height:1.45!important;max-height:2.9em!important}.msg.initial-concern .msg-content{background:#f4f8fc!important;border-color:#dce8f2!important;box-shadow:inset 2px 0 0 #8eabc5!important}.msg.initial-concern .initial-concern-label{color:#66829e!important;font-size:9px;letter-spacing:.035em}.hc-history-card-main{min-width:0;flex:1}.hc-history-card-main>strong{-webkit-line-clamp:2}.hc-history-card em{flex:0 0 auto}.hc-agent-toast small{max-width:280px;-webkit-line-clamp:2}.home-ticket-card{position:relative;overflow:hidden;border-color:#dfe6f1!important;box-shadow:0 3px 12px rgba(31,48,91,.045)!important;transition:transform .16s,border-color .16s,box-shadow .16s!important}.home-ticket-card:before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:linear-gradient(180deg,#5968c8,#3196a8)}.home-ticket-card header{align-items:flex-start}.home-ticket-card .badge{display:inline-flex;align-items:center;gap:5px;padding:5px 8px;border-radius:6px;background:#eef2ff;color:#4e5db5;font-size:9px;font-weight:750;text-transform:capitalize}.home-ticket-card .badge:before{content:'\f111';font-family:'Font Awesome 6 Free';font-weight:900;font-size:6px}.home-ticket-card footer i{color:#6878c9}.home-ticket-card .hc-card-meta-icon{color:#6b78bd;margin-right:4px}.hc-status-badge{white-space:nowrap;text-transform:capitalize}.hc-status-badge i{font-size:5px}.hc-status-active,.hc-status-waiting_customer{background:#eaf2ff!important;color:#3868a8!important}.hc-status-queued,.hc-status-waiting_agent{background:#fff5e8!important;color:#a66b20!important}.hc-status-closed,.hc-status-converted{background:#eaf7f0!important;color:#2b805b!important}.hc-status-pending_email{background:#f2edff!important;color:#7652aa!important}.history-group-title{display:flex;align-items:center;gap:7px;font-size:10px;font-weight:850;color:#34445c;padding:10px 2px 6px}.history-group-title>i{color:#6170bd}.hc-history-count{margin-left:auto;min-width:20px;padding:3px 6px;border-radius:12px;text-align:center;background:#eef2ff;color:#5665b7;font-size:8px}.home-ticket-card .hc-ticket-card-heading{min-width:0}.home-ticket-card .hc-ticket-card-heading>strong{font-size:12px}.home-ticket-card .hc-ticket-card-heading>small{display:block}.home-ticket-card time{white-space:nowrap;font-variant-numeric:tabular-nums}


/* v149.1: enforce compact sidebar text in the actual ticket-list markup. */
#tickets .ticket{min-width:0!important;max-width:100%!important;overflow:hidden!important;box-sizing:border-box!important;}
#tickets .ticket .hc-ticket-list-heading{display:flex!important;align-items:flex-start!important;gap:6px!important;min-width:0!important;max-width:100%!important;overflow:hidden!important;}
#tickets .ticket .hc-ticket-list-heading>strong{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;flex:1 1 0!important;min-width:0!important;max-width:100%!important;max-height:2.8em!important;overflow:hidden!important;white-space:normal!important;text-overflow:ellipsis!important;overflow-wrap:anywhere!important;word-break:break-word!important;line-height:1.4em!important;}
#tickets .ticket .hc-ticket-list-heading>.badge{flex:0 0 auto!important;max-width:42%!important;white-space:nowrap!important;}
#tickets .ticket>small.hc-ticket-list-customer{display:block!important;width:100%!important;max-width:100%!important;min-width:0!important;overflow:hidden!important;white-space:nowrap!important;text-overflow:ellipsis!important;}
#tickets .ticket>small.hc-ticket-preview{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;width:100%!important;max-width:100%!important;min-width:0!important;height:2.72em!important;max-height:2.72em!important;min-height:2.72em!important;overflow:hidden!important;white-space:normal!important;text-overflow:ellipsis!important;overflow-wrap:anywhere!important;word-break:break-word!important;line-height:1.36em!important;box-sizing:border-box!important;}

/* v149 Phase 1: deterministic two-line ticket previews. */
#tickets .ticket{min-width:0!important;width:auto!important;max-width:100%!important;}
#tickets .ticket>small.hc-ticket-preview,#tickets .ticket small.hc-ticket-preview{
 display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;
 width:100%!important;max-width:100%!important;min-width:0!important;height:2.72em!important;min-height:2.72em!important;max-height:2.72em!important;
 margin-top:5px!important;overflow:hidden!important;white-space:normal!important;text-overflow:ellipsis!important;
 overflow-wrap:anywhere!important;word-break:break-word!important;line-height:1.36em!important;box-sizing:border-box!important;
}
#tickets .ticket>small.hc-ticket-preview i{display:inline!important;white-space:nowrap!important;}
.hc-send-status-toast{border-left:3px solid #6274d9!important}
.hc-ai-summary-content{font-size:11px!important;line-height:1.7!important;color:#34445c!important}
.hc-ai-summary-content h1,.hc-ai-summary-content h2,.hc-ai-summary-content h3{margin:12px 0 6px!important;font-weight:850!important;line-height:1.35!important}
.hc-ai-summary-content h1{font-size:15px!important}.hc-ai-summary-content h2{font-size:13px!important}.hc-ai-summary-content h3{font-size:12px!important}
.hc-ai-summary-content p{margin:6px 0!important}.hc-ai-summary-content ul,.hc-ai-summary-content ol{padding-left:19px!important;margin:7px 0!important}.hc-ai-summary-content li{margin:4px 0!important;padding-left:2px!important}
.hc-ai-summary-content blockquote{margin:8px 0!important;padding:7px 10px!important;border-left:3px solid #8292df!important;background:#f5f7ff!important;border-radius:0 7px 7px 0!important}
.hc-ai-summary-content hr{border:0!important;border-top:1px solid #e6ebf4!important;margin:10px 0!important}
.hc-ai-summary-content code{padding:2px 4px!important;border-radius:4px!important;background:#f1f3f8!important;font-family:ui-monospace,monospace!important}
.hc-ai-summary-content pre{overflow:auto!important;white-space:pre-wrap!important;word-break:break-word!important}

/* 2026 agent workspace refinement: grouped WhatsApp-style chat, structured follow-up brief, header alerts and unified search. */
.msg{align-items:flex-start!important;gap:9px!important;margin:7px 0!important;max-width:min(820px,92%)!important}
.msg.agent{align-self:flex-end!important;flex-direction:row-reverse!important}
.msg .msg-avatar{width:30px!important;height:30px!important;flex:0 0 30px!important;border-radius:50%!important;display:grid!important;place-items:center!important;background:#e8edf7!important;color:#465777!important;font-size:11px!important;font-weight:800!important;margin-top:2px!important}
.msg.agent .msg-avatar{background:#e7e5ff!important;color:#5149a5!important}
.msg .msg-content{display:flex!important;flex-direction:column!important;gap:4px!important;min-width:0!important;max-width:100%!important;padding:0!important;background:transparent!important;border:0!important;box-shadow:none!important;overflow:visible!important}
.msg .who{display:flex!important;align-items:center!important;gap:6px!important;margin:0 0 1px!important;padding:0 3px!important;font-size:10px!important;font-weight:750!important;letter-spacing:0!important;text-transform:none!important;color:#53627b!important}
.msg.agent .who{justify-content:flex-end!important;color:#635f98!important}
.msg .msg-text{display:block!important;width:fit-content!important;max-width:100%!important;padding:10px 13px!important;border:1px solid #e1e7f0!important;border-radius:15px 15px 15px 4px!important;background:#fff!important;color:#29364e!important;box-shadow:0 2px 7px rgba(25,39,65,.04)!important;overflow-wrap:anywhere!important;font-size:12px!important;line-height:1.65!important}
.msg.agent .msg-text{align-self:flex-end!important;border-color:#d9e2ff!important;border-radius:15px 15px 4px 15px!important;background:#eaf0ff!important;color:#283b63!important}
.msg.ai .msg-text{background:#f1efff!important;border-color:#e3ddfb!important}
.msg.note .msg-text{background:#fff7e4!important;border-color:#f0dfa9!important}
.msg.initial-concern .msg-text{border-left:3px solid #d59b35!important;background:#fffdf7!important}
.msg .msg-footer{display:flex!important;align-items:center!important;gap:5px!important;padding:0 4px!important;color:#8792a5!important;font-size:9px!important;line-height:1.3!important}
.msg.agent .msg-footer{justify-content:flex-end!important}
.msg .msg-footer i{font-size:9px!important;color:#9aa5b5!important}
.msg.is-grouped{margin-top:1px!important}
.msg.is-grouped .msg-avatar,.msg.is-grouped .who{visibility:hidden!important;height:0!important;margin:0!important;padding:0!important;overflow:hidden!important}
.msg.is-grouped .msg-text{border-top-left-radius:8px!important}
.msg.agent.is-grouped .msg-text{border-top-right-radius:8px!important;border-top-left-radius:15px!important}
.msg.system{max-width:100%!important}
.msg.system .msg-content{gap:0!important}
.msg.system .msg-text{width:fit-content!important;padding:7px 11px!important;border-radius:99px!important;background:#edf1f7!important;border-color:#e0e6ef!important;box-shadow:none!important;color:#66748a!important;font-size:10px!important;text-align:center!important}
.msg.system .msg-footer{display:none!important}
.msg .attachment-list,.msg .hc-attachment-preview{margin-top:4px!important}
.hc-handoff-brief-body{max-height:none!important;overflow:visible!important;padding:0!important;white-space:normal!important;border-top:1px solid #e6eaf2!important}
.hc-handoff-card{padding:14px!important;display:grid!important;gap:12px!important;background:linear-gradient(180deg,#fff,#fafbff)!important}
.hc-handoff-card-head{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:10px!important}
.hc-handoff-card-head strong{display:block!important;font-size:12px!important;color:#273958!important}
.hc-handoff-card-head small{display:block!important;margin-top:3px!important;font-size:9px!important;color:#7a879b!important}
.hc-handoff-meta-grid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:7px!important}
.hc-handoff-meta-item{min-width:0!important;padding:9px 10px!important;border:1px solid #e7ebf3!important;border-radius:9px!important;background:#fff!important}
.hc-handoff-meta-item small{display:block!important;margin-bottom:4px!important;color:#8a95a8!important;font-size:8px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.05em!important}
.hc-handoff-meta-item strong{display:block!important;color:#3d4b64!important;font-size:10px!important;line-height:1.45!important;overflow-wrap:anywhere!important}
.hc-handoff-section{padding:11px 12px!important;border:1px solid #e5eaf2!important;border-radius:11px!important;background:#fff!important}
.hc-handoff-section h4{display:flex!important;align-items:center!important;gap:7px!important;margin:0 0 7px!important;color:#394968!important;font-size:10px!important;font-weight:850!important;letter-spacing:.02em!important}
.hc-handoff-section h4 i{color:#635ce0!important}
.hc-handoff-section p{margin:0!important;color:#53627a!important;font-size:10px!important;line-height:1.6!important;white-space:pre-wrap!important;overflow-wrap:anywhere!important}
.hc-handoff-section.is-concern{border-left:3px solid #d9a447!important;background:#fffdf7!important}
.hc-handoff-stats{display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:6px!important}
.hc-handoff-stat{padding:8px 6px!important;border-radius:9px!important;background:#f5f7fc!important;text-align:center!important}
.hc-handoff-stat strong{display:block!important;color:#354665!important;font-size:16px!important}
.hc-handoff-stat small{display:block!important;color:#7d899d!important;font-size:8px!important}
.hc-handoff-grid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important}.hc-handoff-analysis-grid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important}.hc-handoff-section.is-ai-summary{background:#fbfcff!important;border-color:#e0e6f5!important}.hc-handoff-section.is-ai-summary h4{color:#4b53a3!important}
.hc-handoff-privacy{display:flex!important;align-items:center!important;gap:6px!important;padding:8px 10px!important;border-radius:8px!important;background:#fff8e8!important;color:#866016!important;font-size:9px!important}
.hc-agent-alert-control{position:relative!important;display:inline-flex!important;align-items:center!important}
#hcAgentAlertToggle{display:inline-flex!important;align-items:center!important;gap:7px!important;padding:9px 12px!important;border:1px solid #e0e5ef!important;border-radius:10px!important;background:#fff!important;color:#47536c!important;font:inherit!important;font-size:11px!important;font-weight:700!important;line-height:1.2!important;cursor:pointer!important;box-shadow:none!important}
#hcAgentAlertToggle:hover{border-color:#c9c5fa!important;background:#f8f7ff!important;color:#4e46ad!important}
#hcAgentAlertSettings{position:absolute!important;right:0!important;top:calc(100% + 9px)!important;z-index:99999!important;width:min(340px,calc(100vw - 24px))!important;padding:14px!important;border:1px solid #e0e5ef!important;border-radius:14px!important;background:#fff!important;box-shadow:0 16px 40px rgba(20,30,55,.2)!important;font:12px/1.45 system-ui,sans-serif!important;color:#253047!important}
#hcAgentAlertSettings[hidden]{display:none!important}
#hcAgentAlertSettings .hc-alert-volume{display:flex;align-items:center;gap:10px;margin:12px 0}
#hcAgentAlertSettings .hc-alert-volume input{flex:1;min-width:0}
#hcAgentAlertSettings .hc-alert-actions{display:flex;gap:7px;flex-wrap:wrap}
#hcAgentAlertSettings button{border:1px solid #dce2ec;border-radius:8px;padding:8px 10px;background:#f8f9fc;color:#344159;font:650 10px system-ui;cursor:pointer}
#hcAgentAlertSettings button.primary{background:#29265f;border-color:#29265f;color:#fff}
.hc-global-search{display:flex!important;align-items:center!important;gap:10px!important}
.hc-global-search input{flex:1!important;min-width:0!important}
.hc-global-search #globalSearchSubmit{display:inline-flex!important;align-items:center!important;gap:7px!important;min-height:34px!important;padding:0 13px!important;border:1px solid #e0e5ef!important;border-radius:9px!important;background:#fff!important;color:#4f5d74!important;font-size:10px!important;font-weight:750!important;cursor:pointer!important}
.hc-global-search #globalSearchSubmit:hover{border-color:#c8c3f7!important;background:#f7f6ff!important;color:#5148bd!important}
.hc-search-mode .side{display:none!important}
.hc-search-mode .main{grid-column:1/-1!important;width:100%!important}
.hc-search-mode .details{display:none!important}
.hc-global-search-page{height:100%!important;min-height:0!important;overflow:auto!important;padding:clamp(18px,3vw,34px)!important;background:#f6f7fb!important}
.hc-global-search-page[hidden]{display:none!important}
.hc-global-search-page-head{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:14px!important;margin:0 0 18px!important}
.hc-global-search-page-head h1{margin:4px 0!important;color:#202b41!important;font-size:23px!important;font-weight:800!important}
.hc-global-search-page-head p{margin:0!important;color:#788499!important;font-size:11px!important}
.hc-search-counts{display:flex!important;gap:8px!important;flex-wrap:wrap!important;margin-bottom:14px!important}
.hc-search-counts span{display:inline-flex!important;align-items:center!important;gap:6px!important;padding:7px 10px!important;border:1px solid #e5e9f1!important;border-radius:999px!important;background:#fff!important;color:#637088!important;font-size:10px!important;font-weight:700!important}
.hc-search-results{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important;align-content:start!important}
.hc-search-card{display:flex!important;align-items:flex-start!important;gap:12px!important;min-width:0!important;padding:15px!important;border:1px solid #e3e8f0!important;border-radius:13px!important;background:#fff!important;text-align:left!important;color:#2f3e57!important;text-decoration:none!important;box-shadow:0 3px 12px rgba(29,45,72,.035)!important;cursor:pointer!important;transition:transform .14s ease,box-shadow .14s ease!important}
.hc-search-card:hover{transform:translateY(-2px)!important;box-shadow:0 9px 22px rgba(29,45,72,.08)!important}
.hc-search-card-icon{display:grid!important;place-items:center!important;flex:0 0 36px!important;width:36px!important;height:36px!important;border-radius:11px!important;background:#eaf1ff!important;color:#4767ad!important;font-size:14px!important}
.hc-search-card--followup{background:#fffaf0!important;border-color:#f1dfb9!important}
.hc-search-card--followup .hc-search-card-icon{background:#ffefce!important;color:#95651c!important}
.hc-search-card--hck{background:#f3fbf7!important;border-color:#d5ece1!important}
.hc-search-card--hck .hc-search-card-icon{background:#ddf4e8!important;color:#1e805d!important}
.hc-search-card-main{min-width:0!important;flex:1!important}
.hc-search-card-main header{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:8px!important}
.hc-search-card-main strong{display:block!important;color:#2b3951!important;font-size:12px!important;line-height:1.4!important}
.hc-search-card-main p{margin:6px 0!important;color:#66748b!important;font-size:10px!important;line-height:1.5!important;overflow-wrap:anywhere!important}
.hc-search-card-main small{display:block!important;color:#8a95a8!important;font-size:9px!important;line-height:1.5!important}
.hc-search-kind{flex:0 0 auto!important;padding:4px 6px!important;border-radius:6px!important;background:#edf1f7!important;color:#66748a!important;font-size:8px!important;font-weight:850!important;text-transform:uppercase!important}
.hc-search-card--followup .hc-search-kind{background:#ffefce!important;color:#95651c!important}
.hc-search-card--hck .hc-search-kind{background:#ddf4e8!important;color:#1e805d!important}
.hc-search-empty{grid-column:1/-1!important;display:grid!important;justify-items:center!important;gap:8px!important;padding:48px 20px!important;border:1px dashed #d9e0ea!important;border-radius:14px!important;background:#fff!important;color:#748198!important;text-align:center!important}
.hc-search-empty i{color:#7068d8!important;font-size:23px!important}
.hc-search-empty strong{color:#34435c!important;font-size:13px!important}
.hc-search-empty span{font-size:10px!important}
.hc-private-note .hc-note-actions{display:flex;gap:6px;margin-top:8px}
.hc-private-note .hc-note-actions button{display:inline-flex;align-items:center;gap:5px;border:1px solid #e0e5ee;border-radius:7px;padding:5px 8px;background:#fff;color:#63718a;font-size:9px;font-weight:700;cursor:pointer}
.hc-private-note .hc-note-audit{display:flex;align-items:center;gap:5px;margin-top:7px;color:#8a93a4;font-size:9px}
.hc-private-note.is-deleted{background:#f7f8fa!important;border-style:dashed!important;color:#7d8799!important}
@media(max-width:760px){.hc-handoff-meta-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hc-handoff-grid,.hc-handoff-analysis-grid{grid-template-columns:1fr!important}.hc-handoff-stats{grid-template-columns:repeat(3,minmax(0,1fr))!important}.hc-search-results{grid-template-columns:1fr!important}.hc-global-search-page-head{flex-direction:column!important}.hc-global-search-page{padding:15px!important}.msg{max-width:98%!important}.msg .msg-text{font-size:11px!important}.hc-agent-alert-control{position:static!important}#hcAgentAlertSettings{right:8px!important;top:calc(100% + 7px)!important}}


/* v5: compact WhatsApp-like transcript metadata and note audit actions */
.msg .who{font-size:10px!important;font-weight:750!important;color:#586781!important;margin:0 0 5px!important;display:flex!important;align-items:center!important;gap:6px!important}
.msg .msg-avatar{width:28px!important;height:28px!important;min-width:28px!important;border-radius:50%!important;display:grid!important;place-items:center!important;background:#e9edfb!important;color:#5864a3!important;font-size:10px!important;font-weight:800!important}
.msg .msg-content{min-width:0!important}
.msg .msg-footer{display:flex!important;align-items:center!important;justify-content:flex-end!important;gap:5px!important;margin-top:6px!important;color:#8b96a8!important;font-size:9px!important;line-height:1.3!important}
.msg .msg-footer i{font-size:9px!important}
.msg .msg-footer time{font-size:9px!important}
.msg .msg-audit{font-size:9px!important;color:#8b7891!important;margin-top:5px!important}
.msg .hc-thread-note-actions{justify-content:flex-end!important;margin-top:5px!important}
.msg .hc-thread-note-actions button{font-size:9px!important;padding:3px 7px!important}

.hc-alerts-moved-to-header{position:static!important;inset:auto!important;z-index:auto!important;margin:0 6px 0 0!important;box-shadow:none!important;transform:none!important;align-self:center!important;flex:0 0 auto!important}

/* v143: explicit, accessible follow-up confirmation and clearer handoff content */
.hc-followup-confirm[hidden]{display:none!important}
.hc-followup-confirm{position:fixed;inset:0;z-index:100000;display:grid;place-items:center;padding:20px;background:rgba(15,23,42,.58);backdrop-filter:blur(5px)}
.hc-followup-dialog{width:min(520px,100%);background:#fff;border:1px solid #e4e8f0;border-radius:18px;box-shadow:0 28px 90px rgba(10,20,40,.28);overflow:hidden;color:#17243b}
.hc-followup-dialog-head{display:flex;align-items:flex-start;gap:13px;padding:22px 24px 16px}
.hc-followup-dialog-icon{width:44px;height:44px;flex:0 0 44px;display:grid;place-items:center;border-radius:13px;background:#eeedff;color:#554de8;font-size:19px}
.hc-followup-dialog h2{margin:0;color:#17243b;font-size:18px;font-weight:800;line-height:1.3}
.hc-followup-dialog-head p{margin:6px 0 0;color:#65738a;font-size:13px;line-height:1.55}
.hc-followup-confirm-details{margin:0 24px;padding:14px 15px;border:1px solid #e6eaf1;border-radius:12px;background:#f8faff}
.hc-followup-confirm-details strong{display:block;color:#33445f;font-size:12px;margin-bottom:5px}
.hc-followup-confirm-details p{margin:0;color:#66748a;font-size:12px;line-height:1.55}
.hc-followup-warning{display:flex;gap:9px;align-items:flex-start;margin:14px 24px 0;padding:11px 12px;border-radius:10px;background:#fff8e9;color:#805b16;font-size:11px;line-height:1.5}
.hc-followup-dialog-actions{display:flex;justify-content:flex-end;gap:9px;padding:20px 24px 22px}
.hc-followup-dialog-actions button{min-height:40px;padding:0 16px;border:1px solid #dce2ec;border-radius:9px;background:#fff;color:#40516b;font-size:12px;font-weight:750;cursor:pointer}
.hc-followup-dialog-actions .is-confirm{border-color:#554de8;background:#554de8;color:#fff;box-shadow:0 4px 10px rgba(85,77,232,.18)}
.hc-followup-dialog-actions button:focus-visible{outline:3px solid rgba(85,77,232,.25);outline-offset:2px}
@media(max-width:520px){.hc-followup-confirm{padding:12px}.hc-followup-dialog-head{padding:18px 18px 14px}.hc-followup-confirm-details{margin:0 18px}.hc-followup-warning{margin:12px 18px 0}.hc-followup-dialog-actions{padding:17px 18px 18px}}

/* v143: enforce readable follow-up summary layout in the agent workspace */
.hc-handoff-brief-panel{margin:12px 16px 0!important;border:1px solid #dce4f0!important;border-radius:15px!important;background:#f8faff!important;box-shadow:0 8px 22px rgba(24,39,75,.055)!important}
.hc-handoff-brief-panel>summary{min-height:48px!important;padding:12px 16px!important;background:#f8faff!important}
.hc-handoff-brief-panel>summary>span{font-size:13px!important;color:#263752!important}
.hc-handoff-brief-panel>summary>small{font-size:10px!important}
.hc-handoff-brief-body{max-height:none!important;overflow:visible!important;padding:0!important;white-space:normal!important;border-top:1px solid #e3e9f2!important}
.hc-handoff-card{display:grid!important;gap:14px!important;padding:17px!important;background:#f8faff!important}
.hc-handoff-card-head{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;padding-bottom:12px!important;border-bottom:1px solid #e1e7f1!important}
.hc-handoff-card-head strong{font-size:15px!important;color:#1f2f49!important}.hc-handoff-card-head small{font-size:11px!important;color:#718098!important}
.hc-handoff-meta-grid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:9px!important}.hc-handoff-meta-item{padding:11px 12px!important;border:1px solid #e3e9f2!important;border-radius:10px!important;background:#fff!important}.hc-handoff-meta-item small{display:block!important;margin-bottom:6px!important;font-size:10px!important;color:#77849a!important}.hc-handoff-meta-item strong{display:block!important;font-size:12px!important;line-height:1.5!important;color:#2c3b54!important;overflow-wrap:anywhere!important}
.hc-handoff-section{padding:14px 15px!important;border:1px solid #e3e9f2!important;border-radius:11px!important;background:#fff!important}.hc-handoff-section h4{display:flex!important;align-items:center!important;gap:8px!important;margin:0 0 9px!important;font-size:12px!important;color:#33445f!important}.hc-handoff-section h4 i{margin:0!important;color:#625ce0!important}.hc-handoff-section p{margin:0!important;font-size:13px!important;line-height:1.65!important;color:#53627a!important;white-space:pre-wrap!important;overflow-wrap:anywhere!important}.hc-handoff-section.is-concern{border-left:4px solid #d7a33d!important;background:#fffdf7!important}
.hc-handoff-stats{display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:8px!important;margin:0 0 10px!important}.hc-handoff-stat{display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:5px!important;min-width:0!important;padding:10px 7px!important;border:1px solid #e5eaf3!important;border-radius:9px!important;background:#f9faff!important;text-align:center!important}.hc-handoff-stat strong{display:block!important;font-size:20px!important;line-height:1.2!important;font-weight:850!important;color:#283954!important}.hc-handoff-stat small{display:block!important;font-size:10px!important;line-height:1.35!important;color:#738098!important;white-space:normal!important}.hc-handoff-grid,.hc-handoff-analysis-grid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important}.hc-handoff-privacy{display:flex!important;gap:9px!important;padding:11px 13px!important;border:1px solid #e4e8f2!important;border-radius:9px!important;background:#f3f5fa!important;font-size:11px!important;line-height:1.55!important;color:#66748a!important}
@media(max-width:760px){.hc-handoff-card{padding:12px!important;gap:10px!important}.hc-handoff-meta-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hc-handoff-grid,.hc-handoff-analysis-grid{grid-template-columns:1fr!important}.hc-handoff-stats{grid-template-columns:repeat(3,minmax(0,1fr))!important}.hc-handoff-section p{font-size:12px!important}}
@media(max-width:420px){.hc-handoff-meta-grid{grid-template-columns:1fr!important}.hc-handoff-stats{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hc-handoff-card-head{align-items:flex-start!important}}
</style>
<style id="hc-agent-kapture-workspace-v131">
:root{--hc-ink:#1e293b;--hc-muted:#758196;--hc-border:#e2e7ef;--hc-bg:#f3f5f8;--hc-blue:#2367a8;--hc-blue-dark:#164f87;--hc-panel:#fff;--hc-soft:#f6f8fb}
html,body{height:100%;overflow:hidden}body{background:var(--hc-bg);color:var(--hc-ink);font-family:Inter,"Segoe UI",Arial,sans-serif;font-size:13px}
.top{height:58px!important;min-height:58px!important;background:#17283d!important;color:#fff!important;border:0!important;border-bottom:1px solid #0f2034!important;box-shadow:0 2px 10px #14233725!important;padding:0 18px!important;z-index:30!important}
.top .brand{color:#fff!important;font-size:16px!important;letter-spacing:0!important}.top .brand:before{background:#45a3de!important;box-shadow:0 0 0 4px #45a3de20!important}.top .brand span{color:#a9bfd4!important}.top .agent{color:#e8eef5!important;gap:9px!important}.top .avatar{background:#2c547a!important;border:1px solid #4c7295!important;color:#fff!important;width:32px!important;height:32px!important}
.top .btn{background:#233d58!important;color:#f3f7fb!important;border:1px solid #385571!important;border-radius:5px!important;padding:7px 10px!important;font-size:11px!important}.top .availability-control{background:#213d57!important}.top .hc-connection-state{color:#c8d7e4!important}
.layout{height:calc(100dvh - 58px)!important;grid-template-columns:minmax(270px,304px) minmax(430px,1fr) minmax(310px,360px)!important;background:#fff!important;overflow:hidden!important}
.side{background:#f8fafc!important;border-right:1px solid #dce3ec!important}.side-heading{padding:18px 17px 12px!important;border-bottom:1px solid #e6ebf1!important}.side-heading h2{font-size:17px!important;color:#233247!important;letter-spacing:-.3px!important}.side-heading p{font-size:11px!important;color:#8a95a6!important}.inbox-stats{padding:10px 14px!important;gap:8px!important}.inbox-stat{background:#fff!important;border:1px solid #e5eaf1!important;border-radius:5px!important;box-shadow:none!important;padding:8px!important}.inbox-stat strong{font-size:16px!important;color:#233b56!important}.inbox-stat small{font-size:9px!important;text-transform:uppercase;letter-spacing:.05em;color:#8591a1!important}
.tabs{padding:10px 12px 0!important;gap:4px!important;border-bottom:1px solid #e4e9f0!important}.tab{border-radius:4px 4px 0 0!important;border:1px solid transparent!important;border-bottom:0!important;background:transparent!important;color:#68778b!important;font-size:10px!important;font-weight:700!important;padding:10px 6px!important;text-transform:uppercase;letter-spacing:.03em}.tab.active{background:#fff!important;color:#1e5f99!important;border-color:#dfe6ee!important;box-shadow:inset 0 2px 0 #2d83c4!important}
.tools{padding:11px 13px!important;border-bottom:1px solid #e4e9f0!important}.tools input{height:37px!important;border-radius:4px!important;border:1px solid #d8e0e9!important;background:#fff!important;font-size:11px!important}.list{padding:0 7px 14px!important;background:#f8fafc!important}.ticket{margin:0!important;padding:12px 10px!important;border:0!important;border-bottom:1px solid #e8edf3!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;transform:none!important;transition:background .12s!important}.ticket:hover{background:#f0f5fa!important;border-color:#e8edf3!important}.ticket.sel{background:#eaf3fb!important;border-left:3px solid #2d80bd!important;padding-left:7px!important;border-color:#d9e7f3!important;box-shadow:none!important}.ticket strong{font-size:11px!important;color:#26374b!important}.ticket small{font-size:10px!important;line-height:1.45!important;color:#778598!important}.ticket .badge{border-radius:3px!important;font-size:8px!important;padding:3px 5px!important}
.main{background:#f2f4f7!important;min-width:0!important}.chathead{min-height:65px!important;padding:10px 18px!important;background:#fff!important;border-bottom:1px solid #dfe5ec!important;box-shadow:none!important}.chathead strong{font-size:14px!important;color:#26364b!important}.chathead .btn{border-radius:4px!important;font-size:10px!important}.chathead #close{background:#1f6b9f!important;color:#fff!important;border-color:#1f6b9f!important}.chathead #ticketMeta{font-size:10px!important;color:#7e8b9b!important}
.chatbody{padding:18px clamp(16px,2.5vw,34px)!important;gap:12px!important;background:#f2f4f7!important}.msg{max-width:min(780px,88%)!important;gap:8px!important}.msg-avatar{width:27px!important;height:27px!important;flex-basis:27px!important;border-radius:50%!important;font-size:10px!important}.msg-content{padding:10px 13px!important;border-radius:5px!important;box-shadow:0 1px 2px #17283d0b!important;font-size:12px!important;line-height:1.58!important}.msg.visitor .msg-content{background:#fff!important;border:1px solid #e1e6ed!important;border-top-left-radius:2px!important}.msg.agent .msg-content{background:#e8f2fa!important;border:1px solid #d4e4f0!important;color:#233b51!important;border-top-right-radius:2px!important}.msg.ai .msg-content{background:#f0effb!important;border:1px solid #e0def4!important;border-radius:5px!important}.msg.note .msg-content{background:#fff6df!important;border:1px solid #f1dda5!important}.who{font-size:9px!important;color:#7c8999!important;text-transform:uppercase;letter-spacing:.04em;margin-bottom:5px!important}.initial-concern .msg-content{border-left:3px solid #d59b35!important;background:#fffdf7!important}.initial-concern-label{color:#986716!important;font-weight:800!important}.chatbody .system-event{align-self:center}
.compose{position:relative!important;padding:10px 15px 13px!important;background:#fff!important;border-top:1px solid #dfe5ec!important;box-shadow:0 -2px 8px #1e293b08!important}.hc-compose-toolbar{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:9px}.hc-compose-modes,.hc-compose-actions{display:flex;align-items:center;gap:5px;flex-wrap:wrap}.hc-compose-mode{display:inline-flex;align-items:center;gap:6px;padding:7px 10px;border:1px solid transparent;border-radius:4px;background:transparent;color:#68788b;font-size:10px;font-weight:700;cursor:pointer}.hc-compose-mode.active{background:#eaf3fa;border-color:#d5e5f1;color:#1e6097}.hc-compose-mode[data-compose-mode=note].active{background:#fff4da;border-color:#f1dfb5;color:#946514}.hc-compose-actions .btn{padding:7px 9px!important;font-size:10px!important;border-radius:4px!important}.hc-quick-replies{height:30px;max-width:125px;border:1px solid #dce3eb;border-radius:4px;padding:0 7px;font-size:10px;color:#5c6a7c;background:#fff}.compose textarea{min-height:70px!important;max-height:160px!important;border:1px solid #d8e0e9!important;border-radius:4px!important;font-size:12px!important;box-shadow:none!important}.compose textarea:focus{border-color:#6ba5d0!important;box-shadow:0 0 0 2px #3988c31a!important}.assist{margin-top:7px!important;gap:5px!important}.assist .btn{padding:6px 8px!important;border-radius:4px!important;font-size:9px!important}.actions{margin-top:7px!important;justify-content:flex-end!important}.actions .primary{border-radius:4px!important;background:#21699f!important;border-color:#21699f!important;box-shadow:none!important;padding:8px 15px!important;font-size:10px!important}
.details{background:#fff!important;border-left:1px solid #dce3ec!important;padding:0 0 22px!important;box-shadow:none!important}.details-mobile-head{padding:13px 15px!important;border-bottom:1px solid #e4e9ef!important}.hc-context-heading{display:flex;align-items:center;gap:10px;padding:16px 15px 13px;border-bottom:1px solid #e7ebf0}.hc-customer-avatar{width:36px;height:36px;border-radius:50%;background:#e2eef7;color:#215d8f;display:grid;place-items:center;font-size:13px;font-weight:800}.hc-context-customer{min-width:0;flex:1;display:flex;flex-direction:column;gap:3px}.hc-context-customer strong{font-size:12px;color:#26384e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.hc-context-customer small{font-size:10px;color:#8491a1;overflow-wrap:anywhere}.hc-context-tabs{position:sticky;top:0;z-index:2;display:flex;overflow:auto;gap:0;padding:0 9px;background:#fff;border-bottom:1px solid #dfe5ec;scrollbar-width:thin}.hc-context-tab{flex:0 0 auto;border:0;border-bottom:2px solid transparent;padding:11px 8px 9px;background:transparent;color:#718094;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;cursor:pointer}.hc-context-tab.active{color:#1e669e;border-color:#2c83bd}.hc-context-tab span{display:inline-grid;place-items:center;min-width:15px;height:15px;margin-left:3px;border-radius:10px;background:#edf2f6;color:#607185;font-size:8px}.hc-context-pane{display:none;padding:13px 13px 22px}.hc-context-pane.active{display:block}.hc-pane-intro{padding:8px 2px 12px}.hc-pane-intro strong{font-size:12px;color:#26384d}.hc-pane-intro p{font-size:10px;line-height:1.5;color:#8793a2;margin:5px 0 0}.details .detail-title{font-size:9px!important;letter-spacing:.08em!important;color:#6c7d90!important;margin:12px 0 7px!important}.details .detail-card{border:1px solid #e2e8ef!important;border-radius:4px!important;background:#fff!important;margin-bottom:10px!important;padding:11px!important;box-shadow:none!important}.details .detail-row{font-size:10px!important;padding:7px 0!important;grid-template-columns:82px minmax(0,1fr)!important}.details .detail-row strong{color:#2b3d52!important;font-weight:650!important;overflow-wrap:anywhere}.details .detail-row span:first-child{color:#8591a0!important}.details .btn{border-radius:4px!important;font-size:10px!important}.details .btn.primary{background:#21699f!important;border-color:#21699f!important;color:#fff!important}.hc-field-label{display:block;margin:8px 0 5px;color:#77879a;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.04em}.hc-context-input{width:100%;height:34px;border:1px solid #dce4ec;border-radius:4px;background:#fff;color:#293b50;padding:0 9px;font-size:11px}.hc-save-context{width:100%;margin-top:10px!important}.hc-private-notes{display:flex;flex-direction:column;gap:8px}.hc-private-note{padding:10px;border:1px solid #f1dfb3;border-left:3px solid #daa13d;border-radius:4px;background:#fffaf0}.hc-private-note header{display:flex;justify-content:space-between;gap:8px;color:#86601c;font-size:9px;font-weight:800}.hc-private-note time{font-size:9px;color:#a18b60;font-weight:500}.hc-private-note p{margin:7px 0 0;color:#594b32;font-size:11px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere}.hc-private-empty{padding:18px 12px;border:1px dashed #dce3ea;border-radius:4px;text-align:center;color:#8a96a4;font-size:10px}.hc-side-item{width:100%;text-align:left;border:1px solid #e2e8ef;border-radius:4px;background:#fff;padding:10px;margin:0 0 7px;cursor:pointer}.hc-side-item strong{display:block;font-size:10px;color:#2e4157}.hc-side-item small{display:block;margin-top:4px;font-size:9px;color:#8592a2}.hc-side-thread-messages{max-height:50vh;overflow:auto;display:flex;flex-direction:column;gap:9px;padding:12px 0}.hc-side-message{padding:9px 11px;border:1px solid #e0e7ee;border-radius:4px;background:#f7f9fb}.hc-side-message strong{font-size:9px;color:#1e669e}.hc-side-message time{float:right;font-size:8px;color:#8b97a5}.hc-side-message p{white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px;line-height:1.5;margin:6px 0 0;color:#37485c}.hc-activity-list{display:flex;flex-direction:column;gap:0;border-left:1px solid #d9e2eb;margin:3px 0 15px 5px;padding-left:13px}.hc-activity-item{position:relative;padding:0 0 13px}.hc-activity-item:before{content:"";position:absolute;left:-18px;top:3px;width:7px;height:7px;border-radius:50%;background:#3485b8;border:2px solid #fff;box-shadow:0 0 0 1px #bed2e2}.hc-activity-item strong{display:block;font-size:10px;color:#364a60}.hc-activity-item small{font-size:9px;color:#8a96a5}.hc-activity-item p{font-size:10px;color:#637286;line-height:1.45;margin:4px 0 0;white-space:pre-wrap}.hc-new-side-inline{width:100%;margin-top:4px!important}
.hc-crm-modal[hidden]{display:none!important}.hc-crm-modal{position:fixed;inset:0;z-index:100000;display:grid;place-items:center;padding:18px}.hc-crm-backdrop{position:absolute;inset:0;background:#10233899;backdrop-filter:blur(2px)}.hc-crm-dialog{position:relative;width:min(520px,100%);max-height:min(90dvh,780px);overflow:auto;padding:18px;background:#fff;border:1px solid #dfe6ee;border-radius:7px;box-shadow:0 22px 80px #10233840}.hc-crm-dialog header{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;padding-bottom:12px;border-bottom:1px solid #e7ecf1}.hc-crm-dialog header small{font-size:9px;letter-spacing:.1em;font-weight:800;color:#2a78ad}.hc-crm-dialog h3{font-size:17px;margin:4px 0 0;color:#25394e}.hc-crm-dialog>p{font-size:11px;line-height:1.55;color:#7b8998;margin:13px 0}.hc-crm-dialog label{display:block;margin:12px 0 5px;color:#66788b;font-size:10px;font-weight:800}.hc-crm-dialog input,.hc-crm-dialog select,.hc-crm-dialog textarea{width:100%;border:1px solid #dbe3eb;border-radius:4px;padding:10px;font:12px Inter,system-ui;color:#293b50;background:#fff}.hc-crm-dialog textarea{resize:vertical;line-height:1.5}.hc-crm-dialog footer{display:flex;justify-content:flex-end;gap:8px;margin-top:14px;padding-top:12px;border-top:1px solid #e7ecf1}.hc-crm-dialog footer button{border:1px solid #d7e0e9;border-radius:4px;padding:8px 12px;background:#fff;color:#5d6d7e;font-size:10px;font-weight:700;cursor:pointer}.hc-crm-dialog footer button.primary{background:#21699f;border-color:#21699f;color:#fff}.hc-side-thread-dialog{width:min(640px,100%)}.hc-side-thread-messages{min-height:80px}
.hc-conversion-success{border-radius:4px!important}.details-scrim{z-index:40!important}
@media(max-width:1180px){.layout{grid-template-columns:minmax(260px,300px) minmax(0,1fr)!important}.details{position:fixed!important;right:0!important;top:58px!important;bottom:0!important;width:min(390px,92vw)!important;z-index:50!important;box-shadow:-15px 0 40px #152b4320!important}.layout.details-open .details{transform:translateX(0)!important}.layout:not(.details-open) .details{transform:translateX(105%)!important}.details-scrim{display:none}.layout.details-open .details-scrim{display:block}}
@media(max-width:760px){html,body{overflow:hidden!important}.top{height:56px!important;min-height:56px!important;padding:0 10px!important}.top .agent>span#connectionStatus{display:none!important}.top .agent>span:not(.avatar):not(#connectionStatus){display:inline!important;max-width:72px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:9px}.top .agent .btn:not(.availability-control){display:inline-flex!important;padding:6px 8px!important;font-size:0!important}.top .agent .btn:not(.availability-control) i{font-size:12px!important}.hc-top-nav{display:flex!important}.hc-top-nav a{font-size:0!important;padding:7px 8px!important}.hc-top-nav a i{font-size:12px!important}.layout{height:calc(100dvh - 56px)!important;grid-template-columns:minmax(0,1fr)!important}.side{width:100%;min-width:0}.layout.open .side{display:none!important}.layout.open .main{display:flex!important;height:calc(100dvh - 56px)!important}.main{display:none}.chathead{min-height:58px!important;padding:8px 10px!important}.chathead>div:last-child{display:flex;gap:4px}.chathead .btn{padding:7px!important}.chatbody{padding:11px 9px!important}.msg{max-width:98%!important}.msg-content{max-width:calc(100% - 32px)!important;padding:9px 10px!important;font-size:11px!important}.compose{padding:8px 8px calc(8px + env(safe-area-inset-bottom))!important}.hc-compose-toolbar{align-items:flex-start}.hc-compose-actions{width:100%}.hc-compose-actions .btn{flex:1;justify-content:center}.hc-quick-replies{max-width:none;flex:1}.assist .btn{font-size:8px!important}.details{top:56px!important}.hc-context-tabs{padding:0 5px}.hc-context-tab{padding:10px 6px;font-size:8px}.hc-crm-dialog{padding:14px}.hc-crm-modal{padding:9px}}
@media(min-width:1181px) and (max-width:1350px){.layout{grid-template-columns:270px minmax(400px,1fr) 318px!important}.details{font-size:12px}}
</style>

<style id="hc-agent-kapture-specificity-fixes-v131">
body:not(.hc-agent-dark) .top{height:58px!important;min-height:58px!important;padding:0 18px!important;background:#17283d!important;color:#fff!important;border:0!important;box-shadow:0 2px 10px #14233725!important}
body:not(.hc-agent-dark) .top .brand,body:not(.hc-agent-dark) .top .agent{color:#fff!important}
body:not(.hc-agent-dark) .layout{height:calc(100dvh - 58px)!important;min-height:0!important;grid-template-columns:minmax(270px,304px) minmax(430px,1fr) minmax(310px,360px)!important;gap:0!important;padding:0!important;overflow:hidden!important;border-radius:0!important}
body:not(.hc-agent-dark) .side{background:#f8fafc!important;border:0!important;border-right:1px solid #dce3ec!important;border-radius:0!important}
body:not(.hc-agent-dark) .side-heading{padding:18px 17px 12px!important;background:#f8fafc!important}
body:not(.hc-agent-dark) .tabs{display:flex!important;gap:4px!important;padding:10px 12px 0!important;background:#f8fafc!important}
body:not(.hc-agent-dark) .tab{min-width:0!important;flex:1 1 0!important;border-radius:4px 4px 0 0!important;padding:10px 5px!important;font-size:9px!important;background:transparent!important;color:#68778b!important}
body:not(.hc-agent-dark) .tab.active{background:#fff!important;color:#1e5f99!important;border-color:#dfe6ee!important}
body:not(.hc-agent-dark) .main{background:#f2f4f7!important;border-radius:0!important}
body:not(.hc-agent-dark) .chathead{min-height:65px!important;padding:10px 18px!important;border-radius:0!important}
body:not(.hc-agent-dark) .chatbody{padding:18px clamp(16px,2.5vw,34px)!important;background:#f2f4f7!important}
body:not(.hc-agent-dark) .compose{padding:10px 15px 13px!important;background:#fff!important;border-radius:0!important}
body:not(.hc-agent-dark) .compose textarea{min-height:70px!important;max-height:160px!important;font-size:12px!important}
body:not(.hc-agent-dark) .details{display:flex!important;flex-direction:column!important;position:relative!important;inset:auto!important;width:auto!important;height:100%!important;max-height:100%!important;transform:none!important;visibility:visible!important;border-radius:0!important;border-left:1px solid #dce3ec!important;padding:0 0 22px!important;overflow-y:auto!important;background:#fff!important;box-shadow:none!important}
body:not(.hc-agent-dark) .layout:not(.open) .details{display:none!important}
body:not(.hc-agent-dark) .layout:not(.details-collapsed) .details{grid-column:3!important}
body:not(.hc-agent-dark) .layout:not(.details-collapsed) .main{grid-column:2!important}
body:not(.hc-agent-dark) .details .detail-title{font-size:9px!important;letter-spacing:.08em!important;color:#6c7d90!important;margin:12px 0 7px!important}
body:not(.hc-agent-dark) .details .detail-card{border:1px solid #e2e8ef!important;border-radius:4px!important;background:#fff!important;margin-bottom:10px!important;padding:11px!important;box-shadow:none!important}
body:not(.hc-agent-dark) .details .detail-row{font-size:10px!important;padding:7px 0!important;grid-template-columns:82px minmax(0,1fr)!important}
body:not(.hc-agent-dark) .details .btn{border-radius:4px!important;font-size:10px!important}
@media(max-width:1180px){body:not(.hc-agent-dark) .layout{grid-template-columns:minmax(260px,300px) minmax(0,1fr)!important;padding:0!important;gap:0!important}body:not(.hc-agent-dark) .layout .details{position:fixed!important;top:58px!important;right:0!important;bottom:0!important;width:min(390px,92vw)!important;height:auto!important;max-height:none!important;z-index:52!important;transform:translateX(105%)!important;visibility:hidden!important;border-radius:0!important;box-shadow:-15px 0 40px #152b4320!important}body:not(.hc-agent-dark) .layout.details-open .details{transform:translateX(0)!important;visibility:visible!important}body:not(.hc-agent-dark) .layout.details-open .details-scrim{display:block!important;position:fixed!important;inset:58px 0 0!important;z-index:51!important;background:#10233855!important}}
@media(max-width:760px){body:not(.hc-agent-dark) .top{height:56px!important;min-height:56px!important;padding:0 10px!important}body:not(.hc-agent-dark) .layout{height:calc(100dvh - 56px)!important;grid-template-columns:minmax(0,1fr)!important;padding:0!important;gap:0!important}body:not(.hc-agent-dark) .layout.open .side{display:none!important}body:not(.hc-agent-dark) .layout.open .main{display:flex!important;grid-column:1!important;height:100%!important}body:not(.hc-agent-dark) .layout:not(.open) .main{display:none!important}body:not(.hc-agent-dark) .layout .details{top:56px!important;width:calc(100vw - 14px)!important;max-width:410px!important}body:not(.hc-agent-dark) .layout.details-open .details-scrim{inset:56px 0 0!important}body:not(.hc-agent-dark) .side,body:not(.hc-agent-dark) .main{border-radius:0!important}}
</style>
</head><body><main class="auth"><div class="brand"><span class="mark">✦</span><span><?php echo esc_html(get_bloginfo('name')); ?><small style="display:block;color:#8790a2;font-size:11px;font-weight:500">HelpCenter Agent Access</small></span></div><span class="eyebrow">SECURE AGENT PORTAL</span><h1><?php echo esc_html($title); ?></h1><p class="muted"><?php echo esc_html($subtitle); ?></p><?php echo $body; ?><div class="links"><a href="<?php echo esc_url(home_url('/support-agent/login/')); ?>">Back to agent sign in</a></div></main></body></html><?php }
    private static function forgot_password_page(){ $message='';$error='';if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['hc_agent_forgot_nonce'])&&wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hc_agent_forgot_nonce'])),'hc_agent_forgot')){$login=sanitize_text_field(wp_unslash($_POST['user_login']??''));$user=get_user_by('login',$login);if(!$user&&is_email($login))$user=get_user_by('email',$login);if($user&&in_array('hc_support_agent',(array)$user->roles,true)){$r=retrieve_password($user->user_login);if(is_wp_error($r))$error=$r->get_error_message();else $message='If the account exists and can receive email, a secure reset link has been sent.';}else $message='If the account exists and can receive email, a secure reset link has been sent.';} $body='';if($error)$body.='<div class="notice error">'.esc_html($error).'</div>';if($message)$body.='<div class="notice">'.esc_html($message).'</div>';$body.='<form method="post">'.wp_nonce_field('hc_agent_forgot','hc_agent_forgot_nonce',true,false).'<label for="agent-login">Login ID or work email</label><input id="agent-login" name="user_login" autocomplete="username" required placeholder="Enter your Login ID or email"><button type="submit">Send password reset link</button></form>';self::auth_card('Reset your password','Enter your agent Login ID or work email. We will send a secure reset link if the account is eligible.',$body); }
    private static function reset_password_page(){ $key=sanitize_text_field(wp_unslash($_GET['key']??$_POST['key']??''));$login=sanitize_text_field(wp_unslash($_GET['login']??$_POST['login']??''));$user=check_password_reset_key($key,$login);$error='';$message='';if(is_wp_error($user))$error='This password reset link is invalid or has expired. Request a new link.';elseif(!in_array('hc_support_agent',(array)$user->roles,true))$error='This reset link is not for an agent account.';elseif($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['hc_agent_reset_nonce'])&&wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hc_agent_reset_nonce'])),'hc_agent_reset')){$pass=(string)wp_unslash($_POST['pass1']??'');$confirm=(string)wp_unslash($_POST['pass2']??'');if(strlen($pass)<12)$error='Use a password with at least 12 characters.';elseif($pass!==$confirm)$error='The passwords do not match.';else{reset_password($user,$pass);$message='Your password has been updated. You can now sign in.';}}$body='';if($error)$body.='<div class="notice error">'.esc_html($error).'</div>';if($message)$body.='<div class="notice">'.esc_html($message).'</div>';if(!is_wp_error($user)&&!$message&&in_array('hc_support_agent',(array)$user->roles,true))$body.='<form method="post"><input type="hidden" name="key" value="'.esc_attr($key).'"><input type="hidden" name="login" value="'.esc_attr($login).'">'.wp_nonce_field('hc_agent_reset','hc_agent_reset_nonce',true,false).'<label>New password</label><input type="password" name="pass1" minlength="12" autocomplete="new-password" required><label>Confirm new password</label><input type="password" name="pass2" minlength="12" autocomplete="new-password" required><button type="submit">Update password</button></form>';self::auth_card('Choose a new password','Create a strong password for your HelpCenter agent account.',$body); }
    private static function login_page() {
        if (is_user_logged_in() && self::agent()) { wp_safe_redirect(home_url('/support-agent/')); exit; }
        $error='';
        if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['hc_agent_login_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hc_agent_login_nonce'])),'hc_agent_login')) {
            $login=sanitize_text_field(wp_unslash($_POST['login']??''));
            $pass=(string)wp_unslash($_POST['password']??'');
            $user=wp_signon(array('user_login'=>$login,'user_password'=>$pass,'remember'=>true),is_ssl());
            if (is_wp_error($user)) $error='Login ID or password is incorrect.';
            elseif (!in_array('hc_support_agent',(array)$user->roles,true) && !user_can($user,'hc_agent_portal_access') && !user_can($user,'hc_manage_ai_escalations')) { wp_logout(); $error='This account is not an enabled support-agent account.'; }
            else { wp_safe_redirect(home_url('/support-agent/')); exit; }
        }
        $body='';
        if($error)$body.='<div class="notice error">'.esc_html($error).'</div>';
        $body.='<form method="post">'.wp_nonce_field('hc_agent_login','hc_agent_login_nonce',true,false).'<label for="agent-login">Login ID</label><input id="agent-login" name="login" autocomplete="username" required placeholder="Your agent Login ID"><label for="agent-password">Password</label><input id="agent-password" type="password" name="password" autocomplete="current-password" required placeholder="Your password"><label style="display:flex;align-items:center;gap:8px;font-weight:500"><input type="checkbox" name="remember" value="1" checked style="width:16px;height:16px"> Keep me signed in</label><button type="submit">Sign in to Agent Desk</button><div class="links"><a href="'.esc_url(home_url('/support-agent/forgot-password/')).'">Forgot password?</a></div></form>';
        self::auth_card('Welcome back','Sign in with the Login ID and password provided by your HelpCenter administrator.',$body);
    }
    private static function portal_page() {
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        nocache_headers();
        if (!headers_sent()) header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
        $u=wp_get_current_user(); global $wpdb; $presence_table=$wpdb->prefix.'hc_ai_support_presence'; $presence_row=$wpdb->get_row($wpdb->prepare("SELECT is_available,last_seen,force_logged_out FROM {$presence_table} WHERE user_id=%d",(int)$u->ID)); $initial_available=$presence_row&&!empty($presence_row->is_available)&&empty($presence_row->force_logged_out)&&!empty($presence_row->last_seen)&&strtotime($presence_row->last_seen)>=time()-35; $nonce=wp_create_nonce('hc_agent_portal'); $hck_nonce=wp_create_nonce('hck_nonce'); $ajax=admin_url('admin-ajax.php');
        ?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Support Agent Workspace</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.3.1/css/all.min.css"><style id="hc-agent-workspace-v134">
:root{--hc-ink:#17243a;--hc-muted:#748198;--hc-border:#e2e7f0;--hc-bg:#f5f7fb;--hc-panel:#fff;--hc-primary:#625cf5;--hc-primary-dark:#5148e8;--hc-primary-soft:#f0efff;--hc-navy:#111d34;--hc-green:#0f9f6e;--hc-red:#d84c59;--hc-amber:#bf8427}
*{box-sizing:border-box}html,body{height:100%;margin:0;overflow:hidden}body{background:var(--hc-bg);color:var(--hc-ink);font:13px/1.45 Inter,"Segoe UI",Arial,sans-serif;-webkit-font-smoothing:antialiased}button,input,select,textarea{font:inherit}button{cursor:pointer}.hidden,[hidden]{display:none!important}
.top{height:60px;min-height:60px;display:flex;align-items:center;gap:20px;padding:0 22px;background:#fff;border-bottom:1px solid var(--hc-border);position:relative;z-index:60}.hc-top-brand{display:flex;align-items:center;gap:13px}.agent-home-link{display:flex;align-items:center;gap:9px;color:var(--hc-ink);text-decoration:none;font-size:15px;font-weight:850}.agent-home-link i{width:30px;height:30px;display:grid;place-items:center;border-radius:8px;background:var(--hc-primary);color:#fff}.hc-top-brand>span{padding-left:13px;border-left:1px solid var(--hc-border);color:var(--hc-muted);font-size:11px}.hc-top-nav{height:100%;display:flex;align-items:center}.hc-top-nav a{display:flex;align-items:center;gap:8px;color:#53627a;text-decoration:none;font-size:11px;font-weight:750;padding:9px 12px;border:1px solid var(--hc-border);border-radius:7px}.agent{display:flex;align-items:center;gap:10px;margin-left:auto;color:#41516a;font-size:11px}.avatar{width:31px;height:31px;display:grid;place-items:center;border-radius:50%;background:var(--hc-primary-soft);color:var(--hc-primary);font-weight:800}.btn{min-height:32px;display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:7px 11px;border:1px solid #dce2ed;border-radius:7px;background:#fff;color:#53627a;font-size:10px;font-weight:700;text-decoration:none}.btn:hover{border-color:#c7c8ff;background:#f8f8ff;color:var(--hc-primary)}.btn.primary,.actions .primary{background:var(--hc-primary);border-color:var(--hc-primary);color:#fff}.availability-control{min-height:32px;padding:5px 10px;border-radius:18px;color:#77849a;background:#fff}.availability-control[aria-checked=true]{color:#087c58;border-color:#bce8d8;background:#f1fbf7}.availability-switch-track{width:25px;height:14px;display:inline-flex;align-items:center;padding:2px;border-radius:20px;background:#cbd3df}.availability-switch-thumb{width:10px;height:10px;border-radius:50%;background:#fff;transition:transform .15s}.availability-control[aria-checked=true] .availability-switch-track{background:#12a474}.availability-control[aria-checked=true] .availability-switch-thumb{transform:translateX(11px)}.hc-connection-state{display:none!important}
.hc-global-search{height:48px;display:flex;align-items:center;gap:10px;padding:0 22px;background:#fff;border-bottom:1px solid var(--hc-border)}.hc-global-search>i{color:#8a96a8}.hc-global-search input{width:min(680px,75vw);height:33px;border:1px solid #e1e6ef;border-radius:7px;padding:0 11px;outline:none;font-size:11px}.hc-global-search input:focus{border-color:#aaa7ff;box-shadow:0 0 0 3px #625cf51a}.hc-global-search>span{font-size:9px;color:#8b96a7}
.layout{height:calc(100dvh - 146px);min-height:0;display:grid;grid-template-columns:270px minmax(420px,1fr) 330px;overflow:hidden;background:#fff}.side,.main,.details{min-width:0;min-height:0;overflow:hidden}.side{display:flex;flex-direction:column;background:#fff;border-right:1px solid var(--hc-border)}.side-heading{min-height:76px;display:flex;align-items:center;justify-content:space-between;padding:14px 15px;border-bottom:1px solid #edf0f5}.eyebrow{display:block;color:var(--hc-primary);font-size:9px;font-weight:850;letter-spacing:.12em}.side-heading h2{margin:4px 0 2px;font-size:16px}.side-heading p{margin:0;color:#8793a5;font-size:10px}.icon-btn{width:34px;height:34px;display:grid;place-items:center;border:1px solid #e1e6ef;border-radius:7px;background:#fff;color:#64738a}.inbox-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;padding:10px}.inbox-stat{display:grid;grid-template-columns:7px 1fr;gap:3px 6px;padding:8px 7px;border:1px solid #e7eaf1;border-radius:7px}.inbox-stat strong{font-size:15px}.inbox-stat small{grid-column:2;color:#7a879b;font-size:9px}.stat-dot{width:7px;height:7px;border-radius:50%;background:#7c73f6}.stat-dot.green{background:#19ad7a}.stat-dot.blue{background:#4b9cf0}.tabs{display:flex;gap:5px;padding:0 10px 10px;border-bottom:1px solid #edf0f5}.tab{flex:1;min-height:35px;display:flex;align-items:center;justify-content:center;gap:6px;padding:6px 4px;border:1px solid transparent;border-radius:7px;background:#fff;color:#65738a;font-size:9px;font-weight:750}.tab.active{border-color:#dedcff;background:var(--hc-primary-soft);color:var(--hc-primary)}.list{min-height:0;flex:1;overflow:auto;padding:5px 7px 12px;overscroll-behavior:contain}.ticket{display:block;margin:3px 1px;padding:10px;border:1px solid transparent;border-bottom-color:#edf0f5;border-radius:7px;background:#fff;cursor:pointer}.ticket:hover{background:#fafaff}.ticket.sel{background:#f2f1ff;border-color:#dcd9ff;box-shadow:inset 3px 0 var(--hc-primary)}.ticket strong{font-size:10px}.ticket small{display:block;margin-top:4px;color:#758198;font-size:9px;line-height:1.4;overflow-wrap:anywhere}.ticket .badge{padding:3px 6px;border-radius:20px;background:#f0f2f6;color:#69758a;font-size:8px}.priority-dot{width:6px;height:6px;display:inline-block;margin-right:5px;border-radius:50%;background:#5794da}.priority-dot.priority-low{background:#45a57e}.priority-dot.priority-high{background:#df9d3f}.priority-dot.priority-urgent{background:#d9535e}.unread-pill{display:inline-flex;align-items:center;gap:4px;color:#5148e8;font-weight:800}.unread-pill:before{content:"";width:6px;height:6px;border-radius:50%;background:#625cf5}
.main{display:flex;flex-direction:column;background:#f5f6fb}.home-overview{height:100%;min-height:0;overflow:auto;padding:22px 24px 28px;overscroll-behavior:contain}.home-welcome{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:20px 22px;border:1px solid transparent;border-radius:10px;background:linear-gradient(112deg,#172a4d 0%,#273e75 52%,#5148a7 100%);color:#fff}.home-welcome .eyebrow{color:#c6ccff}.home-welcome h1{color:#fff}.home-welcome p{color:#d8e0f5}.home-welcome h1{margin:5px 0;font-size:21px;letter-spacing:-.5px}.home-welcome p{margin:0;color:var(--hc-muted);font-size:11px}.home-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0 22px}.home-metrics article{min-height:98px;padding:14px 15px;border:1px solid #e5e8f1;border-radius:9px;background:#fff}.home-metrics article span{display:flex;align-items:center;gap:7px;color:#65738a;font-size:10px;font-weight:700}.home-metrics article span i{color:var(--hc-primary)}.home-metrics article strong{display:block;margin:8px 0 1px;font-size:23px}.home-metrics article small{color:#8a96a8;font-size:9px}.home-list-head{display:flex;align-items:end;justify-content:space-between;margin:0 0 10px}.home-list-head h2{margin:0;font-size:15px}.home-list-head p{margin:3px 0 0;color:var(--hc-muted);font-size:10px}.home-list-head>span{color:#7c8799;font-size:10px}.home-ticket-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.home-ticket-card{display:block;width:100%;text-align:left;padding:13px 14px;border:1px solid #e3e7ef;border-radius:8px;background:#fff;color:var(--hc-ink);cursor:pointer}.home-ticket-card:hover{border-color:#c9c7ff;background:#fcfbff}.home-ticket-card header{display:flex;justify-content:space-between;gap:10px}.home-ticket-card strong{font-size:11px}.home-ticket-card p{margin:7px 0;color:#647188;font-size:10px;line-height:1.5}.home-ticket-card footer{display:flex;justify-content:space-between;gap:8px;color:#8591a3;font-size:9px}.home-empty{grid-column:1/-1;padding:35px;text-align:center;color:#8793a5;border:1px dashed #dce2ed;border-radius:8px;background:#fff}.layout.home-mode{grid-template-columns:270px minmax(0,1fr)}.layout.home-mode .details{display:none}.layout.home-mode .side .list{display:none}.layout.home-mode .side .inbox-stats{display:none}.layout.home-mode .side .tabs{border-bottom:0}.layout.home-mode #workspace,.layout.home-mode #blank{display:none!important}.layout.ticket-mode{grid-template-columns:245px minmax(390px,1fr) 330px}.layout.ticket-mode.details-collapsed{grid-template-columns:245px minmax(390px,1fr) 0}.layout.ticket-mode.details-collapsed .details{display:none}.layout.ticket-mode .home-overview{display:none}.layout.ticket-mode .side .inbox-stats{display:none}.layout.ticket-mode .side .tabs .tab[data-tab="closed"]{display:none}.layout.ticket-mode .side .tabs{padding-top:12px}.layout.ticket-mode #workspace{display:flex!important}.layout.ticket-mode #blank{display:none!important}
.chathead{min-height:64px;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 16px;background:#fff;border-bottom:1px solid var(--hc-border)}.chathead>div:first-child{min-width:0}.chathead strong{font-size:13px}.chathead .muted{margin-top:3px;color:#7b879a;font-size:10px}.chathead>div:last-child{display:flex;gap:6px}.chathead .back{display:inline-flex}.chatbody{min-height:0;flex:1;display:flex;flex-direction:column;align-items:flex-start;gap:11px;overflow:auto;overscroll-behavior:contain;padding:18px 24px;background:#f5f6fb;scrollbar-gutter:stable}.msg{max-width:min(800px,88%);display:flex;align-items:flex-end;gap:8px}.msg.agent{align-self:flex-end;flex-direction:row-reverse}.msg-avatar{width:27px;height:27px;flex:0 0 27px;display:grid;place-items:center;border-radius:50%;background:#e8ebf2;color:#60708b;font-size:10px;font-weight:800}.msg-content{max-width:100%;min-width:90px;padding:10px 13px;border:1px solid #e2e6ee;border-radius:8px;background:#fff;color:#283750;font-size:11px;line-height:1.6;overflow-wrap:anywhere}.msg.agent .msg-content{border-color:#dedcff;background:#efeeff}.hc-message-delivery-uncertain{opacity:.82}.hc-message-delivery-uncertain .msg-content{border-style:dashed;border-color:#d6a34d}.msg.ai .msg-content{border-color:#e0def4;background:#f0effb}.msg.note .msg-content{border-color:#f1dda5;background:#fff6df}.initial-concern .msg-content{border-left:3px solid #d59b35;background:#fffdf7}.compose{position:relative;background:#fff;border-top:1px solid #e2e7ef;padding:9px 14px 12px}.compose textarea{width:100%;min-height:66px;max-height:135px;padding:10px 12px;border:1px solid #e1e6ef;border-radius:8px;background:#fafbfe;font-size:12px}.compose .actions{display:flex;justify-content:flex-end;gap:8px;margin-top:8px}.compose .actions #send{min-width:125px;min-height:36px}.hc-compose-toolbar,.hc-compose-modes,.hc-compose-actions{display:flex;align-items:center;gap:7px}.assist{display:flex;flex-wrap:wrap;gap:6px;margin:7px 0}.assist .btn{min-height:27px;padding:5px 8px;font-size:9px}.hc-quick-replies{height:29px;border:1px solid var(--hc-border);border-radius:6px;padding:0 8px;font-size:10px}.closed{padding:10px 14px;background:#fff8e8;border-top:1px solid #f1dfb8;color:#946316;font-size:10px}
.details{display:flex;flex-direction:column;background:#fff;border-left:1px solid var(--hc-border)}.details-mobile-head{display:flex;align-items:center;justify-content:space-between;min-height:48px;padding:8px 14px;border-bottom:1px solid #edf0f5;font-size:11px}.hc-context-heading{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid #edf0f5}.hc-customer-avatar{width:34px;height:34px;display:grid;place-items:center;border-radius:50%;background:var(--hc-primary-soft);color:var(--hc-primary);font-weight:800}.hc-context-customer{display:flex;flex-direction:column;min-width:0}.hc-context-customer strong{font-size:11px}.hc-context-customer small{color:#8591a3;font-size:9px;overflow-wrap:anywhere}.hc-context-content{min-height:0;flex:1;overflow:auto;padding:8px 12px 20px;overscroll-behavior:contain}.hc-right-section{border:1px solid #e6eaf1;border-radius:8px;background:#fff;margin:7px 0;overflow:hidden}.hc-right-section>summary{min-height:39px;display:flex;align-items:center;gap:9px;padding:9px 10px;list-style:none;cursor:pointer;color:#34445c;font-size:10px;font-weight:800}.hc-right-section>summary::-webkit-details-marker{display:none}.hc-right-section>summary>i:first-child{width:15px;color:var(--hc-primary);text-align:center}.hc-right-section>summary>i:last-child{margin-left:auto;color:#9aa5b4;font-size:9px;transition:transform .15s}.hc-right-section[open]>summary>i:last-child{transform:rotate(180deg)}.hc-right-section-body{padding:0 10px 11px;border-top:1px solid #f0f2f6}.detail-title{margin:11px 0 6px;color:#748198;font-size:9px;font-weight:850;text-transform:uppercase;letter-spacing:.06em}.detail-card{padding:9px;border:1px solid #e7ebf1;border-radius:7px;background:#fff;margin:7px 0}.detail-row{display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid #f0f2f6;font-size:10px}.detail-row:last-child{border-bottom:0}.detail-row span{color:#8793a5}.detail-row strong{max-width:68%;text-align:right;overflow-wrap:anywhere}.hc-ticket-id{display:flex;justify-content:space-between;padding:8px 0;font-size:10px}.hc-ticket-id span{color:#8793a5}.hc-ticket-controls{display:grid;grid-template-columns:1fr 1fr;gap:8px}.hc-field-label{display:block;margin:7px 0 4px;color:#77879a;font-size:9px;font-weight:800;text-transform:uppercase}.hc-context-input{width:100%;height:32px;border:1px solid #dce4ec;border-radius:6px;background:#fff;padding:0 8px;font-size:10px}.hc-save-context{width:100%;margin-top:8px}.hc-assignment-stack{display:grid;gap:7px}.hc-assignment-owner{font-size:10px;color:#7c8999}.hc-issue-box{font-size:10px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere}.hc-customer-actions{display:flex;gap:6px;margin-top:9px}.hc-customer-actions .btn{flex:1}.hc-sla-card{padding:9px;border:1px solid #e5e8f1;border-radius:7px;background:#f9faff}.hc-sla-card strong{display:block;font-size:11px}.hc-sla-card small{display:block;margin-top:3px;color:#8591a3;font-size:9px}.hc-history-card{width:100%;display:flex;align-items:center;justify-content:space-between;gap:9px;text-align:left;padding:10px;margin:5px 0;border:1px solid #e1e7f0;border-radius:9px;background:linear-gradient(110deg,#fff 0%,#fbfcff 100%);color:inherit;cursor:pointer;box-shadow:0 2px 7px rgba(31,48,91,.035);text-decoration:none;transition:border-color .15s,transform .15s,box-shadow .15s}.hc-history-card:hover{border-color:#bdc9e6;background:#f9faff;transform:translateY(-1px);box-shadow:0 5px 13px rgba(31,48,91,.07)}.hc-history-kind-icon{width:30px;height:30px;flex:0 0 30px;display:grid;place-items:center;border-radius:8px;background:#eef2ff;color:#5868bf;font-size:12px}.hc-history-kind-icon.conversation-kind{background:#eaf5f8;color:#347f91}.hc-history-card-main{min-width:0;flex:1}.hc-history-status{flex:0 0 auto;padding:4px 7px;border-radius:6px;background:#eef2ff;color:#5362ae;font-size:8px;font-style:normal;font-weight:800;white-space:nowrap;text-transform:capitalize}.hc-history-card-main>small i{color:#7b88bd;margin-right:2px}.hc-history-card-main>strong{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;text-overflow:ellipsis;overflow-wrap:anywhere;line-height:1.35}.hc-history-card-main>small{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;text-overflow:ellipsis;overflow-wrap:anywhere;line-height:1.35}.hc-history-card:hover{border-color:#c9c7ff;background:#fafaff}.hc-history-card-main{min-width:0}.hc-history-card-main strong{display:block;font-size:9px}.hc-history-card-main small{display:block;margin-top:3px;color:#8995a5;font-size:8px}.hc-history-card em{font-size:8px;font-style:normal;color:#69758a;white-space:nowrap}.hc-activity-list{border-left:1px solid #d9e2eb;margin:5px 0 5px 5px;padding-left:13px}.hc-activity-item{position:relative;padding:0 0 11px}.hc-activity-item:before{content:"";position:absolute;left:-18px;top:3px;width:7px;height:7px;border-radius:50%;background:#625cf5;border:2px solid #fff;box-shadow:0 0 0 1px #d7d8fa}.hc-activity-item strong{display:block;font-size:9px}.hc-activity-item small{color:#8a96a5;font-size:8px}.hc-activity-item p{font-size:9px;color:#637286;margin:3px 0;white-space:pre-wrap}.hc-private-panel-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:9px 0}.hc-private-panel-head strong{font-size:10px}.hc-private-panel-intro{color:#8591a3;font-size:9px;line-height:1.5}.hc-private-note{padding:9px;margin:6px 0;border:1px solid #f1dfb3;border-left:3px solid #daa13d;border-radius:6px;background:#fffaf0}.hc-private-note header{display:flex;justify-content:space-between;color:#86601c;font-size:9px}.hc-private-note p{margin:5px 0 0;color:#594b32;font-size:10px;white-space:pre-wrap}.hc-private-empty{padding:12px;border:1px dashed #dce3ea;border-radius:6px;text-align:center;color:#8a96a4;font-size:9px}.hc-note-count{margin-left:auto;padding:2px 6px;border-radius:10px;background:#f0efff;color:#5148e8;font-size:8px}.hc-side-item{width:100%;text-align:left;border:1px solid #e2e8ef;border-radius:6px;background:#fff;padding:8px;margin:0 0 6px;cursor:pointer}.hc-side-item strong{display:block;font-size:9px}.hc-side-item small{display:block;margin-top:3px;font-size:8px;color:#8592a2}.hc-context-content .hc-collapsible{border:0;border-radius:6px}.hc-context-content .hc-collapsible summary{font-size:10px}.summary-side{font-size:10px;line-height:1.55;white-space:pre-wrap;margin-top:8px}
.hc-agent-footer{height:38px;min-height:38px;display:flex;align-items:center;gap:20px;padding:0 18px;background:#fff;border-top:1px solid var(--hc-border);color:#7c899a;font-size:9px;position:relative;z-index:55}.hc-footer-network{display:flex;align-items:center;gap:7px}.hc-footer-network i{width:7px;height:7px;border-radius:50%;background:#a0a9b7}.hc-footer-network.is-good i{background:#0f9f6e}.hc-footer-network.is-unstable i{background:#d59b35}.hc-footer-network.is-offline i{background:#d84c59}.hc-agent-footer #footerSession{margin-left:auto}.hc-connection-warning{position:fixed;top:108px;left:0;right:0;z-index:65;padding:7px 14px;background:#fff7e8;color:#956316;font-size:10px}.layout.details-open .details{transform:translateX(0)}.layout.details-open .details-scrim{display:block;position:fixed;z-index:49;inset:108px 0 38px;background:#17243a44}
.hc-preview-modal,.hc-crm-modal{position:fixed;inset:0;z-index:1000;display:grid;place-items:center;padding:20px;background:#17243a66}.hc-preview-backdrop,.hc-crm-backdrop{position:absolute;inset:0}.hc-preview-dialog,.hc-crm-dialog{position:relative;width:min(640px,100%);max-height:90dvh;overflow:auto;background:#fff;border-radius:10px;padding:18px}.hc-preview-head,.hc-crm-dialog header,.hc-crm-dialog footer{display:flex;align-items:center;justify-content:space-between;gap:10px}.hc-preview-content{max-height:70vh;overflow:auto}.hc-preview-content img,.hc-preview-content video{max-width:100%;max-height:65vh}.hc-crm-dialog textarea,.hc-crm-dialog input,.hc-crm-dialog select{width:100%;padding:9px;border:1px solid var(--hc-border);border-radius:6px}.hc-crm-dialog label{display:block;margin:10px 0 5px;font-size:10px;font-weight:700}.hc-crm-dialog footer{justify-content:flex-end;margin-top:12px}.details-scrim,.inbox-scrim{display:none}#toggleInbox{display:none}
@media(max-width:1120px){.layout.ticket-mode{grid-template-columns:235px minmax(0,1fr)}.details{position:fixed;z-index:70;top:108px;right:0;bottom:38px;width:min(370px,92vw);box-shadow:-12px 0 32px #17243a22;transform:translateX(105%);transition:transform .18s}.layout.details-open .details{transform:translateX(0)}.layout.details-open .details-scrim{display:block;position:fixed;z-index:69;inset:108px 0 38px;background:#17243a44}.layout.home-mode{grid-template-columns:235px minmax(0,1fr)}}
@media(max-width:760px){.top{height:56px;min-height:56px;padding:0 10px;gap:7px}.hc-top-brand>span,.hc-top-nav{display:none}.agent{gap:6px}.agent>span:not(.avatar),.agent .btn:not(.availability-control){display:none}.agent .avatar{width:27px;height:27px}.hc-global-search{height:43px;padding:0 10px}.hc-global-search input{width:100%}.layout,.layout.home-mode,.layout.ticket-mode{height:calc(100dvh - 137px);display:block;position:relative}.side{position:absolute;inset:0;z-index:5;width:100%}.layout.ticket-mode .side{width:100%}.layout.ticket-mode.open .side{display:none}.layout.ticket-mode.inbox-open .side{display:flex!important;position:fixed;top:99px;bottom:38px;left:0;right:auto;width:min(320px,90vw);z-index:75;box-shadow:12px 0 32px #17243a22}.layout.ticket-mode.inbox-open #inboxScrim{display:block;position:fixed;z-index:69;inset:99px 0 38px;background:#17243a44}.layout.ticket-mode .main{display:none}.layout.ticket-mode.open .main{display:flex;position:absolute;inset:0}.layout.home-mode .side{position:absolute;top:0;left:0;right:0;height:94px;width:100%;z-index:5;border-right:0;border-bottom:1px solid var(--hc-border)}.layout.home-mode .side-heading{min-height:46px;padding:6px 12px}.layout.home-mode .side-heading .icon-btn{width:29px;height:29px}.layout.home-mode .tabs{padding:0 10px 7px}.layout.home-mode .tab{min-height:32px}.layout.home-mode .main{display:block;position:absolute;top:94px;left:0;right:0;bottom:0}.layout.home-mode .side .list{display:none}.layout.home-mode .tabs{max-width:360px}.home-overview{padding:12px}.home-welcome{padding:14px;align-items:flex-start}.home-welcome .btn{font-size:0}.home-welcome .btn i{font-size:12px}.home-metrics{grid-template-columns:1fr 1fr;gap:7px;margin:10px 0}.home-metrics article{min-height:80px;padding:10px}.home-metrics article strong{font-size:19px}.home-ticket-list{grid-template-columns:1fr}.chathead{min-height:56px;padding:7px 9px}.chathead #toggleInbox{display:inline-flex!important}.chathead>div:last-child{gap:4px}.chathead .btn{min-height:28px;padding:5px 7px;font-size:9px}.chathead>div:first-child{display:flex;align-items:center;gap:5px;flex-wrap:wrap}.chathead>div:first-child strong{max-width:42vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px}.chathead>div:first-child .muted{display:none}.chathead .back,.chathead #toggleInbox,.chathead #nextTicket{font-size:0!important;padding:6px 8px!important}.chathead .back i,.chathead #toggleInbox i,.chathead #nextTicket i{font-size:11px!important}.chatbody{padding:12px 8px;gap:9px}.msg{max-width:97%}.msg-content{padding:9px 10px;font-size:11px}.compose{max-height:43dvh;overflow:auto;padding:8px}.compose textarea{min-height:58px;max-height:100px;font-size:16px}.assist{flex-wrap:nowrap;overflow:auto}.assist .btn{flex:0 0 auto}.compose .actions #send{width:100%}.details{top:99px;bottom:38px;width:min(430px,calc(100vw - 12px))}.layout.details-open .details-scrim{inset:99px 0 38px}.hc-agent-footer{height:38px;min-height:38px;padding:0 9px;gap:9px;font-size:8px}.hc-agent-footer #footerSession{margin-left:auto}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{scroll-behavior:auto!important;transition:none!important}}

/* v135 focused workspace refinement */
.layout.home-mode .home-overview{padding:18px 22px 26px!important}
.layout.home-mode .home-welcome,.layout.home-mode .home-metrics{display:none!important}
.layout.home-mode .home-list-head{margin:0 0 14px!important;padding:2px 0 12px!important;border-bottom:1px solid #e4e9f2!important}
.layout.home-mode .home-list-head h2{font-size:18px!important}
.layout.home-mode .home-ticket-list{display:grid!important;grid-template-columns:minmax(0,1fr)!important;gap:10px!important;max-width:1100px}
.layout.home-mode .home-ticket-card{padding:16px 18px!important;border:1px solid #dfe5ef!important;border-radius:11px!important;box-shadow:0 2px 8px rgba(27,43,71,.035)!important;min-height:104px!important}
.layout.home-mode .home-ticket-card:hover{border-color:#aaa5fa!important;box-shadow:0 7px 18px rgba(47,55,120,.08)!important;transform:translateY(-1px)}
.layout.home-mode .home-ticket-card strong{font-size:13px!important;color:#26364d!important}
.layout.home-mode .home-ticket-card p{font-size:12px!important;line-height:1.6!important;color:#52647c!important;margin:10px 0!important;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.layout.home-mode .home-ticket-card footer{font-size:10px!important;color:#74839a!important}
.layout.home-mode .side .side-heading{padding-bottom:14px!important}.layout.home-mode .side .tabs{display:grid!important;grid-template-columns:1fr!important;gap:7px!important;padding:8px 10px!important}.layout.home-mode .side .tab{justify-content:flex-start!important;padding:10px 12px!important;min-height:42px!important;font-size:11px!important}
.layout.home-mode .side .inbox-stats{display:none!important}.layout.home-mode .side .list{display:none!important}
/* Readable conversation and a compact, floating-style (but in-flow) reply surface. */
.layout.ticket-mode .chatbody{flex:1 1 auto!important;min-height:0!important;overflow-y:auto!important;padding:22px clamp(18px,3vw,48px)!important;gap:16px!important;background:#f5f7fb!important}
.layout.ticket-mode .msg{max-width:min(760px,84%)!important;align-items:flex-start!important;gap:10px!important}
.layout.ticket-mode .msg-content{padding:13px 16px!important;border-radius:13px!important;font-size:13px!important;line-height:1.65!important;overflow-wrap:anywhere!important;box-shadow:0 3px 10px rgba(26,43,71,.055)!important}
.layout.ticket-mode .msg.visitor .msg-content{border-top-left-radius:4px!important;background:#fff!important;border:1px solid #e0e7f0!important}
.layout.ticket-mode .msg.agent .msg-content{border-top-right-radius:4px!important;background:#e9efff!important;border:1px solid #d7e1ff!important;color:#243b66!important}
.layout.ticket-mode .msg.ai .msg-content{background:#f1efff!important;border:1px solid #e0dcff!important}
.layout.ticket-mode .compose{flex:0 0 auto!important;margin:0 18px 14px!important;padding:12px 14px 10px!important;border:1px solid #dfe6f1!important;border-radius:15px!important;background:#fff!important;box-shadow:0 8px 24px rgba(26,43,71,.09)!important}
.hc-compose-toolbar-legacy,.hc-send-compat{display:none!important}
.layout.ticket-mode .compose textarea{display:block!important;width:100%!important;min-height:78px!important;max-height:180px!important;padding:13px 14px!important;border:1px solid #e1e7f0!important;border-radius:11px!important;background:#fbfcff!important;font-size:13px!important;line-height:1.55!important;resize:vertical!important}
.layout.ticket-mode .assist{display:flex!important;align-items:center!important;gap:7px!important;margin-top:9px!important;overflow:visible!important}
.layout.ticket-mode .assist .btn{width:34px!important;height:32px!important;min-width:34px!important;padding:0!important;display:inline-grid!important;place-items:center!important;border:1px solid #e3e8f1!important;border-radius:9px!important;background:#fff!important;color:#62718a!important;font-size:13px!important;position:relative!important}
.layout.ticket-mode .assist .btn:hover{color:#5148e8!important;border-color:#c9c5ff!important;background:#f8f7ff!important}
.layout.ticket-mode .assist .btn::after{content:attr(title);position:absolute;left:50%;bottom:calc(100% + 9px);transform:translate(-50%,4px);opacity:0;pointer-events:none;white-space:nowrap;padding:6px 9px;border-radius:6px;background:#202b42;color:#fff;font-size:10px;font-weight:650;box-shadow:0 5px 14px #17243a30;transition:.15s ease;z-index:20}
.layout.ticket-mode .assist .btn:hover::after,.layout.ticket-mode .assist .btn:focus-visible::after{opacity:1;transform:translate(-50%,0)}
.hc-followup-top[hidden]{display:none!important}.hc-followup-top{display:inline-flex!important;align-items:center;gap:8px!important;background:#5148e8!important;color:#fff!important;border-color:#5148e8!important;border-radius:9px!important;font-weight:750!important}
.hc-context-icons{position:sticky;top:0;z-index:4;display:flex;align-items:center;justify-content:space-around;gap:5px;padding:8px 10px;background:#fff;border-bottom:1px solid #e6ebf2}
.hc-context-icon{position:relative;display:grid;place-items:center;width:39px;height:36px;border:1px solid transparent;border-radius:9px;background:#fff;color:#74829a;cursor:pointer;font-size:14px}
.hc-context-icon:hover,.hc-context-icon.active{background:#f0efff;border-color:#dedbff;color:#5148e8}
.hc-context-icon::after{content:attr(data-tooltip);position:absolute;left:50%;top:calc(100% + 8px);transform:translate(-50%,-3px);opacity:0;pointer-events:none;white-space:nowrap;padding:6px 9px;border-radius:6px;background:#202b42;color:#fff;font-size:10px;font-weight:650;box-shadow:0 5px 14px #17243a30;transition:.15s ease;z-index:20}
.hc-context-icon:hover::after,.hc-context-icon:focus-visible::after{opacity:1;transform:translate(-50%,0)}
.hc-context-content .hc-right-section[hidden]{display:none!important}
.hc-context-content .hc-right-section{margin:7px 0!important}
.hc-context-content .hc-right-section>summary{display:none!important}
.hc-context-content .hc-right-section-body{padding:12px!important;border-top:0!important}
.hc-context-content #contextPaneCustomer .hc-right-section-body:before{content:'CUSTOMER INFORMATION';display:block;margin:0 0 8px;color:#7a879a;font-size:9px;font-weight:850;letter-spacing:.07em}
.hc-context-content #contextPaneDetails .hc-right-section-body:before{content:'TICKET OVERVIEW & BRIEF';display:block;margin:0 0 8px;color:#7a879a;font-size:9px;font-weight:850;letter-spacing:.07em}
#saveTicketMeta{display:none!important}
@media(max-width:760px){.layout.home-mode .home-overview{padding:12px!important}.layout.home-mode .home-ticket-card{padding:13px!important}.layout.ticket-mode .compose{margin:0 8px 8px!important;padding:9px!important}.layout.ticket-mode .chatbody{padding:12px 9px!important}.layout.ticket-mode .msg{max-width:96%!important}.hc-followup-top span{display:none}.hc-context-icon{width:34px;height:34px}}


.hc-ai-summary-message .msg-content{background:#fff9df!important;border:1px solid #f1df9b!important;color:#594b1d!important;box-shadow:0 3px 12px rgba(148,115,28,.08)!important}.hc-ai-summary-message .msg-text{line-height:1.65!important}.hc-ai-summary-message .msg-text h1,.hc-ai-summary-message .msg-text h2,.hc-ai-summary-message .msg-text h3{margin:8px 0 5px!important;font-size:12px!important}.hc-ai-summary-message .msg-text ul,.hc-ai-summary-message .msg-text ol{padding-left:18px!important;margin:5px 0!important}.hc-ai-summary-message .msg-text p{margin:5px 0!important}.ticket .hc-ticket-list-heading>strong,.ticket .hc-ticket-preview,.home-ticket-card .hc-ticket-card-heading>strong,.home-ticket-card>p{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;overflow:hidden!important;text-overflow:ellipsis!important;overflow-wrap:anywhere!important;word-break:break-word!important;white-space:normal!important;min-width:0!important}

.hc-assignment-picker{position:relative;min-width:0}.hc-assignment-picker-toggle{width:100%;min-height:39px;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 11px;border:1px solid #dce3ee;border-radius:9px;background:#fff;color:#33445a;font-size:11px;font-weight:650;text-align:left;cursor:pointer}.hc-assignment-picker-toggle:hover,.hc-assignment-picker-toggle[aria-expanded=true]{border-color:#8290d5;box-shadow:0 0 0 3px rgba(102,117,198,.09)}.hc-assignment-picker-panel{position:absolute;z-index:40;top:calc(100% + 5px);left:0;right:0;padding:8px;border:1px solid #dce3ee;border-radius:10px;background:#fff;box-shadow:0 14px 35px rgba(28,43,75,.16)}.hc-assignment-picker-panel[hidden]{display:none!important}.hc-assignment-agent-options{max-height:220px;overflow:auto;margin-top:6px}.hc-assignment-agent-option{width:100%;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px;border:0;border-radius:7px;background:#fff;color:#40516a;text-align:left;font-size:10px;cursor:pointer}.hc-assignment-agent-option:hover{background:#f2f4ff}.hc-assignment-agent-option:disabled{opacity:.48;cursor:not-allowed}.hc-assignment-agent-option i{opacity:0;color:#5668bd}.hc-assignment-agent-option[aria-selected=true] i{opacity:1}.hc-assignment-empty{padding:12px;color:#8591a3;font-size:10px;text-align:center}
</style>
<style id="hc-agent-v141-modern-fixes">
.hc-live-support-info-card[hidden]{display:none!important}.hc-live-support-info-card{display:flex;gap:11px;align-items:flex-start;margin:12px 12px 14px;padding:13px;border:1px solid #dbe6f2;border-radius:13px;background:linear-gradient(135deg,#f3f8ff 0%,#f8f7ff 100%);box-shadow:0 5px 16px rgba(37,78,125,.055)}
.hc-live-support-info-icon{width:34px;height:34px;flex:0 0 34px;display:grid;place-items:center;border-radius:10px;background:#e4efff;color:#286ca8;font-size:14px}
.hc-live-support-info-copy{min-width:0;flex:1}.hc-live-support-info-title{display:flex;align-items:center;justify-content:space-between;gap:8px}.hc-live-support-info-title strong{font-size:11px;color:#263e59;font-weight:800}.hc-live-support-info-title span{display:inline-flex;align-items:center;gap:5px;padding:4px 7px;border-radius:20px;background:#e7f7ef;color:#168253;font-size:8px;font-weight:800;white-space:nowrap}.hc-live-support-info-title span i{font-size:6px}.hc-live-support-info-copy p{margin:6px 0 0;color:#64758a;font-size:9px;line-height:1.55}
.hc-modern-loader{width:min(390px,calc(100% - 28px));min-height:190px;margin:18px auto;padding:22px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:9px;border:1px solid #e2e9f3;border-radius:16px;background:linear-gradient(145deg,#fff,#f8faff);box-shadow:0 12px 34px rgba(35,57,93,.07);text-align:center;color:#2b3e58}
.hc-modern-loader strong{font-size:12px;font-weight:800;letter-spacing:.01em}.hc-modern-loader small{font-size:10px;line-height:1.5;color:#8190a5}
.hc-loader-orb{position:relative;width:42px;height:42px;display:block;margin-bottom:2px;border-radius:14px;background:linear-gradient(135deg,#e9efff,#e8e6ff);box-shadow:inset 0 0 0 1px #dce4ff;animation:hcLoaderFloat 1.8s ease-in-out infinite}
.hc-loader-orb i{position:absolute;width:6px;height:6px;border-radius:50%;background:#5e70df;animation:hcLoaderDot 1s ease-in-out infinite}.hc-loader-orb i:nth-child(1){left:10px;top:18px}.hc-loader-orb i:nth-child(2){left:18px;top:18px;animation-delay:.13s}.hc-loader-orb i:nth-child(3){left:26px;top:18px;animation-delay:.26s}
.hc-loader-track{width:150px;height:4px;overflow:hidden;border-radius:9px;background:#e9edf6;margin-top:5px}.hc-loader-track i{display:block;width:42%;height:100%;border-radius:9px;background:linear-gradient(90deg,#6b79e8,#54b7d5);animation:hcLoaderProgress 1.35s ease-in-out infinite}
.hc-loader-skeleton{width:min(300px,100%);display:grid;gap:7px;margin-top:7px}.hc-loader-skeleton i{display:block;height:8px;border-radius:8px;background:linear-gradient(90deg,#edf1f7 20%,#f8faff 45%,#e9eef8 70%);background-size:220% 100%;animation:hcLoaderShimmer 1.25s linear infinite}.hc-loader-skeleton i:nth-child(1){width:92%}.hc-loader-skeleton i:nth-child(2){width:70%}.hc-loader-skeleton i:nth-child(3){width:84%}
.hc-ticket-loader{min-height:230px}.hc-ticket-loader .hc-loader-orb{width:46px;height:46px;border-radius:16px}
@keyframes hcLoaderFloat{0%,100%{transform:translateY(0) rotate(-3deg)}50%{transform:translateY(-4px) rotate(3deg)}}@keyframes hcLoaderDot{0%,80%,100%{transform:translateY(0);opacity:.45}40%{transform:translateY(-6px);opacity:1}}@keyframes hcLoaderProgress{0%{transform:translateX(-110%)}100%{transform:translateX(250%)}}@keyframes hcLoaderShimmer{to{background-position:-220% 0}}
@media(max-width:760px){.hc-live-support-info-card{margin:9px;padding:11px}.hc-modern-loader{min-height:160px;padding:18px}}
@media(prefers-reduced-motion:reduce){.hc-loader-orb,.hc-loader-orb i,.hc-loader-track i,.hc-loader-skeleton i{animation:none!important}}
</style>
<style id="hc-agent-messenger-search-alert-fix-v2">
/* Messenger-style conversation: sender identity and timestamp stay outside the message bubble. */
#messages{display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:0!important;min-width:0!important;}
.layout.ticket-mode #messages .msg{display:flex!important;flex-direction:row!important;align-items:flex-start!important;gap:12px!important;width:fit-content!important;max-width:min(86%,800px)!important;margin:0 0 16px!important;padding:0!important;border:0!important;background:transparent!important;box-shadow:none!important;overflow:visible!important;}
.layout.ticket-mode #messages .msg.agent{flex-direction:row-reverse!important;align-self:flex-end!important;margin-left:auto!important;margin-right:0!important;}
.layout.ticket-mode #messages .msg.visitor,
.layout.ticket-mode #messages .msg.ai,
.layout.ticket-mode #messages .msg.note{align-self:flex-start!important;margin-right:auto!important;}
.layout.ticket-mode #messages .msg .msg-avatar{display:grid!important;place-items:center!important;flex:0 0 36px!important;width:36px!important;height:36px!important;min-width:36px!important;margin:0!important;border:0!important;border-radius:50%!important;background:#dce9f8!important;color:#31547d!important;font-size:12px!important;font-weight:750!important;line-height:1!important;overflow:hidden!important;}
.layout.ticket-mode #messages .msg.agent .msg-avatar{background:#f4dddd!important;color:#8c3d3d!important;}
.layout.ticket-mode #messages .msg.ai .msg-avatar{background:#eee9ff!important;color:#6848b4!important;}
.layout.ticket-mode #messages .msg.note .msg-avatar{background:#fff0c7!important;color:#916000!important;}
.layout.ticket-mode #messages .msg .msg-content{display:flex!important;flex:0 1 auto!important;flex-direction:column!important;align-items:flex-start!important;gap:0!important;width:fit-content!important;min-width:0!important;max-width:100%!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;color:inherit!important;box-shadow:none!important;font-size:13px!important;line-height:1.55!important;overflow:visible!important;}
.layout.ticket-mode #messages .msg.agent .msg-content{align-items:flex-end!important;}
.layout.ticket-mode #messages .msg .who{display:flex!important;align-items:center!important;gap:6px!important;max-width:100%!important;margin:0 0 6px!important;padding:0 4px!important;color:#45546b!important;font-size:12px!important;font-weight:650!important;line-height:1.25!important;letter-spacing:0!important;text-transform:none!important;}
.layout.ticket-mode #messages .msg.agent .who{justify-content:flex-end!important;color:#5c5688!important;}
.layout.ticket-mode #messages .msg .msg-text{display:block!important;width:fit-content!important;max-width:100%!important;min-width:0!important;margin:0!important;padding:10px 14px!important;border:1px solid #e1e6ed!important;border-radius:15px 15px 15px 4px!important;background:#fff!important;color:#222d3d!important;box-shadow:0 1px 2px rgba(20,30,55,.06)!important;font-size:13px!important;line-height:1.55!important;white-space:pre-wrap!important;overflow-wrap:anywhere!important;word-break:break-word!important;}
.layout.ticket-mode #messages .msg.agent .msg-text{align-self:flex-end!important;border-color:#d6e3f7!important;border-radius:15px 15px 4px 15px!important;background:#dceaff!important;color:#1f3555!important;}
.layout.ticket-mode #messages .msg.ai .msg-text{border-color:#ded5fb!important;background:#f3efff!important;color:#40345e!important;}
.layout.ticket-mode #messages .msg.note .msg-text{border-color:#f0dfa9!important;background:#fff7e4!important;color:#594b1d!important;}
.layout.ticket-mode #messages .msg.initial-concern .msg-text{border-left:3px solid #d59b35!important;background:#fffdf7!important;}
.layout.ticket-mode #messages .msg .msg-text p{margin:4px 0!important;}
.layout.ticket-mode #messages .msg .msg-text p:first-child{margin-top:0!important;}
.layout.ticket-mode #messages .msg .msg-text p:last-child{margin-bottom:0!important;}
.layout.ticket-mode #messages .msg .msg-footer{display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:5px!important;margin:6px 0 0!important;padding:0 4px!important;color:#858fa0!important;font-size:10px!important;font-weight:400!important;line-height:1.2!important;}
.layout.ticket-mode #messages .msg.agent .msg-footer{justify-content:flex-end!important;}
.layout.ticket-mode #messages .msg .msg-footer i{font-size:9px!important;color:#9aa4b3!important;}
.layout.ticket-mode #messages .msg .msg-footer time{font-size:10px!important;color:#858fa0!important;font-variant-numeric:tabular-nums!important;white-space:nowrap!important;}
.layout.ticket-mode #messages .msg .msg-attachment{display:block!important;max-width:100%!important;margin:6px 0 0!important;overflow:hidden!important;}
.layout.ticket-mode #messages .msg .msg-attachment img,
.layout.ticket-mode #messages .msg .msg-attachment video,
.layout.ticket-mode #messages .msg .msg-attachment iframe{display:block!important;max-width:100%!important;border-radius:10px!important;}
.layout.ticket-mode #messages .msg .msg-audit,
.layout.ticket-mode #messages .msg .hc-thread-note-actions{margin-top:6px!important;}
.layout.ticket-mode #messages .msg.is-grouped{margin-top:-12px!important;margin-bottom:4px!important;}
.layout.ticket-mode #messages .msg.is-grouped .msg-avatar,
.layout.ticket-mode #messages .msg.is-grouped .who{visibility:hidden!important;}
.layout.ticket-mode #messages .msg.is-grouped .msg-text{border-top-left-radius:8px!important;}
.layout.ticket-mode #messages .msg.agent.is-grouped .msg-text{border-top-right-radius:8px!important;border-top-left-radius:15px!important;}
.layout.ticket-mode #messages .msg.system{display:flex!important;align-self:center!important;max-width:95%!important;margin:12px auto!important;}
.layout.ticket-mode #messages .msg.system .msg-avatar{display:none!important;}
.layout.ticket-mode #messages .msg.system .msg-content{display:block!important;width:auto!important;padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;}
.layout.ticket-mode #messages .msg.system .who,
.layout.ticket-mode #messages .msg.system .msg-footer{display:none!important;}
.layout.ticket-mode #messages .msg.system .msg-text{width:fit-content!important;padding:7px 11px!important;border:1px solid #e0e6ef!important;border-radius:999px!important;background:#edf1f7!important;color:#66748a!important;box-shadow:none!important;font-size:10px!important;text-align:center!important;}
/* Notification bell control and its anchored preferences panel. */
.hc-agent-alert-control{position:relative!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 auto!important;margin:0 2px!important;z-index:45!important;}
#hcAgentAlertToggle{position:relative!important;display:grid!important;place-items:center!important;width:38px!important;height:38px!important;min-width:38px!important;padding:0!important;border:1px solid #42617d!important;border-radius:11px!important;background:#233d58!important;color:#f4f8fc!important;font-size:15px!important;line-height:1!important;box-shadow:0 2px 7px rgba(7,20,35,.12)!important;cursor:pointer!important;transition:background .15s,border-color .15s,transform .15s!important;}
#hcAgentAlertToggle:hover,#hcAgentAlertToggle[aria-expanded="true"]{border-color:#88a8c4!important;background:#315473!important;color:#fff!important;transform:translateY(-1px)!important;}
#hcAgentAlertToggle:focus-visible{outline:3px solid rgba(119,174,224,.5)!important;outline-offset:2px!important;}
#hcAgentAlertToggle>i{display:block!important;font-size:15px!important;}
#hcAgentAlertToggle .hc-alert-visually-hidden{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important;}
.top .agent .hc-alerts-moved-to-header{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:6px!important;min-width:38px!important;min-height:38px!important;padding:0 10px!important;border:1px solid #42617d!important;border-radius:11px!important;background:#233d58!important;color:#f4f8fc!important;font-size:11px!important;font-weight:750!important;line-height:1!important;text-decoration:none!important;box-shadow:0 2px 7px rgba(7,20,35,.12)!important;cursor:pointer!important;transition:background .15s,border-color .15s,transform .15s!important;}
.top .agent .hc-alerts-moved-to-header:hover,.top .agent .hc-alerts-moved-to-header:focus-visible{border-color:#88a8c4!important;background:#315473!important;color:#fff!important;transform:translateY(-1px)!important;outline-offset:2px!important;}
#hcAgentAlertSettings .hc-alert-volume{display:grid!important;grid-template-columns:minmax(65px,1fr) minmax(90px,1.3fr) 38px!important;align-items:center!important;gap:9px!important;margin:13px 0!important;}
#hcAgentAlertSettings .hc-alert-volume input[type=range]{width:100%!important;min-width:0!important;}
#hcAgentAlertSettings{position:absolute!important;top:calc(100% + 9px)!important;right:0!important;left:auto!important;z-index:100000!important;width:min(330px,calc(100vw - 22px))!important;max-height:min(75vh,520px)!important;overflow:auto!important;padding:16px!important;border:1px solid #dfe6ef!important;border-radius:14px!important;background:#fff!important;box-shadow:0 18px 48px rgba(13,29,49,.24)!important;color:#25364b!important;}
#hcAgentAlertSettings[hidden]{display:none!important;}
#hcAgentAlertSettings>strong{font-size:13px!important;font-weight:800!important;color:#24364c!important;}
#hcAgentAlertSettings #hcAgentAlertStatus{font-size:11px!important;line-height:1.5!important;color:#69788d!important;}
#hcAgentAlertSettings label{color:#41536b!important;}
#hcAgentAlertSettings input[type="checkbox"]{width:16px!important;height:16px!important;accent-color:#4269a6!important;}
#hcAgentAlertSettings input[type="range"]{accent-color:#526bc1!important;}
#hcAgentAlertSettings .hc-alert-actions{display:flex!important;gap:7px!important;flex-wrap:wrap!important;margin-top:12px!important;}
#hcAgentAlertSettings .hc-alert-actions button{min-height:34px!important;padding:8px 10px!important;border:1px solid #dce4ef!important;border-radius:8px!important;background:#f7f9fc!important;color:#43536a!important;font-size:10px!important;font-weight:700!important;}
#hcAgentAlertSettings .hc-alert-actions button.primary{border-color:#3f5da2!important;background:#3f5da2!important;color:#fff!important;}
#hcAgentAlertSettings .hc-alert-actions button:focus-visible{outline:2px solid #8298df!important;outline-offset:2px!important;}
/* A true separate results screen, independent of the inbox's quick queue filter. */
.layout.hc-search-mode{grid-template-columns:minmax(0,1fr)!important;}
.layout.hc-search-mode .side{display:none!important;}
.layout.hc-search-mode .main{display:flex!important;position:relative!important;inset:auto!important;grid-column:1/-1!important;grid-row:1!important;width:100%!important;height:100%!important;min-width:0!important;min-height:0!important;overflow:hidden!important;}
.layout.hc-search-mode .hc-global-search-page:not([hidden]){display:block!important;flex:1 1 auto!important;width:100%!important;min-width:0!important;height:100%!important;max-height:100%!important;overflow-y:auto!important;overscroll-behavior:contain!important;background:#f5f7fb!important;}
.layout.hc-search-mode .details{display:none!important;}
.hc-global-search-page-head{align-items:center!important;padding-bottom:15px!important;border-bottom:1px solid #e5eaf2!important;}
.hc-global-search-page-head .btn{display:inline-flex!important;align-items:center!important;gap:7px!important;min-height:36px!important;padding:8px 12px!important;border:1px solid #dce4ef!important;border-radius:9px!important;background:#fff!important;color:#4c5d75!important;font-size:11px!important;font-weight:700!important;}
.hc-global-search-page-head .btn:hover{border-color:#c7c8f1!important;background:#f8f7ff!important;color:#5148bd!important;}
.hc-search-results{padding-bottom:20px!important;}
.hc-search-card{min-height:112px!important;}
@media(max-width:760px){
 .layout.hc-search-mode{display:block!important;position:relative!important;height:calc(100dvh - 137px)!important;min-height:0!important;overflow:hidden!important;}
 .layout.hc-search-mode .main{display:flex!important;position:absolute!important;inset:0!important;top:0!important;right:0!important;bottom:0!important;left:0!important;width:100%!important;height:100%!important;min-height:0!important;overflow:hidden!important;}
 .layout.hc-search-mode .hc-global-search-page:not([hidden]){height:100%!important;padding:14px 12px!important;}
 .layout.hc-search-mode .hc-global-search-page-head{flex-direction:column!important;align-items:stretch!important;gap:10px!important;margin-bottom:13px!important;}
 .layout.hc-search-mode .hc-global-search-page-head h1{font-size:20px!important;}
 .layout.hc-search-mode .hc-global-search-page-head .btn{align-self:flex-start!important;}
 .layout.hc-search-mode .hc-search-results{grid-template-columns:minmax(0,1fr)!important;gap:9px!important;}
 .layout.hc-search-mode .hc-search-card{min-height:0!important;padding:12px!important;}
 .hc-agent-alert-control{position:relative!important;}
 #hcAgentAlertSettings{top:calc(100% + 8px)!important;right:-5px!important;width:min(320px,calc(100vw - 18px))!important;}
}

/* Unified support search v2 — independent page state, not an inbox/ticket overlay. */
#layout.hc-search-mode{display:grid!important;grid-template-columns:minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr)!important;position:relative!important;width:100%!important;height:calc(100dvh - 98px)!important;min-height:0!important;max-height:none!important;overflow:hidden!important;background:#f5f7fb!important;}
#layout.hc-search-mode>.side,
#layout.hc-search-mode>.details,
#layout.hc-search-mode>.details-scrim,
#layout.hc-search-mode>.inbox-scrim{display:none!important;}
#layout.hc-search-mode>.main{display:flex!important;position:relative!important;inset:auto!important;grid-column:1!important;grid-row:1!important;width:100%!important;height:100%!important;min-width:0!important;min-height:0!important;max-height:none!important;overflow:hidden!important;background:#f5f7fb!important;}
#layout.hc-search-mode>.main>#hcSearchResultsPage{display:flex!important;flex:1 1 auto!important;flex-direction:column!important;align-items:stretch!important;width:100%!important;height:100%!important;min-width:0!important;min-height:0!important;max-height:none!important;overflow-y:auto!important;overflow-x:hidden!important;overscroll-behavior:contain!important;padding:clamp(18px,3vw,38px)!important;background:#f5f7fb!important;}
#layout.hc-search-mode>.main>#hcSearchResultsPage[hidden]{display:none!important;}
#layout.hc-search-mode>.main>#homeOverview,
#layout.hc-search-mode>.main>#blank,
#layout.hc-search-mode>.main>#workspace{display:none!important;visibility:hidden!important;}
body.hc-agent-search-open>.hc-global-search{display:none!important;}
body.hc-agent-search-open>.details,
body.hc-agent-search-open>.details-scrim,
body.hc-agent-search-open>.inbox-scrim{display:none!important;}
.hc-global-search{margin:0!important;min-width:0!important;}
.hc-global-search #ticketSearch{flex:1 1 auto!important;width:auto!important;min-width:0!important;height:36px!important;padding:0 12px!important;border:1px solid #dce3ee!important;border-radius:9px!important;background:#f9faff!important;color:#25344b!important;font-size:12px!important;}
.hc-global-search #ticketSearch:focus{outline:0!important;border-color:#8a8af2!important;box-shadow:0 0 0 3px rgba(98,92,245,.12)!important;}
.hc-global-search #globalSearchSubmit{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:8px!important;min-width:94px!important;min-height:36px!important;padding:0 14px!important;border:1px solid #5148e8!important;border-radius:9px!important;background:#5148e8!important;color:#fff!important;font-size:11px!important;font-weight:750!important;cursor:pointer!important;}
.hc-global-search #globalSearchSubmit:hover{background:#4038ca!important;border-color:#4038ca!important;color:#fff!important;}
.hc-global-search #globalSearchSubmit:disabled{opacity:.65!important;cursor:wait!important;}
.hc-global-search-page-head{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:16px!important;margin:0 0 18px!important;padding:0 0 17px!important;border-bottom:1px solid #e4e9f2!important;}
.hc-global-search-page-head h1{margin:5px 0 4px!important;color:#1e2c43!important;font-size:clamp(21px,2vw,27px)!important;font-weight:800!important;line-height:1.2!important;letter-spacing:-.025em!important;}
.hc-global-search-page-head p{margin:0!important;color:#738198!important;font-size:11px!important;line-height:1.55!important;}
.hc-global-search-page-head>.btn{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:8px!important;min-height:37px!important;padding:8px 12px!important;border:1px solid #dce3ed!important;border-radius:9px!important;background:#fff!important;color:#4d5d74!important;font-size:11px!important;font-weight:700!important;white-space:nowrap!important;}
.hc-global-search-page-head>.btn:hover{border-color:#bbb9f5!important;background:#f8f7ff!important;color:#4e46c6!important;}
.hc-search-page-form{display:grid!important;gap:8px!important;width:100%!important;max-width:900px!important;margin:0 0 18px!important;padding:16px!important;border:1px solid #e5eaf2!important;border-radius:13px!important;background:#fff!important;box-shadow:0 3px 14px rgba(25,40,67,.035)!important;}
.hc-search-page-form>label{display:block!important;margin:0!important;color:#53627a!important;font-size:10px!important;font-weight:800!important;letter-spacing:.04em!important;}
.hc-search-page-input-wrap{display:flex!important;align-items:center!important;gap:9px!important;min-width:0!important;min-height:43px!important;padding:4px 5px 4px 12px!important;border:1px solid #dfe5ef!important;border-radius:10px!important;background:#f9faff!important;}
.hc-search-page-input-wrap>i{flex:0 0 auto!important;color:#8793aa!important;font-size:13px!important;}
.hc-search-page-input-wrap input{display:block!important;flex:1 1 auto!important;width:100%!important;min-width:0!important;height:34px!important;padding:0 5px!important;border:0!important;outline:0!important;background:transparent!important;box-shadow:none!important;color:#25344b!important;font-size:12px!important;}
.hc-search-page-input-wrap input:focus{border:0!important;outline:0!important;box-shadow:none!important;}
.hc-search-page-input-wrap button{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:7px!important;flex:0 0 auto!important;min-width:92px!important;min-height:34px!important;padding:0 13px!important;border:1px solid #5148e8!important;border-radius:8px!important;background:#5148e8!important;color:#fff!important;font-size:10px!important;font-weight:800!important;cursor:pointer!important;}
.hc-search-page-input-wrap button:hover{background:#4038ca!important;border-color:#4038ca!important;color:#fff!important;}
.hc-search-page-input-wrap button:disabled{opacity:.6!important;cursor:wait!important;}
.hc-search-counts{display:flex!important;flex-wrap:wrap!important;gap:8px!important;margin:0 0 14px!important;}
.hc-search-counts span{display:inline-flex!important;align-items:center!important;gap:7px!important;min-height:29px!important;padding:6px 10px!important;border:1px solid #e2e8f1!important;border-radius:999px!important;background:#fff!important;color:#5e6c82!important;font-size:10px!important;font-weight:750!important;}
.hc-search-results{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;align-content:start!important;gap:11px!important;width:100%!important;padding:0 0 24px!important;}
.hc-search-card,button.hc-search-card{display:flex!important;align-items:flex-start!important;gap:12px!important;width:100%!important;min-width:0!important;min-height:104px!important;margin:0!important;padding:14px!important;border:1px solid #e1e7f0!important;border-radius:12px!important;background:#fff!important;color:#2f3e55!important;text-align:left!important;text-decoration:none!important;font:inherit!important;box-shadow:0 2px 9px rgba(25,40,67,.035)!important;cursor:pointer!important;}
.hc-search-card:hover{transform:translateY(-1px)!important;border-color:#cdd5e8!important;box-shadow:0 7px 18px rgba(25,40,67,.075)!important;}
.hc-search-card:focus-visible{outline:2px solid #8582ef!important;outline-offset:2px!important;}
.hc-search-card-icon{display:grid!important;place-items:center!important;flex:0 0 36px!important;width:36px!important;height:36px!important;border-radius:10px!important;background:#edf2ff!important;color:#5269b0!important;font-size:14px!important;}
.hc-search-card-main{display:block!important;flex:1 1 auto!important;min-width:0!important;}
.hc-search-card-main>header{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:8px!important;}
.hc-search-card-main>header>strong{display:block!important;min-width:0!important;color:#293852!important;font-size:12px!important;font-weight:800!important;line-height:1.4!important;overflow-wrap:anywhere!important;}
.hc-search-card-main>p{margin:6px 0!important;color:#66748a!important;font-size:10px!important;line-height:1.55!important;overflow-wrap:anywhere!important;}
.hc-search-card-main>small{display:block!important;margin-top:3px!important;color:#8793a5!important;font-size:9px!important;line-height:1.5!important;overflow-wrap:anywhere!important;}
.hc-search-card-main>.hc-search-relationship{margin-top:7px!important;padding:6px 8px!important;border-radius:7px!important;background:#f5f7fc!important;color:#5b6680!important;font-weight:700!important;}
.hc-search-kind{display:inline-flex!important;flex:0 0 auto!important;padding:4px 6px!important;border-radius:6px!important;background:#edf1f7!important;color:#66748a!important;font-size:8px!important;font-style:normal!important;font-weight:850!important;text-transform:uppercase!important;}
.hc-search-card--hck{border-color:#d8ece3!important;background:#fff!important;}
.hc-search-card--hck .hc-search-card-icon{background:#e4f6ed!important;color:#21835e!important;}
.hc-search-card--followup{border-color:#f0e1c2!important;background:#fff!important;}
.hc-search-card--followup .hc-search-card-icon{background:#fff1d8!important;color:#9a6c22!important;}
.hc-search-empty{grid-column:1/-1!important;display:grid!important;justify-items:center!important;gap:8px!important;min-height:180px!important;padding:38px 20px!important;border:1px dashed #d9e1ec!important;border-radius:13px!important;background:#fff!important;color:#77859a!important;text-align:center!important;}
.hc-search-empty>i{color:#7772dc!important;font-size:24px!important;}
.hc-search-empty>strong{color:#34445d!important;font-size:13px!important;font-weight:800!important;}
.hc-search-empty>span{color:#7f8ba0!important;font-size:10px!important;line-height:1.5!important;}
@media(max-width:760px){
 #layout.hc-search-mode{display:block!important;height:calc(100dvh - 94px)!important;min-height:0!important;}
 #layout.hc-search-mode>.main{display:flex!important;position:absolute!important;inset:0!important;width:100%!important;height:100%!important;min-height:0!important;overflow:hidden!important;}
 #layout.hc-search-mode>.main>#hcSearchResultsPage{padding:15px 12px 20px!important;}
 .hc-global-search-page-head{align-items:flex-start!important;flex-direction:column!important;gap:12px!important;margin-bottom:13px!important;padding-bottom:13px!important;}
 .hc-global-search-page-head>.btn{align-self:flex-start!important;}
 .hc-search-page-form{padding:12px!important;margin-bottom:13px!important;}
 .hc-search-page-input-wrap{gap:6px!important;padding-left:9px!important;}
 .hc-search-page-input-wrap button{min-width:76px!important;padding:0 9px!important;}
 .hc-search-page-input-wrap button span{display:inline!important;}
 .hc-search-results{grid-template-columns:minmax(0,1fr)!important;gap:8px!important;}
 .hc-search-card,button.hc-search-card{min-height:0!important;padding:11px!important;}
}

</style>

<style id="hc-agent-followup-mobile-layout-v153">
/* v153: correct the actual HelpCenter Agent Workspace responsive layout.
   The follow-up ticket is rendered here, not in the standalone HCK admin shell. */
@media (max-width:1120px), (max-device-width:600px) {
  html,body{width:100%!important;max-width:100%!important;overflow:hidden!important}
  .top{height:56px!important;min-height:56px!important;padding:0 10px!important;gap:7px!important}
  .hc-top-brand>span,.hc-top-nav{display:none!important}
  .agent{gap:6px!important}
  .agent>span:not(.avatar),.agent .btn:not(.availability-control){display:none!important}
  .agent .avatar{width:28px!important;height:28px!important}
  .hc-global-search{height:43px!important;min-height:43px!important;padding:0 10px!important;gap:8px!important}
  .hc-global-search input{width:100%!important;min-width:0!important;flex:1 1 auto!important}
  .layout.ticket-mode{display:block!important;position:relative!important;width:100%!important;max-width:100%!important;height:calc(100dvh - 137px)!important;min-height:0!important;grid-template-columns:minmax(0,1fr)!important;overflow:hidden!important}
  .layout.ticket-mode .side{position:absolute!important;inset:0!important;z-index:5!important;width:100%!important;min-width:0!important;display:flex!important}
  .layout.ticket-mode.open .side{display:none!important}
  .layout.ticket-mode .main{display:none!important;position:absolute!important;inset:0!important;width:100%!important;min-width:0!important;height:100%!important}
  .layout.ticket-mode.open .main{display:flex!important;grid-column:1!important}
  .layout.ticket-mode.inbox-open .side{display:flex!important;position:fixed!important;top:99px!important;bottom:38px!important;left:0!important;right:auto!important;width:min(320px,90vw)!important;z-index:75!important;box-shadow:12px 0 32px rgba(23,36,58,.18)!important}
  .layout.ticket-mode.inbox-open #inboxScrim{display:block!important;position:fixed!important;z-index:69!important;inset:99px 0 38px!important;background:rgba(23,36,58,.35)!important}
  .layout.ticket-mode .chathead{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;min-height:56px!important;padding:7px 9px!important;flex-wrap:wrap!important}
  .layout.ticket-mode .chathead>div:first-child{display:flex!important;align-items:center!important;gap:5px!important;min-width:0!important;flex-wrap:wrap!important}
  .layout.ticket-mode .chathead>div:first-child strong{max-width:46vw!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;font-size:12px!important}
  .layout.ticket-mode .chathead>div:first-child .muted{display:none!important}
  .layout.ticket-mode .chathead>div:last-child{display:flex!important;align-items:center!important;gap:4px!important;flex-wrap:nowrap!important}
  .layout.ticket-mode .chathead .btn{min-height:32px!important;padding:6px 8px!important;font-size:10px!important}
  .layout.ticket-mode .chathead #toggleInbox{display:inline-flex!important}
  .layout.ticket-mode .chatbody{display:flex!important;flex:1 1 auto!important;min-height:0!important;overflow-y:auto!important;overflow-x:hidden!important;padding:12px 9px!important;gap:12px!important}
  .layout.ticket-mode #messages{min-width:0!important;width:100%!important}
  .layout.ticket-mode #messages .msg{max-width:96%!important;gap:8px!important}
  .layout.ticket-mode #messages .msg .msg-text{font-size:13px!important;line-height:1.6!important;overflow-wrap:anywhere!important}
  .layout.ticket-mode .hc-handoff-banner{display:grid!important;grid-template-columns:34px minmax(0,1fr)!important;align-items:start!important;gap:9px!important;margin:9px!important;padding:12px!important;border-radius:12px!important}
  .layout.ticket-mode .hc-handoff-mark{width:32px!important;height:32px!important;grid-row:1!important}
  .layout.ticket-mode .hc-handoff-copy{min-width:0!important}
  .layout.ticket-mode .hc-handoff-copy .eyebrow{font-size:9px!important;letter-spacing:.09em!important}
  .layout.ticket-mode .hc-handoff-copy strong{font-size:13px!important;line-height:1.4!important;overflow-wrap:anywhere!important}
  .layout.ticket-mode .hc-handoff-copy p{font-size:11px!important;line-height:1.55!important}
  .layout.ticket-mode .hc-handoff-meta{grid-column:1/-1!important;display:flex!important;flex-wrap:wrap!important;gap:7px 12px!important;font-size:10px!important}
  .layout.ticket-mode .hc-handoff-brief-panel{margin:8px!important;border-radius:12px!important}
  .layout.ticket-mode .hc-handoff-brief-panel>summary{display:flex!important;align-items:flex-start!important;gap:7px!important;flex-wrap:wrap!important;padding:11px!important}
  .layout.ticket-mode .hc-handoff-brief-panel>summary>span{font-size:12px!important}
  .layout.ticket-mode .hc-handoff-brief-panel>summary>small{margin-left:0!important;font-size:9px!important}
  .layout.ticket-mode .hc-handoff-card{padding:12px!important;gap:11px!important}
  .layout.ticket-mode .hc-handoff-card-head{align-items:flex-start!important;flex-wrap:wrap!important}
  .layout.ticket-mode .hc-handoff-card-head strong{font-size:13px!important}
  .layout.ticket-mode .hc-handoff-card-head small{font-size:10px!important}
  .layout.ticket-mode .hc-handoff-meta-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:7px!important}
  .layout.ticket-mode .hc-handoff-meta-item{min-width:0!important;padding:9px!important}
  .layout.ticket-mode .hc-handoff-meta-item small{font-size:9px!important}
  .layout.ticket-mode .hc-handoff-meta-item strong{font-size:11px!important;line-height:1.45!important;overflow-wrap:anywhere!important}
  .layout.ticket-mode .hc-handoff-section{min-width:0!important;padding:12px!important}
  .layout.ticket-mode .hc-handoff-section h4{font-size:12px!important}
  .layout.ticket-mode .hc-handoff-section p,.layout.ticket-mode .hc-handoff-richtext{font-size:12px!important;line-height:1.65!important}
  .layout.ticket-mode .hc-handoff-grid,.layout.ticket-mode .hc-handoff-analysis-grid{grid-template-columns:minmax(0,1fr)!important}
  .layout.ticket-mode .hc-handoff-stats{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:6px!important}
  .layout.ticket-mode .hc-handoff-stat{padding:8px 5px!important}
  .layout.ticket-mode .hc-handoff-stat strong{font-size:17px!important}
  .layout.ticket-mode .hc-handoff-stat small{font-size:9px!important}
  .layout.ticket-mode .compose{flex:0 0 auto!important;max-height:43dvh!important;overflow-y:auto!important;margin:0 8px 8px!important;padding:9px!important;border-radius:12px!important}
  .layout.ticket-mode .compose textarea{min-height:66px!important;max-height:120px!important;font-size:16px!important;line-height:1.45!important}
  .layout.ticket-mode .compose .hc-compose-toolbar{align-items:flex-start!important;gap:7px!important}
  .layout.ticket-mode .compose .hc-compose-actions{width:100%!important}
  .layout.ticket-mode .compose .hc-quick-replies{max-width:none!important;flex:1 1 auto!important;min-width:0!important}
  .layout.ticket-mode .compose .assist{display:flex!important;flex-wrap:nowrap!important;overflow-x:auto!important}
  .layout.ticket-mode .compose .actions #send{width:100%!important;min-width:0!important}
  .layout.ticket-mode .details{top:99px!important;bottom:38px!important;width:min(430px,calc(100vw - 12px))!important;max-width:100%!important}
  .layout.ticket-mode .details-scrim{inset:99px 0 38px!important}
  .hc-agent-footer{height:38px!important;min-height:38px!important;padding:0 9px!important;font-size:9px!important}
}
@media (max-width:420px), (max-device-width:420px) {
  .layout.ticket-mode .hc-handoff-meta-grid{grid-template-columns:minmax(0,1fr)!important}
  .layout.ticket-mode .hc-handoff-stats{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  .layout.ticket-mode .hc-handoff-brief-panel>summary{align-items:flex-start!important}
  .layout.ticket-mode .hc-handoff-brief-panel>summary>small{width:100%!important}
  .layout.ticket-mode .chathead>div:first-child strong{max-width:38vw!important}
  .layout.ticket-mode .chathead .btn{padding:6px!important}
}
</style>
</head><body><header class="top">'
<div class="hc-top-brand"><a class="agent-home-link" id="agentHomeLink" href="<?php echo esc_url(home_url('/support-agent/')); ?>" title="Support Agent Home"><i class="fa-solid fa-headset"></i><span>Support Agent</span></a><span>HelpCenter Workspace</span></div><nav class="hc-top-nav" aria-label="Agent workspace navigation"><a href="<?php echo esc_url(home_url('/ticket/agent/')); ?>" target="_blank" rel="noopener"><i class="fa-solid fa-ticket"></i> Ticket Page <i class="fa-solid fa-arrow-up-right-from-square"></i></a></nav><div class="agent"><span class="avatar"><?php echo esc_html(mb_strtoupper(mb_substr($u->display_name?:$u->user_login,0,1))); ?></span><span><?php echo esc_html($u->display_name?:$u->user_login); ?></span><span class="hc-connection-state is-checking" id="connectionStatus" role="status" aria-live="polite"><i></i><span>Checking connection…</span><small id="connectionUptime" aria-label="Current local time">--:--:--</small></span><button class="btn availability-control" id="availability" type="button" role="switch" aria-checked="false"><span class="availability-switch-track" aria-hidden="true"><span class="availability-switch-thumb"></span></span><span class="availability-label">Offline</span></button><button class="btn" onclick="location.href='<?php echo esc_js(wp_logout_url(home_url('/support-agent/login/'))); ?>'"><i class="fa-solid fa-right-from-bracket"></i> Sign out</button></div></header><div class="hc-connection-warning" id="connectionWarning" role="alert" hidden></div><form class="hc-global-search" id="hcGlobalSearchForm" role="search"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><input id="ticketSearch" type="search" placeholder="Search customers, emails, conversations and all tickets…" autocomplete="off" aria-label="Search all support records"><button type="submit" id="globalSearchSubmit"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><span>Search</span></button></form><div class="layout home-mode" id="layout"><aside class="side"><div class="side-heading"><div><span class="eyebrow">WORKSPACE</span><h2 id="sideTitle">Workspace</h2><p id="sideSubtitle">Choose a ticket queue</p></div><button class="icon-btn" type="button" id="refreshTickets" aria-label="Refresh tickets" title="Refresh tickets"><i class="fa-solid fa-rotate"></i></button></div><div class="inbox-stats"><div class="inbox-stat"><span class="stat-dot purple"></span><strong id="assignedCount">—</strong><small>Assigned</small></div><div class="inbox-stat"><span class="stat-dot green"></span><strong id="closedCount">—</strong><small>Closed</small></div><div class="inbox-stat"><span class="stat-dot blue"></span><strong id="messageCount">—</strong><small>Messages</small></div></div><div class="tabs"><button class="tab active" data-tab="assigned"><i class="fa-solid fa-inbox"></i> Assigned to Me</button><button class="tab" data-tab="closed"><i class="fa-solid fa-check-double"></i> Closed by Me</button></div><div class="list" id="tickets"><div class="empty">Loading tickets…</div></div></aside><main class="main"><section class="hc-global-search-page" id="hcSearchResultsPage" hidden><header class="hc-global-search-page-head"><div><span class="eyebrow">UNIFIED SUPPORT SEARCH</span><h1>Search support records</h1><p id="hcSearchSubtitle">Search HelpCenter conversations, HCK tickets and follow-ups.</p></div><button type="button" class="btn" id="hcSearchBack"><i class="fa-solid fa-arrow-left"></i> Back to workspace</button></header><form class="hc-search-page-form" id="hcSearchPageForm" role="search"><label for="hcSearchPageInput">Search all support records</label><div class="hc-search-page-input-wrap"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><input id="hcSearchPageInput" type="search" maxlength="120" placeholder="Customer name, email, ticket number or message…" autocomplete="off"><button type="submit" id="hcSearchPageSubmit"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><span>Search</span></button></div></form><div class="hc-search-counts" id="hcSearchCounts"></div><div id="hcSearchResults" class="hc-search-results" role="region" aria-live="polite" aria-label="Search results"><div class="hc-search-empty"><i class="fa-solid fa-magnifying-glass"></i><strong>Search your support history</strong><span>Enter a customer, email, ticket number or message.</span></div></div></section><section class="home-overview" id="homeOverview"><div class="home-welcome"><div><span class="eyebrow">SUPPORT AGENT WORKSPACE</span><h1>My Workspace</h1><p>Review your assigned work and continue customer conversations.</p></div></div><div class="home-metrics"><article><span><i class="fa-solid fa-inbox"></i> Assigned to me</span><strong id="homeAssignedCount">—</strong><small>Active conversations</small></article><article><span><i class="fa-solid fa-circle-check"></i> Closed by me</span><strong id="homeClosedCount">—</strong><small>Completed conversations</small></article><article><span><i class="fa-solid fa-envelope"></i> Unread</span><strong id="homeUnreadCount">—</strong><small>Customer messages waiting</small></article><article><span><i class="fa-solid fa-stopwatch"></i> SLA at risk</span><strong id="homeSlaCount">—</strong><small>Linked HCK tickets only</small></article></div><div class="home-list-head"><div><h2 id="homeQueueTitle">Assigned to Me</h2><p>Choose a ticket to open its conversation.</p></div><span id="homeTicketCount">0 tickets</span></div><div class="home-ticket-list" id="homeTickets"><div class="home-empty">Loading your tickets…</div></div></section><div class="empty hidden" id="blank"><h2>Select a ticket</h2><p>Choose a ticket from your list or search by ticket ID.</p></div><div id="workspace" class="hidden" style="display:flex;flex-direction:column;min-height:0;height:100%"><div class="chathead"><div><button class="btn back" id="back"><i class="fa-solid fa-arrow-left"></i> Home</button> <button class="btn" type="button" id="toggleInbox"><i class="fa-solid fa-inbox"></i> Assigned</button> <strong id="ticketTitle">Ticket</strong> <button class="hc-title-edit" id="editTicketTitle" type="button" hidden title="Edit case title" aria-label="Edit case title"><i class="fa-solid fa-pen"></i></button><div class="muted" id="ticketMeta"></div></div><div><button class="btn hc-followup-top" type="button" id="convertLiveToHck" hidden title="Create follow-up ticket"><i class="fa-solid fa-ticket"></i><span>Create follow-up ticket</span></button> <button class="btn detail-toggle" id="toggleDetails" type="button" aria-expanded="false"><i class="fa-solid fa-circle-info"></i> Details</button> <button class="btn" id="claim" hidden><i class="fa-solid fa-hand"></i> Claim ticket</button> <button class="btn" id="close" hidden><i class="fa-solid fa-check"></i> Resolve</button></div></div><section class="hc-handoff-banner hc-followup-receipt" id="handoffBanner" hidden aria-live="polite" aria-labelledby="handoffTitle">
 <div class="hc-followup-receipt-top"><span class="hc-handoff-mark" aria-hidden="true"><i class="fa-solid fa-check"></i></span><div class="hc-handoff-copy"><span class="eyebrow">SUCCESS · FOLLOW-UP CREATED</span><h2 id="handoffTitle">HCK ticket created</h2><p id="handoffDescription">Your HelpCenter conversation has been transferred successfully.</p></div><span class="hc-followup-success-pill"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> Created</span></div>
 <div class="hc-followup-ticket-reference"><span>NEW HCK TICKET</span><strong id="handoffTicketNumber">—</strong></div>
 <div class="hc-followup-receipt-status" id="handoffMeta"><span><i class="fa-solid fa-envelope" aria-hidden="true"></i><span>Customer email status</span><strong>Not confirmed</strong></span><span><i class="fa-solid fa-paper-plane" aria-hidden="true"></i><span>Follow-up email status</span><strong>Not confirmed</strong></span><span><i class="fa-solid fa-lock" aria-hidden="true"></i><span>Original conversation</span><strong>Read-only</strong></span></div>
 <div class="hc-followup-receipt-footer"><p><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> The original AI and human-support history is preserved. The private handoff brief is visible only to support agents.</p><button type="button" id="handoffContinue" class="hc-followup-continue">Continue in HCK ticket <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></button></div>
</section><details class="hc-handoff-brief-panel" id="hckHandoffBrief" hidden><summary><span><i class="fa-solid fa-clipboard-list"></i> Agent handoff brief</span><small><i class="fa-solid fa-lock"></i> Internal · support agents only</small><i class="fa-solid fa-chevron-down hc-brief-chevron"></i></summary><div class="hc-handoff-brief-body" id="hckHandoffBriefBody"></div></details><div class="chatbody" id="messages"></div><div class="closed hidden" id="closedBanner"></div><div class="compose" id="composer"><div class="hc-compose-toolbar hc-compose-toolbar-legacy"><div class="hc-compose-modes"><button type="button" class="hc-compose-mode active" data-compose-mode="reply"><i class="fa-regular fa-comment"></i> Reply</button><button type="button" class="hc-compose-mode" data-compose-mode="note"><i class="fa-solid fa-lock"></i> Private note</button></div><div class="hc-compose-actions"><select id="quickReplySelect" class="hc-quick-replies" aria-label="Insert a quick reply"><option value="">Quick replies</option><option value="Hello, thank you for contacting us. I’m checking this for you and will update you shortly.">Acknowledgement</option><option value="Thank you for your patience. We are reviewing the details and will share an update as soon as we have confirmation.">Under review</option><option value="Could you please share the relevant order ID or any additional details so I can check this accurately?">Request details</option><option value="I’m glad I could help. Please let us know if you need any further assistance.">Closing</option></select></div></div><textarea id="replyText" placeholder="Write a professional reply…"></textarea><div class="assist"><button class="btn hc-tool-icon" type="button" data-assist="grammar" data-tooltip="Grammar Check" aria-label="Grammar Check" title="Grammar Check"><i class="fa-solid fa-spell-check" aria-hidden="true"></i></button><button class="btn hc-tool-icon" type="button" data-assist="expand" data-tooltip="Expand Professionally" aria-label="Expand Professionally" title="Expand Professionally"><i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i></button><button class="btn hc-tool-icon" type="button" data-assist="context" data-tooltip="Rewrite Using Context" aria-label="Rewrite Using Context" title="Rewrite Using Context"><i class="fa-solid fa-comments" aria-hidden="true"></i></button><button class="btn hc-tool-icon" id="attach" type="button" data-tooltip="Attachment" aria-label="Attachment" title="Attachment"><i class="fa-solid fa-paperclip" aria-hidden="true"></i></button><input type="file" id="file" multiple accept=".jpg,.jpeg,.png,.gif,.webp,.mp4,.webm,.txt,.csv,.pdf,.zip" hidden></div><div id="stagedAttachments" class="staged-attachments" hidden></div><div class="upload-progress" id="uploadProgress" hidden><div class="upload-progress-track"><span id="uploadProgressBar"></span></div><small id="uploadProgressText">Preparing upload…</small></div><div class="actions hc-send-compat"><button class="primary" id="send" type="button" tabindex="-1" aria-hidden="true"><i class="fa-solid fa-paper-plane" aria-hidden="true"></i> Send reply</button></div></div></div></main><div class="details-scrim" id="detailsScrim"></div><div class="inbox-scrim" id="inboxScrim"></div><aside class="details" id="details">
<div class="details-mobile-head"><strong>Customer &amp; ticket context</strong><button type="button" class="icon-btn" id="closeDetails" aria-label="Close details"><i class="fa-solid fa-xmark"></i></button></div>
<div class="hc-context-heading"><div class="hc-customer-avatar" id="contextAvatar">C</div><div class="hc-context-customer"><strong id="contextCustomerName">Select a ticket</strong><small id="contextCustomerEmail">Customer profile</small></div></div>
<nav class="hc-context-icons" id="hcContextIcons" aria-label="Ticket information sections">
<button type="button" class="hc-context-icon active" data-context-view="profile" data-tooltip="Customer & ticket details" aria-label="Customer and ticket details"><i class="fa-solid fa-user-circle"></i></button>
<button type="button" class="hc-context-icon" data-context-view="previous" data-tooltip="Previous tickets" aria-label="Previous tickets"><i class="fa-solid fa-ticket"></i></button>
<button type="button" class="hc-context-icon" data-context-view="ai" data-tooltip="AI summary" aria-label="AI summary"><i class="fa-solid fa-wand-magic-sparkles"></i></button>
<button type="button" class="hc-context-icon" data-context-view="attachments" data-tooltip="Attachments" aria-label="Attachments"><i class="fa-solid fa-paperclip"></i></button>
<button type="button" class="hc-context-icon" data-context-view="history" data-tooltip="History timeline" aria-label="History timeline"><i class="fa-solid fa-clock-rotate-left"></i></button>
<button type="button" class="hc-context-icon" data-context-view="notes" data-tooltip="Internal notes and side conversations" aria-label="Internal notes and side conversations"><i class="fa-solid fa-lock"></i></button>
</nav><div class="hc-context-content" id="hcContextContent">
<section class="hc-live-support-info-card" id="hcLiveSupportInfoCard" aria-label="Live HelpCenter support conversation" hidden><div class="hc-live-support-info-icon"><i class="fa-solid fa-headset" aria-hidden="true"></i></div><div class="hc-live-support-info-copy"><div class="hc-live-support-info-title"><strong>Live support conversation</strong><span><i class="fa-solid fa-circle"></i> Active</span></div><p>This conversation started in HelpCenter. You can respond to the customer, assign or resolve the conversation, and prepare a summary. Create an HCK follow-up ticket when further support is needed.</p></div></section>
<details class="hc-right-section" data-context-section="customer" id="contextPaneCustomer" open><summary><i class="fa-solid fa-user"></i><span>Customer Information</span><i class="fa-solid fa-chevron-down"></i></summary><div class="hc-right-section-body"><div class="detail-row"><span>Name</span><strong id="detailName">—</strong></div><div class="detail-row"><span>Email</span><strong id="detailEmail">—</strong></div><div class="detail-row"><span>Phone</span><strong id="detailPhone">Not available</strong></div><div class="hc-customer-actions"><button class="btn" type="button" id="editCustomerInline"><i class="fa-solid fa-pen"></i> Edit customer</button><button class="btn" type="button" id="composeEmail"><i class="fa-regular fa-envelope"></i> Email</button></div><div id="convertLiveStatus" class="hc-live-info-card" aria-live="polite" hidden></div></div></details>
<details class="hc-right-section" data-context-section="details" id="contextPaneDetails" open><summary><i class="fa-solid fa-clipboard-list"></i><span>Overview</span><i class="fa-solid fa-chevron-down"></i></summary><div class="hc-right-section-body"><div class="hc-ticket-id"><span>Ticket ID</span><strong id="detailId">—</strong></div><div class="hc-ticket-controls"><div class="hc-field"><label class="hc-field-label" for="prioritySelect">Priority</label><select id="prioritySelect" class="hc-context-input"><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></div><div class="hc-field"><label class="hc-field-label" for="ticketStatusSelect">Status</label><select id="ticketStatusSelect" class="hc-context-input"><option value="active">In progress</option><option value="waiting_customer">Waiting on customer</option></select></div><div class="hc-field"><label class="hc-field-label" for="subStatusSelect">Sub status</label><select id="subStatusSelect" class="hc-context-input"><option value="">Not set</option><option>New</option><option>In Progress</option><option>Awaiting Customer</option><option>Awaiting Internal Team</option><option>Resolved</option></select></div><div class="hc-field"><label class="hc-field-label" for="ticketTagsInput">Tags</label><input id="ticketTagsInput" class="hc-context-input" type="text" placeholder="Add tags, separated by commas"></div></div><span id="detailPriority" hidden>—</span><span id="detailStatus" hidden>—</span><span id="detailAssignedTo" hidden>—</span><button class="btn primary hc-save-context" id="saveTicketMeta" type="button" hidden><i class="fa-solid fa-floppy-disk"></i> Save updates</button><div class="detail-title">Assigned agent</div><div class="hc-assignment-owner">Current owner: <strong id="detailAssignedToAdditional">—</strong></div><div class="hc-assignment-picker" id="hcAssignmentPicker"><label class="hc-field-label" for="hcAssignmentPickerToggle">Reassign to</label><button type="button" class="hc-assignment-picker-toggle" id="hcAssignmentPickerToggle" aria-expanded="false"><span id="hcAssignmentPickerValue">Choose an agent or queue…</span><i class="fa-solid fa-chevron-down"></i></button><div class="hc-assignment-picker-panel" id="hcAssignmentPickerPanel" hidden><input id="assignAgentSearch" class="hc-context-input" type="search" placeholder="Search agent name, email or login…" autocomplete="off"><div id="hcAssignmentAgentOptions" class="hc-assignment-agent-options" role="listbox" aria-label="Available agents"></div></div><select id="assignAgent" class="hc-context-input" hidden><option value="0">Unassigned queue</option></select></div><button class="btn hc-save-context" type="button" id="assignTicket"><i class="fa-solid fa-user-check"></i> Reassign ticket</button><div class="detail-title">Original customer concern</div><div class="detail-card hc-issue-box" id="detailIssue">Select a ticket to view its details.</div><div class="detail-title">SLA</div><div class="hc-sla-card" id="agentSlaCard"><strong id="agentSlaLabel">SLA not scheduled</strong><small id="agentSlaDetail">A linked HCK ticket is required for an SLA countdown.</small></div></div></details>
<details class="hc-right-section" data-context-section="previous" id="contextPaneHistory"><summary><i class="fa-solid fa-ticket"></i><span>Previous Tickets</span><i class="fa-solid fa-chevron-down"></i></summary><div class="hc-right-section-body"><div class="detail-card" id="customerHistory"><span class="muted">Customer history will appear here.</span></div></div></details>
<details class="hc-right-section" data-context-section="ai"><summary><i class="fa-solid fa-wand-magic-sparkles"></i><span>AI Summary</span><i class="fa-solid fa-chevron-down"></i></summary><div class="hc-right-section-body"><button class="btn" type="button" id="generateSummary"><i class="fa-solid fa-wand-magic-sparkles"></i> Generate summary</button><div id="summarySide" class="summary-side" aria-live="polite">Generate an internal handover summary when needed.</div></div></details>
<details class="hc-right-section" data-context-section="attachments"><summary><i class="fa-solid fa-paperclip"></i><span>Attachments</span><i class="fa-solid fa-chevron-down"></i></summary><div class="hc-right-section-body"><div class="detail-card" id="detailAttachments"><span class="muted">No attachments</span></div></div></details>
<details class="hc-right-section" data-context-section="history"><summary><i class="fa-solid fa-clock-rotate-left"></i><span>History Timeline</span><i class="fa-solid fa-chevron-down"></i></summary><div class="hc-right-section-body"><div id="ticketActivity" class="hc-activity-list"><div class="muted">Open a ticket to view its history.</div></div></div></details>
<details class="hc-right-section" data-context-section="notes" id="contextPaneNotes"><summary><i class="fa-solid fa-lock"></i><span>Internal Notes &amp; Side Conversations</span><i class="fa-solid fa-chevron-down"></i><span class="hc-note-count" id="privateNoteCount">0</span></summary><div class="hc-right-section-body"><div class="hc-private-panel-head"><strong>Private agent notes</strong><button type="button" class="btn primary" id="openInternalNoteModal"><i class="fa-solid fa-plus"></i> Add note</button></div><p class="hc-private-panel-intro">Visible only to authorized support agents. These notes never appear in the customer transcript.</p><div id="privateNotesList" class="hc-private-notes"><div class="muted">Select a ticket to load internal notes.</div></div><div class="detail-title">Side conversations</div><div class="detail-card"><p class="hc-private-panel-intro">Discuss this ticket privately with another agent.</p><button type="button" class="btn" id="newSideConversation"><i class="fa-solid fa-comments"></i> Start side conversation</button></div><div id="sideConversationList" class="hc-side-list"><div class="muted">No side conversations loaded.</div></div></div></details>
</div>
</aside></div><footer class="hc-agent-footer"><span class="hc-footer-network" id="footerNetwork"><i></i><b>Checking connection</b></span><span id="footerSession">Session 00:00:00</span><span id="footerClock">--:--:--</span></footer><div class="hc-preview-modal" id="attachmentPreview" hidden role="dialog" aria-modal="true" aria-label="Attachment preview"><div class="hc-preview-backdrop" data-preview-close></div><div class="hc-preview-dialog"><div class="hc-preview-head"><strong id="previewTitle">Attachment preview</strong><button type="button" data-preview-close aria-label="Close preview"><i class="fa-solid fa-xmark"></i></button></div><div class="hc-preview-content" id="previewContent"></div><div class="hc-preview-actions" id="previewActions"><a class="btn preview-download-action" id="previewDownload" href="#" download><i class="fa-solid fa-download"></i> Download</a><button type="button" class="btn" data-preview-close><i class="fa-solid fa-xmark"></i> Cancel</button></div></div></div>
<div class="hc-crm-modal" id="hcInternalNoteModal" hidden role="dialog" aria-modal="true" aria-labelledby="hcInternalNoteTitle"><div class="hc-crm-backdrop" data-crm-close></div><div class="hc-crm-dialog"><header><div><small>PRIVATE WORKSPACE</small><h3 id="hcInternalNoteTitle">Internal note</h3></div><button type="button" class="icon-btn" data-crm-close aria-label="Close"><i class="fa-solid fa-xmark"></i></button></header><p>Only authorized support agents can see this note. It will not be sent to the customer.</p><textarea id="hcInternalNoteText" rows="5" placeholder="Record investigation steps, internal decisions or handover context…"></textarea><footer><button type="button" class="btn" data-crm-close>Cancel</button><button type="button" class="primary" id="saveInternalNote">Save private note</button></footer></div></div>
<div class="hc-crm-modal" id="hcSideConversationModal" hidden role="dialog" aria-modal="true" aria-labelledby="hcSideConversationTitle"><div class="hc-crm-backdrop" data-crm-close></div><div class="hc-crm-dialog"><header><div><small>COLLABORATION</small><h3 id="hcSideConversationTitle">Start a side conversation</h3></div><button type="button" class="icon-btn" data-crm-close aria-label="Close"><i class="fa-solid fa-xmark"></i></button></header><p>Discuss this ticket privately with another support agent. The customer cannot see this thread.</p><label for="hcSideRecipient">Send to</label><select id="hcSideRecipient"></select><label for="hcSideSubject">Subject</label><input id="hcSideSubject" type="text" maxlength="180" placeholder="What do you need help with?"><label for="hcSideMessage">Message</label><textarea id="hcSideMessage" rows="5" placeholder="Add context and a clear question…"></textarea><footer><button type="button" class="btn" data-crm-close>Cancel</button><button type="button" class="primary" id="createSideConversation">Start conversation</button></footer></div></div>
<style id="hc-followup-modal-v151">
body.hc-modal-open{overflow:hidden!important}
body>.hc-crm-modal,body>.hc-preview-modal,body>#hcFollowupConfirm{position:fixed!important;inset:0!important;z-index:100050!important;display:grid!important;place-items:center!important;padding:clamp(12px,3vw,28px)!important;overflow-y:auto!important;overscroll-behavior:contain!important;background:rgba(12,22,39,.64)!important;backdrop-filter:blur(7px)!important;-webkit-backdrop-filter:blur(7px)!important}
body>.hc-crm-modal[hidden],body>.hc-preview-modal[hidden],body>#hcFollowupConfirm[hidden]{display:none!important}
body>.hc-crm-modal .hc-crm-backdrop,body>.hc-preview-modal .hc-preview-backdrop{position:absolute!important;inset:0!important;background:transparent!important;backdrop-filter:none!important}
body>.hc-crm-modal .hc-crm-dialog{position:relative!important;z-index:1!important;width:min(620px,100%)!important;max-height:min(90dvh,820px)!important;overflow:auto!important;margin:auto!important;padding:0!important;border:1px solid #e2e8f0!important;border-radius:18px!important;background:#fff!important;box-shadow:0 30px 100px rgba(5,15,32,.34)!important;color:#17243a!important}
.hc-email-dialog .hc-email-head{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:18px!important;padding:24px 26px 20px!important;border-bottom:1px solid #edf0f5!important}
.hc-email-title-wrap{display:flex;align-items:flex-start;gap:14px;min-width:0}.hc-email-icon{width:44px;height:44px;flex:0 0 44px;display:grid;place-items:center;border-radius:13px;background:#edf2ff;color:#4f5fc2;font-size:18px}
.hc-email-head small{display:block;color:#6572bb;font-size:10px;font-weight:850;letter-spacing:.09em}.hc-email-head h3{margin:4px 0 4px!important;color:#1c2940!important;font-size:21px!important;line-height:1.25!important;font-weight:800!important;letter-spacing:-.035em}.hc-email-head p{margin:0!important;color:#748196!important;font-size:12px!important;line-height:1.5!important}
.hc-email-close{width:34px;height:34px;flex:0 0 34px;border:1px solid #e4e9f1;border-radius:10px;background:#fff;color:#68768b;cursor:pointer}.hc-email-close:hover{background:#f5f7fb;color:#26364e}
.hc-email-recipient{display:flex;align-items:center;gap:12px;margin:18px 26px 0;padding:13px 15px;border:1px solid #e6eaf2;border-radius:12px;background:#f8faff;min-width:0}.hc-email-recipient-icon{width:34px;height:34px;flex:0 0 34px;display:grid;place-items:center;border-radius:50%;background:#e8eefb;color:#5264b4}.hc-email-recipient>div{display:flex;flex-direction:column;gap:3px;min-width:0;flex:1}.hc-email-recipient small{font-size:9px;font-weight:850;letter-spacing:.08em;color:#8490a5}.hc-email-recipient strong{font-size:12px;color:#293950;overflow-wrap:anywhere}.hc-email-recipient span:last-child{font-size:10px;color:#7d899c}.hc-email-secure{display:inline-flex;align-items:center;gap:5px!important;white-space:nowrap;color:#4d806a!important;font-size:10px!important;font-weight:700}.hc-email-form-body{padding:20px 26px 22px}.hc-email-field{margin:0 0 19px}.hc-email-field>label,.hc-email-message-label>label{display:block;margin:0 0 7px!important;color:#34445b!important;font-size:12px!important;font-weight:750!important}.hc-email-field label span{margin-left:5px;color:#9aa5b5;font-size:9px;font-weight:650;text-transform:uppercase;letter-spacing:.04em}.hc-email-field input,.hc-email-field textarea{display:block;width:100%!important;box-sizing:border-box!important;border:1px solid #dce3ed!important;border-radius:10px!important;background:#fff!important;color:#24344b!important;padding:11px 13px!important;font:13px/1.5 Inter,system-ui,sans-serif!important;box-shadow:none!important;outline:none!important}.hc-email-field input{height:44px!important}.hc-email-field textarea{min-height:168px!important;resize:vertical!important}.hc-email-field input:focus,.hc-email-field textarea:focus{border-color:#7180d1!important;box-shadow:0 0 0 3px rgba(92,105,197,.12)!important}.hc-email-field-help{display:block;margin-top:6px;color:#8a96a8;font-size:10px;line-height:1.45}.hc-email-message-label{display:flex;align-items:center;justify-content:space-between;gap:10px}.hc-email-message-label>span{color:#8b96a8;font-size:10px;font-variant-numeric:tabular-nums}.hc-email-templates{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:0 0 9px}.hc-email-templates>span{color:#8793a5;font-size:10px;font-weight:700;margin-right:2px}.hc-email-templates button{border:1px solid #e0e5ee;border-radius:7px;background:#fff;color:#64728a;padding:6px 8px;font-size:10px;font-weight:650;cursor:pointer}.hc-email-templates button:hover,.hc-email-templates button.active{border-color:#c8cff2;background:#f1f2ff;color:#4c59b4}.hc-email-delivery-note{display:flex;align-items:flex-start;gap:9px;padding:11px 12px;border:1px solid #e7eaf5;border-radius:9px;background:#f8f9fd;color:#69768b;font-size:10px;line-height:1.5}.hc-email-delivery-note i{margin-top:1px;color:#6472bd}.hc-email-footer{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;padding:15px 26px 18px!important;border-top:1px solid #edf0f5!important;background:#fbfcfe!important}.hc-email-footer>span{display:flex;align-items:center;gap:7px;color:#8a96a7;font-size:10px}.hc-email-footer>span i{color:#7280b8}.hc-email-footer>div{display:flex;align-items:center;gap:8px}.hc-email-cancel,.hc-email-send{min-height:40px;padding:0 14px;border-radius:9px;font-size:11px;font-weight:750;cursor:pointer}.hc-email-cancel{border:1px solid #dce3ed;background:#fff;color:#5e6c81}.hc-email-send{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid #4d5dbd;background:#4d5dbd;color:#fff;box-shadow:0 4px 12px rgba(77,93,189,.18)}.hc-email-send:hover:not(:disabled){background:#3f4fae}.hc-email-send:disabled{opacity:.45;cursor:not-allowed;box-shadow:none}
body>#hcFollowupConfirm{z-index:100060!important}.hc-followup-dialog{position:relative!important;width:min(560px,100%)!important;max-height:min(90dvh,820px)!important;overflow:auto!important;margin:auto!important;border:1px solid #e1e7f0!important;border-radius:20px!important;background:#fff!important;box-shadow:0 30px 100px rgba(5,15,32,.38)!important;color:#17243a!important}.hc-followup-dialog-head{display:flex!important;align-items:flex-start!important;gap:14px!important;padding:24px 25px 19px!important;border-bottom:1px solid #edf0f5!important}.hc-followup-dialog-icon{width:46px!important;height:46px!important;flex:0 0 46px!important;border-radius:14px!important;background:#edf1ff!important;color:#5363bf!important;font-size:18px!important}.hc-followup-eyebrow{display:block;margin:0 0 5px;color:#6875bf;font-size:9px;font-weight:850;letter-spacing:.1em}.hc-followup-dialog h2{font-size:20px!important;letter-spacing:-.03em!important;font-weight:800!important}.hc-followup-dialog-head p{font-size:12px!important}.hc-followup-x{margin-left:auto;width:32px;height:32px;flex:0 0 32px;border:1px solid #e3e8f0;border-radius:9px;background:#fff;color:#6b7789;cursor:pointer}.hc-followup-confirm-details{margin:18px 25px 13px!important;padding:13px 15px!important;border:1px solid #e6eaf2!important;border-radius:11px!important;background:#f8faff!important}.hc-followup-confirm-details small{display:block;margin-bottom:5px;color:#8792a5;font-size:9px;font-weight:850;letter-spacing:.08em}.hc-followup-confirm-details strong{color:#2d3d55!important;font-size:13px!important}.hc-followup-confirm-details p{margin-top:4px!important;font-size:11px!important}.hc-followup-transfer-list{display:grid;gap:0;margin:0 25px 15px;border:1px solid #e8ecf3;border-radius:11px;overflow:hidden}.hc-followup-transfer-list>div{display:flex;align-items:center;gap:11px;padding:10px 12px;border-bottom:1px solid #edf0f5}.hc-followup-transfer-list>div:last-child{border-bottom:0}.hc-followup-transfer-list>div>i:first-child{width:30px;height:30px;display:grid;place-items:center;border-radius:9px;background:#f0f3fb;color:#6371b7}.hc-followup-transfer-list span{display:flex;flex:1;min-width:0;flex-direction:column;gap:2px}.hc-followup-transfer-list strong{font-size:11px;color:#35445b}.hc-followup-transfer-list small{font-size:10px;color:#8994a5}.hc-followup-transfer-list>div>i:last-child{color:#31936d;font-size:12px}.hc-followup-warning{margin:0 25px!important;padding:11px 12px!important;border:1px solid #f0dfb6!important;border-radius:10px!important;background:#fff9ec!important;color:#805d20!important;font-size:10px!important}.hc-followup-warning>i{margin-top:2px}.hc-followup-warning strong{display:block;margin-bottom:2px}.hc-followup-dialog-actions{padding:18px 25px 22px!important}.hc-followup-dialog-actions button{min-height:40px!important;padding:0 15px!important;border-radius:9px!important;font-size:11px!important}.hc-followup-dialog-actions .is-confirm{background:#4d5dbd!important;border-color:#4d5dbd!important;box-shadow:0 4px 12px rgba(77,93,189,.2)!important}
@media(max-width:600px){body>.hc-crm-modal,body>.hc-preview-modal,body>#hcFollowupConfirm{padding:10px!important;align-items:end!important}.hc-email-dialog{max-height:94dvh!important;border-radius:17px 17px 12px 12px!important}.hc-email-dialog .hc-email-head{padding:18px 17px 15px!important}.hc-email-title-wrap{gap:10px}.hc-email-icon{width:38px;height:38px;flex-basis:38px}.hc-email-head h3{font-size:18px!important}.hc-email-head p{font-size:11px!important}.hc-email-recipient{margin:13px 17px 0;padding:10px}.hc-email-form-body{padding:16px 17px 18px}.hc-email-field textarea{min-height:145px!important}.hc-email-templates{gap:5px}.hc-email-templates button{font-size:9px;padding:6px 7px}.hc-email-footer{align-items:stretch!important;flex-direction:column!important;padding:12px 17px 15px!important}.hc-email-footer>span{line-height:1.4}.hc-email-footer>div{display:grid;grid-template-columns:1fr 1.5fr}.hc-email-footer button{min-height:42px}.hc-followup-dialog{border-radius:17px!important}.hc-followup-dialog-head{padding:18px 17px 15px!important;gap:10px!important}.hc-followup-dialog-icon{width:39px!important;height:39px!important;flex-basis:39px!important}.hc-followup-dialog h2{font-size:17px!important}.hc-followup-confirm-details{margin:14px 17px 11px!important}.hc-followup-transfer-list{margin:0 17px 12px}.hc-followup-warning{margin:0 17px!important}.hc-followup-dialog-actions{padding:15px 17px 17px!important}.hc-followup-dialog-actions button{flex:1}.hc-followup-dialog-actions{display:flex;gap:8px}}
@media(prefers-reduced-motion:reduce){body>.hc-crm-modal,body>#hcFollowupConfirm{scroll-behavior:auto!important}}

/* v154: clear follow-up creation receipt, stable action state and aligned modal icons. */
#convertLiveToHck[hidden],.hc-followup-top[hidden]{display:none!important;visibility:hidden!important}
.hc-followup-dialog-head{align-items:center!important}
.hc-followup-dialog-icon{display:grid!important;place-items:center!important;align-self:center!important;box-sizing:border-box!important;padding:0!important;line-height:1!important;overflow:hidden!important}
.hc-followup-dialog-icon>i{display:block!important;margin:0!important;padding:0!important;line-height:1!important;transform:none!important;font-size:18px!important}
.hc-followup-dialog-head>div{min-width:0!important;flex:1 1 auto!important}
.hc-followup-x{display:grid!important;place-items:center!important;align-self:flex-start!important;line-height:1!important;padding:0!important}
.hc-followup-x>i{display:block!important;margin:0!important;line-height:1!important}
.hc-followup-receipt{display:block!important;margin:14px 16px 10px!important;padding:18px!important;border:1px solid #cfe7d9!important;border-radius:17px!important;background:linear-gradient(145deg,#f4fbf7 0%,#fff 68%)!important;box-shadow:0 10px 28px rgba(28,74,54,.075)!important;color:#1f3c32!important}
.hc-followup-receipt[hidden]{display:none!important}
.hc-followup-receipt-top{display:flex;align-items:center;gap:13px;min-width:0}
.hc-followup-receipt .hc-handoff-mark{width:44px;height:44px;flex:0 0 44px;border-radius:13px;background:#d9f3e5;color:#138451;font-size:19px}
.hc-followup-receipt .hc-handoff-copy{flex:1;min-width:0}
.hc-followup-receipt .hc-handoff-copy .eyebrow{font-size:9px;letter-spacing:.1em;color:#168457}
.hc-followup-receipt .hc-handoff-copy h2{margin:0;color:#1e4334;font-size:17px;font-weight:850;line-height:1.3}
.hc-followup-receipt .hc-handoff-copy p{margin:4px 0 0;color:#60786d;font-size:11px;line-height:1.5}
.hc-followup-success-pill{display:inline-flex;align-items:center;gap:6px;flex:0 0 auto;padding:7px 10px;border:1px solid #c8e8d7;border-radius:999px;background:#e8f8ef;color:#16794d;font-size:10px;font-weight:800}
.hc-followup-ticket-reference{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:15px 0 12px;padding:13px 15px;border:1px solid #dcebe2;border-radius:12px;background:#fff}
.hc-followup-ticket-reference span{color:#84958c;font-size:9px;font-weight:850;letter-spacing:.09em}
.hc-followup-ticket-reference strong{color:#263e34;font-size:16px;font-weight:850;letter-spacing:.01em;overflow-wrap:anywhere;text-align:right}
.hc-followup-receipt-status{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.hc-followup-receipt-status>span{display:grid;grid-template-columns:18px minmax(0,1fr);align-items:center;column-gap:7px;row-gap:3px;min-width:0;padding:10px;border:1px solid #e5eee8;border-radius:10px;background:rgba(255,255,255,.82)}
.hc-followup-receipt-status>span>i{grid-row:1/3;color:#658575;font-size:12px;text-align:center}
.hc-followup-receipt-status>span>span{min-width:0;color:#718279;font-size:9px;line-height:1.35}
.hc-followup-receipt-status>span>strong{color:#a66a28;font-size:10px;font-weight:800;line-height:1.35}
.hc-followup-receipt-status>span>strong.is-accepted{color:#16804f}
.hc-followup-receipt-footer{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:13px;padding-top:12px;border-top:1px solid #e5eee8}
.hc-followup-receipt-footer p{display:flex;align-items:flex-start;gap:7px;min-width:0;margin:0;color:#66796f;font-size:10px;line-height:1.5}
.hc-followup-receipt-footer p i{flex:0 0 auto;margin-top:1px;color:#5d8c73}
.hc-followup-continue{display:inline-flex;align-items:center;justify-content:center;gap:9px;flex:0 0 auto;min-height:38px;padding:0 13px;border:1px solid #168052;border-radius:9px;background:#168052;color:#fff;font-size:10px;font-weight:800;cursor:pointer;box-shadow:0 4px 10px rgba(22,128,82,.14)}
.hc-followup-continue:hover{background:#116b44}
.hc-followup-continue:focus-visible{outline:3px solid rgba(22,128,82,.24);outline-offset:2px}
.hc-followup-open-warning{grid-column:1/-1;margin:4px 0 0!important;padding:8px 10px;border-radius:8px;background:#fff7e8;color:#805b1d;font-size:10px;line-height:1.45}
.hc-followup-created .hc-followup-top[hidden],.hc-followup-created #convertLiveToHck[hidden]{display:none!important}
@media(max-width:760px){.hc-followup-receipt{margin:9px!important;padding:13px!important;border-radius:14px!important}.hc-followup-receipt-top{gap:9px;align-items:flex-start}.hc-followup-receipt .hc-handoff-mark{width:36px;height:36px;flex-basis:36px;font-size:16px}.hc-followup-receipt .hc-handoff-copy h2{font-size:14px}.hc-followup-receipt .hc-handoff-copy p{font-size:10px}.hc-followup-success-pill{padding:6px 8px;font-size:9px}.hc-followup-ticket-reference{margin:11px 0 9px;padding:10px 11px}.hc-followup-ticket-reference strong{font-size:14px}.hc-followup-receipt-status{grid-template-columns:1fr;gap:6px}.hc-followup-receipt-status>span{grid-template-columns:18px minmax(0,1fr) auto;align-items:center;padding:8px 9px}.hc-followup-receipt-status>span>i{grid-row:auto}.hc-followup-receipt-status>span>strong{grid-column:3;grid-row:1}.hc-followup-receipt-footer{align-items:stretch;flex-direction:column;gap:10px}.hc-followup-receipt-footer p{font-size:10px}.hc-followup-continue{width:100%;min-height:42px}.hc-followup-dialog-head{align-items:center!important}.hc-followup-dialog-icon{width:39px!important;height:39px!important;flex-basis:39px!important}}


/* v155: follow-up receipt visibility and responsive layout correction.
   The legacy mobile selector applied display:grid to the banner itself, which
   overrode the HTML hidden state and placed each child in a narrow grid cell. */
#handoffBanner[hidden],
.layout.ticket-mode #handoffBanner[hidden],
.layout #handoffBanner[hidden]{display:none!important;visibility:hidden!important;pointer-events:none!important}
#handoffBanner:not([hidden]),
.layout.ticket-mode #handoffBanner:not([hidden]){display:block!important;visibility:visible!important}
#handoffBanner.hc-followup-receipt{box-sizing:border-box!important;width:auto!important;max-width:100%!important;min-width:0!important;grid-template-columns:none!important;grid-auto-flow:row!important;align-items:stretch!important;}
#handoffBanner .hc-followup-receipt-top{display:flex!important;flex-direction:row!important;align-items:center!important;justify-content:flex-start!important;gap:14px!important;width:100%!important;min-width:0!important}
#handoffBanner .hc-followup-copy{flex:1 1 auto!important;min-width:0!important}
#handoffBanner .hc-followup-ticket-reference{display:flex!important;flex-direction:row!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;width:100%!important;min-width:0!important;box-sizing:border-box!important}
#handoffBanner .hc-followup-receipt-status{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:9px!important;width:100%!important;min-width:0!important}
#handoffBanner .hc-followup-receipt-status>span{min-width:0!important;box-sizing:border-box!important}
#handoffBanner .hc-followup-receipt-footer{display:flex!important;flex-direction:row!important;align-items:center!important;justify-content:space-between!important;gap:14px!important;width:100%!important;min-width:0!important}
#handoffBanner .hc-followup-continue{flex:0 0 auto!important;white-space:normal!important}
@media(max-width:760px){
 #handoffBanner:not([hidden]),.layout.ticket-mode #handoffBanner:not([hidden]){display:block!important}
 #handoffBanner.hc-followup-receipt{margin:9px!important;padding:13px!important;width:auto!important;max-width:calc(100% - 18px)!important}
 #handoffBanner .hc-followup-receipt-top{display:grid!important;grid-template-columns:36px minmax(0,1fr)!important;grid-template-areas:"mark copy" "pill pill"!important;align-items:start!important;gap:9px!important}
 #handoffBanner .hc-handoff-mark{grid-area:mark!important}
 #handoffBanner .hc-followup-copy{grid-area:copy!important}
 #handoffBanner .hc-followup-success-pill{grid-area:pill!important;justify-self:start!important;margin-left:45px!important}
 #handoffBanner .hc-followup-ticket-reference{display:flex!important;flex-direction:column!important;align-items:flex-start!important;gap:5px!important;padding:10px 11px!important}
 #handoffBanner .hc-followup-ticket-reference strong{text-align:left!important;overflow-wrap:anywhere!important;word-break:normal!important;font-size:14px!important}
 #handoffBanner .hc-followup-receipt-status{grid-template-columns:minmax(0,1fr)!important;gap:6px!important}
 #handoffBanner .hc-followup-receipt-status>span{display:grid!important;grid-template-columns:18px minmax(0,1fr) auto!important;align-items:center!important;column-gap:8px!important}
 #handoffBanner .hc-followup-receipt-status>span>i{grid-row:auto!important}
 #handoffBanner .hc-followup-receipt-status>span>strong{grid-column:3!important;grid-row:1!important;white-space:nowrap!important}
 #handoffBanner .hc-followup-receipt-footer{display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:10px!important}
 #handoffBanner .hc-followup-continue{width:100%!important;min-height:42px!important}
}

</style>
<style id="hc-agent-header-title-modal-v156">
/* Ticket header: keep all primary actions visible at narrow viewport widths. */
.layout.ticket-mode .chathead{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;min-width:0!important;max-width:100%!important;box-sizing:border-box!important;}
.layout.ticket-mode .chathead>div:first-child{display:flex!important;align-items:center!important;flex-wrap:wrap!important;gap:7px!important;min-width:0!important;flex:1 1 0!important;}
.layout.ticket-mode .chathead>div:last-child{display:flex!important;align-items:center!important;justify-content:flex-end!important;flex:0 1 auto!important;flex-wrap:wrap!important;gap:7px!important;min-width:0!important;}
.layout.ticket-mode .chathead .btn[hidden],.layout.ticket-mode .chathead [hidden]{display:none!important;}
.layout.ticket-mode .chathead .btn{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:7px!important;min-height:36px!important;height:auto!important;max-width:100%!important;padding:8px 11px!important;border:1px solid #dce4ef!important;border-radius:9px!important;background:#fff!important;color:#40516a!important;font-size:11px!important;font-weight:750!important;line-height:1.2!important;white-space:nowrap!important;box-shadow:0 1px 2px rgba(20,35,60,.04)!important;}
.layout.ticket-mode .chathead .btn>i{display:inline-block!important;flex:0 0 auto!important;font-size:12px!important;line-height:1!important;}
.layout.ticket-mode .chathead .btn:hover{border-color:#bfcdf0!important;background:#f7f8ff!important;color:#4c49bd!important;}
.layout.ticket-mode .chathead .btn:focus-visible,.layout.ticket-mode .hc-title-edit:focus-visible{outline:3px solid rgba(86,99,220,.22)!important;outline-offset:2px!important;}
.layout.ticket-mode .chathead #toggleInbox{width:38px!important;min-width:38px!important;height:36px!important;padding:0!important;background:#f5f7fc!important;border-color:#e0e6f0!important;color:#53627c!important;}
.layout.ticket-mode .chathead #toggleInbox i{font-size:14px!important;}
.layout.ticket-mode .chathead #back{background:#f7f8fc!important;}
.layout.ticket-mode .chathead #close{background:#eaf7f0!important;border-color:#ccebd9!important;color:#16784c!important;}
.layout.ticket-mode .chathead #close:hover{background:#dcf3e6!important;border-color:#aee0c3!important;color:#11643e!important;}
.layout.ticket-mode .chathead #convertLiveToHck{background:#f0efff!important;border-color:#dcd9ff!important;color:#5148ba!important;}
.layout.ticket-mode .chathead #claim{background:#eef6ff!important;border-color:#d6e8fb!important;color:#28649c!important;}
.layout.ticket-mode .chathead #ticketTitle{min-width:0!important;max-width:min(34vw,420px)!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;color:#26364b!important;font-size:13px!important;font-weight:800!important;}
.layout.ticket-mode .hc-title-edit{display:inline-grid!important;place-items:center!important;flex:0 0 34px!important;width:34px!important;min-width:34px!important;height:34px!important;margin:0!important;padding:0!important;border:1px solid #d9e1f0!important;border-radius:9px!important;background:linear-gradient(180deg,#fff,#f5f7fc)!important;color:#5967c5!important;box-shadow:0 2px 6px rgba(40,54,100,.08)!important;cursor:pointer!important;vertical-align:middle!important;}
.layout.ticket-mode .hc-title-edit>i{display:block!important;margin:0!important;font-size:13px!important;line-height:1!important;}
.layout.ticket-mode .hc-title-edit:hover{background:#eeefff!important;border-color:#bfc5f5!important;color:#403da8!important;transform:translateY(-1px);}
.layout.ticket-mode .chathead #ticketMeta{flex:1 0 100%!important;min-width:0!important;margin:0 0 0 2px!important;font-size:10px!important;line-height:1.35!important;}
/* Native title prompt replacement. */
body.hc-title-modal-open{overflow:hidden!important;}
body>.hc-title-modal{position:fixed!important;inset:0!important;z-index:100090!important;display:grid!important;place-items:center!important;padding:18px!important;overflow-y:auto!important;background:rgba(12,22,39,.62)!important;backdrop-filter:blur(7px)!important;-webkit-backdrop-filter:blur(7px)!important;}
body>.hc-title-modal[hidden]{display:none!important;}
.hc-title-modal-backdrop{position:absolute!important;inset:0!important;}
.hc-title-modal-dialog{position:relative!important;z-index:1!important;width:min(480px,100%)!important;margin:auto!important;padding:0!important;overflow:hidden!important;border:1px solid #e2e7f1!important;border-radius:18px!important;background:#fff!important;box-shadow:0 28px 90px rgba(12,22,39,.28)!important;color:#26364b!important;}
.hc-title-modal-head{display:flex!important;align-items:center!important;gap:12px!important;padding:20px 21px 17px!important;border-bottom:1px solid #edf0f5!important;}
.hc-title-modal-icon{display:grid!important;place-items:center!important;flex:0 0 42px!important;width:42px!important;height:42px!important;border:1px solid #e1e3ff!important;border-radius:13px!important;background:#f0efff!important;color:#5954c7!important;font-size:17px!important;}
.hc-title-modal-head>div{min-width:0!important;flex:1!important;}
.hc-title-modal-head small{display:block!important;margin:0 0 4px!important;color:#7771c8!important;font-size:9px!important;font-weight:850!important;letter-spacing:.12em!important;}
.hc-title-modal-head h3{margin:0!important;color:#24344a!important;font-size:17px!important;font-weight:850!important;line-height:1.3!important;}
.hc-title-modal-head p{margin:4px 0 0!important;color:#77849a!important;font-size:11px!important;line-height:1.5!important;}
.hc-title-modal-x{display:grid!important;place-items:center!important;flex:0 0 32px!important;width:32px!important;height:32px!important;padding:0!important;border:1px solid #e5e9f1!important;border-radius:9px!important;background:#fff!important;color:#748096!important;cursor:pointer!important;}
.hc-title-modal-x i{font-size:13px!important;line-height:1!important;}
.hc-title-modal-body{padding:19px 21px 17px!important;}
.hc-title-modal-body label{display:block!important;margin:0 0 7px!important;color:#526178!important;font-size:11px!important;font-weight:800!important;}
.hc-title-modal-body input{display:block!important;width:100%!important;height:44px!important;box-sizing:border-box!important;padding:0 12px!important;border:1px solid #dce3ef!important;border-radius:10px!important;background:#fbfcff!important;color:#25364c!important;font-family:inherit!important;font-size:13px!important;font-weight:600!important;line-height:1.2!important;outline:none!important;}
.hc-title-modal-body input:focus{border-color:#8f8be4!important;box-shadow:0 0 0 4px rgba(94,88,202,.12)!important;background:#fff!important;}
.hc-title-modal-meta{display:flex!important;justify-content:space-between!important;gap:10px!important;margin-top:7px!important;color:#8a95a7!important;font-size:9px!important;}
.hc-title-modal-error{margin:11px 0 0!important;padding:9px 10px!important;border:1px solid #f4d0d0!important;border-radius:8px!important;background:#fff5f5!important;color:#ad3d45!important;font-size:11px!important;line-height:1.45!important;}
.hc-title-modal-error[hidden]{display:none!important;}
.hc-title-modal-actions{display:flex!important;justify-content:flex-end!important;gap:8px!important;padding:14px 21px 18px!important;border-top:1px solid #edf0f5!important;background:#fbfcfe!important;}
.hc-title-modal-actions button{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:7px!important;min-width:104px!important;min-height:38px!important;margin:0!important;padding:8px 13px!important;border:1px solid #dfe5ef!important;border-radius:9px!important;background:#fff!important;color:#536178!important;font-size:11px!important;font-weight:800!important;cursor:pointer!important;}
.hc-title-modal-actions .hc-title-save{border-color:#554fc1!important;background:#554fc1!important;color:#fff!important;}
.hc-title-modal-actions button:disabled{opacity:.65!important;cursor:wait!important;}
@media(max-width:760px){
 .layout.ticket-mode .chathead{display:flex!important;flex-direction:column!important;align-items:stretch!important;justify-content:flex-start!important;gap:8px!important;min-height:0!important;height:auto!important;max-height:none!important;padding:9px 10px!important;overflow:visible!important;}
 .layout.ticket-mode .chathead>div:first-child{display:flex!important;align-items:center!important;justify-content:flex-start!important;flex:0 0 auto!important;flex-wrap:wrap!important;width:100%!important;gap:6px!important;min-width:0!important;}
 .layout.ticket-mode .chathead>div:last-child{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;align-items:stretch!important;justify-content:stretch!important;flex:0 0 auto!important;width:100%!important;gap:6px!important;}
 .layout.ticket-mode .chathead>div:last-child .btn{width:100%!important;min-width:0!important;min-height:36px!important;padding:8px 7px!important;font-size:10px!important;white-space:normal!important;text-align:center!important;}
 .layout.ticket-mode .chathead #convertLiveToHck{grid-column:1/-1!important;}
 .layout.ticket-mode .chathead #ticketTitle{flex:1 1 100px!important;max-width:none!important;min-width:0!important;font-size:12px!important;white-space:normal!important;display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;overflow:hidden!important;overflow-wrap:anywhere!important;line-height:1.25!important;}
 .layout.ticket-mode .chathead #ticketMeta{flex:1 0 100%!important;}
 .layout.ticket-mode .chathead #toggleInbox{width:36px!important;min-width:36px!important;height:34px!important;}
 .layout.ticket-mode .chathead #back{min-height:34px!important;padding:7px 9px!important;}
 .layout.ticket-mode .hc-title-edit{width:34px!important;height:34px!important;flex-basis:34px!important;}
 .hc-title-modal-head{padding:17px 16px 14px!important;}
 .hc-title-modal-body{padding:16px!important;}
 .hc-title-modal-actions{padding:12px 16px 15px!important;}
}
@media(max-width:360px){.layout.ticket-mode .chathead>div:last-child{grid-template-columns:minmax(0,1fr)!important}.layout.ticket-mode .chathead #convertLiveToHck{grid-column:auto!important}}
</style>
<div class="hc-title-modal" id="hcTitleEditModal" hidden role="dialog" aria-modal="true" aria-labelledby="hcTitleEditHeading" aria-describedby="hcTitleEditHelp"><div class="hc-title-modal-backdrop" data-title-modal-close></div><form class="hc-title-modal-dialog" id="hcTitleEditForm"><header class="hc-title-modal-head"><span class="hc-title-modal-icon"><i class="fa-solid fa-pen-to-square" aria-hidden="true"></i></span><div><small>CASE DETAILS</small><h3 id="hcTitleEditHeading">Edit ticket title</h3><p id="hcTitleEditHelp">Use a short, clear title that describes the customer's concern.</p></div><button type="button" class="hc-title-modal-x" data-title-modal-close aria-label="Close"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button></header><div class="hc-title-modal-body"><label for="hcTitleEditInput">Ticket title</label><input id="hcTitleEditInput" name="title" type="text" maxlength="180" autocomplete="off" required><div class="hc-title-modal-meta"><span>Keep the title under 180 characters.</span><span id="hcTitleEditCount">0 / 180</span></div><p class="hc-title-modal-error" id="hcTitleEditError" role="alert" hidden></p></div><footer class="hc-title-modal-actions"><button type="button" class="hc-title-cancel" data-title-modal-close>Cancel</button><button type="submit" class="hc-title-save" id="hcTitleEditSave"><i class="fa-solid fa-check" aria-hidden="true"></i> Save title</button></footer></form></div>
<div class="hc-crm-modal hc-email-modal" id="hcEmailModal" hidden role="dialog" aria-modal="true" aria-labelledby="hcEmailTitle" aria-describedby="hcEmailHelp">
  <div class="hc-crm-backdrop" data-crm-close></div>
  <section class="hc-crm-dialog hc-email-dialog" role="document">
    <header class="hc-email-head"><div class="hc-email-title-wrap"><span class="hc-email-icon"><i class="fa-regular fa-paper-plane"></i></span><div><small>CUSTOMER COMMUNICATION · FOLLOW-UP</small><h3 id="hcEmailTitle">Send a follow-up email</h3><p id="hcEmailHelp">Send a direct update to the customer without changing the ticket status.</p></div></div><button type="button" class="hc-email-close" data-crm-close aria-label="Close"><i class="fa-solid fa-xmark"></i></button></header>
    <div class="hc-email-recipient"><span class="hc-email-recipient-icon"><i class="fa-regular fa-user"></i></span><div><small>RECIPIENT</small><strong id="hcEmailRecipient">Customer email address</strong><span id="hcEmailTicketContext">Current support conversation</span></div><span class="hc-email-secure"><i class="fa-solid fa-lock"></i> Private</span></div>
    <div class="hc-email-form-body">
      <div class="hc-email-field"><label for="hcEmailSubject">Subject <span>Required</span></label><input id="hcEmailSubject" type="text" maxlength="180" placeholder="Add a clear email subject" autocomplete="off"><small class="hc-email-field-help">Keep the subject specific to the customer's request.</small></div>
      <div class="hc-email-field"><div class="hc-email-message-label"><label for="hcEmailMessage">Message <span>Required</span></label><span id="hcEmailMessageCount">0 / 5,000</span></div><div class="hc-email-templates" aria-label="Insert a message template"><span>Start with</span><button type="button" data-email-template="acknowledgement">Acknowledgement</button><button type="button" data-email-template="progress">Progress update</button><button type="button" data-email-template="details">Request details</button><button type="button" data-email-template="checkin">Resolution check-in</button></div><textarea id="hcEmailMessage" rows="8" maxlength="5000" placeholder="Write a clear, helpful update for the customer…"></textarea><small class="hc-email-field-help">A professional greeting and your agent signature will be added automatically.</small></div>
      <div class="hc-email-delivery-note"><i class="fa-solid fa-circle-info"></i><span>This is a separate follow-up email. A record is added to the internal conversation history; the customer will not see it as a chat reply.</span></div>
    </div>
    <footer class="hc-email-footer"><span><i class="fa-solid fa-shield-halved"></i> Review the recipient and message before sending.</span><div><button type="button" class="hc-email-cancel" data-crm-close>Cancel</button><button type="button" class="hc-email-send" id="sendCustomerEmail"><i class="fa-regular fa-paper-plane"></i><span>Send follow-up email</span></button></div></footer>
  </section>
</div>
<div class="hc-crm-modal" id="hcCustomerModal" hidden role="dialog" aria-modal="true" aria-labelledby="hcCustomerTitle"><div class="hc-crm-backdrop" data-crm-close></div><div class="hc-crm-dialog"><header><div><small>CUSTOMER PROFILE</small><h3 id="hcCustomerTitle">Update customer details</h3></div><button type="button" class="icon-btn" data-crm-close aria-label="Close"><i class="fa-solid fa-xmark"></i></button></header><p>These changes apply to this HelpCenter conversation record only. They do not change the customer's WordPress login.</p><label for="hcCustomerName">Customer name</label><input id="hcCustomerName" type="text" maxlength="190"><label for="hcCustomerEmail">Customer email</label><input id="hcCustomerEmail" type="email" maxlength="190"><footer><button type="button" class="btn" data-crm-close>Cancel</button><button type="button" class="primary" id="saveCustomerDetails">Save customer</button></footer></div></div>
<div class="hc-crm-modal" id="hcSideThreadModal" hidden role="dialog" aria-modal="true" aria-labelledby="hcSideThreadTitle"><div class="hc-crm-backdrop" data-crm-close></div><div class="hc-crm-dialog hc-side-thread-dialog"><header><div><small>PRIVATE AGENT THREAD</small><h3 id="hcSideThreadTitle">Side conversation</h3></div><button type="button" class="icon-btn" data-crm-close aria-label="Close"><i class="fa-solid fa-xmark"></i></button></header><div id="hcSideThreadMessages" class="hc-side-thread-messages"></div><label for="hcSideThreadReply">Reply privately</label><textarea id="hcSideThreadReply" rows="3" placeholder="Write a private message to the other agent…"></textarea><footer><button type="button" class="btn" data-crm-close>Close</button><button type="button" class="primary" id="sendSideThreadReply">Send private reply</button></footer></div></div>
        <script data-cfasync="false" src="https://cdn.ably.com/lib/ably.min-2.js"></script><script data-cfasync="false" src="<?php echo esc_url(HC_ASSETS . 'js/hc-realtime-client.js?v=' . (file_exists(HC_PATH . 'assets/js/hc-realtime-client.js') ? filemtime(HC_PATH . 'assets/js/hc-realtime-client.js') : HC_VERSION)); ?>"></script><script data-cfasync="false">const HCAG={ajax:<?php echo wp_json_encode($ajax); ?>,nonce:<?php echo wp_json_encode($nonce); ?>,hckNonce:<?php echo wp_json_encode($hck_nonce); ?>,agentName:<?php echo wp_json_encode($u->display_name?:$u->user_login); ?>,maxFiles:<?php echo (int)max(1,min(3,absint(HC_Core::get_setting('hc_ai_support_max_files_per_message','3')))); ?>,currentUserId:<?php echo (int)get_current_user_id(); ?>,initialAvailable:<?php echo $initial_available?'true':'false'; ?>,alertsEnabled:<?php echo HC_Core::get_setting('hc_ai_support_notifications_enabled','1')==='1'?'true':'false'; ?>,browserAlertsEnabled:<?php echo HC_Core::get_setting('hc_ai_support_browser_notifications','1')==='1'?'true':'false'; ?>,alertSound:<?php echo wp_json_encode(HC_Core::get_setting('hc_ai_support_alert_sound','urgent')); ?>,alertVolume:<?php echo (float)max(0.2,min(1,(float)HC_Core::get_setting('hc_ai_support_alert_volume','0.9'))); ?>};</script><script data-cfasync="false">
        (()=>{
 const $=s=>document.querySelector(s),layout=$('#layout');
 function setContextView(view){let map={profile:['customer','details'],previous:['previous'],ai:['ai'],attachments:['attachments'],history:['history'],notes:['notes']};document.querySelectorAll('#hcContextIcons [data-context-view]').forEach(b=>b.classList.toggle('active',b.dataset.contextView===view));document.querySelectorAll('#hcContextContent .hc-right-section').forEach(sec=>{let key=sec.dataset.contextSection;sec.hidden=!(map[view]||map.profile).includes(key);if(!sec.hidden)sec.open=true;});let box=$('#hcContextContent');if(box)box.scrollTop=0;}
 document.querySelectorAll('#hcContextIcons [data-context-view]').forEach(b=>b.addEventListener('click',()=>setContextView(b.dataset.contextView)));setContextView('profile');
 ['prioritySelect','ticketStatusSelect','subStatusSelect','ticketTagsInput'].forEach(id=>$('#'+id)?.addEventListener('change',()=>{if(active||activeHck)$('#saveTicketMeta')?.click();}));
 $('#agentHomeLink')?.addEventListener('click',e=>{e.preventDefault();goHome();});
 let tab='assigned',homeTab='assigned',active=0,activeLive=0,activeHck=0,activeHckOriginConverted=false,hckPreviousTimer=null,liveConversationTimer=null,liveConversationBusy=false,after=0,aiAfter=0,tickets=[],available=!!HCAG.initialAvailable,listLoaded=false,pollBusy=false,requestSeq=0,listRequestSeq=0,listInteractiveBusy=false,known=new Set(),poller=null,assignmentAgents=[];
 window.HCAgentPushGetActiveTicket=function(){return Number(active||activeLive||0)||0;};
 let hckRealtimeConnection=null,hckRealtimeConnectPromise=null,hckRealtimeGeneration=0,hckRealtimeTicketId=0,hckRealtimeConnected=false,hckRealtimePending=0,hckMessagePollBusy=false,hckMessagePollTimer=null,hckAfterId=0;
 const post=async(action,data={})=>{let f=new FormData();f.append('action',action);f.append('nonce',HCAG.nonce);Object.entries(data).forEach(([k,v])=>f.append(k,v));let ctl=window.AbortController?new AbortController():null,timeoutMs=/(?:summary)/.test(action)?120000:/(?:send|reply)/.test(action)?60000:45000,timedOut=false,timer=ctl?setTimeout(()=>{timedOut=true;ctl.abort()},timeoutMs):null;try{let r=await fetch(HCAG.ajax,{method:'POST',body:f,credentials:'same-origin',cache:'no-store',keepalive:action==='hc_agent_reply',signal:ctl?ctl.signal:undefined});let raw=await r.text(),json;try{json=JSON.parse(raw)}catch(e){json=null}if(!r.ok)throw new Error((json&&json.data&&json.data.message)||('Support server returned HTTP '+r.status+(raw?' · '+raw.slice(0,160).replace(/\s+/g,' '):'')));if(!json)throw new Error('Support server returned an invalid response.');return json}catch(e){if(e&&e.name==='AbortError'&&timedOut){let x=new Error('The support server took too long to respond. Check the conversation before retrying so the same reply is not sent twice.');x.code='HC_REQUEST_TIMEOUT';throw x}throw e}finally{if(timer)clearTimeout(timer)}};
 const postHck=async(action,data={})=>{let f=new FormData();f.append('action',action);f.append('nonce',HCAG.hckNonce||'');Object.entries(data).forEach(([k,v])=>f.append(k,v));let r=await fetch(HCAG.ajax,{method:'POST',body:f,credentials:'same-origin',cache:'no-store'});let j=await r.json();if(!r.ok||!j)throw new Error(j?.data?.message||'HCK request failed.');return j;};
 let agentSlaTimer=null;function paintAgentSla(sla){sla=sla||{};let label=$('#agentSlaLabel'),detail=$('#agentSlaDetail'),card=$('#agentSlaCard');if(agentSlaTimer)clearInterval(agentSlaTimer);if(card)card.classList.toggle('is-overdue',!!sla.overdue);if(sla.completed){if(label)label.textContent='SLA completed';if(detail)detail.textContent=sla.detail||'Ticket has been resolved or closed.';return;}if(!sla.due_at){if(label)label.textContent=sla.label||'SLA not scheduled';if(detail)detail.textContent=sla.detail||'No SLA deadline is recorded.';return;}let dueText=String(sla.due_at),remaining=Number(sla.remaining_seconds);if(!Number.isFinite(remaining)){if(label)label.textContent=sla.label||'SLA deadline recorded';if(detail)detail.textContent=sla.detail||dueText;return;}let deadline=Date.now()+remaining*1000;function tick(){let delta=Math.floor((deadline-Date.now())/1000),abs=Math.abs(delta),days=Math.floor(abs/86400),hours=Math.floor(abs%86400/3600),mins=Math.floor(abs%3600/60),secs=abs%60,clock=(days?days+'d ':'')+String(hours).padStart(2,'0')+':'+String(mins).padStart(2,'0')+':'+String(secs).padStart(2,'0');if(label)label.textContent=delta<0?'Overdue by '+clock:'Due in '+clock;if(detail)detail.textContent=(sla.detail||'SLA deadline')+' · '+dueText+' (site time)';if(card)card.classList.toggle('is-overdue',delta<0);}tick();agentSlaTimer=setInterval(tick,1000);}
 const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const renderMarkdown=s=>{
  // Small, safe Markdown renderer for AI summaries and AI timeline messages.
  // Escape untrusted model output before adding only the formatting tags below.
  let source=String(s||'').replace(/\r\n?/g,'\n'),codeBlocks=[];
  source=source.replace(/```([\w-]*)\n?([\s\S]*?)```/g,(m,lang,code)=>{let token='HC_CODE_BLOCK_'+codeBlocks.length+'_END';codeBlocks.push('<pre><code'+(lang?' class=\"language-'+esc(lang)+'\"':'')+'>'+esc(code.replace(/\n$/,''))+'</code></pre>');return token;});
  let lines=esc(source).split('\n'),out=[],paragraph=[],listType='';
  const inline=v=>v.replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/__([^_]+)__/g,'<strong>$1</strong>').replace(/(^|[^*])\*([^*]+)\*/g,'$1<em>$2</em>').replace(/(^|[^_])_([^_]+)_/g,'$1<em>$2</em>');
  const flushParagraph=()=>{if(paragraph.length){out.push('<p>'+inline(paragraph.join(' '))+'</p>');paragraph=[];}};
  const closeList=()=>{if(listType){out.push('</'+listType+'>');listType='';}};
  for(let i=0;i<lines.length;i++){
   let line=lines[i],trim=line.trim();
   if(!trim){flushParagraph();closeList();continue;}
   let codeMatch=trim.match(/^(HC_CODE_BLOCK_\d+_END)$/);if(codeMatch){flushParagraph();closeList();out.push(trim);continue;}
   let heading=trim.match(/^(#{1,3})\s+(.+)$/);if(heading){flushParagraph();closeList();let level=heading[1].length;out.push('<h'+level+'>'+inline(heading[2])+'</h'+level+'>');continue;}
   if(/^([-*_])\1{2,}$/.test(trim)){flushParagraph();closeList();out.push('<hr>');continue;}
   let bullet=trim.match(/^[-*+]\s+(.+)$/),ordered=trim.match(/^\d+[.)]\s+(.+)$/);
   if(bullet||ordered){flushParagraph();let wanted=ordered?'ol':'ul';if(listType!==wanted){closeList();out.push('<'+wanted+'>');listType=wanted;}out.push('<li>'+inline((bullet||ordered)[1])+'</li>');continue;}
   let quote=trim.match(/^&gt;\s?(.*)$/);if(quote){flushParagraph();closeList();out.push('<blockquote>'+inline(quote[1])+'</blockquote>');continue;}
   closeList();paragraph.push(trim);
  }
  flushParagraph();closeList();
  let html=out.join('');codeBlocks.forEach((block,i)=>{html=html.replace('HC_CODE_BLOCK_'+i+'_END',block);});
  return html;
 };
 function renderAvailability(){let b=$('#availability');if(!b)return;b.setAttribute('aria-checked',available?'true':'false');b.innerHTML='<span class="availability-switch-track" aria-hidden="true"><span class="availability-switch-thumb"></span></span><span class="availability-label">'+(available?'Available':'Offline')+'</span>'; }
 function msgKey(m){let key=String(m.message_key||'');if(key)return key;let id=Number(m.id)||0;if(id>0)return 'ticket:'+id;if(m.client_message_id)return 'client:'+String(m.client_message_id);return 'msg:'+String(m.created_at||'')+':'+String(m.sender_type||'')+':'+String(m.content||'');}
 let ticketSnapshots=new Map(),activityTimelineRows=[];
 function claimCrossTabAlert(key){try{let storageKey='hc_agent_alert_'+String(key||'').replace(/[^a-z0-9:_-]/gi,'_'),now=Date.now(),prior=Number(localStorage.getItem(storageKey)||0);if(prior&&now-prior<12000)return false;localStorage.setItem(storageKey,String(now));return true;}catch(e){return true;}}
 function ensureToastHost(){let host=document.getElementById('hcAgentToastHost');if(!host){host=document.createElement('div');host.id='hcAgentToastHost';host.className='hc-agent-toast-host';host.setAttribute('aria-live','polite');host.setAttribute('aria-atomic','false');document.body.appendChild(host);}return host;}
 let storedAgentVolume=null;try{storedAgentVolume=localStorage.getItem('hc_agent_alert_volume_'+String(HCAG.currentUserId||'agent'))}catch(e){}
 let agentAlertPrefs={sound:HCAG.alertSound||'urgent',volume:storedAgentVolume!==null?Math.max(0,Math.min(1,Number(storedAgentVolume))):Number(HCAG.alertVolume)||0.9},agentAlertsEnabled=HCAG.alertsEnabled!==false,browserAlertsEnabled=HCAG.browserAlertsEnabled!==false;
 let agentAlertContext=null,agentAlertUnlocked=false,agentAlertMuted=false,agentPromptDismissKey='hc_agent_prompt_dismissed';try{agentAlertMuted=localStorage.getItem('hc_agent_alert_muted_'+String(HCAG.currentUserId||'agent'))==='1'}catch(e){}
 function playAgentAlert(name){if(!agentAlertsEnabled||agentAlertMuted||!agentAlertUnlocked||agentAlertPrefs.volume<=0)return;try{let C=window.AudioContext||window.webkitAudioContext;if(!C)return;if(!agentAlertContext)agentAlertContext=new C();let c=agentAlertContext;if(c.state==='suspended')c.resume();let patterns={chime:[880,1174,1568],bell:[660,990,1320,990],urgent:[1046,1318,1568,1318,1046],soft:[523,659,784],digital:[784,784,1174,784],classic:[988,784,988,784,1318]};let notes=patterns[name]||patterns.chime,base=c.currentTime;notes.forEach((hz,i)=>{let o=c.createOscillator(),g=c.createGain(),start=base+i*.16,duration=.22;o.type=name==='digital'?'square':'sine';o.frequency.setValueAtTime(hz,start);g.gain.setValueAtTime(.0001,start);g.gain.exponentialRampToValueAtTime(Math.max(.01,Math.min(1,Number(agentAlertPrefs.volume)||.8))*.85,start+.018);g.gain.exponentialRampToValueAtTime(.0001,start+duration);o.connect(g);g.connect(c.destination);o.start(start);o.stop(start+duration+.02)});}catch(e){console.warn('[HelpCenter alerts] Audio unavailable',e)}}
 function unlockAgentAlerts(){agentAlertUnlocked=true;try{let C=window.AudioContext||window.webkitAudioContext;if(C&&!agentAlertContext)agentAlertContext=new C();if(agentAlertContext&&agentAlertContext.state==='suspended')agentAlertContext.resume()}catch(e){}}
 function ensureAgentAlertSettings(){if(document.getElementById('hcAgentAlertSettings'))return;let header=document.querySelector('header .agent')||document.querySelector('.agent');if(!header)return;let host=document.createElement('div');host.className='hc-agent-alert-control';let toggle=document.createElement('button');toggle.id='hcAgentAlertToggle';toggle.type='button';toggle.setAttribute('aria-label','Open notification settings');toggle.title='Notification settings';toggle.innerHTML='<i class=\"fa-solid fa-bell\" aria-hidden=\"true\"></i><span class=\"hc-alert-visually-hidden\">Alerts</span>';toggle.setAttribute('aria-haspopup','dialog');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-controls','hcAgentAlertSettings');host.appendChild(toggle);let wrap=document.createElement('section');wrap.id='hcAgentAlertSettings';wrap.hidden=true;wrap.setAttribute('role','dialog');wrap.setAttribute('aria-label','Notification preferences');wrap.innerHTML='<strong style=\"display:block;font-size:14px;margin-bottom:5px\">Notification preferences</strong><p id=\"hcAgentAlertStatus\" style=\"margin:0 0 10px;color:#68758a;font-size:10px\"></p><label style=\"display:flex;align-items:center;justify-content:space-between;gap:10px;font-size:11px;font-weight:700;margin:10px 0\"><span>Sound alerts</span><input type=\"checkbox\" id=\"hcAgentSoundEnabled\"></label><label class=\"hc-alert-volume\"><span style=\"font-size:10px;font-weight:700\">Volume</span><input type=\"range\" id=\"hcAgentAlertVolume\" min=\"0\" max=\"1\" step=\"0.05\"><output id=\"hcAgentAlertVolumeValue\" style=\"min-width:34px;text-align:right;font-size:10px\"></output></label><div class=\"hc-alert-actions\"><button type=\"button\" class=\"primary\" id=\"hcAgentTestAlert\"><i class=\"fa-solid fa-volume-high\"></i> Test sound</button><button type=\"button\" id=\"hcAgentEnableAlerts\" data-hc-enable-push><i class=\"fa-regular fa-bell\"></i> Browser notifications</button><button type=\"button\" id=\"hcAgentCloseAlerts\" aria-label=\"Close\">Close</button></div>';host.appendChild(wrap);header.insertBefore(host,header.querySelector('button[onclick*="logout"],button:last-child')||null);function moveFloatingAlertsWidget(){document.querySelectorAll('button,a,[role="button"],[onclick]').forEach(el=>{if(el.id==='hcAgentAlertToggle'||el.closest('#hcAgentAlertSettings')||el.classList.contains('hc-alerts-moved-to-header'))return;let label=String(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim();if(!/^(?:🔔\s*)?Alerts$/i.test(label))return;let cs=window.getComputedStyle(el);if(cs.position!=='fixed')return;el.classList.add('hc-alerts-moved-to-header');['position','right','left','top','bottom','inset','z-index','transform','margin','box-shadow'].forEach(prop=>el.style.removeProperty(prop));el.style.setProperty('position','static','important');el.style.setProperty('inset','auto','important');el.style.setProperty('margin','0 6px 0 0','important');el.style.setProperty('z-index','auto','important');header.insertBefore(el,host);});}if(!moveFloatingAlertsWidget()&&!window.__hcAlertWidgetObserver&&document.body){let alertObserver=new MutationObserver(()=>{if(moveFloatingAlertsWidget()){alertObserver.disconnect();window.__hcAlertWidgetObserver=null;}});window.__hcAlertWidgetObserver=alertObserver;alertObserver.observe(document.body,{childList:true,subtree:true});window.setTimeout(()=>{if(window.__hcAlertWidgetObserver===alertObserver){alertObserver.disconnect();window.__hcAlertWidgetObserver=null;}},8000);}let status=wrap.querySelector('#hcAgentAlertStatus'),soundToggle=wrap.querySelector('#hcAgentSoundEnabled'),volume=wrap.querySelector('#hcAgentAlertVolume'),volumeOut=wrap.querySelector('#hcAgentAlertVolumeValue');soundToggle.checked=!agentAlertMuted;volume.value=String(agentAlertPrefs.volume);volumeOut.value=Math.round(agentAlertPrefs.volume*100)+'%';function update(){if(!agentAlertsEnabled){status.textContent='Sound alerts are disabled by the site administrator. Browser notifications remain separately controlled.';soundToggle.disabled=true;volume.disabled=true;return}soundToggle.disabled=false;volume.disabled=false;status.textContent=agentAlertMuted?'Sound alerts are muted for this agent.':'Administrator sound: '+agentAlertPrefs.sound+'. Your volume preference applies only to this browser.';}toggle.addEventListener('click',()=>{wrap.hidden=!wrap.hidden;toggle.setAttribute('aria-expanded',wrap.hidden?'false':'true');update();if(!wrap.hidden)window.setTimeout(()=>soundToggle.focus(),0)});document.addEventListener('click',e=>{if(!host.contains(e.target)&&!wrap.hidden){wrap.hidden=true;toggle.setAttribute('aria-expanded','false')}});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!wrap.hidden){wrap.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.focus()}});soundToggle.addEventListener('change',()=>{agentAlertMuted=!soundToggle.checked;try{localStorage.setItem('hc_agent_alert_muted_'+String(HCAG.currentUserId||'agent'),agentAlertMuted?'1':'0')}catch(e){}update()});volume.addEventListener('input',()=>{agentAlertPrefs.volume=Math.max(0,Math.min(1,Number(volume.value)||0));volumeOut.value=Math.round(agentAlertPrefs.volume*100)+'%';try{localStorage.setItem('hc_agent_alert_volume_'+String(HCAG.currentUserId||'agent'),String(agentAlertPrefs.volume))}catch(e){}});wrap.querySelector('#hcAgentTestAlert').addEventListener('click',()=>{unlockAgentAlerts();if(agentAlertsEnabled&&!agentAlertMuted)playAgentAlert(agentAlertPrefs.sound)});window.addEventListener('hc-web-push-enable-result',e=>{let r=e.detail||{};if(r.status==='blocked'){status.textContent='Notifications are blocked. Click the site icon beside the address bar → Site settings → Notifications → Allow. Return here and click Retry after allowing.';}else if(r.status==='active'){status.textContent='Push notifications are active in this browser.';}else if(r.status==='unsupported'){status.textContent='This browser does not support Web Push notifications.';}else if(r.status==='disabled'){status.textContent='Browser notifications are disabled by the site administrator.';}else if(r.status==='error'){status.textContent='Push setup failed: '+((r.error&&r.error.message)||'Unknown error')+'. Please retry.';}else{status.textContent='Notification permission was not granted. Please try again.';}});window.addEventListener('hc-web-push-state',e=>{let d=e.detail||{};if(d.permission==='denied'){status.textContent='Notifications are blocked. Click the site icon beside the address bar → Site settings → Notifications → Allow. Then click Browser notifications again.';}else if(d.permission==='granted'&&d.subscribed){status.textContent='Push notifications are active in this browser.';}else if(d.permission==='granted'){status.textContent='Permission granted, but push setup is incomplete. Click Browser notifications to finish.';}else if(d.permission==='default'&&status.textContent.indexOf('blocked')!==-1){status.textContent='Permission is available. Click Browser notifications to enable push.';}});wrap.querySelector('#hcAgentCloseAlerts').addEventListener('click',()=>{wrap.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.focus()});update();}
 function notifyAgent(title,detail,id,dedupeKey){if(dedupeKey&&!claimCrossTabAlert('notify:'+dedupeKey))return;let alertKind=/assigned|new conversation|new ticket/i.test(String(title))?'new-ticket':'reply';playAgentAlert(alertKind==='new-ticket'?'bell':'digital');let host=ensureToastHost(),node=document.createElement('div');node.className='hc-agent-toast';node.innerHTML='<span class="toast-icon"><i class="fa-solid fa-headset"></i></span><div><strong></strong><small></small></div><button type="button" aria-label="Dismiss notification">×</button>';node.querySelector('strong').textContent=title;node.querySelector('small').textContent=detail;node.querySelector('button').addEventListener('click',()=>node.remove());host.appendChild(node);window.setTimeout(()=>{if(node.isConnected)node.remove();},9000);let hasPush=false;try{hasPush=localStorage.getItem('hc_web_push_agent_'+String(HCAG.currentUserId||'agent'))==='1'}catch(e){}if(browserAlertsEnabled&&!hasPush&&'Notification'in window&&Notification.permission==='granted'){try{let n=new Notification(title,{body:detail,tag:'hc-agent-'+(id||Date.now()),renotify:false});n.onclick=()=>{window.focus();if(id)openTicket(id,false);n.close();};}catch(e){}}}
 function sendStatusToast(title,detail){let host=ensureToastHost(),node=document.createElement('div');node.className='hc-agent-toast hc-send-status-toast';node.innerHTML='<span class="toast-icon"><i class="fa-solid fa-paper-plane"></i></span><div><strong></strong><small></small></div>';node.querySelector('strong').textContent=title;node.querySelector('small').textContent=detail||'';host.appendChild(node);window.setTimeout(()=>{if(node.isConnected)node.remove();},2600);}
 function relativeAge(value){if(!value)return '—';let d=new Date(String(value).replace(' ','T'));if(Number.isNaN(d.getTime()))return String(value);let sec=Math.max(0,Math.floor((Date.now()-d.getTime())/1000));if(sec<60)return sec+' sec';let min=Math.floor(sec/60);if(min<60)return min+' min';let hr=Math.floor(min/60);if(hr<24)return hr+' hr';let day=Math.floor(hr/24);return day+' d';}
 function updateRelativeTimes(){document.querySelectorAll('[data-relative-time]').forEach(n=>{n.textContent=relativeAge(n.getAttribute('data-relative-time'));});}
 function renderList(rows,counts={}){let previous=new Map(tickets.map(x=>[String(x.id),x]));let wasLoaded=listLoaded;tickets=(rows||[]).map(x=>Object.assign({},x,{is_live:false}));ticketSnapshots=new Map(tickets.map(x=>[String(x.id),{count:Number(x.message_count)||0,last:String(x.last_activity||''),preview:String(x.preview||'')} ]));let assignedCount=document.getElementById('assignedCount'),closedCount=document.getElementById('closedCount'),messageCount=document.getElementById('messageCount');if(assignedCount)assignedCount.textContent=tab==='assigned'?tickets.length:'—';if(closedCount)closedCount.textContent=tab==='closed'?tickets.length:'—';if(messageCount)messageCount.textContent=tickets.reduce((n,x)=>n+(Number(x.message_count)||0),0).toLocaleString();let incoming=[];if(tab==='assigned'&&wasLoaded){tickets.forEach(x=>{let prev=previous.get(String(x.id));if(!prev){incoming.push({ticket:x,type:'new'});return;}let changed=(Number(x.message_count)||0)>(Number(prev.message_count)||0)||String(x.last_activity||'')!==String(prev.last_activity||'')||String(x.preview||'')!==String(prev.preview||'');if(changed&&Number(x.id)!==Number(active))incoming.push({ticket:x,type:'reply'});});}if(incoming.length){incoming.forEach(item=>{let x=item.ticket;notifyAgent(item.type==='new'?'New conversation assigned':'New customer reply',(x.title||('#'+x.id))+' · '+(x.visitor_name||'Customer')+' — '+String(x.preview||'Open the conversation to review the latest message.').slice(0,100),Number(x.id),(x.type||'ticket')+':'+Number(x.id)+':'+(x.last_message_id||x.updated_at||''));});}listLoaded=true;let cards=tickets.map(t=>{let sla=t.sla||{},remain=Math.max(0,Number(sla.remaining_seconds)||0),slaClock=String(Math.floor(remain/3600)).padStart(2,'0')+':'+String(Math.floor(remain%3600/60)).padStart(2,'0')+':'+String(remain%60).padStart(2,'0'),slaText=sla.completed?'SLA completed':(sla.due_at?(sla.overdue?'SLA overdue':'SLA due in '+slaClock):'SLA not scheduled');return `<button type="button" class="home-ticket-card" data-id="${t.id}"><header><span class="hc-ticket-card-heading"><strong title="${esc(t.title||'AI is preparing a conversation title')}">${t.title?esc(t.title):'<span class="hc-title-pending"><i class="fa-solid fa-wand-magic-sparkles"></i> Preparing title…</span>'}</strong><small>#${t.id} · ${esc(t.visitor_name)}</small></span><span class="badge hc-status-badge hc-status-${esc(String(t.status||'').toLowerCase())}"><i class="fa-solid fa-circle"></i> ${esc(t.status)}</span></header><p title="${esc(t.preview||t.issue||'No message preview')}"><i class="fa-regular fa-message hc-card-meta-icon"></i> ${esc(t.preview||t.issue||'No message preview')}</p><footer><span><span class="priority-dot priority-${esc((t.priority||'normal').toLowerCase())}"></span>${esc((t.priority||'normal').toUpperCase())} priority${t.unread? ' · <span class="unread-pill">Unread</span>':''}</span><time data-relative-time="${esc(t.last_activity||t.created_at||'')}" title="${esc(t.last_activity||t.created_at||'')}">${esc(relativeAge(t.last_activity||t.created_at||''))}</time></footer><footer><span><i class="fa-solid fa-user-check hc-card-meta-icon"></i> ${esc(t.assigned_agent_name||HCAG.agentName||'Assigned agent')} · <i class="fa-regular fa-comments hc-card-meta-icon"></i> ${Number(t.message_count)||0}</span><span>${esc(slaText)}</span></footer></button>`}).join('');let empty='<div class="home-empty">No tickets in this queue.</div>';let home=document.getElementById('homeTickets');if(home)home.innerHTML=cards||empty;let title=document.getElementById('homeQueueTitle');if(title)title.textContent=tab==='closed'?'Closed by Me':'Assigned to Me';let count=document.getElementById('homeTicketCount');if(count)count.textContent=tickets.length+' ticket'+(tickets.length===1?'':'s');let hA=document.getElementById('homeAssignedCount'),hC=document.getElementById('homeClosedCount'),hU=document.getElementById('homeUnreadCount'),hS=document.getElementById('homeSlaCount');if(hA)hA.textContent=counts.assigned??(tab==='assigned'?tickets.length:'—');if(hC)hC.textContent=counts.closed??(tab==='closed'?tickets.length:'—');if(hU)hU.textContent=counts.unread??tickets.filter(x=>x.unread).length;let unreadTotal=Number(counts.unread??tickets.filter(x=>x.unread).length)||0;document.title=(unreadTotal?'('+unreadTotal+') ':'')+(document.title.replace(/^\(\d+\)\s*/,''));if(hS)hS.textContent=counts.sla_risk??tickets.filter(x=>x.sla&&x.sla.due_at&&(x.sla.overdue||x.sla.due_soon)).length;let left=document.getElementById('tickets');if(left)left.innerHTML=tickets.map(t=>`<div class="ticket ${active==t.id?'sel':''}" data-id="${t.id}"><div class="hc-ticket-list-heading"><strong title="${esc(t.title||'AI is preparing a conversation title')}">${t.title?esc(t.title):'<span class="hc-title-pending"><i class="fa-solid fa-wand-magic-sparkles"></i> Preparing title…</span>'}</strong><span class="badge hc-status-badge hc-status-${esc(String(t.status||'').toLowerCase())}"><i class="fa-solid fa-circle"></i> ${esc(t.status)}</span></div><small class="hc-ticket-list-customer"><i class="fa-solid fa-hashtag"></i> ${t.id} · <i class="fa-regular fa-user"></i> ${esc(t.visitor_name)} · <i class="fa-solid fa-user-check"></i> ${esc(t.assigned_agent_name||HCAG.agentName||'Assigned agent')}</small><small class="hc-ticket-preview" title="${esc(t.preview||t.issue||'No message preview')}"><i class="fa-regular fa-message"></i> ${esc(t.preview||t.issue||'No message preview')}</small><small class="inbox-card-meta"><span class="priority-dot priority-${esc((t.priority||'normal').toLowerCase())}"></span>${esc((t.priority||'normal').toUpperCase())} priority${t.unread?' · <span class="unread-pill">Unread</span>':''}</small><small><i class="fa-regular fa-clock"></i> <time data-relative-time="${esc(t.last_activity||t.created_at||'')}">${esc(relativeAge(t.last_activity||t.created_at||''))}</time></small></div>`).join('')||'<div class="empty" style="padding:25px">No conversations in this queue.</div>';updateRelativeTimes();}
 async function loadList(q,options={}){
  const silent=!!options.silent;if(silent&&listInteractiveBusy)return tickets;const seq=++listRequestSeq,requestTab=tab;if(!silent)listInteractiveBusy=true;
  let term=q===undefined?'':String(q||'').trim();
  let listNode=$('#tickets'),homeNode=$('#homeTickets');
  if(!silent){
   if(listNode){listNode.setAttribute('aria-busy','true');if(!tickets.length)listNode.innerHTML='<div class="hc-modern-loader" role="status"><span class="hc-loader-orb"><i></i><i></i><i></i></span><strong>Loading your queue</strong><small>Syncing conversations and assignments</small><span class="hc-loader-track"><i></i></span></div>';}
   if(homeNode){homeNode.setAttribute('aria-busy','true');if(!tickets.length)homeNode.innerHTML='<div class="hc-modern-loader" role="status"><span class="hc-loader-orb"><i></i><i></i><i></i></span><strong>Loading your queue</strong><small>Syncing conversations and assignments</small><span class="hc-loader-track"><i></i></span></div>';}
   document.querySelectorAll('.tab').forEach(b=>{b.disabled=true;b.setAttribute('aria-busy','true')});
  }
  try{
   if(requestTab==='assigned'){
    let pair=await Promise.all([post('hc_agent_list',{tab:'assigned',q:term}),post('hc_agent_live_list',{q:term})]);
    if(seq!==listRequestSeq||requestTab!==tab)return tickets;
    if(pair[0].success&&pair[1].success){
     let normal=(pair[0].data.tickets||[]).map(x=>Object.assign({},x,{is_live:false,has_live:false}));
     let live=(pair[1].data.tickets||[]).map(x=>Object.assign({},x,{is_live:false,has_live:true}));
     let merged=new Map();normal.forEach(x=>merged.set(String(x.id),x));
     live.forEach(x=>{let key=String(x.id),base=merged.get(key);if(base){base.has_live=true;base.agent_connected=!!x.agent_connected;base.live_message_count=Number(x.message_count)||0;}else{merged.set(key,Object.assign({},x,{is_live:false,has_live:true}));}});
     let rows=Array.from(merged.values()).sort((a,b)=>String(b.last_activity||b.created_at||'').localeCompare(String(a.last_activity||a.created_at||'')));
     renderList(rows,pair[0].data.counts||{});
    }else throw new Error(pair[0].data?.message||pair[1].data?.message||'Could not load assigned work');
   }else{
    let r=await post('hc_agent_list',{tab:requestTab,q:term});
    if(seq!==listRequestSeq||requestTab!==tab)return tickets;
    if(r.success)renderList((r.data.tickets||[]).map(x=>Object.assign({},x,{is_live:false})),r.data.counts||{});
    else throw new Error(r.data?.message||'Could not load tickets');
   }
   return tickets;
  }catch(e){
   if(!silent&&seq===listRequestSeq&&requestTab===tab&&!tickets.length){
    if($('#tickets'))$('#tickets').innerHTML='<div class="empty" style="padding:25px">'+esc(e.message||'Connection problem. Refresh to retry.')+'</div>';
    if($('#homeTickets'))$('#homeTickets').innerHTML='<div class="home-empty">'+esc(e.message||'Could not load this queue. Please retry.')+'</div>';
   }
   return tickets;
  }finally{
   if(!silent&&seq===listRequestSeq){listInteractiveBusy=false;if(listNode)listNode.removeAttribute('aria-busy');if(homeNode)homeNode.removeAttribute('aria-busy');document.querySelectorAll('.tab').forEach(b=>{b.disabled=false;b.removeAttribute('aria-busy')});}
  }
 }

 let ticketRealtimeConnection=null,ticketRealtimeConnectPromise=null,ticketRealtimeId=0,ticketRealtimePending=0,ticketRealtimeGeneration=0,ticketRealtimeConnected=false,ticketRealtimeRetryTimer=null,ticketRealtimeRetryAttempt=0,ticketRefreshQueued=false,ticketServerReadyId=0,ticketReadyPublishedId=0,liveAfter=0,liveAiAfter=0;
 function configureTicketFallback(){
  if(ticketTimer)clearInterval(ticketTimer);ticketTimer=null;
  if(!active||activeHck)return;
  ticketTimer=setInterval(()=>{if(active&&!activeHck&&!document.hidden&&$('#workspace')&&!$('#workspace').classList.contains('hidden')){if(pollBusy)ticketRefreshQueued=true;else openTicket(active,true)}},ticketRealtimeConnected?10000:1200);
 }
 function configureLiveConversationFallback(){
  if(liveConversationTimer)clearInterval(liveConversationTimer);liveConversationTimer=null;
  if(activeLive&&!activeHck&&!activeHckOriginConverted&&!document.hidden){liveConversationTimer=setInterval(()=>{if(activeLive&&!document.hidden){if(pollBusy)ticketRefreshQueued=true;else openTicket(active,true);}},ticketRealtimeConnected?15000:3000);}
 }
 async function refreshLiveConversation(id){
  id=Number(id)||0;if(!id||id!==activeLive||activeHck||activeHckOriginConverted||document.hidden||liveConversationBusy)return;
  liveConversationBusy=true;
  try{
   const r=await post('hc_agent_live_ticket',{conversation_id:id,after_id:liveAfter,ai_after_id:liveAiAfter});
   if(!r.success)throw new Error(r.data?.message||'Live conversation refresh failed.');
   const d=r.data||{},t=d.ticket||{},issue=String(t.issue||'').trim();
   liveAfter=Math.max(liveAfter,Number(d.last_id)||0);liveAiAfter=Math.max(liveAiAfter,Number(d.last_ai_id)||0);
   const norm=v=>String(v||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase();
   let incoming=Array.isArray(d.messages)?d.messages.slice():[];
   if(issue&&!incoming.some(m=>m.sender_type==='visitor'&&norm(m.content)===norm(issue)))incoming.push({id:-Math.abs(id),message_key:'initial-concern:'+id,sender_type:'visitor',sender_name:t.visitor_name||'Customer',content:issue,created_at:t.created_at||'',is_initial_concern:true});
   incoming.sort((a,b)=>{let c=String(a.created_at||'').localeCompare(String(b.created_at||''));if(c)return c;if(a.is_initial_concern&&!b.is_initial_concern)return -1;if(b.is_initial_concern&&!a.is_initial_concern)return 1;return Number(a.id||0)-Number(b.id||0)});
   const rows=incoming.map(m=>({id:m.id,message_key:m.message_key||('live:'+m.id),is_initial_concern:!!m.is_initial_concern,sender_type:m.sender_type,sender_name:m.sender_name,content:m.content,created_at:m.created_at,attachment_url:m.attachment_url,attachment_name:m.attachment_name,attachment_mime:m.attachment_mime,attachment_kind:m.attachment_kind}));
   const fresh=rows.filter(m=>!known.has(msgKey(m)));
   if(fresh.length){activityTimelineRows=activityTimelineRows.concat(fresh);let activitySeen=new Set();activityTimelineRows=activityTimelineRows.filter(m=>{let k=msgKey(m);if(activitySeen.has(k))return false;activitySeen.add(k);return true;});renderTicketActivity(activityTimelineRows);fresh.forEach(m=>{if(m.attachment_name)m.content=(m.content?m.content+'\n':'')+'Attachment: '+m.attachment_name;});const added=appendUnique(fresh,false);let customerRows=fresh.filter(m=>m.sender_type==='visitor');if(added&&customerRows.length){let last=customerRows[customerRows.length-1];notifyAgent('New customer message','#'+id+' · '+String(last.content||'New message received').replace(/\s+/g,' ').slice(0,115),id,'message:'+id+':'+msgKey(last));}}
   if(t.issue&&$('#detailIssue'))$('#detailIssue').textContent=t.issue;
   if(d.customer_history)renderCustomerHistory(d.customer_history);
  }catch(e){console.warn('Live conversation background refresh failed:',e.message||e);}
  finally{liveConversationBusy=false;}
 }
 function publishAgentReady(id){
  id=Number(id)||0;
  if(!id||Number(active)!==id||ticketServerReadyId!==id||!ticketRealtimeConnected||!ticketRealtimeConnection||ticketReadyPublishedId===id)return;
  ticketReadyPublishedId=id;
  ticketRealtimeConnection.publishTo('hc-agent-reply-'+id,'agent.ready',{ticket_id:id,occurred_at:Date.now()}).catch(error=>{console.warn('[HelpCenter Ably] Agent-ready signal failed.',{ticket_id:id,error:error});if(ticketReadyPublishedId===id)ticketReadyPublishedId=0;});
 }
 function connectTicketRealtime(id){
  id=Number(id)||0;
  if(!id)return Promise.reject(new Error('A valid HelpCenter ticket ID is required for realtime.'));
  if(!window.HCRealtimeClient||!window.Ably){
   ticketRealtimeConnected=false;configureTicketFallback();
   if(ticketRealtimeRetryTimer)clearTimeout(ticketRealtimeRetryTimer);
   const missingDelay=Math.min(30000,1000*Math.pow(2,Math.min(ticketRealtimeRetryAttempt++,5)));
   ticketRealtimeRetryTimer=window.setTimeout(()=>{ticketRealtimeRetryTimer=null;if(Number(active)===id&&!ticketRealtimeConnection&&!ticketRealtimePending)connectTicketRealtime(id).catch(()=>{});},missingDelay);
   return Promise.reject(new Error('The Ably SDK or HelpCenter realtime client is unavailable. Check that both scripts loaded successfully.'));
  }

  if(ticketRealtimeId===id){
   // All callers for the same ticket must share the exact in-flight promise.
   if(ticketRealtimeConnectPromise)return ticketRealtimeConnectPromise;
   if(ticketRealtimeConnection){
    const state=ticketRealtimeConnection.client&&ticketRealtimeConnection.client.connection?ticketRealtimeConnection.client.connection.state:'';
    const failedChannel=Array.isArray(ticketRealtimeConnection.channels)&&ticketRealtimeConnection.channels.some(channel=>channel&&channel.state==='failed');
    if(state!=='failed'&&state!=='closed'&&!failedChannel)return Promise.resolve(ticketRealtimeConnection);
    try{ticketRealtimeConnection.close();}catch(e){}
    ticketRealtimeConnection=null;
   }
   // A pending marker without its promise is an orphaned state, not a reason
   // to return null. Reset it and start a real connection attempt below.
   if(ticketRealtimePending===id){ticketRealtimePending=0;ticketRealtimeId=0;}
  }

  if(ticketRealtimeRetryTimer){clearTimeout(ticketRealtimeRetryTimer);ticketRealtimeRetryTimer=null;}
  const generation=++ticketRealtimeGeneration;
  if(ticketRealtimeConnection){try{ticketRealtimeConnection.close();}catch(e){}ticketRealtimeConnection=null;}
  ticketRealtimeConnectPromise=null;
  ticketRealtimeId=id;
  ticketRealtimePending=id;
  ticketRealtimeConnected=false;
  configureTicketFallback();

  const rawConnectionPromise=window.HCRealtimeClient.connect({
   ajaxUrl:HCAG.ajax,
   nonce:HCAG.nonce,
   channelType:'agent_ticket',
   ticketId:id,
   recoveryScope:'helpcenter-agent-ticket:'+id
  },function(ev,eventName,channelName){
   if(generation!==ticketRealtimeGeneration||Number(active)!==id||Number(ev.ticket_id)!==id)return;
   if(channelName==='hc-customer-msg-'+id){
    if(eventName!=='customer.message'||!ev.message)return;
    console.info('[HC Support Realtime] Agent browser received customer message from Ably.',{ticket_id:id,client_message_id:ev.message.client_message_id||''});
    let direct=Object.assign({},ev.message,{id:0,sender_type:'visitor',sender_name:ev.message.sender_name||'Customer'});
    let directAdded=appendUnique([direct],false);
    if(directAdded)notifyAgent('New customer message','#'+id+' · '+String(direct.content||'New message received').replace(/\s+/g,' ').slice(0,115),id,'direct:'+id+':'+String(direct.client_message_id||direct.created_at||Date.now()));
    return;
   }
   if(ev.message){
    let message=ev.message,added=appendUnique([message],false);
    if(added&&message.sender_type==='visitor')notifyAgent('New customer message','#'+id+' · '+String(message.content||'New message received').replace(/\s+/g,' ').slice(0,115),id,'ticket:'+id+':'+msgKey(message));
    after=Math.max(after,Number(message.id)||0);
    return;
   }
   requestTicketRefresh();
  },function(state,reason){
   if(generation!==ticketRealtimeGeneration)return;
   ticketRealtimeConnected=state==='connected';
   configureTicketFallback();
   if(ticketRealtimeConnected){
    ticketRealtimeRetryAttempt=0;
    if(ticketRealtimeRetryTimer){clearTimeout(ticketRealtimeRetryTimer);ticketRealtimeRetryTimer=null;}
    publishAgentReady(id);
    requestTicketRefresh();
    return;
   }
   if(state==='failed'||state==='closed'){
    const staleConnection=ticketRealtimeConnection;
    ticketRealtimeConnection=null;
    ticketRealtimeConnectPromise=null;
    ticketRealtimePending=0;
    ticketRealtimeId=0;
    const retryGeneration=++ticketRealtimeGeneration;
    if(staleConnection){try{staleConnection.close();}catch(e){}}
    if(ticketRealtimeRetryTimer)clearTimeout(ticketRealtimeRetryTimer);
    const retryDelay=Math.min(30000,1000*Math.pow(2,Math.min(ticketRealtimeRetryAttempt++,5)));
    ticketRealtimeRetryTimer=window.setTimeout(()=>{
     ticketRealtimeRetryTimer=null;
     if(retryGeneration===ticketRealtimeGeneration&&Number(active)===id&&!ticketRealtimeConnection&&!ticketRealtimePending){connectTicketRealtime(id).catch(error=>console.warn('[HelpCenter Ably] Scheduled ticket reconnect failed.',error));}
    },retryDelay);
   }
  });

  let pending;
  pending=Promise.resolve(rawConnectionPromise).then(connection=>{
   // A connection attempt belongs to the generation that created it. Never
   // let an old ticket attempt recursively start a new connection: doing so
   // can replace the connection for the ticket the agent has since opened.
   if(generation!==ticketRealtimeGeneration||ticketRealtimePending!==id||ticketRealtimeId!==id){
    if(connection&&typeof connection.close==='function')connection.close();
    const replacement=(ticketRealtimeId===id&&ticketRealtimeConnectPromise&&ticketRealtimeConnectPromise!==pending)
     ?ticketRealtimeConnectPromise:null;
    if(replacement)return replacement;
    const superseded=new Error('This ticket realtime connection attempt was superseded by a newer ticket selection.');
    superseded.code='HC_REALTIME_ATTEMPT_SUPERSEDED';
    throw superseded;
   }
   // If the agent switched away while this connection was attaching, close
   // this attempt and report a context change. Returning null here used to
   // hide the cause and made the send loop retry a connection that no longer
   // belonged to the active workspace.
   if(Number(active)!==id){
    if(connection&&typeof connection.close==='function')connection.close();
    if(ticketRealtimeConnectPromise===pending)ticketRealtimeConnectPromise=null;
    if(ticketRealtimePending===id)ticketRealtimePending=0;
    if(ticketRealtimeId===id)ticketRealtimeId=0;
    ticketRealtimeConnected=false;
    const changed=new Error('The active ticket changed before its realtime connection finished attaching.');
    changed.code='HC_REALTIME_TICKET_CONTEXT_CHANGED';
    throw changed;
   }
   ticketRealtimeConnection=connection;
   ticketRealtimePending=0;
   ticketRealtimeRetryAttempt=0;
   if(ticketRealtimeRetryTimer){clearTimeout(ticketRealtimeRetryTimer);ticketRealtimeRetryTimer=null;}
   publishAgentReady(id);
   return connection;
  }).catch(error=>{
   if(generation===ticketRealtimeGeneration){
    if(ticketRealtimePending===id)ticketRealtimePending=0;
    ticketRealtimeId=0;
    ticketRealtimeConnected=false;
    ticketRealtimeConnection=null;
    if(ticketRealtimeConnectPromise===pending)ticketRealtimeConnectPromise=null;
    configureTicketFallback();
    if(ticketRealtimeRetryTimer)clearTimeout(ticketRealtimeRetryTimer);
    const retryDelay=Math.min(30000,1000*Math.pow(2,Math.min(ticketRealtimeRetryAttempt++,5)));
    ticketRealtimeRetryTimer=window.setTimeout(()=>{
     ticketRealtimeRetryTimer=null;
     if(generation===ticketRealtimeGeneration&&Number(active)===id&&!ticketRealtimeConnection&&!ticketRealtimePending){connectTicketRealtime(id).catch(retryError=>console.warn('[HelpCenter Ably] Scheduled ticket reconnect failed.',retryError));}
    },retryDelay);
   }
   // Preserve the real auth/channel/Ably error for the waiting send operation.
   if(error&&error.code==='HC_REALTIME_ATTEMPT_SUPERSEDED'){
    console.debug('[HelpCenter Ably] Ignored a stale ticket connection attempt.',{ticket_id:id,generation:generation,current_generation:ticketRealtimeGeneration,current_ticket:ticketRealtimeId,active_ticket:Number(active)||0});
   }
   throw error;
  });
  ticketRealtimeConnectPromise=pending;
  return pending;
 }

 function waitForAgentTicketRealtime(ticketId,timeoutMs){
  ticketId=Number(ticketId)||0;
  if(!ticketId||ticketId!==Number(active))return Promise.reject(new Error('The requested ticket is no longer active in this agent workspace.'));
  const timeout=Math.max(5000,Math.min(30000,Number(timeoutMs)||15000));
  const deadline=Date.now()+timeout;
  function attempt(lastError){
   if(ticketId!==Number(active))return Promise.reject(new Error('The requested ticket is no longer active in this agent workspace.'));
   const remaining=deadline-Date.now();
   if(remaining<=0)return Promise.reject(lastError||new Error('The agent ticket realtime channels did not become ready before the timeout.'));
   return connectTicketRealtime(ticketId).then(connection=>{
    if(!connection)throw new Error('The agent ticket realtime connection was closed while initializing.');
    if(typeof connection.whenReady==='function')return connection.whenReady(Math.min(remaining,12000)).then(()=>connection);
    if(ticketRealtimeConnected)return connection;
    throw new Error('The agent ticket realtime channels are not attached.');
   }).then(connection=>{
    if(ticketId!==Number(active))throw new Error('The active ticket changed before realtime publishing.');
    if(connection.isReady&& !connection.isReady())throw new Error('The agent ticket realtime connection lost readiness before publishing.');
    return connection;
   }).catch(error=>{
    if(ticketId!==Number(active))throw error;
    const left=deadline-Date.now();
    if(left<=0)throw error;
    return new Promise(resolve=>window.setTimeout(resolve,Math.min(300,Math.max(50,left)))).then(()=>attempt(error));
   });
  }
  return attempt(null);
 }
 function publishAgentServerRelay(ticketId,message){
  const fd=new FormData();
  fd.append('action','hc_agent_realtime_relay');
  fd.append('nonce',HCAG.nonce);
  fd.append('ticket_id',String(ticketId));
  fd.append('client_message_id',String(message.client_message_id||''));
  fd.append('content',String(message.content||''));
  return fetch(HCAG.ajax,{method:'POST',body:fd,credentials:'same-origin',cache:'no-store',keepalive:true})
   .then(response=>response.json().then(data=>({response:response,data:data})))
   .then(result=>{
    if(!result.response.ok||!result.data||!result.data.success)throw new Error(result.data&&result.data.data&&result.data.data.message||'The HelpCenter realtime relay did not acknowledge delivery.');
    console.debug('[HelpCenter Realtime] Server relay publish acknowledged by Ably before transcript persistence.',{ticket_id:ticketId,client_message_id:message.client_message_id});
    setAgentMessageState(message.client_message_id,'Realtime accepted · saving',false);
    return true;
   });
 }
 function publishAgentLiveMessage(ticketId,message){
  ticketId=Number(ticketId)||0;
  if(!ticketId||!message)return Promise.resolve(false);
  return waitForAgentTicketRealtime(ticketId,15000).then(connection=>{
   if(!connection.directPublish)throw new Error('The agent ticket token does not grant direct publish permission on the reply channel.');
   return connection.publishTo('hc-agent-reply-'+ticketId,'agent.message',{ticket_id:ticketId,message:message}).then(()=>true);
  }).then(delivered=>{
   if(!delivered)return false;
   console.info('[HC Support Realtime] Agent browser published to Ably before the transcript save.',{ticket_id:ticketId,client_message_id:message.client_message_id});
   setAgentMessageState(message.client_message_id,'Realtime accepted · saving',false);
   return true;
  }).catch(error=>{
   const realtimeConnection=(ticketRealtimeId===ticketId)?ticketRealtimeConnection:null;
   const channelStates=realtimeConnection&&Array.isArray(realtimeConnection.channels)?realtimeConnection.channels.map(channel=>({name:channel.name||'',state:channel.state||'',error:channel.errorReason&&channel.errorReason.message?channel.errorReason.message:''})):[];
   const cause=error&&error.cause?error.cause:null;
   console.warn('[HC Support Realtime] Direct browser publish did not complete; attempting authenticated pre-save relay.',{
    ticket_id:ticketId,
    client_message_id:message.client_message_id,
    error_name:error&&error.name?String(error.name):'Error',
    error_message:error&&error.message?String(error.message):String(error||'Unknown direct publish error'),
    error_code:error&&error.code!==undefined?error.code:null,
    error_status_code:error&&error.statusCode!==undefined?error.statusCode:null,
    error_cause:cause&&cause.message?String(cause.message):null,
    token_allows_direct_publish:realtimeConnection?!!realtimeConnection.directPublish:null,
    connection_state:realtimeConnection&&realtimeConnection.client&&realtimeConnection.client.connection?realtimeConnection.client.connection.state:null,
    channel_states:channelStates,
    original_error:error
   });
   return publishAgentServerRelay(ticketId,message).catch(relayError=>{
    console.error('[HC Support Realtime] Both pre-save delivery paths failed. Reply will remain unsaved.',{ticket_id:ticketId,client_message_id:message.client_message_id,browser_error:error,relay_error:relayError});
    return false;
   });
  });
 }

 function requestTicketRefresh(){if(!active||activeHck)return;if(pollBusy){ticketRefreshQueued=true;return;}openTicket(active,true);}
 function goHome(){closeHckAgentRealtime();$('#hcLiveSupportInfoCard').hidden=true;if(liveConversationTimer)clearInterval(liveConversationTimer);liveConversationTimer=null;$('#hckHandoffBrief').hidden=true;$('#hckHandoffBriefBody').textContent='';if(hckPreviousTimer)clearInterval(hckPreviousTimer);hckPreviousTimer=null;activeHckOriginConverted=false;$('#handoffBanner').hidden=true;if(ticketTimer)clearInterval(ticketTimer);ticketTimer=null;if(hckPreviousTimer)clearInterval(hckPreviousTimer);hckPreviousTimer=null;layout.classList.remove('details-open','inbox-open','ticket-mode','open');layout.classList.add('home-mode');active=0;activeLive=0;activeHck=0;tickets=[];ticketSnapshots.clear();listLoaded=false;crmPrivateNotes=[];crmSideRows=[];renderPrivateNotes();renderSideRows();ticketRefreshQueued=false;ticketRealtimeGeneration++;if(ticketRealtimeRetryTimer){clearTimeout(ticketRealtimeRetryTimer);ticketRealtimeRetryTimer=null;}ticketRealtimeId=0;ticketRealtimePending=0;ticketRealtimeConnected=false;ticketRealtimeConnectPromise=null;ticketRealtimeRetryAttempt=0;ticketServerReadyId=0;ticketReadyPublishedId=0;if(ticketRealtimeConnection){ticketRealtimeConnection.close();ticketRealtimeConnection=null;}configureTicketFallback();known.clear();$('#workspace').classList.add('hidden');$('#blank').classList.add('hidden');$('#homeOverview').style.display='block';$('#sideTitle').textContent='Workspace';$('#sideSubtitle').textContent='Choose a ticket queue';$('#messages').innerHTML='';$('#detailName').textContent='—';$('#detailEmail').textContent='—';$('#detailId').textContent='—';$('#detailPriority').textContent='—';$('#detailStatus').textContent='—';$('#detailAssignedTo').textContent='—';$('#detailIssue').textContent='Select a conversation to view its details.';$('#customerHistory').innerHTML='<span class="muted">Customer history will appear when you open a conversation.</span>';$('#detailAttachments').innerHTML='<span class="muted">No conversation selected</span>';$('#summarySide').textContent='Open a conversation to view or generate its summary.';$('#convertLiveToHck').hidden=true;$('#convertLiveStatus').innerHTML='';$('#convertLiveStatus').hidden=true;$('#convertLiveStatus').classList.remove('is-visible');let u=new URL(window.location.href);u.searchParams.delete('ticket');u.searchParams.set('tab',homeTab||tab);history.replaceState({tab:homeTab||tab},'',u);tab=homeTab||'assigned';loadList();}
 let hcRealtimeConnection=null,hcRealtimeConnectPromise=null,hcRealtimeConnected=false,listTimer=null,ticketTimer=null,hcInboxRetryTimer=null,hcInboxRetryAttempt=0,hcInboxGeneration=0;
 function configureRealtimeFallback(connected){
  hcRealtimeConnected=!!connected;
  if(listTimer)clearInterval(listTimer);listTimer=null;
  // Staff inbox events are the fast lane. A short HTTP reconciliation remains
  // available while the browser reconnects or Cloudflare blocks the SDK.
  {let delay=hcRealtimeConnected?5000:2500;listTimer=setInterval(()=>{if(!document.hidden)loadList(undefined,{silent:true});},delay);}
  configureTicketFallback();configureHckPreviousFallback();configureLiveConversationFallback();
 }
 function scheduleAgentInboxReconnect(){
  if(hcInboxRetryTimer)clearTimeout(hcInboxRetryTimer);
  const delay=Math.min(30000,1000*Math.pow(2,Math.min(hcInboxRetryAttempt++,5)));
  hcInboxRetryTimer=setTimeout(()=>{hcInboxRetryTimer=null;connectAgentInboxRealtime();},delay);
 }
 function connectAgentInboxRealtime(){
  if(hcRealtimeConnectPromise||!window.HCRealtimeClient||!window.Ably){
   if(!window.HCRealtimeClient||!window.Ably){console.error('[HC Support Realtime] Ably SDK or HelpCenter realtime module is missing. Check script requests and Cloudflare Rocket Loader.');configureRealtimeFallback(false);scheduleAgentInboxReconnect();}
   return;
  }
  const generation=++hcInboxGeneration;
  hcRealtimeConnected=false;configureRealtimeFallback(false);
  const pending=window.HCRealtimeClient.connect({ajaxUrl:HCAG.ajax,nonce:HCAG.nonce,channelType:'support',recoveryScope:'helpcenter-agent-inbox'},function(ev,eventName){
   let typingEvent=String(eventName||'').indexOf('typing.')===0;if(typingEvent)return;
   let eventTicket=Number(ev.ticket_id)||0;
   if(active&&eventTicket===Number(active)){requestTicketRefresh();return;}
   if(activeLive&&eventTicket===Number(activeLive)){refreshLiveConversation(activeLive);return;}
   loadList(undefined,{silent:true});
  },function(state,reason){
   if(generation!==hcInboxGeneration)return;
   configureRealtimeFallback(state==='connected');
   if(state==='connected'){
    hcInboxRetryAttempt=0;if(hcInboxRetryTimer){clearTimeout(hcInboxRetryTimer);hcInboxRetryTimer=null;}
    loadList(undefined,{silent:true});if(active)requestTicketRefresh();if(activeLive)refreshLiveConversation(activeLive);
   }else if(state==='failed'||state==='closed'){
    console.error('[HC Support Realtime] Agent inbox connection is terminal; obtaining a fresh token.',reason||'');
    const staleInbox=hcRealtimeConnection;hcRealtimeConnection=null;hcRealtimeConnectPromise=null;hcInboxGeneration++;
    if(staleInbox){try{staleInbox.close();}catch(closeError){}}
    scheduleAgentInboxReconnect();
   }
  }).then(connection=>{
   if(generation!==hcInboxGeneration){connection.close();return null;}
   hcRealtimeConnection=connection;hcInboxRetryAttempt=0;return connection;
  }).catch(error=>{
   if(generation!==hcInboxGeneration)return null;
   console.error('[HC Support Realtime] Agent inbox failed to attach.',error);
   hcRealtimeConnection=null;scheduleAgentInboxReconnect();return null;
  }).finally(()=>{if(generation===hcInboxGeneration)hcRealtimeConnectPromise=null;});
  hcRealtimeConnectPromise=pending;
 }
 connectAgentInboxRealtime();

 function attachmentHTML(m){let a=m.attachment||{},expired=m.attachment_deleted_at||m.attachment_expired||a.expired;if(expired)return `<div class="attachment-expired"><i class="fa-solid fa-clock-rotate-left"></i><span><strong>Attachment expired.</strong> The file was removed from storage under the administrator’s retention policy. Ask the sender to upload it again if needed.</span></div>`;let rawUrl=m.attachment_url||a.url||'',kind=m.attachment_kind||a.kind||'',mime=m.attachment_mime||a.mime||'',rawName=m.attachment_name||a.name||'Attachment';if(!rawUrl)return '';let url=esc(rawUrl),name=esc(rawName);if(kind==='image'||mime.startsWith('image/'))return `<div class="msg-attachment inline-media hc-image-only"><button type="button" class="hc-image-preview-trigger" data-preview-url="${url}" data-preview-name="${name}" data-preview-kind="image" data-preview-mime="${esc(mime)}" aria-label="View ${name}"><img src="${url}" alt="${name}" loading="lazy"></button></div>`;if(kind==='video'||mime.startsWith('video/'))return `<div class="msg-attachment inline-media"><small>Attachment preview · ${name}</small><video src="${url}" controls preload="metadata" playsinline></video></div>`;if(mime==='application/pdf'||mime==='text/plain'||mime==='text/csv')return `<div class="msg-attachment inline-media"><small>Attachment preview · ${name}</small><iframe src="${url}" title="${name}" loading="lazy" sandbox style="width:min(100%,520px);height:340px;border:1px solid #e1e5ef;border-radius:9px;background:#fff"></iframe></div>`;return `<div class="msg-attachment"><span class="file-link"><i class="fa-solid fa-paperclip"></i>${name} · Preview unavailable</span></div>`}
 function conversationLoadingMarkup(title='Loading conversation',detail='Fetching the conversation and customer context…'){return `<div class="hc-modern-loader hc-ticket-loader" role="status" aria-label="${esc(title)}" aria-live="polite"><span class="hc-loader-orb"><i></i><i></i><i></i></span><strong>${esc(title)}</strong><small>${esc(detail)}</small><div class="hc-loader-skeleton"><i></i><i></i><i></i></div></div>`;}
 function fullMessageTime(value){let raw=String(value||'').trim();if(!raw)return 'Time unavailable';let normalized=raw.indexOf('T')>=0?raw:raw.replace(' ','T');let d=new Date(normalized);if(Number.isNaN(d.getTime()))return raw.replace('T',' ');let months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];let day=d.getDate(),suffix=(day===1||day===21||day===31)?'st':(day===2||day===22)?'nd':(day===3||day===23)?'rd':'th';let hour=d.getHours(),ampm=hour>=12?'pm':'am';hour=hour%12||12;let pad=n=>String(n).padStart(2,'0');return months[d.getMonth()]+' '+day+suffix+' '+String(d.getFullYear()).slice(-2)+', '+hour+':'+pad(d.getMinutes())+':'+pad(d.getSeconds())+' '+ampm;}
 function messageSenderType(m){let type=String(m&&m.sender_type||'').trim().toLowerCase();if(type==='visitor'||type==='customer'||type==='guest')return 'customer';if(type==='agent'||type==='support_agent'||type==='staff')return 'agent';return type||'unknown';}
 function messageGroupKey(m){let type=messageSenderType(m),name=String(m&&m.sender_name||'').trim().toLowerCase(),uid=Number(m&&(m.sender_user_id||m.user_id)||0);return type+':'+(uid||name||'unknown');}
 function messageWithinGroup(a,b){if(!a||!b||messageSenderType(a)==='system'||messageSenderType(b)==='system')return false;let ak=String(a.group_key||messageGroupKey(a)),bk=String(b.group_key||messageGroupKey(b));if(ak!==bk)return false;let at=Date.parse(String(a.created_at||'').replace(' ','T')),bt=Date.parse(String(b.created_at||'').replace(' ','T'));return Number.isFinite(at)&&Number.isFinite(bt)&&bt>=at&&(bt-at)<300000;}
 function handoffRead(raw){let lines=String(raw||'').replace(/\r/g,'').split('\n');let out={headline:lines.shift()||'HelpCenter handoff',meta:{},sections:{},counts:[]};let known=['Source conversation','Customer','Transferred by','Transferred at','Handoff reason'];while(lines.length){let line=lines[0]||'';let matched=known.find(k=>line.indexOf(k+':')===0);if(matched){out.meta[matched]=line.slice(matched.length+1).trim();lines.shift();continue;}break;}let headings=['CUSTOMER’S ORIGINAL CONCERN',"CUSTOMER'S ORIGINAL CONCERN",'CONVERSATION BACKGROUND','LATEST CUSTOMER UPDATE','LATEST HUMAN-AGENT UPDATE','EXISTING AI CONVERSATION SUMMARY'];let current='';lines.forEach(line=>{let title=headings.find(h=>line.trim().toUpperCase()===h);if(title){current=title;out.sections[current]=[];return;}if(current)out.sections[current].push(line);else if(line.trim())out.sections['NOTES']=(out.sections['NOTES']||[]).concat([line]);});Object.keys(out.sections).forEach(k=>out.sections[k]=out.sections[k].join('\n').trim());let stats=String(out.sections['CONVERSATION BACKGROUND']||'').match(/Customer messages:\s*(\d+)\s*·\s*AI replies:\s*(\d+)\s*·\s*Human-agent replies:\s*(\d+)\s*·\s*Private notes:\s*(\d+)\s*·\s*System events:\s*(\d+)/i);if(stats)out.counts=[['Customer',stats[1]],['AI replies',stats[2]],['Agent replies',stats[3]],['Private notes',stats[4]],['System events',stats[5]]];if(out.sections['CONVERSATION BACKGROUND'])out.sections['CONVERSATION BACKGROUND']=out.sections['CONVERSATION BACKGROUND'].replace(/^Customer messages:.*\n?/i,'').replace(/The complete imported AI and human-support transcript[\s\S]*$/i,'');return out;}
 function handoffSection(title,icon,body,extra){if(!body)return '';return `<section class="hc-handoff-section ${extra||''}"><h4><i class="fa-solid ${icon}"></i>${esc(title)}</h4><p>${esc(body)}</p></section>`;}
 function handoffAiSections(raw){let value=String(raw||'').replace(/\r/g,'').replace(/This note is private to authorized support agents[\s\S]*$/i,'').trim();if(!value)return '';let re=/(?:^|\s)#{1,4}\s*(Customer(?:’|')s original (?:issue|concern)|Investigation and agent actions|Final resolution and outcome|Outstanding items)\s*[:—-]?\s*/gim,hits=[],m;while((m=re.exec(value))!==null)hits.push({index:m.index,end:re.lastIndex,title:m[1].replace(/\s+/g,' ').trim()});let icon='fa-wand-magic-sparkles';if(!hits.length)return handoffSection('Existing AI conversation summary',icon,value,'is-ai-summary');let html='',intro=value.slice(0,hits[0].index).trim();if(intro)html+=handoffSection('Summary notes',icon,intro,'is-ai-summary');hits.forEach((h,i)=>{let body=value.slice(h.end,i+1<hits.length?hits[i+1].index:value.length).trim();if(body)html+=handoffSection(h.title,icon,body,'is-ai-summary');});return html;}
 function renderHandoffBrief(raw){let d=handoffRead(raw),source=d.meta['Source conversation']||'',customer=d.meta.Customer||'',stats=d.counts.map(x=>`<div class="hc-handoff-stat"><strong>${esc(x[1])}</strong><small>${esc(x[0])}</small></div>`).join('');let meta=[['Customer',customer,'fa-user'],['Transferred by',d.meta['Transferred by']||'—','fa-user-check'],['Transferred at',d.meta['Transferred at']||'—','fa-clock'],['Handoff reason',d.meta['Handoff reason']||'—','fa-arrow-right-arrow-left']].map(x=>`<div class="hc-handoff-meta-item"><small><i class="fa-solid ${x[2]}"></i> ${esc(x[0])}</small><strong>${esc(x[1])}</strong></div>`).join('');let bg=d.sections['CONVERSATION BACKGROUND']||'The original HelpCenter transcript is preserved in the ticket history.';let privacy=(d.sections.NOTES||'This note is private to authorized support agents. It is not sent to the customer. Use the original messages below for the exact wording and chronology.').replace(/^This note is private.*$/gm,'').trim();return `<div class="hc-handoff-card"><header class="hc-handoff-card-head"><div><strong><i class="fa-solid fa-clipboard-check"></i> HelpCenter follow-up summary</strong><small>${esc(source||'Source conversation')} · Internal agent context</small></div><span class="hc-search-kind">Private</span></header><div class="hc-handoff-meta-grid">${meta}</div>${handoffSection('Customer’s original concern','fa-circle-exclamation',d.sections['CUSTOMER’S ORIGINAL CONCERN']||d.sections["CUSTOMER'S ORIGINAL CONCERN"]||'No separate detailed concern was recorded.','is-concern')}<section class="hc-handoff-section"><h4><i class="fa-solid fa-chart-simple"></i> Conversation background</h4><div class="hc-handoff-stats">${stats||''}</div><p style="margin-top:8px">${esc(bg||'Complete transcript retained.')}</p></section><div class="hc-handoff-grid">${handoffSection('Latest customer update','fa-user',d.sections['LATEST CUSTOMER UPDATE']||'No separate customer message was found.')}${handoffSection('Latest human-agent update','fa-headset',d.sections['LATEST HUMAN-AGENT UPDATE']||'No human-agent reply was recorded before handoff.')}</div>${d.sections['EXISTING AI CONVERSATION SUMMARY']?`<div class="hc-handoff-analysis-grid">${handoffAiSections(d.sections['EXISTING AI CONVERSATION SUMMARY'])}</div>`:''}<div class="hc-handoff-privacy"><i class="fa-solid fa-lock"></i> ${esc(privacy||'Internal note only. Never visible to the customer.')}</div></div>`;}
 function messageHTML(m,previous){
  let isAiSummary=m.sender_type==='internal_note'&&String(m.sender_name||'').toLowerCase().indexOf('ai ticket summary')!==-1;
  let cls=m.sender_type==='visitor'||m.sender_type==='customer'?'visitor':m.sender_type==='internal_note'?'note':m.sender_type==='ai'?'ai':m.sender_type==='system'?'system':'agent';
  let name=cls==='ai'?'AI Bot':(m.sender_name||m.sender_type||'Support');
  let nameParts=String(name).trim().split(/\s+/).filter(Boolean);
  let initials=nameParts.slice(0,2).map(part=>part.charAt(0)).join('').toUpperCase()||'?';
  let avatar=cls==='ai'?'<i class="fa-solid fa-robot" aria-hidden="true"></i>':cls==='system'?'<i class="fa-solid fa-circle-info" aria-hidden="true"></i>':esc(initials);
  let who=cls==='ai'?'<i class="fa-solid fa-robot" aria-hidden="true"></i> <span>AI Bot</span>':esc(name);
  let content=(cls==='ai'||isAiSummary)?renderMarkdown(isAiSummary?String(m.content||'').replace(/^(?:AI Ticket Summary|AI handover summary):\s*/i,''):m.content):esc(m.content).replace(/\n/g,'<br>');
  let grouped=messageWithinGroup(previous,m),key=messageGroupKey(m);
  let audit=m.is_edited?`<div class="msg-audit"><i class="fa-solid fa-pen"></i> Edited${m.edited_by_name?' by '+esc(m.edited_by_name):''}</div>`:'';
  let noteActions=m.is_internal_note&&m.can_edit_note?`<div class="hc-note-actions hc-thread-note-actions"><button type="button" data-hck-note-edit="${Number(m.id)||0}"><i class="fa-solid fa-pen"></i> Edit</button><button type="button" data-hck-note-delete="${Number(m.id)||0}"><i class="fa-solid fa-trash"></i> Delete</button></div>`:'';
  if(m.is_deleted)return `<div class="msg note is-deleted" data-message-key="${esc(msgKey(m))}"><div class="msg-content"><div class="msg-text"><i class="fa-solid fa-trash"></i> Private note deleted${m.deleted_by_name?' by '+esc(m.deleted_by_name):''} · ${esc(fullMessageTime(m.deleted_at||m.created_at))}</div></div></div>`;
  return `<div class="msg ${cls}${grouped?' is-grouped':''}${isAiSummary?' hc-ai-summary-message':''}${m.is_initial_concern?' initial-concern':''}" data-message-key="${esc(msgKey(m))}" data-client-message-id="${esc(m.client_message_id||'')}" data-group-key="${esc(key)}" data-created-at="${esc(m.created_at||'')}" data-sender-name="${esc(name)}" data-sender-type="${esc(m.sender_type||'')}" data-sender-user-id="${Number(m.sender_user_id||m.user_id||0)}"><span class="msg-avatar" aria-hidden="true">${avatar}</span><div class="msg-content"><div class="who">${m.is_initial_concern?'<span class="initial-concern-label">ORIGINAL CUSTOMER CONCERN</span> ':''}${who}${m.is_internal_note?'<span class="hc-note-label">Internal note</span>':''}</div><div class="msg-text">${content}</div>${attachmentHTML(m)}${audit}${noteActions}<div class="msg-footer"><time title="${esc(fullMessageTime(m.created_at))}">${esc(fullMessageTime(m.created_at))}</time></div></div></div>`;
 }

 function appendUnique(rows,initial){let added=0,box=$('#messages'),wasNearBottom=box.scrollHeight-box.scrollTop-box.clientHeight<120,previous=null;let lastNode=box.lastElementChild;if(lastNode&&lastNode.classList.contains('msg'))previous={sender_type:lastNode.dataset.senderType|| (lastNode.classList.contains('visitor')?'visitor':lastNode.classList.contains('agent')?'agent':lastNode.classList.contains('ai')?'ai':lastNode.classList.contains('note')?'internal_note':'system'),sender_user_id:lastNode.dataset.senderUserId||0,sender_name:lastNode.dataset.senderName||'',group_key:lastNode.dataset.groupKey,created_at:lastNode.dataset.createdAt};(rows||[]).forEach(m=>{let key=msgKey(m),id=Number(m.id)||0,clientKey=m.client_message_id?'client:'+String(m.client_message_id):'',node=box.querySelector('[data-message-key="'+CSS.escape(key)+'"]');if(!node&&m.client_message_id)node=box.querySelector('[data-client-message-id="'+CSS.escape(String(m.client_message_id))+'"]');if(!node&&id>0&&clientKey)node=box.querySelector('[data-message-key="'+CSS.escape(clientKey)+'"]');if(node){if(id>0){known.delete(clientKey);known.add(key);let html=messageHTML(m,previous),wrap=document.createElement('div');wrap.innerHTML=html;let replacement=wrap.firstElementChild;if(replacement){replacement.dataset.messageKey=key;node.replaceWith(replacement);previous=m;}}return;}if(known.has(key))return;known.add(key);box.insertAdjacentHTML('beforeend',messageHTML(m,previous));previous=m;added++;});if(initial||added){let jump=()=>{box.scrollTop=box.scrollHeight;let last=box.lastElementChild;if(last&&last.scrollIntoView)last.scrollIntoView({block:'end',behavior:'auto'});box.scrollTop=box.scrollHeight};requestAnimationFrame(()=>{jump();requestAnimationFrame(jump)});setTimeout(jump,180);setTimeout(jump,450)}return added;}
 function renderCustomerHistory(h){
  let box=$('#customerHistory');if(!box)return;h=h||{};let tickets=h.tickets||[],convs=h.conversations||[];
  let html='<div class="customer-history-summary"><strong>'+(Number(h.ticket_count)||tickets.length)+'</strong> tickets <span>·</span> <strong>'+(Number(h.conversation_count)||convs.length)+'</strong> HelpCenter conversations</div>';
  function renderGroup(title,items,type){if(!items.length)return '';let groupIcon=type==='tickets'?'fa-ticket':'fa-comments';let out='<section class="hc-history-group" data-history-group="'+type+'"><div class="history-group-title"><i class="fa-solid '+groupIcon+'"></i> '+title+' <span class="hc-history-count">'+items.length+'</span></div><div class="hc-history-items">';items.forEach(x=>{let url='',titleText='',meta='',status=x.status||'Unknown';if(type==='tickets'){url='#';titleText=(x.subject||'Support ticket');meta='#'+Number(x.id)+' · '+(String(x.source||'').indexOf('helpcenter')===0?'HelpCenter':'Ticket Center')+' · '+(x.category||'Uncategorised')+' · '+(x.agent||'Unassigned')+' · Updated '+(x.updated_at||x.created_at||'');}else{let u=new URL(window.location.href);u.searchParams.set('tab','all');u.searchParams.set('ticket',String(x.id));url=u.toString();titleText=(x.title||x.subject||'Support conversation');meta='#'+Number(x.id)+' · '+(x.agent||'Unassigned')+' · '+(x.updated_at||x.created_at||'');}out+=type==='tickets'?'<button type="button" class="history-item hc-history-card hc-history-ticket-card" data-history-card data-hck-ticket="'+Number(x.id)+'"><span class="hc-history-kind-icon ticket-kind"><i class="fa-solid fa-ticket"></i></span><span class="hc-history-card-main"><strong>'+esc(titleText)+'</strong><small><i class="fa-solid fa-hashtag"></i> '+esc(meta)+'</small></span><em class="hc-history-status">'+esc(status)+'</em></button>':'<a class="history-item hc-history-card hc-history-conversation-card" data-history-card href="'+esc(url)+'"><span class="hc-history-kind-icon conversation-kind"><i class="fa-solid fa-comments"></i></span><span class="hc-history-card-main"><strong>'+(titleText?esc(titleText):'<span class="hc-title-pending"><i class="fa-solid fa-wand-magic-sparkles"></i> Preparing title…</span>')+'</strong><small><i class="fa-solid fa-hashtag"></i> '+esc(meta)+'</small></span><em class="hc-history-status">'+esc(status)+'</em></a>';});out+='</div>';if(items.length>10)out+='<button type="button" class="hc-history-more" data-history-more="'+type+'" data-shown="10">Load 10 more <span>('+Math.min(10,items.length-10)+' available)</span></button>';return out+'</section>';}
  html+=renderGroup('Tickets',tickets,'tickets')+renderGroup('HelpCenter conversations',convs,'conversations');if(!tickets.length&&!convs.length)html+='<small class="muted">No previous support records were found for this customer.</small>';box.innerHTML=html;box.querySelectorAll('[data-history-group]').forEach(group=>group.querySelectorAll('[data-history-card]').forEach((card,i)=>{if(i>=10)card.hidden=true;}));
 }
 $('#customerHistory')?.addEventListener('click',function(e){let btn=e.target.closest('[data-history-more]');if(!btn)return;let group=btn.closest('[data-history-group]');if(!group)return;let shown=Number(btn.dataset.shown)||10,next=shown+10,cards=group.querySelectorAll('[data-history-card]');cards.forEach((card,i)=>{if(i<next)card.hidden=false;});btn.dataset.shown=String(next);let remaining=Math.max(0,cards.length-next);if(!remaining)btn.remove();else btn.innerHTML='Load 10 more <span>('+Math.min(10,remaining)+' available)</span>';});

 function resetTicketDetailsForLoading(id){
  const receipt=$('#handoffBanner');if(receipt){receipt.hidden=true;receipt.removeAttribute('data-ticket-id');}
  // Clear every customer/ticket-specific field immediately. Never leave the previous
  // customer's details visible while a new ticket request is in flight.
  const set=(selector,value)=>{let el=$(selector);if(el)el.textContent=value;};
  set('#ticketTitle','Loading ticket #'+id);set('#ticketMeta','Loading customer and conversation details…');
  ['#detailName','#detailEmail','#detailPhone','#contextCustomerName','#contextCustomerEmail','#detailStatus','#detailAssignedTo','#detailAssignedToAdditional'].forEach(sel=>set(sel,'Loading…'));set('#detailId','#'+id);
  set('#detailIssue','Loading original customer concern…');set('#detailPriority','—');set('#agentSlaLabel','Loading SLA…');set('#agentSlaDetail','Retrieving ticket service-level information…');
  const htmlDefaults={'#customerHistory':'<span class=\"muted\">Loading customer history…</span>','#detailAttachments':'<span class=\"muted\">Loading attachments…</span>','#summarySide':'<span class=\"muted\">Loading AI summary…</span>','#ticketActivity':'<div class=\"muted\">Loading timeline…</div>','#privateNotesList':'<div class=\"muted\">Loading private notes…</div>','#sideConversationList':'<div class=\"muted\">Loading side conversations…</div>'};
  Object.entries(htmlDefaults).forEach(([sel,html])=>{let el=$(sel);if(el)el.innerHTML=html;});
  set('#contextAvatar','…');
  ['#prioritySelect','#ticketStatusSelect','#subStatusSelect','#ticketTagsInput','#saveTicketMeta','#editCustomer','#editCustomerInline','#composeEmail','#newSideConversation','#openInternalNoteModal','#assignTicket','#generateSummary'].forEach(sel=>{let el=$(sel);if(el)el.disabled=true;});
  if($('#prioritySelect'))$('#prioritySelect').value='normal';if($('#ticketStatusSelect'))$('#ticketStatusSelect').value='active';if($('#subStatusSelect'))$('#subStatusSelect').value='';if($('#ticketTagsInput'))$('#ticketTagsInput').value='';
  $('#editTicketTitle').hidden=true;$('#claim').hidden=true;$('#close').hidden=true;$('#closedBanner').classList.add('hidden');
  let assignSearch=$('#assignAgentSearch');if(assignSearch)assignSearch.value='';
  let assign=$('#assignAgent');if(assign){assign.innerHTML='<option value=\"0\">Loading agents…</option>';assign.disabled=true;}
  let convert=$('#convertLiveStatus');if(convert){convert.innerHTML='';convert.hidden=true;convert.classList.remove('is-visible');}
  $('#hcLiveSupportInfoCard').hidden=true;$('#handoffBanner').hidden=true;$('#hckHandoffBrief').hidden=true;$('#hckHandoffBriefBody').textContent='';
 }
 async function openTicket(id,incremental=false){id=Number(id)||0;if(!id)return;if(activeHck&&incremental)return;if(!incremental){if(liveConversationTimer)clearInterval(liveConversationTimer);liveConversationTimer=null;if(hckPreviousTimer)clearInterval(hckPreviousTimer);hckPreviousTimer=null;clearStagedAgentFiles();activeHck=0;$('#hckHandoffBrief').hidden=true;$('#hckHandoffBriefBody').textContent='';if(layout.classList.contains('home-mode')){homeTab=tab==='closed'?'closed':'assigned';}$('#sideTitle').textContent=tab==='closed'?'Closed by Me':'Assigned to Me';$('#sideSubtitle').textContent=tab==='closed'?'Conversations closed by you':'Your active conversations';document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===tab));layout.classList.remove('home-mode','inbox-open');layout.classList.add('ticket-mode');$('#homeOverview').style.display='none';}if(pollBusy&&incremental){ticketRefreshQueued=true;return;}if(!incremental){if(window.matchMedia('(min-width: 1121px)').matches){layout.classList.remove('details-collapsed');$('#toggleDetails')?.setAttribute('aria-expanded','true');}else{layout.classList.remove('details-open');$('#toggleDetails')?.setAttribute('aria-expanded','false');}}const seq=++requestSeq;if(!incremental){$('#hcLiveSupportInfoCard').hidden=true;activeLive=0;activeHckOriginConverted=false;$('#handoffBanner').hidden=true;$('#workspace').classList.remove('hc-followup-created');$('#convertLiveToHck').hidden=true;$('#convertLiveToHck').disabled=false;$('#convertLiveToHck').innerHTML='<i class="fa-solid fa-ticket" aria-hidden="true"></i><span>Create follow-up ticket</span>';after=0;aiAfter=0;active=id;activityTimelineRows=[];liveAfter=0;liveAiAfter=0;resetTicketDetailsForLoading(id);ticketServerReadyId=0;ticketReadyPublishedId=0;connectTicketRealtime(id).catch(error=>console.warn('[HelpCenter Ably] Ticket connection initialization failed; the send path will retry readiness.',error));known.clear();let u=new URL(window.location.href);u.searchParams.set('ticket',String(id));u.searchParams.set('tab',tab);history.replaceState({ticket:id,tab:tab},'',u);$('#messages').innerHTML=conversationLoadingMarkup('Loading conversation','Fetching the conversation, latest replies and customer context…');$('#replyText').disabled=true;$('#composer').classList.add('hc-composer-loading');}pollBusy=true;$('#blank').classList.add('hidden');$('#workspace').classList.remove('hidden');layout.classList.add('open','ticket-mode');try{let r=await post('hc_agent_ticket',{ticket_id:id,after_id:incremental?after:0,ai_after_id:incremental?aiAfter:0,search:searchMode?1:0,view_all:(tab==='all'||searchMode||!!(tickets.find(x=>Number(x.id)===Number(id))||{}).view_only)?1:0,initial_latest:!incremental?1:0});searchMode=false;if(seq!==requestSeq)return;if(!r.success){$('#replyText').disabled=false;$('#composer').classList.remove('hc-composer-loading');$('#messages').innerHTML='<div class="empty"><p>'+esc(r.data?.message||'Unable to open ticket')+'</p><button class="btn" type="button" id="retryTicketLoad">Retry loading</button></div>';$('#retryTicketLoad')?.addEventListener('click',()=>openTicket(id,false));return;}let d=r.data;if(!d||!d.ticket||Number(d.ticket.id)!==Number(id)){throw new Error('The ticket details response was incomplete. Refresh the inbox and open the ticket again.');}if(d.can_handle){ticketServerReadyId=Number(id);publishAgentReady(id);}d.messages=Array.isArray(d.messages)?d.messages:[];$('#replyText').disabled=!d.can_handle;$('#composer').classList.toggle('hidden',!d.can_handle);$('#close').hidden=!d.can_handle;$('#composer').classList.remove('hc-composer-loading');if(d.sla)paintAgentSla(d.sla);setComposerMode('reply');let inboxItem=tickets.find(x=>Number(x.id)===Number(id));let linkedLive=!!(inboxItem&&inboxItem.has_live);
 // The issue column is the authoritative copy of the customer's original handoff concern.
 // Always reconcile it into the visible transcript; do not rely on the message-table row existing.
 if(!incremental&&d&&d.ticket){
  const original=String(d.ticket.issue||'').trim();
  const norm=v=>String(v||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase();
  if(original){
   const key=norm(original);let match=(d.messages||[]).find(m=>m.sender_type==='visitor'&&(norm(m.content)===key||norm(m.content).startsWith(key)));
   if(match){match.is_initial_concern=true;match.message_key=match.message_key||('initial-concern:'+Number(id));}
   else {d.messages=d.messages||[];d.messages.push({id:-Math.abs(Number(id)),message_key:'initial-concern:'+Number(id),source_type:'initial_concern',sender_type:'visitor',sender_name:d.ticket.visitor_name||'Customer',content:original,created_at:d.ticket.created_at||inboxItem?.created_at||(d.messages||[]).map(m=>String(m.created_at||'')).filter(Boolean).sort().slice(-1)[0]||'',is_initial_concern:true});}
   d.messages.sort((a,b)=>{let at=String(a.created_at||''),bt=String(b.created_at||'');let cmp=at.localeCompare(bt);if(cmp)return cmp;if(a.is_initial_concern&&!b.is_initial_concern)return -1;if(b.is_initial_concern&&!a.is_initial_concern)return 1;return String(a.message_key||a.id||'').localeCompare(String(b.message_key||b.id||''));});
  }
 }
if(linkedLive&&!incremental){try{let liveResponse=await post('hc_agent_live_ticket',{conversation_id:id});if(seq!==requestSeq||Number(active)!==Number(id))return;if(liveResponse.success&&Array.isArray(liveResponse.data.messages)){let merged=new Map();(d.messages||[]).forEach(m=>merged.set(msgKey(m),m));liveResponse.data.messages.forEach(m=>{let key=msgKey(m);if(!m.message_key)m.message_key=key;let existing=merged.get(key);if(existing){merged.set(key,Object.assign({},m,existing));}else merged.set(key,m);});d.messages=Array.from(merged.values()).sort((a,b)=>{let c=String(a.created_at||'').localeCompare(String(b.created_at||''));if(c)return c;if(a.is_initial_concern&&!b.is_initial_concern)return -1;if(b.is_initial_concern&&!a.is_initial_concern)return 1;return String(a.message_key||'').localeCompare(String(b.message_key||''));});}}catch(liveErr){console.warn('Could not merge complete live transcript; standard ticket transcript retained.',liveErr);}}activeLive=linkedLive?Number(id):0;liveAfter=0;liveAiAfter=0;$('#hcLiveSupportInfoCard').hidden=!linkedLive;configureLiveConversationFallback();$('#convertLiveToHck').hidden=!linkedLive;$('#convertLiveToHck').disabled=!linkedLive;$('#convertLiveToHck').innerHTML='<i class="fa-solid fa-ticket" aria-hidden="true"></i><span>Create follow-up ticket</span>';$('#workspace').classList.remove('hc-followup-created');$('#convertLiveStatus').innerHTML='';$('#convertLiveStatus').hidden=true;$('#convertLiveStatus').classList.remove('is-visible');after=Math.max(after,Number(d.last_id)||0);aiAfter=Math.max(aiAfter,Number(d.last_ai_id)||0);$('#editTicketTitle').hidden=false;$('#ticketTitle').textContent=d.ticket.title||('Preparing title… · #'+d.ticket.id);$('#ticketMeta').textContent='#'+d.ticket.id+' · '+(d.ticket.visitor_name||'Customer')+' · '+(d.ticket.visitor_email||'No email')+' · '+d.ticket.status;if(Array.isArray(d.agents)){assignmentAgents=d.agents;renderAssignmentAgents(d.ticket.assigned_agent_id||0);}$('#detailAssignedTo').textContent=d.ticket.assigned_agent_name||(assignmentAgents.find(a=>Number(a.id)===Number(d.ticket.assigned_agent_id))||{}).name||(Number(d.ticket.assigned_agent_id)?'Assigned agent':'Unassigned');if($('#detailAssignedToAdditional'))$('#detailAssignedToAdditional').textContent=$('#detailAssignedTo').textContent;$('#assignTicket').disabled=d.ticket.status==='closed'||d.ticket.status==='archived'||d.ticket.status==='converted';if($('#summarySide'))$('#summarySide').innerHTML=d.ticket.ai_summary?'<article class="hc-ai-summary-card"><div class="hc-ai-summary-card-head"><i class="fa-solid fa-wand-magic-sparkles"></i> Final conversation summary</div><div class="hc-ai-summary-content">'+renderMarkdown(d.ticket.ai_summary)+'</div></article>':'No summary generated yet.';$('#detailName').textContent=d.ticket.visitor_name||'—';$('#detailEmail').textContent=d.ticket.visitor_email||'—';if(typeof d.ticket.customer_phone!=='undefined')$('#detailPhone').textContent=d.ticket.customer_phone||'Not available';$('#detailId').textContent='#'+d.ticket.id;$('#detailPriority').innerHTML='<span class="priority">'+esc(d.ticket.priority||'normal')+'</span>';if($('#prioritySelect'))$('#prioritySelect').value=['low','normal','high','urgent'].includes(String(d.ticket.priority||'normal').toLowerCase())?String(d.ticket.priority||'normal').toLowerCase():'normal';if($('#ticketStatusSelect'))$('#ticketStatusSelect').value=['active','waiting_customer'].includes(String(d.ticket.status||'').toLowerCase())?String(d.ticket.status).toLowerCase():'active';$('#detailStatus').textContent=d.ticket.status||'—';$('#detailIssue').textContent=d.ticket.issue||'No issue description provided.';if(typeof d.customer_history!=='undefined')renderCustomerHistory(d.customer_history);let rows=d.messages||[];let added=0;if(!incremental){activityTimelineRows=rows.slice();$('#messages').innerHTML='';added=appendUnique(rows,true);}else{activityTimelineRows=activityTimelineRows.concat(rows);let activitySeen=new Set();activityTimelineRows=activityTimelineRows.filter(m=>{let k=msgKey(m);if(activitySeen.has(k))return false;activitySeen.add(k);return true;});}renderTicketActivity(activityTimelineRows);if(incremental){let nearBottom=$('#messages').scrollHeight-$('#messages').scrollTop-$('#messages').clientHeight<100;added=appendUnique(rows,false);if(nearBottom&&added)$('#messages').scrollTop=$('#messages').scrollHeight;let incomingCustomer=rows.filter(m=>m.sender_type==='visitor');if(added&&incomingCustomer.length){let last=incomingCustomer[incomingCustomer.length-1];notifyAgent('New customer message','#'+id+' · '+String(last.content||'New message received').replace(/\s+/g,' ').slice(0,115),id,'message:'+id+':'+msgKey(last));}}if(!incremental){requestAnimationFrame(()=>$('#messages').scrollTop=$('#messages').scrollHeight);setTimeout(()=>$('#messages').scrollTop=$('#messages').scrollHeight,250);$('#messages').querySelectorAll('img').forEach(img=>{if(!img.complete)img.addEventListener('load',()=>$('#messages').scrollTop=$('#messages').scrollHeight,{once:true})});}
 let at=rows.filter(m=>m.attachment_url||m.attachment_expired||m.attachment_deleted_at||(m.attachment&&m.attachment.url));$('#detailAttachments').innerHTML=at.length?at.map(m=>attachmentHTML(m)).join(''):'<span class="muted">No attachments</span>';$('#contextCustomerName').textContent=d.ticket.visitor_name||'Customer';$('#contextCustomerEmail').textContent=d.ticket.visitor_email||'No email on file';$('#contextAvatar').textContent=(d.ticket.visitor_name||'C').trim().charAt(0).toUpperCase();if(!incremental)loadWorkspaceExtras(active,rows,d.ticket);let closed=d.ticket.status==='closed'||d.ticket.status==='archived';let canHandle=!!d.can_handle;['prioritySelect','ticketStatusSelect','subStatusSelect','ticketTagsInput','saveTicketMeta','editCustomer','editCustomerInline','composeEmail','newSideConversation','openInternalNoteModal'].forEach(id=>{let el=$('#'+id);if(el)el.disabled=!canHandle;});$('#closedBanner').classList.toggle('hidden',canHandle);$('#closedBanner').textContent=canHandle?'':(closed?'This ticket is closed and available for historical viewing.':(d.ticket.status==='converted'?'This conversation was transferred to an HCK ticket and is now read-only.':'This ticket is assigned to another agent. You can view its history, but only the assigned agent can reply or change its status.'));$('#claim').hidden=!(d.ticket.status==='closed'&&tab==='closed');$('#claim').disabled=false;$('#close').hidden=!canHandle;$('#composer').classList.toggle('hidden',!canHandle);$('#assignTicket').disabled=!canHandle;if($('#generateSummary'))$('#generateSummary').disabled=!canHandle;
 }catch(e){if(!incremental){$('#replyText').disabled=false;$('#composer').classList.remove('hc-composer-loading');$('#messages').innerHTML='<div class="empty"><p>'+esc(e.message||'Could not load this conversation. Please retry.')+'</p><button class="btn" type="button" id="retryTicketLoad">Retry loading</button></div>';$('#retryTicketLoad')?.addEventListener('click',()=>openTicket(id,false));}}finally{if(seq===requestSeq){pollBusy=false;if(ticketRefreshQueued&&active){ticketRefreshQueued=false;window.setTimeout(()=>{if(active&&!pollBusy)openTicket(active,true)},0);}}}}
 async function openLiveTicket(id){if(liveConversationTimer)clearInterval(liveConversationTimer);liveConversationTimer=null;$('#hckHandoffBrief').hidden=true;$('#hckHandoffBriefBody').textContent='';$('#handoffBanner').hidden=true;$('#workspace').classList.remove('hc-followup-created');$('#convertLiveToHck').hidden=true;$('#convertLiveToHck').disabled=false;$('#convertLiveToHck').innerHTML='<i class="fa-solid fa-ticket" aria-hidden="true"></i><span>Create follow-up ticket</span>';activeLive=Number(id)||0;active=0;activityTimelineRows=[];known.clear();after=0;aiAfter=0;requestSeq++;if(!activeLive)return;if(window.matchMedia('(min-width: 1121px)').matches){layout.classList.remove('details-collapsed');$('#toggleDetails')?.setAttribute('aria-expanded','true');}else{layout.classList.remove('details-open');$('#toggleDetails')?.setAttribute('aria-expanded','false');}layout.classList.add('open');$('#blank').classList.add('hidden');$('#workspace').classList.remove('hidden');$('#messages').innerHTML=conversationLoadingMarkup('Loading live conversation','Restoring the live chat history and attachments…');$('#ticketTitle').textContent='Live conversation #'+activeLive;$('#editTicketTitle').hidden=true;$('#ticketMeta').textContent='HelpCenter human support · Read and convert';$('#composer').classList.add('hidden');$('#claim').hidden=true;$('#close').hidden=true;$('#closedBanner').classList.add('hidden');if($('#generateSummary'))$('#generateSummary').disabled=true;try{let r=await post('hc_agent_live_ticket',{conversation_id:activeLive});if(!r.success)throw new Error(r.data?.message||'Could not load live conversation');let d=r.data,t=d.ticket;paintAgentSla(d.sla);setComposerMode('reply');crmContextTab('details');crmPrivateNotes=[];crmSideRows=[];renderPrivateNotes();renderSideRows();
 // Defensive client reconciliation for legacy live-conversation rows.
 const liveIssue=String(t.issue||'').trim();
 const liveNorm=v=>String(v||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase();
 if(liveIssue){let first=(d.messages||[]).find(m=>m.sender_type==='visitor'&&(liveNorm(m.content)===liveNorm(liveIssue)||liveNorm(m.content).startsWith(liveNorm(liveIssue))));if(first)first.is_initial_concern=true;else{d.messages=d.messages||[];d.messages.push({id:-Math.abs(Number(id)),message_key:'initial-concern:'+Number(id),sender_type:'visitor',sender_name:t.visitor_name||'Customer',content:liveIssue,created_at:t.created_at||(d.messages||[]).map(m=>String(m.created_at||'')).filter(Boolean).sort().slice(-1)[0]||'',is_initial_concern:true});}}
 $('#detailName').textContent=t.visitor_name||'—';$('#detailEmail').textContent=t.visitor_email||'—';$('#detailPhone').textContent=t.customer_phone||'Not available';$('#contextCustomerName').textContent=t.visitor_name||'Customer';$('#contextCustomerEmail').textContent=t.visitor_email||'No email on file';$('#contextAvatar').textContent=(t.visitor_name||'C').trim().charAt(0).toUpperCase();$('#detailId').textContent='#'+t.id;$('#detailPriority').innerHTML='<span class="priority">'+esc(t.priority||'normal')+'</span>';$('#detailStatus').textContent=t.status||'—';['prioritySelect','ticketStatusSelect','subStatusSelect','ticketTagsInput','saveTicketMeta','editCustomer','editCustomerInline','composeEmail','newSideConversation','openInternalNoteModal'].forEach(id=>{let el=$('#'+id);if(el)el.disabled=true;});$('#detailAssignedTo').textContent=t.assigned_agent_name||'Assigned agent';$('#detailIssue').textContent=t.issue||'No issue description provided.';renderCustomerHistory(d.customer_history);$('#convertLiveToHck').hidden=false;$('#convertLiveToHck').disabled=false;$('#convertLiveStatus').innerHTML='<div class="hc-live-info-title"><i class="fa-solid fa-arrow-right-arrow-left"></i><span>Conversation handoff</span></div><p>Transfer the complete chat and attachments to an HCK ticket. The original conversation will then become read-only.</p>';$('#convertLiveStatus').hidden=false;$('#convertLiveStatus').classList.add('is-visible');activityTimelineRows=(d.messages||[]).slice();renderTicketActivity(activityTimelineRows);let liveFiles=(d.messages||[]).filter(m=>m.attachment_path&&m.attachment_name);$('#detailAttachments').innerHTML=liveFiles.length?liveFiles.map(m=>'<div class="detail-row"><span><i class="fa-solid fa-paperclip"></i> '+esc(m.attachment_name)+'</span><small>'+esc(m.attachment_mime||'Attachment')+'</small></div>').join(''):'<span class="muted">No attachments. The full transcript will be transferred.</span>'; $('#summarySide').textContent='Live conversation transcript';$('#messages').innerHTML='';(d.messages||[]).sort((a,b)=>{let c=String(a.created_at||'').localeCompare(String(b.created_at||''));if(c)return c;if(a.is_initial_concern&&!b.is_initial_concern)return -1;if(b.is_initial_concern&&!a.is_initial_concern)return 1;return Number(a.id||0)-Number(b.id||0)}).forEach(m=>{let who=m.sender_type==='visitor'?'visitor':(m.sender_type==='ai'?'ai':(m.sender_type==='internal_note'?'internal_note':'agent'));let row={id:m.id,message_key:m.message_key||('live:'+m.id),is_initial_concern:!!m.is_initial_concern,sender_type:m.sender_type,sender_name:m.sender_name,content:m.content,created_at:m.created_at,attachment_url:m.attachment_url,attachment_name:m.attachment_name,attachment_mime:m.attachment_mime,attachment_kind:m.attachment_kind,is_initial_concern:!!m.is_initial_concern};if(m.attachment_name)row.content=(row.content?row.content+'\n':'')+'Attachment: '+m.attachment_name;let liveKey=msgKey(row);if(!known.has(liveKey)){known.add(liveKey);$('#messages').insertAdjacentHTML('beforeend',messageHTML(row));}});if(!d.messages?.length)$('#messages').innerHTML='<div class="empty">No messages found.</div>';let liveMessages=$('#messages');let jumpLive=()=>{liveMessages.scrollTop=liveMessages.scrollHeight;let last=liveMessages.lastElementChild;if(last&&last.scrollIntoView)last.scrollIntoView({block:'end',behavior:'auto'});liveMessages.scrollTop=liveMessages.scrollHeight};jumpLive();requestAnimationFrame(()=>{jumpLive();requestAnimationFrame(jumpLive)});setTimeout(jumpLive,180);setTimeout(jumpLive,500);$('#messages').querySelectorAll('img').forEach(img=>{if(!img.complete)img.addEventListener('load',()=>$('#messages').scrollTop=$('#messages').scrollHeight,{once:true})});configureLiveConversationFallback();}catch(e){$('#messages').innerHTML='<div class="empty">'+esc(e.message||'Unable to load live conversation')+'</div>';$('#convertLiveToHck').hidden=true;}}
 function showHandoffBanner(data){
  const banner=$('#handoffBanner');if(!banner)return;
  const number=String(data.ticket_number||('HCK-'+(data.ticket_id||'')));
  const source=Number(data.source_id||active||0);
  $('#handoffTitle').textContent='Your follow-up ticket is ready';
  $('#handoffTicketNumber').textContent=number;
  $('#handoffDescription').textContent='Created from HelpCenter conversation #'+source+'. Continue all customer replies in this HCK ticket.';
  const meta=$('#handoffMeta');
  if(meta){
   const row=(icon,label,ok,yes,no)=>'<span><i class="fa-solid '+icon+'" aria-hidden="true"></i><span>'+label+'</span><strong class="'+(ok?'is-accepted':'is-unconfirmed')+'">'+(ok?yes:no)+'</strong></span>';
   meta.innerHTML=row('fa-envelope','Ticket access email',!!data.email_sent,'Accepted','Not confirmed')+row('fa-paper-plane','Follow-up email',!!data.followup_email_sent,'Accepted','Not confirmed')+row('fa-lock','Original conversation',true,'Read-only','Read-only');
  }
  banner.dataset.ticketId=String(Number(data.ticket_id)||0);
  banner.hidden=false;
  const action=$('#handoffContinue');if(action){action.onclick=()=>{const brief=$('#hckHandoffBrief');if(brief)brief.open=false;const composer=$('#composer');if(composer&&!composer.classList.contains('hidden')){composer.scrollIntoView({behavior:'smooth',block:'nearest'});window.setTimeout(()=>$('#replyText')?.focus({preventScroll:true}),250);}else $('#messages')?.scrollIntoView({behavior:'smooth',block:'start'});};}
  const convert=$('#convertLiveToHck');if(convert){convert.hidden=true;convert.disabled=true;convert.innerHTML='<i class="fa-solid fa-ticket" aria-hidden="true"></i><span>Create follow-up ticket</span>';}
  $('#workspace')?.classList.add('hc-followup-created');
 }
 function confirmLiveFollowup(conversationId){
  return new Promise(resolve=>{
   let overlay=document.getElementById('hcFollowupConfirm');
   if(!overlay){
    overlay=document.createElement('div');overlay.id='hcFollowupConfirm';overlay.className='hc-followup-confirm';overlay.hidden=true;
    overlay.innerHTML='<section class="hc-followup-dialog" role="dialog" aria-modal="true" aria-labelledby="hcFollowupConfirmTitle" aria-describedby="hcFollowupConfirmDescription"><header class="hc-followup-dialog-head"><span class="hc-followup-dialog-icon"><i class="fa-solid fa-ticket"></i></span><div><small class="hc-followup-eyebrow">TICKET HANDOFF</small><h2 id="hcFollowupConfirmTitle">Create a follow-up ticket?</h2><p id="hcFollowupConfirmDescription">Review what will move to HCK before you continue.</p></div><button type="button" class="hc-followup-x" data-followup-cancel aria-label="Close"><i class="fa-solid fa-xmark"></i></button></header><div class="hc-followup-confirm-details"><small>ORIGINAL CONVERSATION</small><strong>HelpCenter conversation #'+Number(conversationId)+'</strong><p>The new HCK ticket will keep the customer&rsquo;s support history together.</p></div><div class="hc-followup-transfer-list"><div><i class="fa-solid fa-comments"></i><span><strong>Conversation history</strong><small>AI and human-agent messages</small></span><i class="fa-solid fa-check"></i></div><div><i class="fa-solid fa-paperclip"></i><span><strong>Available attachments</strong><small>Files associated with the conversation</small></span><i class="fa-solid fa-check"></i></div><div><i class="fa-solid fa-clipboard-list"></i><span><strong>Agent handoff brief</strong><small>Private context for the HCK support team</small></span><i class="fa-solid fa-check"></i></div><div><i class="fa-solid fa-envelope"></i><span><strong>Customer notification</strong><small>Ticket access email is attempted after creation; delivery status is reported</small></span><i class="fa-solid fa-check"></i></div></div><div class="hc-followup-warning"><i class="fa-solid fa-triangle-exclamation"></i><span><strong>This action changes the original conversation to read-only.</strong> All further customer replies must continue in the new HCK ticket.</span></div><div class="hc-followup-dialog-actions"><button type="button" data-followup-cancel>Cancel</button><button type="button" class="is-confirm" data-followup-confirm><i class="fa-solid fa-arrow-right"></i> Create follow-up ticket</button></div></section>';
    document.body.appendChild(overlay);
   }
   let settled=false;const finish=value=>{if(settled)return;settled=true;overlay.hidden=true;document.removeEventListener('keydown',onKey);hcSyncModalLock();resolve(value);};
   const onKey=e=>{if(e.key==='Escape'){e.preventDefault();finish(false);}if(e.key==='Tab'){let buttons=overlay.querySelectorAll('button:not([disabled])'),first=buttons[0],last=buttons[buttons.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}};
   overlay.hidden=false;document.body.classList.add('hc-modal-open');overlay.querySelectorAll('[data-followup-cancel]').forEach(button=>button.onclick=()=>finish(false));overlay.querySelector('[data-followup-confirm]').onclick=()=>finish(true);overlay.onclick=e=>{if(e.target===overlay)finish(false);};document.addEventListener('keydown',onKey);overlay.querySelector('[data-followup-confirm]').focus();
  });
 }
 $('#convertLiveToHck')?.addEventListener('click',async()=>{
  let id=activeLive,btn=$('#convertLiveToHck');if(!id||btn.disabled)return;
  const approved=await confirmLiveFollowup(id);if(!approved)return;
  if(id!==activeLive||btn.disabled)return;
  let createdReceipt=null;
  btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i><span>Creating follow-up…</span>';
  $('#convertLiveStatus').textContent='Transferring the complete conversation…';
  try{
   let r=await post('hc_agent_live_convert',{conversation_id:id});
   if(!r.success)throw new Error(r.data?.message||'Ticket conversion failed.');
   const hckId=Number(r.data.ticket_id||0);
   if(!hckId)throw new Error('The follow-up was created, but the server did not return its ticket ID.');
   createdReceipt={ticket_id:hckId,ticket_number:r.data.ticket_number,source_id:id,email_sent:!!r.data.email_sent,followup_email_sent:!!r.data.followup_email_sent};
   activeHckOriginConverted=true;
   if(liveConversationTimer)clearInterval(liveConversationTimer);liveConversationTimer=null;
   btn.hidden=true;btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-ticket" aria-hidden="true"></i><span>Create follow-up ticket</span>';
   $('#convertLiveStatus').innerHTML='';$('#convertLiveStatus').hidden=true;$('#convertLiveStatus').classList.remove('is-visible');
   const opened=await openHckPreviousTicket(hckId,false);
   activeHckOriginConverted=true;
   showHandoffBanner(createdReceipt);
   if(!opened){$('#handoffDescription').textContent+=' The ticket was created, but its workspace could not be loaded. Open it from your HCK ticket queue.';}
  }catch(e){
   if(createdReceipt){
    activeHckOriginConverted=true;btn.hidden=true;btn.disabled=true;showHandoffBanner(createdReceipt);
    $('#handoffDescription').textContent+=' The ticket exists, but could not be opened automatically. Open '+createdReceipt.ticket_number+' from your HCK ticket queue.';
   }else{
    $('#convertLiveStatus').textContent=e.message||'Conversion failed.';$('#convertLiveStatus').hidden=false;
    btn.disabled=false;btn.hidden=false;btn.innerHTML='<i class="fa-solid fa-ticket"></i><span>Create follow-up ticket</span>';
   }
  }
 });
 let searchMode=false;
 function renderAssignmentAgents(selected){let sel=$('#assignAgent');if(!sel)return;let term=($('#assignAgentSearch')?.value||'').trim().toLowerCase();let filtered=assignmentAgents.filter(a=>!term||String(a.name||'').toLowerCase().includes(term)||String(a.email||'').toLowerCase().includes(term)||String(a.login||'').toLowerCase().includes(term));let selectedAgent=assignmentAgents.find(a=>Number(a.id)===Number(selected));if(selectedAgent&&!filtered.some(a=>Number(a.id)===Number(selected)))filtered.unshift(selectedAgent);let options=[{id:0,label:'Unassigned queue',eligible:true}];filtered.forEach(a=>{let active=Number(a.active)||0,capacity=Math.max(1,Number(a.capacity)||1),isCurrent=Number(a.id)===Number(selected),eligible=isCurrent||(!!a.online&&active<capacity);options.push({id:Number(a.id),label:esc(a.name)+(a.online?' · Available':' · Offline')+' · '+active+'/'+capacity+' tickets'+(isCurrent?' · Current owner':''),eligible:eligible});});sel.innerHTML=options.map(o=>'<option value="'+o.id+'" '+(o.eligible?'':'disabled')+'>'+o.label+'</option>').join('');let wanted=String(selected||0);if(Array.from(sel.options).some(o=>o.value===wanted&&!o.disabled))sel.value=wanted;else if(!Array.from(sel.options).some(o=>o.value===sel.value&&!o.disabled))sel.value='0';let value=$('#hcAssignmentPickerValue'),list=$('#hcAssignmentAgentOptions');if(value){let chosen=Array.from(sel.options).find(o=>o.value===sel.value);value.textContent=chosen?chosen.textContent:'Choose an agent or queue…';}if(list){list.innerHTML=options.map(o=>'<button type="button" class="hc-assignment-agent-option" role="option" data-agent-id="'+o.id+'" aria-selected="'+(String(o.id)===sel.value?'true':'false')+'" '+(o.eligible?'':'disabled')+'><span>'+o.label+'</span><i class="fa-solid fa-check"></i></button>').join('')||'<div class="hc-assignment-empty">No matching agents</div>';}}
 $('#assignAgentSearch')?.addEventListener('input',()=>renderAssignmentAgents($('#assignAgent')?.value||0));
 $('#hcAssignmentPickerToggle')?.addEventListener('click',()=>{let panel=$('#hcAssignmentPickerPanel'),button=$('#hcAssignmentPickerToggle');if(!panel)return;panel.hidden=!panel.hidden;button.setAttribute('aria-expanded',panel.hidden?'false':'true');if(!panel.hidden){$('#assignAgentSearch').value='';renderAssignmentAgents($('#assignAgent')?.value||0);$('#assignAgentSearch').focus();}});
 $('#hcAssignmentAgentOptions')?.addEventListener('click',e=>{let option=e.target.closest('[data-agent-id]');if(!option||option.disabled)return;let select=$('#assignAgent');select.value=String(option.dataset.agentId);renderAssignmentAgents(Number(select.value));$('#hcAssignmentPickerPanel').hidden=true;$('#hcAssignmentPickerToggle').setAttribute('aria-expanded','false');});
 document.addEventListener('click',e=>{let picker=$('#hcAssignmentPicker');if(picker&&!picker.contains(e.target)){let panel=$('#hcAssignmentPickerPanel');if(panel&&!panel.hidden){panel.hidden=true;$('#hcAssignmentPickerToggle').setAttribute('aria-expanded','false');}}});
 $('#tickets').addEventListener('click',async e=>{let t=e.target.closest('[data-id]');if(t){openTicket(t.dataset.id);}});$('#homeTickets')?.addEventListener('click',async e=>{let t=e.target.closest('[data-id]');if(!t)return;let id=Number(t.dataset.id);homeTab=tab;document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===tab));layout.classList.remove('home-mode','inbox-open');layout.classList.add('ticket-mode');$('#homeOverview').style.display='none';await loadList();openTicket(id,false);});document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));tab=b.dataset.tab;homeTab=tab;known.clear();tickets=[];ticketSnapshots.clear();listLoaded=false;goHome()});$('#back').onclick=()=>{if(activeHck){if(activeHckOriginConverted){goHome();return;}closeHckAgentRealtime();activeHck=0;if(hckPreviousTimer)clearInterval(hckPreviousTimer);hckPreviousTimer=null;if(hckMessagePollTimer)clearInterval(hckMessagePollTimer);hckMessagePollTimer=null;openTicket(active,false);}else goHome();};$('#toggleInbox')?.addEventListener('click',()=>{layout.classList.remove('details-open');layout.classList.toggle('inbox-open');});$('#inboxScrim')?.addEventListener('click',()=>layout.classList.remove('inbox-open'));const detailsPanel=$('#layout'),wideDetails=()=>window.matchMedia('(min-width: 1121px)').matches,openDetails=()=>{if(wideDetails()){detailsPanel.classList.remove('details-collapsed');$('#toggleDetails')?.setAttribute('aria-expanded','true');}else{detailsPanel.classList.add('details-open');$('#toggleDetails')?.setAttribute('aria-expanded','true');}},closeDetails=()=>{if(wideDetails()){detailsPanel.classList.add('details-collapsed');$('#toggleDetails')?.setAttribute('aria-expanded','false');}else{detailsPanel.classList.remove('details-open');$('#toggleDetails')?.setAttribute('aria-expanded','false');}},toggleDetails=()=>{if(wideDetails()){detailsPanel.classList.toggle('details-collapsed');$('#toggleDetails')?.setAttribute('aria-expanded',detailsPanel.classList.contains('details-collapsed')?'false':'true');}else{detailsPanel.classList.toggle('details-open');$('#toggleDetails')?.setAttribute('aria-expanded',detailsPanel.classList.contains('details-open')?'true':'false');}};$('#toggleDetails')?.addEventListener('click',toggleDetails);$('#closeDetails')?.addEventListener('click',closeDetails);$('#detailsScrim')?.addEventListener('click',closeDetails);window.addEventListener('resize',()=>{if(!wideDetails())detailsPanel.classList.remove('details-collapsed');else detailsPanel.classList.remove('details-open');});$('#refreshTickets')?.addEventListener('click',async()=>{let b=$('#refreshTickets');b.disabled=true;b.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i>';try{await loadList();if(active)await openTicket(active,true)}finally{b.disabled=false;b.innerHTML='<i class="fa-solid fa-rotate"></i>'}});let ticketSearchTimer=null,globalSearchRequestId=0,globalSearchPageActive=false,globalSearchReturnState=null,globalSearchHistoryEntry=false;
function saveSearchReturnState(){
 const nodes={layout:layout,home:$('#homeOverview'),workspace:$('#workspace'),blank:$('#blank'),page:$('#hcSearchResultsPage')};
 const attr=(node,name)=>node?node.getAttribute(name):null;
 return {layoutClass:attr(nodes.layout,'class'),homeStyle:attr(nodes.home,'style'),workspaceStyle:attr(nodes.workspace,'style'),workspaceClass:attr(nodes.workspace,'class'),blankStyle:attr(nodes.blank,'style'),blankClass:attr(nodes.blank,'class'),pageHidden:nodes.page?nodes.page.hidden:true,bodyHadSearchClass:document.body.classList.contains('hc-agent-search-open')};
}
function restoreSearchAttribute(node,name,value){if(!node)return;if(value===null)node.removeAttribute(name);else node.setAttribute(name,value);}
function enterGlobalSearchPage(){
 if(!globalSearchPageActive){globalSearchReturnState=saveSearchReturnState();globalSearchPageActive=true;}
 layout.classList.remove('home-mode','ticket-mode','open','inbox-open','details-open','details-collapsed');
 layout.classList.add('hc-search-mode');
 document.body.classList.add('hc-agent-search-open');
 $('#hcSearchResultsPage').hidden=false;
 $('#homeOverview').style.setProperty('display','none','important');
 $('#workspace').style.setProperty('display','none','important');
 $('#workspace').classList.add('hidden');
 $('#blank').style.setProperty('display','none','important');
 $('#blank').classList.add('hidden');
}
function restoreGlobalSearchPage(){
 if(!globalSearchPageActive)return;
 const state=globalSearchReturnState;
 if(state){
  restoreSearchAttribute(layout,'class',state.layoutClass);
  restoreSearchAttribute($('#homeOverview'),'style',state.homeStyle);
  restoreSearchAttribute($('#workspace'),'style',state.workspaceStyle);
  restoreSearchAttribute($('#workspace'),'class',state.workspaceClass);
  restoreSearchAttribute($('#blank'),'style',state.blankStyle);
  restoreSearchAttribute($('#blank'),'class',state.blankClass);
  if(state.bodyHadSearchClass)document.body.classList.add('hc-agent-search-open');else document.body.classList.remove('hc-agent-search-open');
 }else{
  layout.classList.remove('hc-search-mode');
  document.body.classList.remove('hc-agent-search-open');
  $('#hcSearchResultsPage').hidden=true;
 }
 $('#hcSearchResultsPage').hidden=true;
 globalSearchPageActive=false;
 globalSearchReturnState=null;
 globalSearchHistoryEntry=false;
}
function buildSearchUrl(term){const url=new URL(window.location.href);url.searchParams.delete('ticket');url.searchParams.set('hc_search',term);return url;}
function updateSearchUrl(term,fromHistory,wasAlreadyOpen){
 if(fromHistory)return;
 const url=buildSearchUrl(term),state=Object.assign({},history.state||{},{hcSearch:true,hcSearchQuery:term});
 if(!wasAlreadyOpen){history.pushState(state,'',url);globalSearchHistoryEntry=true;}
 else history.replaceState(state,'',url);
}
function renderSearchMessage(icon,title,detail){$('#hcSearchResults').innerHTML='<div class="hc-search-empty"><i class="fa-solid '+icon+'" aria-hidden="true"></i><strong>'+esc(title)+'</strong><span>'+esc(detail)+'</span></div>';}
async function runGlobalSearch(term,options={}){
 const wasAlreadyOpen=globalSearchPageActive;
 const fromHistory=!!options.fromHistory;
 if(fromHistory)globalSearchHistoryEntry=!!(history.state&&history.state.hcSearch);
 term=String(term||'').trim().slice(0,120);
 const searchRequestId=++globalSearchRequestId;
 enterGlobalSearchPage();
 if(!fromHistory)updateSearchUrl(term,false,wasAlreadyOpen);
 const topInput=$('#ticketSearch'),pageInput=$('#hcSearchPageInput');
 if(topInput&&topInput.value!==term)topInput.value=term;
 if(pageInput&&pageInput.value!==term)pageInput.value=term;
 $('#hcSearchCounts').innerHTML='';
 const submit=$('#hcSearchPageSubmit');
 if(term.length<2){if(submit)submit.disabled=false;$('#hcSearchSubtitle').textContent='Enter at least 2 characters to search your support history.';renderSearchMessage('fa-magnifying-glass','Enter at least 2 characters','Search customers, email addresses, ticket IDs, ticket subjects and message content across HelpCenter and HCK.');return;}
 $('#hcSearchSubtitle').textContent='Searching support history for “'+term+'”…';
 if(submit)submit.disabled=true;
 renderSearchMessage('fa-spinner fa-spin','Searching support history…','Matching HelpCenter conversations, HCK tickets and follow-ups.');
 try{
  const r=await post('hc_agent_global_search',{q:term});
  if(searchRequestId!==globalSearchRequestId||!globalSearchPageActive)return;
  if(!r.success)throw new Error(r.data?.message||'Search failed.');
  const rows=Array.isArray(r.data.results)?r.data.results:[],counts=r.data.counts||{};
  $('#hcSearchSubtitle').textContent='Results for “'+term+'”. Select a record to open it.';
  $('#hcSearchCounts').innerHTML='<span><i class="fa-solid fa-comments" aria-hidden="true"></i> '+(Number(counts.conversations)||0)+' conversations</span><span><i class="fa-solid fa-ticket" aria-hidden="true"></i> '+(Number(counts.hck)||0)+' HCK tickets</span><span><i class="fa-solid fa-arrow-right-arrow-left" aria-hidden="true"></i> '+(Number(counts.followups)||0)+' HCK follow-ups</span>';
  $('#hcSearchResults').innerHTML=rows.length?rows.map(x=>{
   const kind=x.kind||'conversation',id=Number(x.id)||0;
   const cls=kind==='followup'?'hc-search-card--followup':kind==='hck'?'hc-search-card--hck':'hc-search-card--conversation';
   const icon=kind==='followup'?'fa-arrow-right-arrow-left':kind==='hck'?'fa-ticket':'fa-comments';
   const label=kind==='followup'?'HCK follow-up':kind==='hck'?'HCK ticket':'HelpCenter conversation';
   const relation=x.relationship?'<small class="hc-search-relationship"><i class="fa-solid fa-link" aria-hidden="true"></i> '+esc(x.relationship)+'</small>':'';
   const body='<span class="hc-search-card-icon"><i class="fa-solid '+icon+'" aria-hidden="true"></i></span><span class="hc-search-card-main"><header><strong>'+esc(x.title||label)+'</strong><em class="hc-search-kind">'+label+'</em></header><p>'+esc(x.preview||x.customer||'No matching message preview')+'</p><small>'+esc(x.number||('#'+id))+' · '+esc(x.customer||'Customer')+' · '+esc(x.email||'')+' · '+esc(x.status||'')+'</small><small><i class="fa-regular fa-clock" aria-hidden="true"></i> '+esc(x.updated_at||'')+'</small>'+relation+'</span>'; 
   if(kind==='conversation')return '<button type="button" class="hc-search-card '+cls+'" data-search-conversation="'+id+'">'+body+'</button>';
   const href=String(x.url||'#');return '<a class="hc-search-card '+cls+'" href="'+esc(href)+'" target="_blank" rel="noopener">'+body+'</a>';
  }).join(''):'<div class="hc-search-empty"><i class="fa-regular fa-folder-open" aria-hidden="true"></i><strong>No matching support records</strong><span>Try another name, email address, ticket number or message phrase.</span></div>';
 }catch(e){
  if(searchRequestId!==globalSearchRequestId||!globalSearchPageActive)return;
  $('#hcSearchSubtitle').textContent='Search could not be completed.';
  renderSearchMessage('fa-triangle-exclamation','Search could not be completed',e.message||'Please try again.');
 }finally{if(submit&&globalSearchPageActive)submit.disabled=false;}
}
function closeGlobalSearch(forTicket=false){
 if(!globalSearchPageActive)return;
 globalSearchRequestId++;
 if(forTicket){
  const url=new URL(window.location.href);url.searchParams.delete('hc_search');
  history.replaceState(Object.assign({},history.state||{},{hcSearch:false}),'',url);
  restoreGlobalSearchPage();
  return;
 }
 if(globalSearchHistoryEntry&&new URL(window.location.href).searchParams.has('hc_search')){history.back();return;}
 const url=new URL(window.location.href);url.searchParams.delete('hc_search');
 history.replaceState(Object.assign({},history.state||{},{hcSearch:false}),'',url);
 restoreGlobalSearchPage();
}
const globalSearchForm=$('#hcGlobalSearchForm');
if(globalSearchForm)globalSearchForm.addEventListener('submit',e=>{e.preventDefault();clearTimeout(ticketSearchTimer);runGlobalSearch($('#ticketSearch').value);});
const pageSearchForm=$('#hcSearchPageForm');
if(pageSearchForm)pageSearchForm.addEventListener('submit',e=>{e.preventDefault();clearTimeout(ticketSearchTimer);runGlobalSearch($('#hcSearchPageInput').value);});
$('#hcSearchBack').addEventListener('click',()=>closeGlobalSearch(false));
$('#hcSearchResults').addEventListener('click',e=>{const b=e.target.closest('[data-search-conversation]');if(!b)return;const id=Number(b.dataset.searchConversation);if(!id)return;closeGlobalSearch(true);searchMode=true;tab='all';openTicket(id,false);});
$('#hcSearchPageInput').addEventListener('input',e=>{clearTimeout(ticketSearchTimer);const value=e.target.value.trim();if(value.length>=2)ticketSearchTimer=setTimeout(()=>runGlobalSearch(value),400);});
$('#ticketSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();clearTimeout(ticketSearchTimer);runGlobalSearch(e.currentTarget.value);}});
window.addEventListener('popstate',()=>{
 const url=new URL(window.location.href);
 if(url.searchParams.has('hc_search'))runGlobalSearch(url.searchParams.get('hc_search')||'',{fromHistory:true});
 else if(globalSearchPageActive){globalSearchRequestId++;restoreGlobalSearchPage();}
});

 let agentSendInFlight=false,agentPendingCount=0,agentPersistenceQueues=Object.create(null),agentPendingSends=Object.create(null),agentAttachmentSendBusy=false;
 function enqueueAgentPersistence(ticketId,work){
  // Keep permanent transcript inserts in sender order. Realtime publish is
  // started before this queue and the composer remains available.
  let previous=agentPersistenceQueues[ticketId]||Promise.resolve();
  let next=previous.catch(()=>{}).then(work);
  agentPersistenceQueues[ticketId]=next.catch(()=>{});
  return next;
 }
 function setAgentMessageState(clientId,label,failed,retryLabel){let node=$('#messages').querySelector('[data-client-message-id="'+CSS.escape(String(clientId))+'"]');if(!node)return;let who=node.querySelector('.who');if(who)who.textContent=(HCAG.agentName||'You');let retry=node.querySelector('.hc-message-retry');if(failed){node.classList.add('hc-message-delivery-uncertain');if(!retry){retry=document.createElement('button');retry.type='button';retry.className='hc-message-retry';retry.style.cssText='display:block;margin-top:6px;border:0;background:transparent;color:#a33b28;text-decoration:underline;font-family:inherit;font-size:11px;font-weight:600;padding:0;cursor:pointer';retry.addEventListener('click',()=>retryAgentSave(clientId));node.querySelector('.msg-content')?.appendChild(retry);}retry.textContent=retryLabel||'Retry saving';}else if(retry){retry.remove();node.classList.remove('hc-message-delivery-uncertain');}}
 function finishAgentSaveCount(){agentPendingCount=Math.max(0,agentPendingCount-1);agentSendInFlight=agentPendingCount>0;}
 window.addEventListener('beforeunload',function(e){if(Object.keys(agentPendingSends).length){e.preventDefault();e.returnValue='';}});
 function sendHckAgentMessage(entry){
  if(!entry||entry.saving)return;
  entry.saving=true;agentPendingCount++;agentSendInFlight=true;
  // Reserve the persistence slot synchronously in submit order. The direct
  // Ably/relay promises have already started independently for every message.
  // Persist immediately; never wait for a socket handshake, publish ACK, or
  // server relay. The PHP save handler emits the durable event after commit.
  if(entry.directPromise&&typeof entry.directPromise.catch==='function')entry.directPromise.catch(error=>console.warn('[HCK Realtime] Agent direct publish failed; saved-message event will recover delivery.',error));
  if(!entry.formData.has('realtime_delivered'))entry.formData.append('realtime_delivered','0');
  let run=enqueueAgentPersistence(entry.ticketId,()=>fetch(HCAG.ajax,{method:'POST',body:entry.formData,credentials:'same-origin',cache:'no-store',keepalive:!entry.formData.get('attachments[]')}).then(response=>response.json().then(r=>({response,r})))).then(({response,r})=>{
   if(!response.ok||!r||!r.success)throw new Error(r&&r.data&&r.data.message||'HCK reply could not be saved.');
   let node=$('#messages').querySelector('[data-client-message-id="'+CSS.escape(entry.clientId)+'"]');
   if(node){let id=Number(r.data.message_id)||0;if(id){node.dataset.messageKey='hck:'+id;node.dataset.messageId=String(id);}let who=node.querySelector('.who');if(who)who.textContent=(HCAG.agentName||'You');node.classList.remove('hc-message-delivery-uncertain');node.querySelector('.hc-hck-retry')?.remove();}
   delete agentPendingSends[entry.clientId];
  }).catch(err=>{
   let node=$('#messages').querySelector('[data-client-message-id="'+CSS.escape(entry.clientId)+'"]');
   if(node){let who=node.querySelector('.who');if(who)who.textContent=(HCAG.agentName||'You');node.classList.add('hc-message-delivery-uncertain');if(!node.querySelector('.hc-hck-retry')){let retry=document.createElement('button');retry.type='button';retry.className='hc-hck-retry';retry.textContent='Retry saving';retry.style.cssText='display:block;margin-top:6px;border:0;background:transparent;color:#a33b28;text-decoration:underline;font-family:inherit;font-size:11px;font-weight:600;padding:0;cursor:pointer';retry.addEventListener('click',()=>sendHckAgentMessage(entry));node.querySelector('.msg-content')?.appendChild(retry);}}
   console.warn('[HCK] Agent reply persistence failed; retry is available.',{ticket_id:entry.ticketId,client_message_id:entry.clientId,realtime_delivered:!!entry.realtimeDelivered,error:err});
  }).finally(()=>{entry.saving=false;finishAgentSaveCount();});
  entry.savingPromise=run;return run;
 }
 function saveAgentMessage(entry){
  if(entry.savingPromise)return entry.savingPromise;
  entry.saving=true;agentPendingCount++;agentSendInFlight=true;
  let task=enqueueAgentPersistence(entry.ticketId,async()=>{
   let r;
   // Public text replies must be acknowledged by the live Ably channel (or the
   // authenticated pre-save relay) BEFORE WordPress is allowed to persist them.
   // Internal notes and staged-attachment sends retain their existing workflow.
   if(entry.requireRealtime){
    let accepted=false;
    try{accepted=!!(await Promise.resolve(entry.directPromise));}catch(deliveryError){console.warn('[HelpCenter Realtime] Pre-save delivery promise rejected.',deliveryError);}
    entry.realtimeDelivered=accepted;
    if(!accepted)throw new Error('Live delivery was not acknowledged. This reply has NOT been saved. Check the agent realtime connection and retry.');
   }
   if(entry.ids.length){
    let fd=new FormData();fd.append('action','hc_ai_escalation_send_staged');fd.append('nonce',HCAG.nonce);fd.append('ticket_id',entry.ticketId);fd.append('message',entry.text);fd.append('client_message_id',entry.clientId);fd.append('realtime_delivered',entry.realtimeDelivered?'1':'0');entry.ids.forEach(id=>fd.append('staged_ids[]',id));
    let response=await fetch(HCAG.ajax,{method:'POST',body:fd,credentials:'same-origin',cache:'no-store',keepalive:!entry.ids.length});let raw=await response.text();try{r=JSON.parse(raw)}catch(e){throw new Error('Upload/send endpoint returned an invalid response (HTTP '+response.status+'). Check the server upload limits and PHP error log.')}
   }else{
    r=await post('hc_agent_reply',{ticket_id:entry.ticketId,message:entry.text,client_message_id:entry.clientId,realtime_delivered:entry.realtimeDelivered?1:0});
   }
   if(!r||!r.success)throw new Error(r&&r.data&&r.data.message||'Reply could not be saved.');
   if(r.data.message_data){appendUnique([r.data.message_data],false);after=Math.max(after,Number(r.data.message_data.id)||0);}
   (r.data.messages||[]).forEach(m=>{appendUnique([m],false);after=Math.max(after,Number(m.id)||0)});
   setAgentMessageState(entry.clientId,'Saved',false);delete agentPendingSends[entry.clientId];return r;
  }).catch(error=>{entry.error=error;let deliveryPending=!!entry.requireRealtime&&!entry.realtimeDelivered;setAgentMessageState(entry.clientId,deliveryPending?'Live delivery failed · not saved':'Save failed · retry',true,deliveryPending?'Retry live delivery':'Retry saving');console.error('[HelpCenter] Agent reply did not complete. A public reply is never saved before live delivery acknowledgement.',{ticket_id:entry.ticketId,client_message_id:entry.clientId,realtime_delivered:!!entry.realtimeDelivered,error:error});return null;}).finally(()=>{entry.saving=false;entry.savingPromise=null;finishAgentSaveCount();});
  entry.savingPromise=task;return task;
 }
 function retryAgentSave(clientId){let entry=agentPendingSends[String(clientId)];if(!entry||entry.saving)return;if(entry.requireRealtime&&!entry.realtimeDelivered){entry.directPromise=publishAgentLiveMessage(entry.ticketId,entry.realtimePayload);}else{entry.directPromise=Promise.resolve(!!entry.realtimeDelivered);}setAgentMessageState(entry.clientId,'Retrying delivery/save…',false);saveAgentMessage(entry);}
 $('#messages').addEventListener('click',e=>{let b=e.target.closest('.hc-message-retry');if(b){e.preventDefault();e.stopPropagation();}});
 $('#send').addEventListener('click',e=>{
  e.preventDefault();
  if(activeHck){
   let text=$('#replyText').value.trim(),files=Array.from($('#file').files||[]);if(!text||$('#send').disabled||agentUploading)return;
   let ticketId=Number(activeHck),clientId=((window.crypto&&crypto.randomUUID)?crypto.randomUUID():String(Date.now())+'-'+Math.random().toString(16).slice(2));
   let isPrivate=crmComposerMode==='note';
   let fd=new FormData();fd.append('action','hck_admin_reply');fd.append('nonce',HCAG.hckNonce||'');fd.append('ticket_id',ticketId);fd.append('message',text);fd.append('client_message_id',clientId);fd.append('internal',isPrivate?'1':'0');files.forEach(f=>fd.append('attachments[]',f,f.name));
   appendUnique([{client_message_id:clientId,message_key:'client:'+clientId,sender_type:isPrivate?'internal_note':'agent',sender_name:HCAG.agentName||'You',content:text,created_at:''}],false);
   $('#replyText').value='';$('#replyText').style.height='auto';$('#file').value='';$('#stagedAttachments').innerHTML='';$('#stagedAttachments').hidden=true;$('#send').disabled=false;$('#send').innerHTML=isPrivate?'<i class="fa-solid fa-lock"></i> Save private note':'<i class="fa-solid fa-paper-plane"></i> Send reply';
   let directPromise=(!isPrivate&&!files.length)?deliverHckAgentMessage(ticketId,{client_message_id:clientId,sender_type:'agent',sender_name:HCAG.agentName||'Support agent',content:text,created_at:new Date().toISOString(),attachments:[]}):Promise.resolve(false);
   let entry={ticketId:ticketId,clientId:clientId,formData:fd,directPromise:directPromise,realtimeDelivered:false,saving:false,savingPromise:null};agentPendingSends[clientId]=entry;sendHckAgentMessage(entry);
   return;
  }
  let text=$('#replyText').value.trim(),ids=stagedAgentFiles.map(x=>x.token);if((!text&&!ids.length)||!active||$('#send').disabled||agentUploading||agentAttachmentSendBusy)return;
  let ticketId=Number(active),clientId=((window.crypto&&crypto.randomUUID)?crypto.randomUUID():String(Date.now())+'-'+Math.random().toString(16).slice(2));
  $('#replyText').value='';$('#replyText').style.height='auto';
  if(text)appendUnique([{client_message_id:clientId,sender_type:'agent',sender_name:HCAG.agentName||'You',content:text,created_at:''}],false);
  let realtimePayload=(!ids.length&&text&&crmComposerMode!=='note')?{client_message_id:clientId,sender_name:HCAG.agentName||'Support agent',content:text,created_at:new Date().toISOString()}:null;
  let directPromise=realtimePayload?publishAgentLiveMessage(ticketId,realtimePayload):Promise.resolve(false);
  let entry={ticketId:ticketId,clientId:clientId,text:text,ids:ids.slice(),directPromise:directPromise,realtimePayload:realtimePayload,requireRealtime:!!realtimePayload,realtimeDelivered:false,saving:false,savingPromise:null,error:null};agentPendingSends[clientId]=entry;
  if(ids.length){agentAttachmentSendBusy=true;stagedAgentFiles=[];renderAgentStaged();}
  // Keep the composer ready for the next text while this message is being
  // published/saved. Each message owns its own promise and idempotency key.
  $('#send').removeAttribute('aria-busy');$('#send').disabled=false;$('#send').innerHTML=crmComposerMode==='note'?'<i class="fa-solid fa-lock"></i> Save private note':'<i class="fa-solid fa-paper-plane"></i> Send reply';
  saveAgentMessage(entry).finally(()=>{if(ids.length)agentAttachmentSendBusy=false;});
 });

 $('#replyText').addEventListener('input',function(){this.style.height='auto';this.style.height=Math.min(this.scrollHeight,190)+'px'});$('#replyText').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();if(!$('#send').disabled)$('#send').click()}});
 $('#close').onclick=async()=>{if(!active||$('#close').disabled||!confirm('Close this ticket?'))return;let id=active;$('#close').disabled=true;try{let r=await post('hc_agent_close',{ticket_id:id});if(r.success){goHome();}else alert(r.data?.message||'Could not close ticket')}catch(e){alert(e.message||'Could not close ticket. Please retry.')}finally{$('#close').disabled=false}};$('#claim').onclick=async()=>{if(activeHck){let b=$('#claim');b.disabled=true;try{let r=await post('hc_agent_hck_claim',{ticket_id:activeHck,current_hc_ticket_id:Number(active||activeLive||0)});if(!r.success)throw new Error(r.data?.message||'Could not take ticket.');closeHckAgentRealtime();await openHckPreviousTicket(activeHck);}catch(e){alert(e.message||'Could not take ticket.');}finally{b.disabled=false;}return;}let r=await post('hc_agent_claim',{ticket_id:active});if(r.success){await openTicket(active,false);await loadList()}else alert(r.data?.message||'Could not claim ticket')};
 document.querySelectorAll('[data-assist]').forEach(b=>b.onclick=async()=>{let text=$('#replyText').value.trim();if(!text)return alert('Type a draft first.');b.disabled=true;try{let r=await post('hc_agent_text_assist',{mode:b.dataset.assist,text,ticket_id:active});if(r.success)$('#replyText').value=r.data.text;else alert(r.data?.message||'Text assistance unavailable')}finally{b.disabled=false}});
 const titleEditModal=$('#hcTitleEditModal'),titleEditForm=$('#hcTitleEditForm'),titleEditInput=$('#hcTitleEditInput'),titleEditError=$('#hcTitleEditError'),titleEditSave=$('#hcTitleEditSave');
 let titleEditReturnFocus=null;
 function closeTitleEditModal(){if(!titleEditModal||titleEditModal.hidden)return;titleEditModal.hidden=true;document.body.classList.remove('hc-title-modal-open');if(titleEditReturnFocus&&titleEditReturnFocus.isConnected)titleEditReturnFocus.focus();}
 function openTitleEditModal(){if(!active||!titleEditModal||!titleEditInput)return;titleEditReturnFocus=$('#editTicketTitle');titleEditInput.value=$('#ticketTitle').textContent.trim();let count=$('#hcTitleEditCount');if(count)count.textContent=String(titleEditInput.value.length)+' / 180';titleEditError.hidden=true;titleEditError.textContent='';titleEditSave.disabled=false;titleEditSave.innerHTML='<i class="fa-solid fa-check" aria-hidden="true"></i> Save title';titleEditModal.hidden=false;document.body.classList.add('hc-title-modal-open');window.setTimeout(()=>{titleEditInput.focus();titleEditInput.select();},30);}
 $('#editTicketTitle')?.addEventListener('click',openTitleEditModal);
 titleEditModal?.querySelectorAll('[data-title-modal-close]').forEach(el=>el.addEventListener('click',closeTitleEditModal));
 titleEditInput?.addEventListener('input',()=>{let count=$('#hcTitleEditCount');if(count)count.textContent=String(titleEditInput.value.length)+' / 180';});
 titleEditModal?.addEventListener('click',e=>{if(e.target===titleEditModal)closeTitleEditModal();});
 document.addEventListener('keydown',e=>{if(!titleEditModal||titleEditModal.hidden)return;if(e.key==='Escape'){e.preventDefault();closeTitleEditModal();}else if(e.key==='Tab'){let focusables=titleEditModal.querySelectorAll('button:not([disabled]),input:not([disabled])'),first=focusables[0],last=focusables[focusables.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
 titleEditForm?.addEventListener('submit',async e=>{e.preventDefault();if(!active)return;let next=String(titleEditInput.value||'').trim();if(!next||next.length>180){titleEditError.textContent='Enter a title between 1 and 180 characters.';titleEditError.hidden=false;titleEditInput.focus();return;}let ticketId=Number(active);titleEditSave.disabled=true;titleEditInput.disabled=true;titleEditSave.innerHTML='<i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> Saving…';titleEditError.hidden=true;try{let r=await post('hc_agent_title_update',{ticket_id:ticketId,title:next});if(!r.success)throw new Error(r.data?.message||'Title could not be saved.');if(Number(active)===ticketId){$('#ticketTitle').textContent=r.data.title;let row=tickets.find(x=>Number(x.id)===ticketId);if(row)row.title=r.data.title;loadList(undefined,{silent:true});}closeTitleEditModal();}catch(err){titleEditError.textContent=err.message||'Title could not be saved. Please try again.';titleEditError.hidden=false;}finally{titleEditSave.disabled=false;titleEditInput.disabled=false;titleEditSave.innerHTML='<i class="fa-solid fa-check" aria-hidden="true"></i> Save title';}});
 $('#generateSummary')?.addEventListener('click',async()=>{let b=$('#generateSummary'),box=$('#summarySide');if(!active)return;b.disabled=true;b.setAttribute('aria-busy','true');b.innerHTML='<i class="fa-solid fa-circle-notch fa-spin" aria-hidden="true"></i> Generating…';box.classList.add('hc-summary-generating');box.setAttribute('aria-live','polite');box.textContent='';try{let r=activeHck?await postHck('hck_generate_ticket_ai_summary',{ticket_id:activeHck}):await post('hc_agent_summary',{ticket_id:active});if(!r.success)throw new Error(r.data?.message||'Summary generation failed');box.classList.remove('hc-summary-generating');box.innerHTML='<article class="hc-ai-summary-card"><div class="hc-ai-summary-card-head"><i class="fa-solid fa-wand-magic-sparkles"></i> Final conversation summary</div><div class="hc-ai-summary-content">'+renderMarkdown(r.data.summary||'No summary returned.')+'</div></article>';b.innerHTML='<i class="fa-solid fa-rotate"></i> Regenerate summary';}catch(e){box.classList.remove('hc-summary-generating');box.textContent=e.message||'Could not generate summary.';b.innerHTML='<i class="fa-solid fa-rotate"></i> Try again';}finally{b.disabled=false;b.removeAttribute('aria-busy');}});
  $('#assignTicket')?.addEventListener('click',async()=>{if(!active)return;let target=Number($('#assignAgent').value||0);if(!confirm('Reassign ticket #'+active+' to '+($('#assignAgent').selectedOptions[0]?.textContent||'the unassigned queue')+'?'))return;let b=$('#assignTicket');b.disabled=true;try{let r=await post('hc_agent_transfer',{ticket_id:active,agent_id:target});if(!r.success)throw new Error(r.data?.message||'Reassignment failed');goHome();}catch(e){alert(e.message||'Could not reassign ticket.');}finally{b.disabled=false;}});
  var stagedAgentFiles=[],agentUploading=false,agentUploadXhr=null;function clearStagedAgentFiles(){if(agentUploadXhr){try{agentUploadXhr.abort();}catch(e){}agentUploadXhr=null;}agentUploading=false;(stagedAgentFiles||[]).forEach(f=>post('hc_ai_escalation_cancel_staged',{ticket_id:active,staged_id:f.token}).catch(()=>{}));stagedAgentFiles=[];$('#file').value='';$('#stagedAttachments').innerHTML='';$('#stagedAttachments').hidden=true;$('#uploadProgress').hidden=true;if(cancelAgentUpload)cancelAgentUpload.hidden=true;}function renderAgentStaged(){let box=$('#stagedAttachments');box.innerHTML='';stagedAgentFiles.forEach(f=>{let chip=document.createElement('span');chip.className='staged-agent-file';let name=document.createElement('span');name.textContent=f.name+' · '+(f.size/1048576).toFixed(2)+' MB';let remove=document.createElement('button');remove.type='button';remove.textContent='×';remove.setAttribute('aria-label','Remove '+f.name);remove.onclick=()=>{stagedAgentFiles=stagedAgentFiles.filter(x=>x.token!==f.token);renderAgentStaged();post('hc_ai_escalation_cancel_staged',{ticket_id:active,staged_id:f.token}).catch(()=>{});};chip.append(name,remove);box.appendChild(chip);});box.hidden=!stagedAgentFiles.length;}
  $('#attach').onclick=()=>$('#file').click();$('#file').onchange=()=>{let files=Array.from($('#file').files||[]);if(!files.length)return;if(activeHck){if(files.length>Number(HCAG.maxFiles||3)){alert('You can attach up to '+HCAG.maxFiles+' files to one message.');$('#file').value='';return;}let box=$('#stagedAttachments');box.innerHTML=files.map(f=>'<span class="staged-agent-file">'+esc(f.name)+' · '+(f.size/1048576).toFixed(2)+' MB</span>').join('');box.hidden=false;return;}if(!active){alert('Open a ticket before attaching a file.');$('#file').value='';return;}if(stagedAgentFiles.length+files.length>Number(HCAG.maxFiles||3)){alert('You can attach up to '+HCAG.maxFiles+' files to one message.');$('#file').value='';return;}agentUploading=true;$('#attach').disabled=true;cancelAgentUpload.hidden=false;let index=0;function next(){if(index>=files.length){agentUploading=false;agentUploadXhr=null;$('#attach').disabled=false;$('#file').value='';$('#uploadProgress').hidden=true;cancelAgentUpload.hidden=true;renderAgentStaged();return;}let file=files[index++],fd=new FormData();fd.append('action','hc_ai_escalation_stage_upload');fd.append('nonce',HCAG.nonce);fd.append('ticket_id',active);fd.append('file',file);let xhr=new XMLHttpRequest();agentUploadXhr=xhr;xhr.open('POST',HCAG.ajax,true);xhr.withCredentials=true;xhr.timeout=120000;$('#uploadProgress').hidden=false;$('#uploadProgressBar').style.width='0%';$('#uploadProgressText').textContent='Uploading '+file.name+'…';xhr.upload.onprogress=e=>{if(e.lengthComputable){let pct=Math.round(e.loaded/e.total*100);$('#uploadProgressBar').style.width=pct+'%';$('#uploadProgressText').textContent='Uploading '+file.name+' · '+pct+'%';}};xhr.onload=()=>{let r;try{r=JSON.parse(xhr.responseText)}catch(e){r=null;}if(xhr.status>=200&&xhr.status<300&&r&&r.success){stagedAgentFiles.push({token:r.data.token,name:r.data.name||file.name,size:r.data.size||file.size});renderAgentStaged();next();}else{agentUploading=false;agentUploadXhr=null;$('#attach').disabled=false;$('#file').value='';$('#uploadProgress').hidden=true;cancelAgentUpload.hidden=true;alert(r&&r.data&&r.data.message||('Upload failed (HTTP '+xhr.status+'). If this is a large file, check Nginx client_max_body_size and PHP upload_max_filesize/post_max_size.'));}};xhr.onerror=()=>{agentUploading=false;agentUploadXhr=null;$('#attach').disabled=false;$('#file').value='';$('#uploadProgress').hidden=true;cancelAgentUpload.hidden=true;alert('Network error during upload.');};xhr.ontimeout=()=>{agentUploading=false;agentUploadXhr=null;$('#attach').disabled=false;$('#file').value='';$('#uploadProgress').hidden=true;cancelAgentUpload.hidden=true;alert('Upload timed out. Try a smaller file or check the server upload limits.');};xhr.onabort=()=>{agentUploading=false;agentUploadXhr=null;$('#attach').disabled=false;$('#file').value='';$('#uploadProgress').hidden=true;cancelAgentUpload.hidden=true;};xhr.send(fd);}next();};
  var cancelAgentUpload=document.createElement('button');cancelAgentUpload.type='button';cancelAgentUpload.className='upload-cancel';cancelAgentUpload.textContent='Cancel upload';cancelAgentUpload.onclick=()=>{if(agentUploadXhr)agentUploadXhr.abort();};$('#uploadProgress').appendChild(cancelAgentUpload);
 const preview=$('#attachmentPreview'),previewContent=$('#previewContent'),previewDownload=$('#previewDownload');let previewUrl='';function closePreview(){preview.hidden=true;previewContent.innerHTML='';previewUrl='';document.body.classList.remove('hc-preview-open');}document.querySelectorAll('[data-preview-close]').forEach(x=>x.addEventListener('click',closePreview));document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!preview.hidden)closePreview()});document.addEventListener('click',e=>{let b=e.target.closest('[data-preview-url]');if(!b)return;let url=b.dataset.previewUrl,name=b.dataset.previewName||'Attachment',kind=b.dataset.previewKind,mime=b.dataset.previewMime||'';previewUrl=url;$('#previewTitle').textContent=name;previewContent.innerHTML='';if(kind==='image'||mime.startsWith('image/')){let img=document.createElement('img');img.src=url;img.alt=name;previewContent.appendChild(img);}else if(kind==='video'||mime.startsWith('video/')){let video=document.createElement('video');video.src=url;video.controls=true;video.autoplay=false;video.playsInline=true;previewContent.appendChild(video);}else{let a=document.createElement('a');a.href=url;a.className='preview-download';a.target='_blank';a.rel='noopener';a.textContent='Open attachment';previewContent.appendChild(a);}previewDownload.href=url+(url.indexOf('?')>=0?'&':'?')+'download=1';previewDownload.setAttribute('download',name);preview.hidden=false;document.body.classList.add('hc-preview-open');});
 let heartbeatFailures=0,lastHeartbeatOk=0,connectionSince=0,connectionState='is-checking';const connectionNode=$('#footerNetwork');function paintConnection(state){if(!connectionNode)return;connectionState=state;if(state!=='is-good')connectionSince=0;connectionNode.classList.remove('is-checking','is-good','is-unstable','is-offline');connectionNode.classList.add(state);let label=state==='is-good'?'Internet connected':state==='is-unstable'?'Connection unstable':'Internet disconnected';connectionNode.querySelector('b').textContent=label;let warning=$('#connectionWarning');if(warning){warning.hidden=state==='is-good'||state==='is-checking';warning.textContent=state==='is-offline'?'Internet connection lost. Live updates and new assignments may stop until you reconnect.':'Your internet connection is unstable. Live updates may be delayed; HelpCenter is retrying automatically.';}}let hcAvailableSince=0,hcAvailableAccumulated=0;function updateConnectionUptime(){let clock=$('#footerClock'),session=$('#footerSession');let now=new Date();if(clock)clock.textContent=new Intl.DateTimeFormat('en-GB',{timeZone:'UTC',day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true}).format(now)+' GMT';if(session){let sec=hcAvailableAccumulated+(available&&hcAvailableSince?Math.floor((Date.now()-hcAvailableSince)/1000):0),h=String(Math.floor(sec/3600)).padStart(2,'0'),m=String(Math.floor(sec%3600/60)).padStart(2,'0'),ss=String(sec%60).padStart(2,'0');session.textContent=available?'Available '+h+':'+m+':'+ss:'Available time paused';}}async function heartbeat(){if(!navigator.onLine){heartbeatFailures=Math.max(heartbeatFailures,2);paintConnection('is-offline');return;}try{let r=await post('hc_agent_presence');if(r.success){heartbeatFailures=0;lastHeartbeatOk=Date.now();if(!connectionSince)connectionSince=Date.now();paintConnection('is-good');let wasAvailable=available;available=!!r.data.available;hcAvailableAccumulated=Math.max(0,Number(r.data.available_seconds_today)||0);hcAvailableSince=available?Date.now():0;renderAvailability();if(available!==wasAvailable)configureRealtimeFallback(hcRealtimeConnected);}else{heartbeatFailures++;paintConnection(heartbeatFailures>=3?'is-offline':'is-unstable');}}catch(e){heartbeatFailures++;paintConnection(heartbeatFailures>=3?'is-offline':'is-unstable');}}window.addEventListener('online',()=>{heartbeatFailures=0;paintConnection('is-unstable');heartbeat();});document.addEventListener('visibilitychange',()=>{if(!document.hidden){heartbeat();configureRealtimeFallback(hcRealtimeConnected);}else{if(ticketTimer)clearInterval(ticketTimer);ticketTimer=null;if(listTimer)clearInterval(listTimer);listTimer=null;if(hckPreviousTimer)clearInterval(hckPreviousTimer);hckPreviousTimer=null;if(liveConversationTimer)clearInterval(liveConversationTimer);liveConversationTimer=null;}});window.addEventListener('offline',()=>{heartbeatFailures=3;paintConnection('is-offline');});setInterval(updateConnectionUptime,1000);setInterval(updateRelativeTimes,30000);updateConnectionUptime();document.addEventListener('click',unlockAgentAlerts,{once:true});$('#availability').onclick=async()=>{let next=!available;let b=$('#availability');b.disabled=true;try{let r=await post('hc_agent_presence',{available:next?1:0,manual_toggle:1});if(r.success){available=!!r.data.available;hcAvailableAccumulated=Math.max(0,Number(r.data.available_seconds_today)||0);hcAvailableSince=available?Date.now():0;renderAvailability();configureRealtimeFallback(hcRealtimeConnected);}else alert(r.data?.message||'Could not update availability')}catch(e){alert(e.message||'Could not update availability')}finally{b.disabled=false}};
 function syncAgentViewport(){let h=window.visualViewport?window.visualViewport.height:window.innerHeight;document.documentElement.style.setProperty('--hc-agent-vh',Math.max(320,Math.round(h))+'px');}syncAgentViewport();if(window.visualViewport){window.visualViewport.addEventListener('resize',syncAgentViewport);window.visualViewport.addEventListener('scroll',syncAgentViewport);}window.addEventListener('resize',syncAgentViewport);$('#replyText').addEventListener('focus',()=>{syncAgentViewport();setTimeout(()=>{let c=$('#composer');if(c)c.scrollIntoView({block:'end',behavior:'smooth'});},80)});
 renderAvailability();ensureAgentAlertSettings();document.addEventListener('click',unlockAgentAlerts,{once:true});let initialUrl=new URL(window.location.href),initialSearch=initialUrl.searchParams.get('hc_search'),initialTicket=initialUrl.searchParams.get('ticket'),initialTab=initialUrl.searchParams.get('tab');if(initialTab==='closed'){tab='closed';homeTab='closed';document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab==='closed'));}if(initialSearch!==null){runGlobalSearch(initialSearch,{fromHistory:true});}else if(initialTicket&&/^\d+$/.test(initialTicket)){searchMode=true;openTicket(initialTicket,false);}loadList();heartbeat();setInterval(heartbeat,10000);configureRealtimeFallback(false);

/* v131 Kapture-style CRM workflows. Private collaboration data is kept outside the customer transcript. */
let crmComposerMode='reply', crmCurrentTicket=null, crmPrivateNotes=[], crmSideRows=[], crmCurrentSide=0, activeHckPrivateNotes=[];
function hcSyncModalLock(){const open=!!document.querySelector('.hc-crm-modal:not([hidden]),.hc-preview-modal:not([hidden]),.hc-followup-confirm:not([hidden])');document.body.classList.toggle('hc-modal-open',open);}
// Keep fixed overlays outside the transformed/scrolled ticket workspace. A fixed
// descendant of the workspace can otherwise behave like an ordinary page section.
document.querySelectorAll('.hc-crm-modal,.hc-preview-modal').forEach(modal=>{if(modal.parentElement!==document.body)document.body.appendChild(modal);});
function crmModal(id,open){const node=document.getElementById(id);if(!node)return;if(node.parentElement!==document.body)document.body.appendChild(node);node.hidden=!open;hcSyncModalLock();if(open){window.requestAnimationFrame(()=>{const first=node.querySelector('input:not([disabled]),textarea:not([disabled]),select:not([disabled]),button:not([disabled])');if(first)first.focus();});}}
function crmContextTab(name){
 const aliases={additional:'details',side:'notes',past:'previous',activity:'history'};
 const target=aliases[name]||name;
 if(typeof setContextView==='function'){setContextView(['customer','details','additional'].includes(target)?'profile':target);return;}
 const section=$('#details [data-context-section="'+target+'"]');if(section){section.open=true;}
}
document.querySelectorAll('[data-crm-close]').forEach(b=>b.addEventListener('click',()=>{let m=b.closest('.hc-crm-modal');if(m){m.hidden=true;hcSyncModalLock();}}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelectorAll('.hc-crm-modal:not([hidden])').forEach(m=>m.hidden=true);hcSyncModalLock();}});
function closeHckAgentRealtime(){
 hckRealtimeGeneration++;hckRealtimeTicketId=0;hckRealtimePending=0;hckRealtimeConnected=false;hckRealtimeConnectPromise=null;
 if(hckRealtimeConnection){try{hckRealtimeConnection.close();}catch(e){}hckRealtimeConnection=null;}
 configureHckPreviousFallback();
}
function hckAgentMessageRow(message){
 const m=message||{},atts=Array.isArray(m.attachments)?m.attachments:[],first=atts[0]||{};
 let content=String(m.content||'');if(atts.length>1)content+=(content?'\n':'')+atts.slice(1).map(a=>'Attachment: '+String(a.name||'Attachment')).join('\n');
 return {id:Number(m.id)||0,client_message_id:String(m.client_message_id||''),message_key:m.client_message_id?'client:'+String(m.client_message_id):'hck:'+(Number(m.id)||0),sender_type:'visitor',sender_name:m.sender_name||'Customer',content:content,created_at:m.created_at||'Just now',attachment_name:first.name||'',attachment_url:first.url||'',attachment_mime:first.mime||'',attachment_kind:String(first.mime||'').startsWith('image/')?'image':(String(first.mime||'').startsWith('video/')?'video':'file')};
}
function hckAgentReceive(event,eventName,channelName,ticketId,generation){
 if(generation!==hckRealtimeGeneration||Number(activeHck)!==Number(ticketId)||eventName!=='hck.message'||channelName!=='hck-customer-'+ticketId)return;
 const m=event&&event.message;if(!m||m.is_internal||m.sender_type==='agent')return;
 const row=hckAgentMessageRow(m),added=appendUnique([row],false);hckAfterId=Math.max(hckAfterId,Number(row.id)||0);
 if(added){notifyAgent('New customer message','HCK ticket #'+ticketId+' · '+String(row.content||'New message received').replace(/\s+/g,' ').slice(0,115),ticketId,msgKey(row));}
}
function connectHckAgentRealtime(ticketId){
 ticketId=Number(ticketId)||0;if(!ticketId||!window.HCRealtimeClient||!window.Ably)return Promise.resolve(null);
 if(hckRealtimeTicketId===ticketId&&(hckRealtimeConnection||hckRealtimeConnectPromise))return hckRealtimeConnectPromise||Promise.resolve(hckRealtimeConnection);
 closeHckAgentRealtime();const generation=++hckRealtimeGeneration;hckRealtimeTicketId=ticketId;hckRealtimePending=ticketId;hckRealtimeConnected=false;configureHckPreviousFallback();
 hckRealtimeConnectPromise=window.HCRealtimeClient.connect({ajaxUrl:HCAG.ajax,nonce:HCAG.hckNonce,channelType:'hck_ticket',ticketId:ticketId,sourceHcTicketId:Number(active||activeLive||0)},(ev,eventName,channelName)=>hckAgentReceive(ev,eventName,channelName,ticketId,generation),state=>{
  if(generation!==hckRealtimeGeneration)return;hckRealtimeConnected=state==='connected';configureHckPreviousFallback();
  console.debug('[HCK Ably] Agent Desk ticket '+ticketId+': '+state);
  if(hckRealtimeConnected)pollHckAgentMessages();
 }).then(connection=>{
  if(generation!==hckRealtimeGeneration||Number(activeHck)!==ticketId){connection.close();return null;}
  hckRealtimeConnection=connection;hckRealtimePending=0;hckRealtimeConnected=true;configureHckPreviousFallback();console.info('[HCK Ably] Agent Desk subscribed to HCK ticket '+ticketId);pollHckAgentMessages();return connection;
 }).catch(error=>{
  if(generation!==hckRealtimeGeneration)return null;hckRealtimePending=0;hckRealtimeTicketId=0;hckRealtimeConnected=false;hckRealtimeConnectPromise=null;console.warn('[HCK Ably] Agent Desk ticket connection failed; incremental polling enabled.',{ticket_id:ticketId,error:error});configureHckPreviousFallback();return null;
 });
 return hckRealtimeConnectPromise;
}
function publishHckAgentMessage(ticketId,message){
 ticketId=Number(ticketId)||0;if(!ticketId||!message)return Promise.resolve(false);
 const connect=hckRealtimeConnectPromise||connectHckAgentRealtime(ticketId);
 return Promise.resolve(connect).then(connection=>{
  if(!connection||Number(activeHck)!==ticketId||message._hcPublishCancelled)return false;
  const publicMessage=Object.assign({},message);delete publicMessage._hcPublishCancelled;
  return connection.publishTo('hck-agent-'+ticketId,'hck.message',{ticket_id:ticketId,message:publicMessage}).then(()=>{console.debug('[HCK Ably] Agent message publish acknowledged.',{ticket_id:ticketId,client_message_id:message.client_message_id});return true;}).catch(error=>{console.warn('[HCK Ably] Agent direct publish failed; saved-message fallback will be used.',{ticket_id:ticketId,client_message_id:message.client_message_id,error:error});return false;});
 }).catch(()=>false);
}
function relayHckAgentMessage(ticketId,message){
 const fd=new FormData();fd.append('action','hck_publish_realtime_message');fd.append('nonce',HCAG.hckNonce||'');fd.append('ticket_id',String(ticketId));fd.append('client_message_id',String(message.client_message_id));fd.append('message',String(message.content||''));
 return fetch(HCAG.ajax,{method:'POST',body:fd,credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(r=>{if(!r||!r.success)throw new Error(r&&r.data&&r.data.message||'Realtime server relay failed.');console.info('[HCK Realtime] Agent pre-save relay acknowledged.',{ticket_id:ticketId,client_message_id:message.client_message_id});return true;}).catch(error=>{console.warn('[HCK Realtime] Agent relay failed; database recovery remains available.',{ticket_id:ticketId,client_message_id:message.client_message_id,error:error});return false;});
}
function deliverHckAgentMessage(ticketId,message){
 let timer;const direct=publishHckAgentMessage(ticketId,message);
 return Promise.race([direct,new Promise(resolve=>{timer=setTimeout(()=>resolve(false),650);})]).then(delivered=>{
  clearTimeout(timer);if(delivered)return true;
  message._hcPublishCancelled=true;
  return relayHckAgentMessage(ticketId,message);
 });
}
async function pollHckAgentMessages(){
 const ticketId=Number(activeHck)||0;if(!ticketId||hckMessagePollBusy||document.hidden)return;
 hckMessagePollBusy=true;try{const r=await postHck('hck_poll_new_messages',{ticket_id:ticketId,after_id:hckAfterId,source_hc_ticket_id:Number(active||activeLive||0)});if(!r.success)throw new Error(r.data?.message||'HCK message recovery failed.');if(Number(activeHck)!==ticketId)return;
  (r.data.messages||[]).forEach(m=>{if(m.is_internal)return;const sender=m.sender_type==='agent'?'agent':'visitor';const atts=Array.isArray(m.attachments)?m.attachments:[];const first=atts[0]||{};let content=String(m.content||'');if(atts.length>1)content+=(content?'\n':'')+atts.slice(1).map(a=>'Attachment: '+String(a.name||'Attachment')).join('\n');const row={id:Number(m.id)||0,client_message_id:String(m.client_message_id||''),message_key:m.client_message_id?'client:'+m.client_message_id:'hck:'+m.id,sender_type:sender,sender_name:m.sender_name|| (sender==='agent'?'Support agent':'Customer'),content:content,created_at:m.created_at||'',attachment_name:first.name||'',attachment_url:first.url||'',attachment_mime:first.mime||'',attachment_kind:String(first.mime||'').startsWith('image/')?'image':(String(first.mime||'').startsWith('video/')?'video':'file')};const added=appendUnique([row],false);if(added&&sender==='visitor'){notifyAgent('New customer message','HCK ticket #'+ticketId+' · '+String(content||'New message received').replace(/\s+/g,' ').slice(0,115),ticketId,msgKey(row));}hckAfterId=Math.max(hckAfterId,Number(m.id)||0);});
  hckAfterId=Math.max(hckAfterId,Number(r.data.last_id)||0);
 }catch(e){console.warn('[HCK] Incremental message recovery failed:',e.message||e);}finally{hckMessagePollBusy=false;}
}
function configureHckPreviousFallback(){
 if(hckPreviousTimer)clearInterval(hckPreviousTimer);hckPreviousTimer=null;
 if(activeHck&&!document.hidden){hckPreviousTimer=setInterval(()=>{if(activeHck&&!document.hidden&&!hckRealtimeConnected)pollHckAgentMessages();},1500);}
 if(hckMessagePollTimer)clearInterval(hckMessagePollTimer);hckMessagePollTimer=null;
 if(activeHck&&!document.hidden&&hckRealtimeConnected){hckMessagePollTimer=setInterval(()=>{if(activeHck&&!document.hidden)pollHckAgentMessages();},20000);}
}
async function openHckPreviousTicket(ticketId,incremental=false){
 const currentHcId=Number(active||activeLive||0);if(!currentHcId)return;
 if(!incremental){
  const receipt=$('#handoffBanner');if(receipt)receipt.hidden=true;
  $('#hcLiveSupportInfoCard').hidden=true;
  clearStagedAgentFiles();
  if(Number(activeHck)!==Number(ticketId)){hckAfterId=0;closeHckAgentRealtime();}
  activeHck=Number(ticketId);
  connectHckAgentRealtime(activeHck);
  if(hckPreviousTimer)clearInterval(hckPreviousTimer);
  hckPreviousTimer=null;
  if(liveConversationTimer)clearInterval(liveConversationTimer);liveConversationTimer=null;
  if(ticketTimer)clearInterval(ticketTimer);
  layout.classList.remove('inbox-open');
  layout.classList.add('open','ticket-mode');
  $('#homeOverview').style.display='none';
  
  $('#handoffBanner').hidden=true;
  $('#ticketTitle').textContent='Loading HCK ticket…';
  $('#ticketMeta').textContent='Previous customer ticket';
  $('#messages').innerHTML=conversationLoadingMarkup('Loading follow-up ticket','Restoring the original conversation and current ticket replies…');
  ['prioritySelect','ticketStatusSelect'].forEach(id=>$('#'+id).dataset.dirty='');
 }
 const box=$('#messages');
 const oldScroll=box.scrollTop;
 const wasBottom=(box.scrollHeight-box.scrollTop-box.clientHeight)<70;
 try{
  let r=await post('hc_agent_hck_ticket',{ticket_id:activeHck,current_hc_ticket_id:currentHcId});
  if(!r.success)throw new Error(r.data?.message||'Could not open previous ticket.');
  let d=r.data,t=d.ticket;
  hckAfterId=Math.max(hckAfterId,...(Array.isArray(d.messages)?d.messages.map(m=>Number(m.id)||0):[0]));
  $('#ticketTitle').textContent=(t.number||('#'+t.id))+' · '+(t.subject||'Support ticket');
  $('#ticketMeta').textContent=(t.status||'').replace(/_/g,' ')+' · '+(t.agent_name||'Unassigned')+' · Updated '+(t.updated_at||'');
  $('#detailId').textContent=t.number||('#'+t.id);
  $('#detailName').textContent=t.customer_name||'—';
  $('#detailEmail').textContent=t.customer_email||'—';
  $('#detailPhone').textContent=t.customer_phone||'Not available';
  $('#detailAssignedTo').textContent=t.agent_name||'Unassigned';
  $('#detailAssignedToAdditional').textContent=t.agent_name||'Unassigned';
  $('#contextCustomerName').textContent=t.customer_name||'Customer';
  $('#contextCustomerEmail').textContent=t.customer_email||'No email on file';
  $('#contextAvatar').textContent=(t.customer_name||'C').trim().charAt(0).toUpperCase();
  $('#detailIssue').textContent=t.subject||'No issue description provided.';
  $('#detailPriority').textContent=t.priority||'—';
  $('#detailStatus').textContent=t.status||'—';
  if(!incremental||!$('#prioritySelect').dataset.dirty)$('#prioritySelect').value=t.priority||'normal';
  if(!incremental||!$('#ticketStatusSelect').dataset.dirty){
   $('#ticketStatusSelect').innerHTML='<option value="open">Open</option><option value="in_progress">In progress</option><option value="awaiting_reply">Awaiting reply</option><option value="resolved">Resolved</option><option value="closed">Closed</option>';
   $('#ticketStatusSelect').value=t.status||'open';
  }
  const canHandle=!!d.can_handle;
  ['prioritySelect','ticketStatusSelect','saveTicketMeta'].forEach(id=>{let el=$('#'+id);if(el)el.disabled=!canHandle;});
  ['subStatusSelect','ticketTagsInput','assignTicket','assignAgent','assignAgentSearch','editCustomer','editCustomerInline','composeEmail','openInternalNoteModal','newSideConversation'].forEach(id=>{let el=$('#'+id);if(el)el.disabled=true;});
  $('#claim').hidden=!d.can_claim;
  $('#claim').textContent='Take ticket';
  $('#close').hidden=true;
  $('#composer').classList.toggle('hidden',!canHandle);
  $('#attach').disabled=!canHandle;
  $('#generateSummary').disabled=!canHandle;
  $('#convertLiveToHck').hidden=true;
  $('#sideConversationList').innerHTML='<div class="hc-private-empty">Side conversations are attached to the active HelpCenter conversation. Use Internal Note for this HCK ticket.</div>';
  $('#summarySide').innerHTML=t.ai_summary?'<article class="hc-ai-summary-card"><div class="hc-ai-summary-card-head"><i class="fa-solid fa-wand-magic-sparkles"></i> Final ticket summary</div><div class="hc-ai-summary-content">'+renderMarkdown(t.ai_summary)+'</div></article>':'No AI summary has been generated for this HCK ticket yet.';
  const briefText=String(d.handoff_brief||'');const briefPanel=$('#hckHandoffBrief'),briefBody=$('#hckHandoffBriefBody');if(briefPanel&&briefBody){briefBody.innerHTML=briefText?renderHandoffBrief(briefText):'';briefPanel.hidden=!briefText;if(briefText)briefPanel.open=false;}
  $('#privateNotesList').innerHTML='';
  let privateRows=(d.messages||[]).filter(m=>m.is_internal&&!['HelpCenter Handoff Brief','AI Ticket Summary'].includes(String(m.sender_name||'')));activeHckPrivateNotes=privateRows;
  $('#privateNoteCount').textContent=String(privateRows.length);
  if(privateRows.length){privateRows.forEach(m=>{let el=document.createElement('article');el.className='hc-private-note'+(m.is_deleted?' is-deleted':'');el.dataset.hckNoteId=String(m.id);if(m.is_deleted){el.innerHTML=`<div class="hc-note-audit"><i class="fa-solid fa-trash"></i> Private note deleted by ${esc(m.deleted_by_name||'agent')} · ${esc(m.deleted_at||m.created_at||'')}</div>`;}else{let h=document.createElement('header');h.innerHTML=`<span><i class="fa-solid fa-lock"></i> ${esc(m.sender_name||'Agent')}</span><time>${esc(m.created_at||'')}</time>`;let p=document.createElement('p');p.textContent=m.message||'';el.append(h,p);if(m.edited_at){let audit=document.createElement('div');audit.className='hc-note-audit';audit.innerHTML=`<i class="fa-solid fa-pen"></i> Edited by ${esc(m.edited_by_name||'agent')} · ${esc(m.edited_at)}`;el.append(audit);}if(m.can_edit){let actions=document.createElement('div');actions.className='hc-note-actions';actions.innerHTML=`<button type="button" data-hck-note-edit="${Number(m.id)}"><i class="fa-solid fa-pen"></i> Edit</button><button type="button" data-hck-note-delete="${Number(m.id)}"><i class="fa-solid fa-trash"></i> Delete</button>`;el.append(actions);}}$('#privateNotesList').appendChild(el);});}
  else $('#privateNotesList').innerHTML='<div class="hc-private-empty">No internal notes on this ticket.</div>';
  $('#ticketActivity').innerHTML=(d.activity||[]).length?d.activity.map(a=>'<div class="hc-activity-item"><strong>'+esc(a.title||'Ticket update')+'</strong><small>'+esc(a.actor||'System')+' · '+esc(a.created_at||'')+'</small><p>'+esc(a.detail||'')+'</p></div>').join(''):'<div class="hc-private-empty">No ticket activity recorded.</div>';
  if(!incremental){$('#detailAttachments').innerHTML='';box.innerHTML='';}
  const existingKeys=new Set(Array.from(box.querySelectorAll('[data-message-key]')).map(node=>node.getAttribute('data-message-key')));
  (d.messages||[]).forEach(m=>{
   if(m.is_internal&&m.sender_name==='HelpCenter Handoff Brief')return;
   let who=m.is_internal?'internal_note':(m.sender_type==='ai'?'ai':(m.sender_type==='visitor'||m.sender_type==='customer'?'visitor':m.sender_type==='system'?'system':m.is_admin?'agent':'visitor'));
   let firstFile=(m.attachments||[])[0]||{};
   let mime=firstFile.mime||'';
   let kind=mime.startsWith('image/')?'image':(mime.startsWith('video/')?'video':'file');
   let messageKey='hck:'+m.id,clientId=String(m.client_message_id||''),existingClient=clientId?box.querySelector('[data-client-message-id="'+CSS.escape(clientId)+'"]'):null;if(existingClient){existingClient.dataset.messageKey=messageKey;let whoNode=existingClient.querySelector('.who');if(whoNode)whoNode.textContent=(m.sender_name||m.sender_type)+' · '+(m.created_at||'');existingKeys.add(messageKey);return;}if(existingKeys.has(messageKey))return;existingKeys.add(messageKey);let row={id:m.id,message_key:messageKey,client_message_id:clientId,sender_type:who,sender_name:m.sender_name||m.sender_type,sender_user_id:Number(m.user_id)||0,is_internal_note:!!m.is_internal,is_edited:!!m.edited_at,edited_by_name:m.edited_by_name||'',is_deleted:!!m.is_deleted,deleted_at:m.deleted_at||'',deleted_by_name:m.deleted_by_name||'',can_edit_note:!!m.can_edit,content:m.message||'',created_at:m.created_at,attachment_name:firstFile.filename||'',attachment_url:firstFile.url||'',attachment_mime:mime,attachment_kind:kind};
   if(m.attachments?.length){
    row.content+='\n'+m.attachments.map(a=>'Attachment: '+a.filename).join('\n');
    m.attachments.forEach(a=>{let el=document.createElement('a');el.className='hc-history-card';el.href=a.url||'#';el.target='_blank';el.rel='noopener';el.textContent=a.filename||'Attachment';$('#detailAttachments').appendChild(el);});
   }
   box.insertAdjacentHTML('beforeend',messageHTML(row));
  });
  if(!$('#detailAttachments').children.length)$('#detailAttachments').innerHTML='<span class="muted">No attachments</span>';
  if(!box.querySelector('[data-message-key]')&&!d.messages?.length)box.innerHTML='<div class="empty">No messages found.</div>';
  paintAgentSla(d.sla);
  if(incremental&&!wasBottom)box.scrollTop=oldScroll;else if(incremental&&box.scrollHeight>oldScroll)box.scrollTop=box.scrollHeight;else box.scrollTop=box.scrollHeight;
  if(!incremental)configureHckPreviousFallback();
  return true;
 }catch(e){if(!incremental)box.innerHTML='<div class="empty">'+esc(e.message||'Could not open previous ticket.')+'</div>';return false;}
}
$('#customerHistory')?.addEventListener('click',e=>{let b=e.target.closest('[data-hck-ticket]');if(b)openHckPreviousTicket(Number(b.dataset.hckTicket));});
function renderPrivateNotes(){const box=$('#privateNotesList');if(!box)return;$('#privateNoteCount').textContent=String(crmPrivateNotes.length);if(!crmPrivateNotes.length){box.innerHTML='<div class="hc-private-empty">No private notes yet. Add investigation details or handover context for other agents.</div>';return;}box.innerHTML=crmPrivateNotes.map(n=>{if(Number(n.is_deleted))return `<article class="hc-private-note is-deleted"><div class="hc-note-audit"><i class="fa-solid fa-trash"></i> Note deleted by ${esc(n.deleted_by_name||'support agent')} · ${esc(n.deleted_at||'')}</div></article>`;let actions=n.can_edit?`<div class="hc-note-actions"><button type="button" data-note-edit="${Number(n.id)}"><i class="fa-solid fa-pen"></i> Edit</button><button type="button" data-note-delete="${Number(n.id)}"><i class="fa-solid fa-trash"></i> Delete</button></div>`:'';let audit=n.updated_at?`<div class="hc-note-audit"><i class="fa-solid fa-pen"></i> Edited by ${esc(n.updated_by_name||'support agent')} · ${esc(n.updated_at)}</div>`:'';return `<article class="hc-private-note" data-note-id="${Number(n.id)}"><header><span><i class="fa-solid fa-lock"></i> ${esc(n.author_name||'Support agent')}</span><time>${esc(n.created_at||'')}</time></header><p>${esc(n.note||'')}</p>${audit}${actions}</article>`}).join('');}
function renderSideRows(){const box=$('#sideConversationList');const count=$('#sideConversationCount');if(count)count.textContent=String(crmSideRows.length);if(!box)return;if(!crmSideRows.length){box.innerHTML='<div class="hc-private-empty">No private side conversations for this ticket yet. Start one to bring another agent into the investigation.</div>';return;}box.innerHTML=crmSideRows.map(x=>`<button type="button" class="hc-side-item" data-side-id="${Number(x.id)}"><strong>${esc(x.subject||'Side conversation')}</strong><small>With ${esc(Number(x.created_by)===Number(HCAG.currentUserId)?(x.recipient_name||'agent'):(x.created_by_name||'agent'))} · ${esc(x.updated_at||x.created_at||'')}</small></button>`).join('');}
function renderTicketActivity(rows){const box=$('#ticketActivity');if(!box)return;let a=(rows||[]).slice(-60).reverse();if(!a.length){box.innerHTML='<div class="hc-private-empty">No activity has been recorded yet.</div>';return;}box.innerHTML=a.map(m=>{let label=m.sender_type==='visitor'?'Customer':m.sender_type==='ai'?'AI assistant':m.sender_type==='system'?'System':'Support agent';let content=String(m.content||'').replace(/\s+/g,' ').slice(0,220);return `<div class="hc-activity-item"><strong>${esc(label)} · ${esc(m.sender_name||'')}</strong><small>${esc(m.created_at||'')}</small><p>${esc(content)}</p></div>`}).join('');}
async function loadWorkspaceExtras(ticketId, messages, ticket){if(!ticketId)return;try{let r=await post('hc_agent_workspace_data',{ticket_id:ticketId});if(!r.success)throw new Error(r.data?.message||'Workspace details unavailable');if(Number(active)!==Number(ticketId))return;crmCurrentTicket=ticket||crmCurrentTicket;crmPrivateNotes=r.data.notes||[];crmSideRows=r.data.side_conversations||[];renderPrivateNotes();renderSideRows();let meta=r.data.meta||{};if($('#subStatusSelect'))$('#subStatusSelect').value=meta.sub_status||'';if($('#ticketTagsInput'))$('#ticketTagsInput').value=(meta.tags||[]).join(', ');renderTicketActivity(messages||[]);}catch(e){console.warn('Could not load private CRM workspace details:',e);if($('#privateNotesList'))$('#privateNotesList').innerHTML='<div class="hc-private-empty">Private workspace details could not be loaded. Refresh the ticket to retry.</div>';}}
function setComposerMode(mode){crmComposerMode=mode==='note'?'note':'reply';document.querySelectorAll('[data-compose-mode]').forEach(b=>b.classList.toggle('active',b.dataset.composeMode===crmComposerMode));$('#replyText').placeholder=crmComposerMode==='note'?'Write a private internal note for support agents…':'Write a professional reply to the customer…';$('#send').innerHTML=crmComposerMode==='note'?'<i class="fa-solid fa-lock"></i> Save private note':'<i class="fa-solid fa-paper-plane"></i> Send reply';$('#send').classList.toggle('hc-private-send',crmComposerMode==='note');if($('#attach'))$('#attach').disabled=crmComposerMode==='note';}
document.querySelectorAll('[data-compose-mode]').forEach(b=>b.addEventListener('click',()=>setComposerMode(b.dataset.composeMode)));
$('#messages')?.addEventListener('click',async e=>{let edit=e.target.closest('[data-hck-note-edit]'),del=e.target.closest('[data-hck-note-delete]');if(!edit&&!del)return;let id=Number((edit||del).dataset[edit?'hckNoteEdit':'hckNoteDelete']),row=activeHckPrivateNotes.find(n=>Number(n.id)===id);if(!row)return;if(edit){let value=window.prompt('Edit this private HCK note:',row.message||'');if(value===null)return;try{let r=await postHck('hck_edit_internal_note',{ticket_id:activeHck,message_id:id,message:value});if(!r.success)throw new Error(r.data?.message||'Could not edit note.');await openHckPreviousTicket(activeHck,false);}catch(err){window.alert(err.message);}}else if(window.confirm('Delete this private HCK note? Its text will be removed and an audit marker will remain.')){try{let r=await postHck('hck_delete_internal_note',{ticket_id:activeHck,message_id:id});if(!r.success)throw new Error(r.data?.message||'Could not delete note.');await openHckPreviousTicket(activeHck,false);}catch(err){window.alert(err.message);}}});
$('#privateNotesList')?.addEventListener('click',async e=>{let edit=e.target.closest('[data-note-edit]'),del=e.target.closest('[data-note-delete]'),hckEdit=e.target.closest('[data-hck-note-edit]'),hckDel=e.target.closest('[data-hck-note-delete]');if(edit||del){let id=Number((edit||del).dataset[edit?'noteEdit':'noteDelete']),row=crmPrivateNotes.find(n=>Number(n.id)===id);if(!row)return;if(edit){let value=window.prompt('Edit this private note:',row.note||'');if(value===null)return;try{let r=await post('hc_agent_workspace_note_edit',{ticket_id:active,note_id:id,note:value});if(!r.success)throw new Error(r.data?.message||'Could not edit note.');await loadWorkspaceExtras(active,[],crmCurrentTicket);}catch(err){window.alert(err.message);}}else if(window.confirm('Delete this private note? Its text will be removed and an audit entry will remain.')){try{let r=await post('hc_agent_workspace_note_delete',{ticket_id:active,note_id:id});if(!r.success)throw new Error(r.data?.message||'Could not delete note.');await loadWorkspaceExtras(active,[],crmCurrentTicket);}catch(err){window.alert(err.message);}}return;}if(hckEdit||hckDel){let id=Number((hckEdit||hckDel).dataset[hckEdit?'hckNoteEdit':'hckNoteDelete']),row=activeHckPrivateNotes.find(n=>Number(n.id)===id);if(!row)return;if(hckEdit){let value=window.prompt('Edit this private HCK note:',row.message||'');if(value===null)return;try{let r=await postHck('hck_edit_internal_note',{ticket_id:activeHck,message_id:id,message:value});if(!r.success)throw new Error(r.data?.message||'Could not edit note.');await openHckPreviousTicket(activeHck,false);}catch(err){window.alert(err.message);}}else if(window.confirm('Delete this private HCK note? Its text will be removed and an audit marker will remain.')){try{let r=await postHck('hck_delete_internal_note',{ticket_id:activeHck,message_id:id});if(!r.success)throw new Error(r.data?.message||'Could not delete note.');await openHckPreviousTicket(activeHck,false);}catch(err){window.alert(err.message);}}}});
async function submitPrivateNote(text){if(!active||!text.trim())return;let r=await post('hc_agent_workspace_note',{ticket_id:active,note:text.trim()});if(!r.success)throw new Error(r.data?.message||'Private note could not be saved.');await loadWorkspaceExtras(active,[],crmCurrentTicket);crmContextTab('notes');}
let privateNoteInFlight=false;$('#send').addEventListener('click',async e=>{if(crmComposerMode!=='note')return;e.preventDefault();e.stopImmediatePropagation();let text=$('#replyText').value.trim();if(!text||!active||$('#send').disabled||privateNoteInFlight)return;privateNoteInFlight=true;let btn=$('#send');btn.disabled=true;try{await submitPrivateNote(text);$('#replyText').value='';$('#replyText').style.height='auto';}catch(err){alert(err.message||'Private note could not be saved.');}finally{privateNoteInFlight=false;btn.disabled=false;setComposerMode('reply');}},true);
$('#openInternalNoteModal')?.addEventListener('click',()=>{if(!active)return alert('Open a ticket first.');$('#hcInternalNoteText').value='';crmModal('hcInternalNoteModal',true);});
$('#saveInternalNote')?.addEventListener('click',async()=>{let text=$('#hcInternalNoteText').value.trim(),b=$('#saveInternalNote');if(!active||!text)return alert('Open a ticket and enter a note.');b.disabled=true;try{await submitPrivateNote(text);$('#hcInternalNoteText').value='';crmModal('hcInternalNoteModal',false);}catch(e){alert(e.message||'Could not save note.');}finally{b.disabled=false;}});
$('#privateNotesList')?.addEventListener('click',()=>{});
const hcEmailTemplates={acknowledgement:'Thank you for contacting us. We are following up on your support request and reviewing the details. We will share an update as soon as we have confirmed information.',progress:'We wanted to share a quick update on your support request. Our team is continuing to review the details. We will contact you again when we have a confirmed update.',details:'To help us investigate this further, could you please share the following details?\n\n[Add the specific information you need from the customer.]',checkin:'We are following up to check whether the solution shared for your support request has resolved the issue. Please let us know if you need any further assistance.'};
const emailMessage=$('#hcEmailMessage'),emailCount=$('#hcEmailMessageCount'),emailSend=$('#sendCustomerEmail');
function updateEmailComposer(){if(emailCount)emailCount.textContent=(emailMessage?.value.length||0).toLocaleString()+' / 5,000';if(emailSend)emailSend.disabled=!$('#hcEmailSubject')?.value.trim()||!emailMessage?.value.trim();}
document.querySelectorAll('[data-email-template]').forEach(button=>button.addEventListener('click',()=>{if(!emailMessage)return;emailMessage.value=hcEmailTemplates[button.dataset.emailTemplate]||'';updateEmailComposer();emailMessage.focus();emailMessage.setSelectionRange(emailMessage.value.length,emailMessage.value.length);document.querySelectorAll('[data-email-template]').forEach(x=>x.classList.toggle('active',x===button));}));
emailMessage?.addEventListener('input',updateEmailComposer);$('#hcEmailSubject')?.addEventListener('input',updateEmailComposer);
$('#composeEmail')?.addEventListener('click',()=>{if(!active||activeLive)return alert('Customer email is available for a standard assigned ticket.');const email=$('#detailEmail').textContent||'No email';$('#hcEmailRecipient').textContent=email;$('#hcEmailTicketContext').textContent='HelpCenter conversation #'+active+' · '+($('#detailName').textContent||'Customer');$('#hcEmailSubject').value='Update regarding your support request #'+active;emailMessage.value='';document.querySelectorAll('[data-email-template]').forEach(x=>x.classList.remove('active'));updateEmailComposer();crmModal('hcEmailModal',true);});
emailSend?.addEventListener('click',async()=>{let subject=$('#hcEmailSubject').value.trim(),message=emailMessage.value.trim(),b=emailSend;if(!active||!subject||!message)return;if(b.disabled)return;b.disabled=true;b.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i><span>Sending email…</span>';try{let r=await post('hc_agent_send_followup_email',{ticket_id:active,subject,message});if(!r.success)throw new Error(r.data?.message||'Email could not be sent.');crmModal('hcEmailModal',false);alert(r.data.message||'Email sent.');}catch(e){alert(e.message||'Email failed.');}finally{b.disabled=false;b.innerHTML='<i class="fa-regular fa-paper-plane"></i><span>Send follow-up email</span>';updateEmailComposer();}});
function openSideComposer(){if(!active||activeLive)return alert('Open an assigned ticket before starting a side conversation.');let select=$('#hcSideRecipient');let agents=(assignmentAgents||[]).filter(a=>Number(a.id)!==Number(HCAG.currentUserId));select.innerHTML=agents.map(a=>`<option value="${Number(a.id)}">${esc(a.name)}${a.online?' · Available':' · Offline'}</option>`).join('');if(!agents.length){alert('No other HelpCenter agents are available in the agent directory.');return;}$('#hcSideSubject').value='Ticket #'+active+' · Internal help';$('#hcSideMessage').value='';crmModal('hcSideConversationModal',true);}
$('#newSideConversation')?.addEventListener('click',openSideComposer);
$('#createSideConversation')?.addEventListener('click',async()=>{let b=$('#createSideConversation'),recipient_id=Number($('#hcSideRecipient').value||0),subject=$('#hcSideSubject').value.trim(),message=$('#hcSideMessage').value.trim();if(!recipient_id||!subject||!message)return alert('Choose an agent and enter a subject and message.');b.disabled=true;b.textContent='Creating…';try{let r=await post('hc_agent_workspace_side_create',{ticket_id:active,recipient_id,subject,message});if(!r.success)throw new Error(r.data?.message||'Side conversation could not be created.');crmModal('hcSideConversationModal',false);await loadWorkspaceExtras(active,[],crmCurrentTicket);crmContextTab('side');openSideThread(r.data.id);}catch(e){alert(e.message||'Side conversation could not be created.');}finally{b.disabled=false;b.textContent='Start conversation';}});
async function openSideThread(sideId){let r=await post('hc_agent_workspace_side_get',{side_id:sideId});if(!r.success)throw new Error(r.data?.message||'Could not load side conversation.');crmContextTab('side');crmCurrentSide=Number(sideId);$('#hcSideThreadTitle').textContent=r.data.side.subject||'Side conversation';let box=$('#hcSideThreadMessages');box.innerHTML=(r.data.messages||[]).map(m=>`<article class="hc-side-message"><strong>${esc(m.author_name||'Agent')}</strong><time>${esc(m.created_at||'')}</time><p>${esc(m.content||'')}</p></article>`).join('')||'<div class="hc-private-empty">No messages yet.</div>';box.scrollTop=box.scrollHeight;crmModal('hcSideThreadModal',true);}
$('#sideConversationList')?.addEventListener('click',e=>{let b=e.target.closest('[data-side-id]');if(!b)return;openSideThread(Number(b.dataset.sideId)).catch(err=>alert(err.message));});
$('#sendSideThreadReply')?.addEventListener('click',async()=>{let message=$('#hcSideThreadReply').value.trim(),b=$('#sendSideThreadReply');if(!crmCurrentSide||!message)return;b.disabled=true;try{let r=await post('hc_agent_workspace_side_reply',{side_id:crmCurrentSide,message});if(!r.success)throw new Error(r.data?.message||'Private reply failed.');$('#hcSideThreadReply').value='';await openSideThread(crmCurrentSide);await loadWorkspaceExtras(active,[],crmCurrentTicket);}catch(e){alert(e.message||'Could not send private reply.');}finally{b.disabled=false;}});
function openCustomerEdit(){if(!active)return;$('#hcCustomerName').value=$('#detailName').textContent==='—'?'':$('#detailName').textContent;$('#hcCustomerEmail').value=$('#detailEmail').textContent==='—'?'':$('#detailEmail').textContent;crmModal('hcCustomerModal',true);}
$('#editCustomer')?.addEventListener('click',openCustomerEdit);$('#editCustomerInline')?.addEventListener('click',openCustomerEdit);
$('#saveCustomerDetails')?.addEventListener('click',async()=>{let b=$('#saveCustomerDetails'),name=$('#hcCustomerName').value.trim(),email=$('#hcCustomerEmail').value.trim();if(!active||!name||!email)return alert('Enter a customer name and a valid email.');b.disabled=true;try{let r=await post('hc_agent_workspace_update',{ticket_id:active,customer_name:name,customer_email:email});if(!r.success)throw new Error(r.data?.message||'Customer details were not updated.');$('#detailName').textContent=name;$('#detailEmail').textContent=email;$('#contextCustomerName').textContent=name;$('#contextCustomerEmail').textContent=email;$('#contextAvatar').textContent=name.charAt(0).toUpperCase();crmModal('hcCustomerModal',false);loadList();}catch(e){alert(e.message||'Customer details could not be saved.');}finally{b.disabled=false;}});
['prioritySelect','ticketStatusSelect','subStatusSelect','ticketTagsInput'].forEach(id=>{let el=$('#'+id);if(el){el.addEventListener(id==='ticketTagsInput'?'input':'change',()=>{el.dataset.dirty='1';});}});
  $('#saveTicketMeta')?.addEventListener('click',async()=>{let b=$('#saveTicketMeta');if(activeHck){b.disabled=true;try{let pr=await postHck('hck_admin_change_priority',{ticket_id:activeHck,priority:$('#prioritySelect').value});if(!pr.success)throw new Error(pr.data?.message||'Priority update failed.');let st=await postHck('hck_admin_change_status',{ticket_id:activeHck,status:$('#ticketStatusSelect').value});if(!st.success)throw new Error(st.data?.message||'Status update failed.');['prioritySelect','ticketStatusSelect'].forEach(id=>$('#'+id).dataset.dirty='');await openHckPreviousTicket(activeHck,true);}catch(e){alert(e.message||'Ticket update failed.');}finally{b.disabled=false;}return;}let tags=$('#ticketTagsInput').value.split(',').map(x=>x.trim()).filter(Boolean),priority=$('#prioritySelect').value,sub_status=$('#subStatusSelect').value;if(!active)return;b.disabled=true;b.textContent='Saving…';try{let r=await post('hc_agent_workspace_update',{ticket_id:active,priority,ticket_status:$('#ticketStatusSelect').value,sub_status,tags:JSON.stringify(tags)});if(!r.success)throw new Error(r.data?.message||'Ticket details could not be saved.');$('#detailPriority').innerHTML='<span class="priority">'+esc(priority)+'</span>';$('#detailStatus').textContent=r.data.ticket_status||$('#ticketStatusSelect').value;alert('Ticket details saved.');loadList();}catch(e){alert(e.message||'Ticket details could not be saved.');}finally{b.disabled=false;b.innerHTML='<i class="fa-solid fa-floppy-disk"></i> Save ticket details';}});
$('#quickReplySelect')?.addEventListener('change',e=>{let v=e.target.value;if(!v)return;let box=$('#replyText');box.value=(box.value.trim()?box.value.trim()+'\n\n':'')+v;box.focus();box.dispatchEvent(new Event('input'));e.target.value='';setComposerMode('reply');});
// Deep links for agent-to-agent handoffs open the private thread without granting ticket ownership.
let crmInitialUrl=new URL(window.location.href),crmSideId=crmInitialUrl.searchParams.get('side_conversation');if(crmSideId&&/^\d+$/.test(crmSideId)){openSideThread(Number(crmSideId)).catch(e=>console.warn('Side conversation could not be opened:',e));}

})();</script><script id="hck-scroll-boundary-guard-v104">
(function(){
  if(window.__hckScrollBoundaryGuardV104)return;
  window.__hckScrollBoundaryGuardV104=true;
  var selector=[
    '.hck-admin-thread','.hck-customer-history-body','.hc-history-list','.hc-history-items',
    '#messages','.chatbody','.hc-support-transcript','.hc-support-ticket-list',
    '.hc-support-visitor-pane','.hc-support-context-body','.hc-support-history',
    '.hc-support-history-list','.hc-support-customer-history','.hc-ai-conversation-detail',
    '.hc-ai-conversation-messages','.hc-chat-messages','.hc-chat-body',
    '.hc-widget-messages','.hc-bot-messages','#hc-chat-messages','#hcMessages'
  ].join(',');
  function scrollBox(target){
    var node=target&&target.nodeType===1?target:target&&target.parentElement;
    while(node&&node!==document.body&&node!==document.documentElement){
      if(node.matches&&node.matches(selector)){
        var cs=window.getComputedStyle(node);
        var oy=cs.overflowY;
        if((oy==='auto'||oy==='scroll'||node.scrollHeight>node.clientHeight+1)&&node.scrollHeight>node.clientHeight+1)return node;
      }
      node=node.parentElement;
    }
    return null;
  }
  function atTop(el){return el.scrollTop<=1;}
  function atBottom(el){return el.scrollTop+el.clientHeight>=el.scrollHeight-2;}
  document.addEventListener('wheel',function(e){
    if(!e||!e.cancelable||!e.deltaY)return;
    var el=scrollBox(e.target);if(!el)return;
    if((e.deltaY<0&&atTop(el))||(e.deltaY>0&&atBottom(el)))e.preventDefault();
  },{capture:true,passive:false});
  var lastTouchY=null;
  document.addEventListener('touchstart',function(e){
    if(e.touches&&e.touches.length)lastTouchY=e.touches[0].clientY;
  },{capture:true,passive:true});
  document.addEventListener('touchmove',function(e){
    if(!e||!e.cancelable||!e.touches||!e.touches.length||lastTouchY===null)return;
    var y=e.touches[0].clientY,dy=y-lastTouchY;lastTouchY=y;
    if(Math.abs(dy)<0.5)return;
    var el=scrollBox(e.target);if(!el)return;
    /* Finger moving down requests scroll-up; finger moving up requests scroll-down. */
    if((dy>0&&atTop(el))||(dy<0&&atBottom(el)))e.preventDefault();
  },{capture:true,passive:false});
  document.addEventListener('touchend',function(){lastTouchY=null;},{capture:true,passive:true});
  document.addEventListener('touchcancel',function(){lastTouchY=null;},{capture:true,passive:true});
  function apply(){document.querySelectorAll(selector).forEach(function(el){
    if(el.scrollHeight>el.clientHeight+1){
      el.style.overscrollBehaviorY='none';
      el.style.overscrollBehaviorX='none';
      el.style.webkitOverflowScrolling='touch';
    }
  });}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply,{once:true});else apply();
  window.addEventListener('load',apply,{once:true});
})();
</script><?php if (class_exists('HC_Web_Push')) { HC_Web_Push::print_client_bootstrap(); } ?></body></html><?php
    }
    private static function tables() { global $wpdb; return array($wpdb->prefix.'hc_ai_escalations',$wpdb->prefix.'hc_ai_escalation_messages'); }
    private static function visitor_label($name,$email='') { $name=trim((string)$name); $email=trim((string)$email); if($name==='' || ($email!=='' && strcasecmp($name,$email)===0) || is_email($name)) return 'Customer'; return $name; }
    public static function reset_subject($title,$user_login='',$user_data=null) { if ($user_data && in_array('hc_support_agent',(array)$user_data->roles,true)) return get_option('hc_escalation_reset_subject','Reset your HelpCenter agent password'); return $title; }
    public static function reset_message($message,$key,$user_login,$user_data=null) { if (!$user_data || !in_array('hc_support_agent',(array)$user_data->roles,true)) return $message; $url=add_query_arg(array('key'=>$key,'login'=>$user_login),home_url('/support-agent/reset-password/')); $tpl=get_option('hc_escalation_reset_body',"Hello {name},\n\nUse this secure link to reset your password: {reset_url}\n\nIf you did not request this, ignore this email."); return str_replace(array('{name}','{login}','{email}','{portal}','{reset_url}'),array($user_data->display_name?:$user_login,$user_login,$user_data->user_email,home_url('/support-agent/login/'),$url),$tpl); }

    public static function generate_password() {
        if (!self::supervisor() || !check_ajax_referer('hc_nonce','nonce',false)) wp_send_json_error(array('message'=>'Administrator permission required.'),403);
        wp_send_json_success(array('password'=>wp_generate_password(24,true,true)));
    }

    public static function create_agent() {
        if (!self::supervisor() || !check_ajax_referer('hc_nonce','nonce',false)) wp_send_json_error(array('message'=>'Administrator permission required.'),403);
        $name=sanitize_text_field(wp_unslash($_POST['name']??''));
        $email=sanitize_email(wp_unslash($_POST['email']??''));
        $login=sanitize_user(wp_unslash($_POST['login']??''));
        $login_auto=!empty($_POST['login_auto']);
        if (!$login) {
            $base=sanitize_user(strtolower(remove_accents($name ?: (strstr($email,'@',true) ?: 'agent'))),true);
            $base=trim(preg_replace('/[^a-z0-9._-]+/','.', $base),'.-_');
            if (!$base) $base='agent';
            $login=$base; $n=1; while(username_exists($login)) { $login=$base.'.'.$n; $n++; }
        } elseif ($login_auto && username_exists($login)) { $base=$login; $n=1; while(username_exists($login)) { $login=$base.'.'.$n; $n++; } }
        $mode=sanitize_key($_POST['password_mode']??'auto');
        if (!in_array($mode,array('auto','manual'),true)) $mode='auto';
        $pass=$mode==='manual'?(string)wp_unslash($_POST['manual_password']??''):(string)wp_unslash($_POST['password']??'');
        if ($mode==='auto' && strlen($pass)<12) { $pass=wp_generate_password(24,true,true); }
        if (!$login||!validate_username($login)||!is_email($email)||strlen($pass)<12||username_exists($login)||email_exists($email)) wp_send_json_error(array('message'=>'Please provide a unique Login ID, valid email and a password of at least 12 characters.'),400);
        $id=wp_insert_user(array('user_login'=>$login,'user_email'=>$email,'display_name'=>$name?:$login,'user_pass'=>$pass,'role'=>'hc_support_agent'));
        if (is_wp_error($id)) wp_send_json_error(array('message'=>$id->get_error_message()),400);
        $ids=HC_Core::get_setting('hc_ai_support_agent_ids','');$list=array_filter(array_map('absint',preg_split('/[,;\s]+/',(string)$ids)));$list[]=(int)$id;HC_Core::update_setting('hc_ai_support_agent_ids',implode(',',array_unique($list)));
        $subject=get_option('hc_escalation_agent_welcome_subject','Your HelpCenter agent account');
        $body=get_option('hc_escalation_agent_welcome_body',"Hello {name},\n\nYour HelpCenter agent account has been created.\nLogin ID: {login}\nTemporary password: {password}\nAgent portal: {portal}\n\nPlease sign in and change your password if required.");
        $body=str_replace(array('{name}','{login}','{email}','{password}','{portal}'),array($name?:$login,$login,$email,$pass,home_url('/support-agent/login/')),$body); if(strpos(get_option('hc_escalation_agent_welcome_body',''),'{password}')===false)$body.="\n\nLogin ID: {$login}\nTemporary password: {$pass}";
        $mail_sent=wp_mail($email,$subject,$body);
        wp_send_json_success(array('id'=>$id,'login'=>$login,'password_mode'=>$mode,'email_sent'=>(bool)$mail_sent,'message'=>$mail_sent?'Agent account created and login details emailed.':'Agent account created, but the invitation email could not be sent. Please use the password shown below and check SMTP settings.','temporary_password'=>$mode==='auto'?$pass:''));
    }
    public static function manage_agent() {
        if (!self::supervisor() || !check_ajax_referer('hc_nonce','nonce',false)) wp_send_json_error(array('message'=>'Administrator permission required.'),403);
        $id=absint($_POST['agent_id']??0);$user=get_user_by('id',$id);
        if (!$user || !in_array('hc_support_agent',(array)$user->roles,true)) wp_send_json_error(array('message'=>'Support agent not found.'),404);
        $task=sanitize_key($_POST['task']??'');global $wpdb;$presence=$wpdb->prefix.'hc_ai_support_presence';
        if ($task==='availability') {
            $on=absint($_POST['available']??0)?1:0;
            $wpdb->query($wpdb->prepare("INSERT INTO {$presence} (user_id,is_available,last_seen,force_logged_out) VALUES (%d,%d,%s,0) ON DUPLICATE KEY UPDATE is_available=VALUES(is_available),last_seen=VALUES(last_seen),force_logged_out=0",$id,$on,current_time('mysql')));
            if($on && class_exists('HC_Live_Support')) HC_Live_Support::dispatch_queue();
        } elseif ($task==='capacity') {
            $cap=max(1,min(100,absint($_POST['capacity']??1)));$map=json_decode((string)HC_Core::get_setting('hc_ai_support_agent_capacity_json','{}'),true);if(!is_array($map))$map=array();$map[(string)$id]=$cap;HC_Core::update_setting('hc_ai_support_agent_capacity_json',wp_json_encode($map));
        } elseif ($task==='force_logout') {
            if(function_exists('wp_destroy_all_sessions'))wp_destroy_all_sessions($id);
            $wpdb->update($presence,array('is_available'=>0,'force_logged_out'=>1),array('user_id'=>$id));
            if(class_exists('HC_Live_Support')){ $ticket_table=$wpdb->prefix.'hc_ai_escalations'; $message_table=$wpdb->prefix.'hc_ai_escalation_messages'; $rows=$wpdb->get_results($wpdb->prepare("SELECT id,conversation_id,status,queue_started_at,created_at FROM {$ticket_table} WHERE assigned_agent_id=%d AND status IN ('active','waiting_agent','waiting_customer','pending_email')",$id)); foreach((array)$rows as $row){$wpdb->update($ticket_table,array('assigned_agent_id'=>0,'assigned_agent_name'=>'','status'=>$row->status==='pending_email'?'pending_email':'queued','queue_started_at'=>(string)($row->queue_started_at ?: $row->created_at),'last_activity'=>current_time('mysql')),array('id'=>(int)$row->id));$wpdb->insert($message_table,array('ticket_id'=>(int)$row->id,'conversation_id'=>(int)$row->conversation_id,'sender_type'=>'system','sender_name'=>'System','content'=>'This ticket was returned to the support queue by an administrator.','created_at'=>current_time('mysql')));} HC_Live_Support::dispatch_queue(); }
        } elseif ($task==='reset_password') {
            $reset=retrieve_password($user->user_login); if(is_wp_error($reset))wp_send_json_error(array('message'=>$reset->get_error_message()),400);
        } elseif ($task==='rename') {
            $name=sanitize_text_field(wp_unslash($_POST['name']??''));$email=sanitize_email(wp_unslash($_POST['email']??''));if(!$name||!is_email($email))wp_send_json_error(array('message'=>'Enter a valid name and email.'),400);$result=wp_update_user(array('ID'=>$id,'display_name'=>$name,'user_email'=>$email));if(is_wp_error($result))wp_send_json_error(array('message'=>$result->get_error_message()),400);
        } else wp_send_json_error(array('message'=>'Unknown agent action.'),400);
        wp_send_json_success(array('message'=>'Agent details updated.'));
    }

    public static function agent_directory(){if(!self::supervisor()||!check_ajax_referer('hc_nonce','nonce',false))wp_send_json_error(array('message'=>'Administrator permission required.'),403);global $wpdb;$users=get_users(array('role'=>'hc_support_agent','orderby'=>'display_name','order'=>'ASC','number'=>500));$presence=$wpdb->prefix.'hc_ai_support_presence';$tickets=$wpdb->prefix.'hc_ai_escalations';$capacity=json_decode((string)HC_Core::get_setting('hc_ai_support_agent_capacity_json','{}'),true);if(!is_array($capacity))$capacity=array();$out=array();foreach($users as $u){$pr=$wpdb->get_row($wpdb->prepare("SELECT is_available,last_seen FROM {$presence} WHERE user_id=%d",$u->ID),ARRAY_A);$online=!empty($pr['is_available'])&&!empty($pr['last_seen'])&&strtotime($pr['last_seen'])>=time()-35;$active=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tickets} WHERE assigned_agent_id=%d AND status IN ('active','waiting_agent','waiting_customer','pending_email')",$u->ID));$out[]=array('id'=>(int)$u->ID,'name'=>$u->display_name?:$u->user_login,'email'=>$u->user_email,'login'=>$u->user_login,'online'=>$online,'active'=>$active,'capacity'=>max(1,(int)($capacity[(string)$u->ID]??1)));}wp_send_json_success(array('agents'=>$out,'count'=>count($out)));}
    public static function bulk_delete_agents(){if(!self::supervisor()||!check_ajax_referer('hc_nonce','nonce',false))wp_send_json_error(array('message'=>'Administrator permission required.'),403);$raw=wp_unslash($_POST['agent_ids']??array());$ids=is_array($raw)?$raw:explode(',',(string)$raw);$ids=array_values(array_unique(array_filter(array_map('absint',$ids))));if(!$ids)wp_send_json_error(array('message'=>'Select at least one agent.'),400);if(count($ids)>100)wp_send_json_error(array('message'=>'Delete up to 100 agents per request.'),400);global $wpdb;$tt=$wpdb->prefix.'hc_ai_escalations';$mt=$wpdb->prefix.'hc_ai_escalation_messages';$deleted=0;$errors=array();foreach($ids as $id){$u=get_userdata($id);if(!$u||!in_array('hc_support_agent',(array)$u->roles,true)){$errors[]='Agent #'.$id.' was not found';continue;}if(function_exists('wp_destroy_all_sessions'))wp_destroy_all_sessions($id);$rows=$wpdb->get_results($wpdb->prepare("SELECT id,conversation_id,queue_started_at,created_at FROM {$tt} WHERE assigned_agent_id=%d AND status IN ('active','waiting_agent','waiting_customer')",$id));foreach((array)$rows as $ticket){$now=current_time('mysql');$wpdb->update($tt,array('assigned_agent_id'=>0,'assigned_agent_name'=>'','status'=>'queued','queue_started_at'=>(string)($ticket->queue_started_at ?: $ticket->created_at),'last_activity'=>$now),array('id'=>(int)$ticket->id));$wpdb->insert($mt,array('ticket_id'=>(int)$ticket->id,'conversation_id'=>(int)$ticket->conversation_id,'sender_type'=>'system','sender_name'=>'System','content'=>'The assigned support agent account was removed. This ticket has returned to the queue.','created_at'=>$now));if(class_exists('HC_Realtime'))HC_Realtime::publish_ticket_event((int)$ticket->id,'ticket.transferred',(int)$wpdb->insert_id);} $wpdb->delete($wpdb->prefix.'hc_ai_support_presence',array('user_id'=>$id),array('%d'));require_once ABSPATH.'wp-admin/includes/user.php';$r=wp_delete_user($id);if($r)$deleted++;else $errors[]='Could not delete '.$u->user_login;} $configured=array_values(array_diff(array_filter(array_map('absint',preg_split('/[,;\s]+/',(string)HC_Core::get_setting('hc_ai_support_agent_ids','')))),$ids));HC_Core::update_setting('hc_ai_support_agent_ids',implode(',',$configured));if(class_exists('HC_Live_Support'))HC_Live_Support::dispatch_queue();if($errors)wp_send_json_error(array('message'=>'Deleted '.$deleted.' agents. '.implode(' | ',array_slice($errors,0,4)),'deleted'=>$deleted));wp_send_json_success(array('message'=>'Deleted '.$deleted.' agent accounts. Active tickets were returned to the queue.','deleted'=>$deleted));}
    public static function search_agents() { if(!self::supervisor()||!check_ajax_referer('hc_nonce','nonce',false))wp_send_json_error(array('message'=>'Forbidden'),403);$q=sanitize_text_field(wp_unslash($_POST['q']??''));$args=array('role'=>'hc_support_agent','orderby'=>'display_name','order'=>'ASC','number'=>100);if($q!==''){$args['search']='*'.esc_attr($q).'*';$args['search_columns']=array('user_login','user_email','display_name');}$users=get_users($args);$out=array();foreach($users as $u)$out[]=array('id'=>$u->ID,'name'=>$u->display_name,'email'=>$u->user_email,'login'=>$u->user_login);wp_send_json_success(array('agents'=>$out)); }
    private static function agent_guard() { self::guard(); if(!self::agent())wp_send_json_error(array('message'=>'Only agent accounts may use this endpoint.'),403); }
    public static function list_live_conversations() {
        self::agent_guard(); global $wpdb; $uid=get_current_user_id();
        $t=$wpdb->prefix.'hc_ai_escalations'; $m=$wpdb->prefix.'hc_ai_escalation_messages';
        $q=sanitize_text_field(wp_unslash($_POST['q']??''));
        $sql="SELECT t.*, (SELECT content FROM {$m} mm WHERE mm.ticket_id=t.id AND mm.sender_type<>'internal_note' ORDER BY mm.id DESC LIMIT 1) preview, (SELECT COUNT(*) FROM {$m} mc WHERE mc.ticket_id=t.id AND mc.sender_type<>'internal_note') message_count FROM {$t} t WHERE t.assigned_agent_id=%d AND t.status IN ('queued','active','waiting_agent','waiting_customer')";
        $args=array($uid);
        if($q!==''){$like='%'.$wpdb->esc_like($q).'%';$sql.=" AND (CAST(t.id AS CHAR) LIKE %s OR CAST(t.user_id AS CHAR) LIKE %s OR t.visitor_name LIKE %s OR t.visitor_email LIKE %s OR t.issue LIKE %s OR EXISTS (SELECT 1 FROM {$wpdb->users} su WHERE su.ID=t.user_id AND su.user_login LIKE %s) OR EXISTS (SELECT 1 FROM {$m} sm WHERE sm.ticket_id=t.id AND sm.content LIKE %s))";array_push($args,$like,$like,$like,$like,$like,$like,$like);}
        $sql.=' ORDER BY t.last_activity DESC LIMIT 100'; $rows=$wpdb->get_results($wpdb->prepare($sql,$args)); $out=array();
        foreach((array)$rows as $r){if(trim((string)$r->ai_title)===''&&!get_transient('hc_ticket_title_retry_'.(int)$r->id)&&!wp_next_scheduled('hc_agent_generate_ticket_title',array((int)$r->id)))wp_schedule_single_event(time()+3,'hc_agent_generate_ticket_title',array((int)$r->id));$out[]=array('id'=>(int)$r->id,'title'=>(string)$r->ai_title,'visitor_name'=>self::visitor_label($r->visitor_name,$r->visitor_email),'visitor_email'=>$r->visitor_email,'status'=>$r->status,'preview'=>wp_strip_all_tags($r->preview?:$r->issue),'issue'=>$r->issue,'created_at'=>$r->created_at,'last_activity'=>$r->last_activity,'message_count'=>(int)$r->message_count,'priority'=>(string)$r->priority,'assigned_agent_id'=>(int)$r->assigned_agent_id,'assigned_agent_name'=>(string)$r->assigned_agent_name,'agent_connected'=>!empty($r->agent_connected_at));}
        wp_send_json_success(array('tickets'=>$out,'count'=>count($out)));
    }
    private static function customer_history($user_id, $email, $current_hc_id = 0) {
        global $wpdb;
        $user_id=absint($user_id); $email=sanitize_email($email); $out=array('tickets'=>array(),'conversations'=>array(),'ticket_count'=>0,'conversation_count'=>0);
        $ht=$wpdb->prefix.'hck_tickets';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$ht))===$ht) {
            $where=$user_id ? $wpdb->prepare('(user_id=%d OR customer_id=%d OR customer_email=%s)',$user_id,$user_id,$email) : (is_email($email)?$wpdb->prepare('customer_email=%s',$email):'1=0');
            $rows=$wpdb->get_results("SELECT id,ticket_number,subject,status,category,source,created_at,updated_at,agent_id,assigned_to,customer_email FROM {$ht} WHERE {$where} ORDER BY created_at DESC,id DESC LIMIT 500");
            $seen_ticket_ids=array(); foreach((array)$rows as $r){$rid=(int)$r->id;if(!$rid||isset($seen_ticket_ids[$rid]))continue;$seen_ticket_ids[$rid]=true;$history_agent_id=function_exists('hck_get_ticket_agent_id')?hck_get_ticket_agent_id($r):(int)($r->agent_id??$r->assigned_to??0);$a=$history_agent_id?get_userdata((int)$history_agent_id):false;$subject=trim((string)$r->subject);if(substr_count(strtolower($subject),'https://')+substr_count(strtolower($subject),'http://')>1)$subject='HelpCenter follow-up';$out['tickets'][]=array('id'=>$rid,'number'=>function_exists('hck_get_ticket_number')?hck_get_ticket_number($r):(string)$r->ticket_number,'subject'=>$subject,'status'=>(string)$r->status,'source'=>(string)$r->source,'category'=>(string)$r->category,'created_at'=>(string)$r->created_at,'updated_at'=>(string)$r->updated_at,'agent'=>$a?($a->display_name?:$a->user_login):'Unassigned','unread'=>false,'url'=>function_exists('hck_admin_url')?hck_admin_url('view/'.$rid.'/'):'');}
            $out['ticket_count']=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$ht} WHERE {$where}");
        }
        $ct=$wpdb->prefix.'hc_ai_escalations';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$ct))===$ct) {
            $where=$user_id?$wpdb->prepare('(user_id=%d OR visitor_email=%s)',$user_id,$email):(is_email($email)?$wpdb->prepare('visitor_email=%s',$email):'1=0');
            $conversation_where="({$where}) AND status<>'converted'";
            $rows=$wpdb->get_results("SELECT id,issue,ai_title,status,created_at,last_activity,assigned_agent_name,visitor_name FROM {$ct} WHERE {$conversation_where} ORDER BY created_at DESC,id DESC LIMIT 500");
            $seen_conversation_ids=array(); foreach((array)$rows as $r){$rid=(int)$r->id;if(!$rid||isset($seen_conversation_ids[$rid]))continue;$seen_conversation_ids[$rid]=true;$out['conversations'][]=array('id'=>$rid,'title'=>(string)$r->ai_title,'subject'=>(string)$r->ai_title,'status'=>(string)$r->status,'updated_at'=>(string)$r->last_activity,'created_at'=>(string)$r->created_at,'agent'=>(string)$r->assigned_agent_name,'current'=>$rid===(int)$current_hc_id);}
            $out['conversation_count']=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$ct} WHERE {$conversation_where}");
        }
        return $out;
    }

    public static function live_ticket_detail() {
        self::agent_guard(); global $wpdb; $id=absint($_POST['conversation_id']??0); $uid=get_current_user_id();
        $after_id=absint($_POST['after_id']??0); $ai_after_id=absint($_POST['ai_after_id']??0);
        $table=$wpdb->prefix.'hc_ai_escalations'; $messages=$wpdb->prefix.'hc_ai_escalation_messages';
        $ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND assigned_agent_id=%d",$id,$uid));
        if(!$ticket || !in_array($ticket->status,array('queued','active','waiting_agent','waiting_customer'),true)) wp_send_json_error(array('message'=>'This live conversation is no longer assigned to you or has already been converted.'),404);
        $now=current_time('mysql');
        $connected = $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET last_agent_seen_at=%s,agent_connected_at=%s WHERE id=%d AND assigned_agent_id=%d AND status IN ('queued','active','waiting_agent','waiting_customer')",
            $now,$now,$id,$uid
        ));
        if ($connected === false) {
            wp_send_json_error(array('message'=>'Could not register your connection to this conversation. Please refresh and try again.'),500);
        }
        if ($connected === 0) {
            $fresh_connection = $wpdb->get_row($wpdb->prepare("SELECT status,agent_connected_at FROM {$table} WHERE id=%d AND assigned_agent_id=%d",$id,$uid));
            if (!$fresh_connection || !in_array($fresh_connection->status,array('queued','active','waiting_agent','waiting_customer'),true)) {
                wp_send_json_error(array('message'=>'This conversation has already been converted or is no longer available.'),409);
            }
            // A second request in the same second may update no values; accept it
            // only when the first request already recorded the connection.
            if (empty($fresh_connection->agent_connected_at)) {
                wp_send_json_error(array('message'=>'Could not register your connection to this conversation. Please refresh and try again.'),500);
            }
        }
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id,client_message_id,sender_type,sender_name,content,created_at,attachment_path,attachment_name,attachment_mime,attachment_size,attachment_kind,attachment_deleted_at FROM {$messages} WHERE ticket_id=%d AND sender_type<>'internal_note' AND id>%d ORDER BY id ASC LIMIT 200",$id,$after_id),ARRAY_A);
        $out=array(); foreach((array)$rows as $r){$row=array('id'=>(int)$r['id'],'client_message_id'=>(string)($r['client_message_id']??''),'message_key'=>'ticket:'.(int)$r['id'],'source_type'=>'ticket','sender_type'=>(string)$r['sender_type'],'sender_name'=>(string)$r['sender_name'],'content'=>(string)$r['content'],'created_at'=>(string)$r['created_at'],'attachment_id'=>(int)$r['id'],'attachment_path'=>(string)$r['attachment_path'],'attachment_name'=>(string)$r['attachment_name'],'attachment_mime'=>(string)$r['attachment_mime'],'attachment_size'=>(int)$r['attachment_size'],'attachment_kind'=>(string)$r['attachment_kind'],'attachment_deleted_at'=>(string)$r['attachment_deleted_at']);if(!empty($r['attachment_name'])&&!empty($r['attachment_path'])&&class_exists('HC_Live_Support'))$row['attachment_url']=HC_Live_Support::attachment_preview_url($id,(int)$r['id'],'');$out[]=$row;}
        // The detailed handoff concern is stored in the ticket row as well as the
        // first visitor message. Restore it to the transcript if older records
        // are missing that message row.
        $issue = trim(wp_strip_all_tags((string) $ticket->issue));
        $issue = preg_replace('/(?:\\s*Five minutes have passed\\.?\\s*Preparing your secure follow-up ticket(?:\\.{1,3}|…)?\\s*)+/iu', ' ', $issue);
        $issue = preg_replace('/(?:\\s*Five minutes have passed\\.?\\s*)+/iu', ' ', (string) $issue);
        $issue = preg_replace('/(?:\\s*Preparing your secure follow-up ticket(?:\\.{1,3}|…)?\\s*)+/iu', ' ', (string) $issue);
        $issue = trim((string) $issue);
        if ($after_id===0 && mb_strlen($issue) < 100) {
            foreach ($out as $message_row) {
                $candidate_issue = trim(wp_strip_all_tags((string) ($message_row['content'] ?? '')));
                $candidate_issue = preg_replace('/(?:\\s*Five minutes have passed\\.?\\s*Preparing your secure follow-up ticket(?:\\.{1,3}|…)?\\s*)+/iu', ' ', $candidate_issue);
                $candidate_issue = preg_replace('/(?:\\s*Five minutes have passed\\.?\\s*)+/iu', ' ', (string) $candidate_issue);
                $candidate_issue = preg_replace('/(?:\\s*Preparing your secure follow-up ticket(?:\\.{1,3}|…)?\\s*)+/iu', ' ', (string) $candidate_issue);
                $candidate_issue = trim((string) $candidate_issue);
                if (($message_row['sender_type'] ?? '') === 'visitor' && mb_strlen($candidate_issue) >= 100) {
                    $issue = $candidate_issue;
                    break;
                }
            }
        }
        $last_ai_id=$ai_after_id;
        if (class_exists('HC_Live_Support') && method_exists('HC_Live_Support','get_ticket_ai_history')) {
            foreach ((array)HC_Live_Support::get_ticket_ai_history($ticket,$ai_after_id,200,$ai_after_id===0) as $ai) {
                $last_ai_id=max($last_ai_id,(int)$ai['id']);
                $ai_id=(int)($ai['id']??0);$out[] = array('id'=>$ai_id,'message_key'=>'ai:'.$ai_id,'source_type'=>'ai','sender_type'=>($ai['role']??'')==='user'?'visitor':'ai','sender_name'=>($ai['role']??'')==='user'?(string)$ticket->visitor_name:'AI Assistant','content'=>(string)($ai['content']??''),'created_at'=>(string)($ai['created_at']??''));
            }
        }
        $last_id=$after_id; foreach((array)$rows as $row_for_cursor)$last_id=max($last_id,(int)$row_for_cursor['id']);
        $issue_key = preg_replace('/\\s+/u', ' ', mb_strtolower($issue));
        $issue_found = false;
        if ($after_id===0 && $issue !== '') {
            foreach ($out as $message_row) {
                if (($message_row['sender_type'] ?? '') === 'visitor' && preg_replace('/\\s+/u', ' ', mb_strtolower(trim(wp_strip_all_tags((string) ($message_row['content'] ?? ''))))) === $issue_key) {
                    $issue_found = true;
                    break;
                }
            }
            if (!$issue_found) {
                array_unshift($out, array(
                    'id' => -1 * (int) $ticket->id,
                    'message_key' => 'initial-concern:' . (int) $ticket->id,
                    'source_type' => 'initial_concern',
                    'is_initial_concern' => true,
                    'sender_type' => 'visitor',
                    'sender_name' => (string) ($ticket->visitor_name ?: 'Customer'),
                    'content' => $issue,
                    'created_at' => (string) $ticket->created_at,
                    'attachment_id' => 0,
                    'attachment_path' => '',
                    'attachment_name' => '',
                    'attachment_mime' => '',
                    'attachment_size' => 0,
                    'attachment_kind' => '',
                    'attachment_deleted_at' => ''
                ));
            }
        }
        usort($out,function($a,$b){$cmp=strcmp((string)$a['created_at'],(string)$b['created_at']);return $cmp!==0?$cmp:((int)$a['id']<=>(int)$b['id']);});
        wp_send_json_success(array('ticket'=>array('id'=>(int)$ticket->id,'title'=>(string)$ticket->ai_title,'visitor_name'=>self::visitor_label($ticket->visitor_name,$ticket->visitor_email),'visitor_email'=>(string)$ticket->visitor_email,'issue'=>$issue,'status'=>(string)$ticket->status,'priority'=>(string)$ticket->priority,'assigned_agent_id'=>(int)$ticket->assigned_agent_id,'assigned_agent_name'=>(string)$ticket->assigned_agent_name,'created_at'=>(string)$ticket->created_at,'agent_connected'=>true),'messages'=>$out,'last_id'=>$last_id,'last_ai_id'=>$last_ai_id,'customer_history'=>(($rows||$last_ai_id>$ai_after_id)?self::customer_history((int)$ticket->user_id,(string)$ticket->visitor_email,(int)$ticket->id):null)));
    }

    public static function convert_live_conversation() {
        self::agent_guard();
        if(!class_exists('HCK_HelpCenter_Integration')) wp_send_json_error(array('message'=>'The HCK Ticket System integration is not available.'),503);
        $id=absint($_POST['conversation_id']??0); if(!$id)wp_send_json_error(array('message'=>'Invalid live conversation.'),400);
        $result=HCK_HelpCenter_Integration::agent_convert($id,get_current_user_id());
        if(is_wp_error($result))wp_send_json_error(array('message'=>$result->get_error_message()),409);
        wp_send_json_success($result);
    }

    public static function list_tickets() {
        self::agent_guard(); global $wpdb; list($t,$m)=self::tables();
        $uid=get_current_user_id(); $tab=sanitize_key($_POST['tab']??'assigned'); $q=sanitize_text_field(wp_unslash($_POST['q']??''));
        if($tab==='closed'){$where="t.status='closed' AND t.closed_by_agent_id=%d";$args=array($uid);}
        elseif($tab==='all'){$where="1=1";$args=array();}
        else{$where="t.assigned_agent_id=%d AND t.status NOT IN ('closed','archived','converted')";$args=array($uid);}
        if($q!==''){$where='1=1';$args=array();}
        $hck_links=$wpdb->prefix.'hck_hc_links'; $hck_table=$wpdb->prefix.'hck_tickets';
        $has_hck=($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hck_links))===$hck_links && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hck_table))===$hck_table);
        $hck_join=$has_hck?" LEFT JOIN {$hck_links} hl ON hl.hc_ticket_id=t.id LEFT JOIN {$hck_table} hkt ON hkt.id=hl.hck_ticket_id ":'';
        $hck_select=$has_hck?"hkt.sla_first_response_due_at,hkt.sla_resolution_due_at,hkt.sla_first_responded_at,hkt.sla_first_response_breached,hkt.sla_resolution_breached,hkt.ticket_number AS hck_ticket_number,":'';
        $ai_messages=$wpdb->prefix.'hc_ai_messages'; $has_ai=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$ai_messages))===$ai_messages;
        $ai_unread=$has_ai?"(SELECT MAX(am.created_at) FROM {$ai_messages} am WHERE am.conversation_id=t.conversation_id AND am.role='user')":"NULL";
        $sql="SELECT t.*, {$hck_select}(SELECT content FROM {$m} mm WHERE mm.ticket_id=t.id AND mm.sender_type IN ('visitor','agent','ai','system') ORDER BY mm.id DESC LIMIT 1) preview, (SELECT sender_type FROM {$m} ms WHERE ms.ticket_id=t.id AND ms.sender_type IN ('visitor','agent','ai','system') ORDER BY ms.id DESC LIMIT 1) preview_sender, (SELECT COUNT(*) FROM {$m} mc WHERE mc.ticket_id=t.id) message_count, GREATEST(COALESCE((SELECT MAX(um.created_at) FROM {$m} um WHERE um.ticket_id=t.id AND um.sender_type='visitor'),'1970-01-01 00:00:00'),COALESCE({$ai_unread},'1970-01-01 00:00:00')) AS last_customer_message_at FROM {$t} t {$hck_join} WHERE {$where}";
        if($q!==''){$like='%'.$wpdb->esc_like($q).'%';$sql.=" AND (CAST(t.id AS CHAR) LIKE %s OR CAST(t.user_id AS CHAR) LIKE %s OR t.visitor_name LIKE %s OR t.visitor_email LIKE %s OR t.issue LIKE %s OR EXISTS (SELECT 1 FROM {$wpdb->users} su WHERE su.ID=t.user_id AND su.user_login LIKE %s) OR EXISTS (SELECT 1 FROM {$m} sm WHERE sm.ticket_id=t.id AND sm.content LIKE %s))";array_push($args,$like,$like,$like,$like,$like,$like,$like);}
        $sql.=' ORDER BY t.last_activity DESC LIMIT 250';
        $rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);$out=array();
        foreach((array)$rows as $r){if(trim((string)$r->ai_title)===''&&!get_transient('hc_ticket_title_retry_'.(int)$r->id)&&!wp_next_scheduled('hc_agent_generate_ticket_title',array((int)$r->id)))wp_schedule_single_event(time()+3,'hc_agent_generate_ticket_title',array((int)$r->id));$due=!empty($r->sla_first_responded_at)?(string)($r->sla_resolution_due_at??''):(string)(($r->sla_first_response_due_at??'')?:($r->sla_resolution_due_at??''));$due_ts=$due?strtotime($due.' UTC'):0;$unread=!empty($r->last_customer_message_at)&&strtotime($r->last_customer_message_at)>strtotime((string)($r->last_agent_seen_at?:'1970-01-01 00:00:00'));$out[]=array('id'=>(int)$r->id,'title'=>(string)$r->ai_title,'visitor_name'=>self::visitor_label($r->visitor_name,$r->visitor_email),'status'=>$r->status,'preview'=>trim((($r->preview_sender==='visitor')?'Customer: ': (($r->preview_sender==='agent')?'Agent: ':'' )).wp_strip_all_tags($r->preview?:$r->issue)),'issue'=>$r->issue,'last_activity'=>$r->last_activity,'last_customer_message_at'=>(string)$r->last_customer_message_at,'created_at'=>$r->created_at,'message_count'=>(int)$r->message_count,'priority'=>(string)$r->priority,'assigned_agent_id'=>(int)$r->assigned_agent_id,'assigned_agent_name'=>(string)$r->assigned_agent_name,'view_only'=>(int)$r->assigned_agent_id!==$uid || in_array($r->status,array('closed','archived','converted'),true),'unread'=>$unread,'sla'=>array('due_at'=>$due,'remaining_seconds'=>(int)($due_ts?($due_ts-current_time('timestamp')):0),'overdue'=>(bool)($due_ts && $due_ts<current_time('timestamp') && !in_array($r->status,array('closed','archived','converted'),true)),'due_soon'=>(bool)($due_ts && $due_ts>=current_time('timestamp') && $due_ts<=current_time('timestamp')+HOUR_IN_SECONDS),'completed'=>(bool)in_array($r->status,array('closed','archived','converted'),true),'ticket_number'=>(string)($r->hck_ticket_number??'')));}
        $assigned_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE assigned_agent_id=%d AND status NOT IN ('closed','archived','converted')",$uid));
        $closed_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE status='closed' AND closed_by_agent_id=%d",$uid));
        // Dashboard counters must cover the complete assigned queue, not only the
        // 250 rows returned for the visible list. Keep the list limit independent.
        $unread_message_time = "(SELECT MAX(um.created_at) FROM {$m} um WHERE um.ticket_id=t.id AND um.sender_type='visitor')";
        if ($has_ai) {
            $unread_message_time = "GREATEST(COALESCE({$unread_message_time},'1970-01-01 00:00:00'),COALESCE((SELECT MAX(am.created_at) FROM {$ai_messages} am WHERE am.conversation_id=t.conversation_id AND am.role='user'),'1970-01-01 00:00:00'))";
        } else {
            $unread_message_time = "COALESCE({$unread_message_time},'1970-01-01 00:00:00')";
        }
        $unread_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$t} t WHERE t.assigned_agent_id=%d AND t.status NOT IN ('closed','archived','converted') AND {$unread_message_time}>COALESCE(t.last_agent_seen_at,'1970-01-01 00:00:00')",
            $uid
        ));
        $sla_risk_count = 0;
        if ($has_hck) {
            $sla_due_expr = "CASE WHEN hkt.sla_first_responded_at IS NOT NULL THEN hkt.sla_resolution_due_at ELSE COALESCE(hkt.sla_first_response_due_at,hkt.sla_resolution_due_at) END";
            $sla_risk_count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$t} t WHERE t.assigned_agent_id=%d AND t.status NOT IN ('closed','archived','converted') AND EXISTS (SELECT 1 FROM {$hck_links} hl INNER JOIN {$hck_table} hkt ON hkt.id=hl.hck_ticket_id WHERE hl.hc_ticket_id=t.id AND {$sla_due_expr} IS NOT NULL AND {$sla_due_expr}<=%s)",
                $uid,
                wp_date('Y-m-d H:i:s', current_time('timestamp') + HOUR_IN_SECONDS)
            ));
        }
        wp_send_json_success(array('tickets'=>$out,'count'=>count($out),'counts'=>array('assigned'=>$assigned_count,'closed'=>$closed_count,'unread'=>$unread_count,'sla_risk'=>$sla_risk_count)));
    }
    /**
     * Unified, type-aware search across HelpCenter conversations and HCK tickets.
     * Numeric identifiers never search message bodies or timestamps. HCK and
     * HelpCenter remain separate stores; hck_hc_links is the authoritative
     * relationship for a HelpCenter conversation converted into an HCK ticket.
     */
    public static function global_search() {
        self::agent_guard();
        global $wpdb;

        $raw = trim(sanitize_text_field(wp_unslash($_POST['q'] ?? '')));
        if ($raw === '') wp_send_json_error(array('message' => 'Enter something to search.'), 400);
        if (mb_strlen($raw) > 120) $raw = mb_substr($raw, 0, 120);

        $query = trim($raw);
        $numeric_id = 0;
        if (preg_match('/^#([0-9]{1,18})$/', $query, $match) || preg_match('/^([0-9]{1,6})$/', $query, $match)) {
            $numeric_id = (int) $match[1];
            $query_type = 'ticket_id';
        } elseif (preg_match('/^[0-9]{7,18}$/', $query)) {
            // Long bare numeric values are treated as phone numbers. Prefix
            // with # when an agent intends an unusually long numeric ticket ID.
            $query_type = 'phone';
        } elseif (is_email($query)) {
            $query_type = 'email';
        } elseif (preg_match('/^[A-Za-z]{1,12}[-_][A-Za-z0-9_-]{2,60}$/', $query)) {
            $query_type = 'ticket_number';
        } elseif (preg_match('/^[0-9+() .-]{7,24}$/', $query) && preg_match('/[0-9]{7,}/', preg_replace('/\D+/', '', $query))) {
            $query_type = 'phone';
        } else {
            $query_type = 'text';
        }

        // Numeric IDs are exact-only. Short numeric strings must never match
        // message content, dates, phone fragments, or unrelated timestamps.
        $like = '%' . $wpdb->esc_like($query) . '%';
        $phone_digits = preg_replace('/\D+/', '', $query);
        $uid = get_current_user_id();
        $supervisor = self::supervisor();
        list($hc_tickets, $hc_messages) = self::tables();
        $results = array();
        $seen = array();
        $counts = array('conversations' => 0, 'hck' => 0, 'followups' => 0);

        $can_view_hc = static function($row) use ($uid, $supervisor) {
            return $supervisor || (int) $row->assigned_agent_id === (int) $uid || ((string) $row->status === 'closed' && (int) $row->closed_by_agent_id === (int) $uid);
        };
        $add_hc = function($row, $relationship = '') use (&$results, &$seen, &$counts, $can_view_hc, $hc_messages) {
            if (!$row || !$can_view_hc($row)) return;
            $id = (int) $row->id;
            $key = 'hc:' . $id;
            if (isset($seen[$key])) return;
            $seen[$key] = true;
            global $wpdb;
            $preview = $wpdb->get_var($wpdb->prepare(
                "SELECT content FROM {$hc_messages} WHERE ticket_id=%d AND sender_type<>'internal_note' ORDER BY id DESC LIMIT 1", $id
            ));
            if ($preview === null || $preview === '') $preview = (string) $row->issue;
            $preview = trim(wp_strip_all_tags((string) $preview));
            if (mb_strlen($preview) > 220) $preview = mb_substr($preview, 0, 220) . '…';
            $title = trim((string) $row->ai_title) ?: 'HelpCenter conversation #' . $id;
            $results[] = array(
                'kind' => 'conversation', 'id' => $id, 'title' => $title,
                'number' => 'HC #' . $id,
                'customer' => self::visitor_label($row->visitor_name, $row->visitor_email),
                'email' => (string) $row->visitor_email, 'status' => (string) $row->status,
                'updated_at' => (string) ($row->last_activity ?: $row->created_at),
                'preview' => $preview, 'relationship' => $relationship,
                'url' => add_query_arg(array('tab' => 'all', 'ticket' => $id), home_url('/support-agent/')),
            );
            $counts['conversations']++;
        };

        $hck_table = $wpdb->prefix . 'hck_tickets';
        $hck_messages = $wpdb->prefix . 'hck_ticket_messages';
        $links_table = $wpdb->prefix . 'hck_hc_links';
        $has_hck = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $hck_table)) === $hck_table;
        $has_hck_messages = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $hck_messages)) === $hck_messages;
        $has_links = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $links_table)) === $links_table;

        $can_view_hck = static function($ticket) use ($uid) {
            if (!$ticket) return false;
            $is_supervisor = function_exists('hck_is_supervisor_user')
                ? hck_is_supervisor_user($uid)
                : (user_can($uid, 'manage_options') || user_can($uid, 'manage_woocommerce') || user_can($uid, 'hck_view_tickets'));
            if ($is_supervisor) return true;
            return function_exists('hck_get_ticket_agent_id') && hck_get_ticket_agent_id($ticket) === (int) $uid;
        };
        $add_hck = function($row, $relationship = '') use (&$results, &$seen, &$counts, $can_view_hck, $has_hck_messages, $hck_messages, $has_links, $links_table, $wpdb) {
            if (!$row) return;
            $id = (int) $row->id;
            $ticket = function_exists('hck_get_ticket') ? hck_get_ticket($id) : $row;
            if (!$ticket || !$can_view_hck($ticket)) return;
            $key = 'hck:' . $id;
            if (isset($seen[$key])) return;
            $seen[$key] = true;
            $preview = '';
            if ($has_hck_messages) {
                $preview = (string) $wpdb->get_var($wpdb->prepare(
                    "SELECT message FROM {$hck_messages} WHERE ticket_id=%d AND is_internal=0 AND is_deleted=0 ORDER BY id DESC LIMIT 1", $id
                ));
            }
            if ($preview === '') $preview = (string) ($row->subject ?? '');
            $preview = trim(wp_strip_all_tags($preview));
            if (mb_strlen($preview) > 220) $preview = mb_substr($preview, 0, 220) . '…';
            $is_hc_followup = false;
            if ($has_links) {
                $is_hc_followup = (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$links_table} WHERE hck_ticket_id=%d LIMIT 1", $id));
            }
            $kind = $is_hc_followup ? 'followup' : 'hck';
            $results[] = array(
                'kind' => $kind, 'id' => $id, 'title' => (string) ($row->subject ?? ''),
                'number' => !empty($row->ticket_number) ? (string) $row->ticket_number : (function_exists('hck_get_ticket_number') ? hck_get_ticket_number($ticket) : 'HCK #' . $id),
                'customer' => trim((string) ($row->customer_name ?? '')) ?: 'Customer',
                'email' => (string) ($row->customer_email ?? ''), 'status' => (string) ($row->status ?? ''),
                'updated_at' => (string) (($row->updated_at ?? '') ?: ($row->created_at ?? '')),
                'preview' => $preview, 'relationship' => $relationship,
                'url' => function_exists('hck_admin_url') ? hck_admin_url('view/' . $id . '/') : home_url('/ticket/admin/view/' . $id . '/'),
            );
            if ($is_hc_followup) $counts['followups']++; else $counts['hck']++;
        };

        // Search HelpCenter records using only fields appropriate to the query type.
        $hc_where = $supervisor ? '1=1' : "(t.assigned_agent_id=%d OR (t.status='closed' AND t.closed_by_agent_id=%d))";
        $hc_args = $supervisor ? array() : array($uid, $uid);
        if ($query_type === 'ticket_id') {
            $hc_where .= ' AND t.id=%d'; $hc_args[] = $numeric_id;
        } elseif ($query_type === 'email') {
            $hc_where .= ' AND t.visitor_email=%s'; $hc_args[] = strtolower($query);
        } elseif ($query_type === 'ticket_number') {
            // HelpCenter identifiers are numeric; a formatted HCK number is not
            // treated as a HelpCenter message-text search.
            $hc_where .= ' AND 1=0';
        } elseif ($query_type === 'phone') {
            $phone_expr = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(meta_value,' ',''),'-',''),'(',''),')',''),'+',''),'.','')";
            $hc_where .= " AND EXISTS (SELECT 1 FROM {$wpdb->usermeta} ph WHERE ph.user_id=t.user_id AND ph.meta_key IN ('billing_phone','phone','billing_phone_number') AND {$phone_expr}=%s)";
            $hc_args[] = $phone_digits;
        } else {
            if (mb_strlen($query) < 3) wp_send_json_error(array('message' => 'For text search, enter at least 3 characters. Use # followed by a ticket ID for exact lookup.'), 400);
            $hc_where .= " AND (t.ai_title LIKE %s OR t.visitor_name LIKE %s OR t.visitor_email LIKE %s OR t.issue LIKE %s OR EXISTS (SELECT 1 FROM {$hc_messages} sm WHERE sm.ticket_id=t.id AND sm.sender_type<>'internal_note' AND sm.content LIKE %s))";
            array_push($hc_args, $like, $like, $like, $like, $like);
        }
        $hc_sql = "SELECT t.id,t.ai_title,t.visitor_name,t.visitor_email,t.status,t.assigned_agent_id,t.closed_by_agent_id,t.last_activity,t.created_at,t.issue FROM {$hc_tickets} t WHERE {$hc_where} ORDER BY t.last_activity DESC,t.id DESC LIMIT 60";
        $hc_rows = $hc_args ? $wpdb->get_results($wpdb->prepare($hc_sql, $hc_args)) : $wpdb->get_results($hc_sql);
        foreach ((array) $hc_rows as $row) $add_hc($row);

        // Search HCK tickets. A numeric query is exact ID only; message bodies
        // are searched only for meaningful alphabetic/general text queries.
        if ($has_hck) {
            $hck_where = '1=1'; $hck_args = array();
            if ($query_type === 'ticket_id') {
                $hck_where .= ' AND ht.id=%d'; $hck_args[] = $numeric_id;
            } elseif ($query_type === 'ticket_number') {
                $hck_where .= ' AND ht.ticket_number=%s'; $hck_args[] = strtoupper($query);
            } elseif ($query_type === 'email') {
                $hck_where .= ' AND ht.customer_email=%s'; $hck_args[] = strtolower($query);
            } elseif ($query_type === 'phone') {
                $phone_expr = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(meta_value,' ',''),'-',''),'(',''),')',''),'+',''),'.','')";
                $hck_where .= " AND (EXISTS (SELECT 1 FROM {$wpdb->usermeta} ph WHERE ph.user_id=ht.user_id AND ph.meta_key IN ('billing_phone','phone','billing_phone_number') AND {$phone_expr}=%s) OR EXISTS (SELECT 1 FROM {$wpdb->usermeta} ph2 WHERE ph2.user_id=ht.customer_id AND ph2.meta_key IN ('billing_phone','phone','billing_phone_number') AND {$phone_expr}=%s))";
                $hck_args[] = $phone_digits; $hck_args[] = $phone_digits;
            } else {
                if (mb_strlen($query) < 3) wp_send_json_error(array('message' => 'For text search, enter at least 3 characters. Use # followed by a ticket ID for exact lookup.'), 400);
                $message_clause = $has_hck_messages ? " OR EXISTS (SELECT 1 FROM {$hck_messages} hm WHERE hm.ticket_id=ht.id AND hm.is_internal=0 AND hm.is_deleted=0 AND hm.message LIKE %s)" : '';
                $hck_where .= " AND (ht.subject LIKE %s OR COALESCE(ht.customer_name,'') LIKE %s OR COALESCE(ht.customer_email,'') LIKE %s{$message_clause})";
                array_push($hck_args, $like, $like, $like);
                if ($has_hck_messages) $hck_args[] = $like;
            }
            $hck_sql = "SELECT ht.id,ht.ticket_number,ht.subject,ht.status,ht.customer_name,ht.customer_email,ht.created_at,ht.updated_at FROM {$hck_table} ht WHERE {$hck_where} ORDER BY ht.updated_at DESC,ht.id DESC LIMIT 60";
            $hck_rows = $hck_args ? $wpdb->get_results($wpdb->prepare($hck_sql, $hck_args)) : $wpdb->get_results($hck_sql);
            foreach ((array) $hck_rows as $row) $add_hck($row);

            // Expand real HelpCenter <-> HCK conversion relationships in both
            // directions. Do not infer links from customer names or email alone.
            if ($has_links) {
                $matched_hck_ids = array();
                foreach ($results as $result) if (in_array($result['kind'], array('hck', 'followup'), true)) $matched_hck_ids[] = (int) $result['id'];
                foreach (array_unique($matched_hck_ids) as $hck_id) {
                    $link = $wpdb->get_row($wpdb->prepare("SELECT hc_ticket_id FROM {$links_table} WHERE hck_ticket_id=%d LIMIT 1", $hck_id));
                    if ($link) {
                        $hc_row = $wpdb->get_row($wpdb->prepare("SELECT t.id,t.ai_title,t.visitor_name,t.visitor_email,t.status,t.assigned_agent_id,t.closed_by_agent_id,t.last_activity,t.created_at,t.issue FROM {$hc_tickets} t WHERE t.id=%d", (int) $link->hc_ticket_id));
                        if ($hc_row) $add_hc($hc_row, 'Original HelpCenter conversation converted to this HCK follow-up');
                    }
                }
                $matched_hc_ids = array();
                foreach ($results as $result) if ($result['kind'] === 'conversation') $matched_hc_ids[] = (int) $result['id'];
                foreach (array_unique($matched_hc_ids) as $hc_id) {
                    $link = $wpdb->get_row($wpdb->prepare("SELECT hck_ticket_id FROM {$links_table} WHERE hc_ticket_id=%d LIMIT 1", $hc_id));
                    if ($link) {
                        $hck_row = $wpdb->get_row($wpdb->prepare("SELECT id,ticket_number,subject,status,customer_name,customer_email,created_at,updated_at FROM {$hck_table} WHERE id=%d", (int) $link->hck_ticket_id));
                        if ($hck_row) $add_hck($hck_row, 'Follow-up ticket created from this HelpCenter conversation');
                    }
                }
            }
        }

        // Newest activity first. No duplicate rows are possible because the
        // source-system ID is the dedupe key; numeric searches are exact-only.
        usort($results, static function($a, $b) {
            $date = strcmp((string) $b['updated_at'], (string) $a['updated_at']);
            if ($date !== 0) return $date;
            return strcmp((string) $a['number'], (string) $b['number']);
        });
        wp_send_json_success(array(
            'query' => $query, 'query_type' => $query_type,
            'results' => $results, 'counts' => $counts, 'count' => count($results),
        ));
    }

    private static function access_ticket($id,$allow_closed=false) { global $wpdb;list($t)=self::tables();$ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",$id));if(!$ticket)wp_send_json_error(array('message'=>'Ticket not found.'),404);if((int)$ticket->assigned_agent_id!==get_current_user_id()&&!($allow_closed&&$ticket->status==='closed'&&(int)$ticket->closed_by_agent_id===get_current_user_id()))wp_send_json_error(array('message'=>'This ticket is not assigned to you. Search does not grant access to an active ticket owned by another agent.'),403);return $ticket; }
    private static function access_ticket_for_note($id) { if (!self::workspace_note_supervisor()) return self::access_ticket($id,true); global $wpdb; list($t)=self::tables(); $ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",absint($id))); if(!$ticket) wp_send_json_error(array('message'=>'Ticket not found.'),404); return $ticket; }
    public static function send_followup_email() {
        self::agent_guard();
        global $wpdb;
        $id=absint($_POST['ticket_id']??0);
        $subject=sanitize_text_field(wp_unslash($_POST['subject']??''));
        $message=trim(sanitize_textarea_field(wp_unslash($_POST['message']??'')));
        if(!$id || $subject==='' || $message==='') wp_send_json_error(array('message'=>'Enter an email subject and message.'),400);
        if(mb_strlen($subject)>180 || mb_strlen($message)>5000) wp_send_json_error(array('message'=>'The subject or message is too long.'),400);
        $table=$wpdb->prefix.'hc_ai_escalations';
        $ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$id));
        if(!$ticket) wp_send_json_error(array('message'=>'The conversation could not be found.'),404);
        if((int)$ticket->assigned_agent_id!==get_current_user_id() && !current_user_can('manage_options')) wp_send_json_error(array('message'=>'Only the assigned agent can email this customer.'),403);
        if(in_array($ticket->status,array('closed','converted'),true)) wp_send_json_error(array('message'=>'This conversation is closed or has been converted. Use the HCK ticket portal for further follow-up.'),409);
        $email=sanitize_email($ticket->visitor_email);
        if(!is_email($email)) wp_send_json_error(array('message'=>'This customer does not have a valid email address.'),400);
        $name=sanitize_text_field($ticket->visitor_name?:'Customer');
        $agent=wp_get_current_user();
        $body='<p>Hello '.esc_html($name).',</p>'.wpautop(esc_html($message)).'<p>Regards,<br>'.esc_html($agent->display_name?:'Support Team').'</p>';
        $html='<!doctype html><html><body style="font-family:Arial,sans-serif;color:#263044;line-height:1.6">'.$body.'<hr><p style="font-size:12px;color:#8992a3">'.esc_html(get_bloginfo('name')).' Support</p></body></html>';
        $headers=array('Content-Type: text/html; charset=UTF-8');
        if(function_exists('hck_send_mail')) $sent=hck_send_mail($email,$subject,$html);
        else $sent=wp_mail($email,$subject,$html,$headers);
        if(!$sent) {
            $sent=wp_mail($email,$subject,$html,$headers);
        }
        if(!$sent) {
            error_log('[HelpCenter Agent] Follow-up email failed for HC conversation '.$id.' to '.$email.'; check SMTP/wp_mail provider logs.');
            wp_send_json_error(array('message'=>'The mail server did not accept this email. Check the SMTP connection and try again.'),502);
        }
        $log='Follow-up email sent to '.$email.'. Subject: '.$subject."\n\n".$message;
        $wpdb->insert($wpdb->prefix.'hc_ai_escalation_messages',array('ticket_id'=>$id,'conversation_id'=>(int)$ticket->conversation_id,'sender_type'=>'internal_note','sender_user_id'=>get_current_user_id(),'sender_name'=>$agent->display_name?:'Support','content'=>$log,'created_at'=>current_time('mysql')));
        wp_send_json_success(array('message'=>'Follow-up email accepted by the mail server and sent to '.$email.'.'));
    }

    public static function ticket_detail() {
        self::agent_guard(); global $wpdb; list($t,$m)=self::tables();
        $id=absint($_POST['ticket_id']??0); $uid=get_current_user_id();
        $ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",$id));
        if(!$ticket) wp_send_json_error(array('message'=>'Ticket not found.'),404);
        $search=!empty($_POST['search']); $view_all=!empty($_POST['view_all']);
        $can_handle=(int)$ticket->assigned_agent_id===$uid && !in_array($ticket->status,array('closed','archived','converted'),true);
        $after=absint($_POST['after_id']??0); $ai_after=absint($_POST['ai_after_id']??0); $initial_latest=!empty($_POST['initial_latest']) && $after===0 && $ai_after===0;
        // Only touch the ticket row on an initial open. Incremental message polls
        // must be read-only; writing last_agent_seen_at on every poll creates
        // avoidable database contention while the agent is viewing a conversation.
        if ((int)$ticket->assigned_agent_id===$uid && $initial_latest) {
            $seen=current_time('mysql');
            $updates=array('last_agent_seen_at'=>$seen);
            $formats=array('%s');
            if ($can_handle && in_array((string)$ticket->status,array('queued','active','waiting_agent','waiting_customer'),true) && empty($ticket->agent_connected_at)) {
                $updates['agent_connected_at']=$seen;
                $formats[]='%s';
                $ticket->agent_connected_at=$seen;
            }
            $wpdb->update($t,$updates,array('id'=>$id),$formats,array('%d'));
            $ticket->last_agent_seen_at=$seen;
        }
        if(!$can_handle && !$view_all && !($ticket->status==='closed'&&((int)$ticket->closed_by_agent_id===$uid||$search))) wp_send_json_error(array('message'=>'This ticket is not assigned to you. Use All Tickets for read-only history.'),403);
        if(!$initial_latest) $msgs=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$m} WHERE ticket_id=%d AND id>%d ORDER BY id ASC LIMIT 100",$id,$after),ARRAY_A);
        elseif($initial_latest) $msgs=array_reverse((array)$wpdb->get_results($wpdb->prepare("SELECT * FROM {$m} WHERE ticket_id=%d ORDER BY id DESC LIMIT 100",$id),ARRAY_A));
        else $msgs=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$m} WHERE ticket_id=%d ORDER BY id ASC",$id),ARRAY_A);
        // The cursor must reflect only rows delivered in this response. Using MAX(id)
        // from the whole ticket here skips rows when a reconnect has >100 pending messages.
        $last_message_cursor=$after;
        foreach((array)$msgs as $delivered_message) $last_message_cursor=max($last_message_cursor,(int)($delivered_message['id']??0));
        $ai_last=$ai_after;
        if (class_exists('HC_Live_Support')) {
            $ai_rows=HC_Live_Support::get_ticket_ai_history($ticket,$ai_after,$initial_latest?100:1500,$initial_latest);
            foreach((array)$ai_rows as $a) {
                $ai_last=max($ai_last,(int)$a['id']);
                $msgs[]=array('id'=>0,'message_key'=>'ai:'.(int)$a['id'],'source_id'=>(int)$a['id'],'source_type'=>'ai','ticket_id'=>$id,'sender_type'=>$a['role']==='user'?'visitor':'ai','sender_name'=>$a['role']==='user'?self::visitor_label($ticket->visitor_name,$ticket->visitor_email):'AI Assistant','content'=>$a['content'],'created_at'=>$a['created_at']);
            }
        }
        usort($msgs,function($a,$b){$ta=(string)($a['created_at']??'');$tb=(string)($b['created_at']??'');$cmp=strcmp($ta,$tb);if($cmp!==0)return $cmp;return (($a['source_type']??'ticket')==='ai'?0:1) <=> (($b['source_type']??'ticket')==='ai'?0:1);});
        foreach($msgs as &$msg){
            if(!isset($msg['message_key'])) $msg['message_key']='ticket:'.(int)$msg['id'];
            if(!empty($msg['attachment_name'])){$msg['attachment_expired']=empty($msg['attachment_path'])&&!empty($msg['attachment_deleted_at']);$msg['attachment_url']=(!$msg['attachment_expired']&&class_exists('HC_Live_Support'))?HC_Live_Support::attachment_preview_url($id,(int)$msg['id'],''):'';}
        } unset($msg);
        // Incremental polling is deliberately a compact read path. The old code
        // rebuilt the agent directory (including per-agent presence/count queries),
        // SLA linkage and up to 500 customer-history rows on every message poll.
        // Those are workspace metadata and are loaded on initial ticket open only.
        if (!$initial_latest) {
            wp_send_json_success(array(
                'ticket'=>array(
                    'id'=>(int)$ticket->id,
                    'visitor_name'=>self::visitor_label($ticket->visitor_name,$ticket->visitor_email),
                    'visitor_email'=>(string)$ticket->visitor_email,
                    'title'=>(string)$ticket->ai_title,
                    'issue'=>(string)$ticket->issue,
                    'priority'=>(string)$ticket->priority,
                    'status'=>(string)$ticket->status,
                    'assigned_agent_id'=>(int)$ticket->assigned_agent_id,
                    'assigned_agent_name'=>(string)$ticket->assigned_agent_name,
                    'created_at'=>(string)$ticket->created_at,
                    'ai_summary'=>(string)$ticket->ai_summary
                ),
                'messages'=>$msgs,
                'last_id'=>$last_message_cursor,
                'last_ai_id'=>$ai_last,
                'can_handle'=>$can_handle
            ));
        }
        $closed_by=''; if(!empty($ticket->closed_by_agent_id)){$u=get_userdata((int)$ticket->closed_by_agent_id);$closed_by=$u?($u->display_name.' ('.$u->user_email.')'):'';}
        $customer_phone=''; if(!empty($ticket->user_id)){foreach(array('billing_phone','phone','billing_phone_number') as $phone_key){$candidate=trim((string)get_user_meta((int)$ticket->user_id,$phone_key,true));if($candidate!==''){$customer_phone=$candidate;break;}}}
        $agent_ids=array_filter(array_map('absint',preg_split('/[,;\\s]+/',(string)HC_Core::get_setting('hc_ai_support_agent_ids',''))));
        $role_agent_ids=get_users(array('role'=>'hc_support_agent','fields'=>'ID','number'=>500));
        $agent_ids=array_values(array_unique(array_merge($agent_ids,array_map('absint',(array)$role_agent_ids))));
        $agents=array();
        if($agent_ids){$presence=$wpdb->prefix.'hc_ai_support_presence';$capacity_map=json_decode((string)HC_Core::get_setting('hc_ai_support_agent_capacity_json','{}'),true);if(!is_array($capacity_map))$capacity_map=array();foreach(get_users(array('include'=>$agent_ids,'orderby'=>'display_name','order'=>'ASC')) as $agent_user){$agent_id=(int)$agent_user->ID;$presence_row=$wpdb->get_row($wpdb->prepare("SELECT is_available,last_seen FROM {$presence} WHERE user_id=%d",$agent_id),ARRAY_A);$online=!empty($presence_row['is_available'])&&!empty($presence_row['last_seen'])&&strtotime($presence_row['last_seen'])>=time()-35;$active_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE assigned_agent_id=%d AND status IN ('active','waiting_agent','waiting_customer','pending_email')",$agent_id));$capacity=max(1,min(100,absint($capacity_map[(string)$agent_id]??1)));$agents[]=array('id'=>$agent_id,'name'=>$agent_user->display_name?:$agent_user->user_login,'email'=>(string)$agent_user->user_email,'online'=>(bool)$online,'active'=>$active_count,'capacity'=>$capacity);}}
        $sla=array('due_at'=>'','overdue'=>false,'due_soon'=>false,'label'=>'SLA not scheduled','detail'=>'A linked HCK ticket is required for an SLA countdown.');
        $links=$wpdb->prefix.'hck_hc_links';$hck=$wpdb->prefix.'hck_tickets';
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links))===$links && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hck))===$hck){$hr=$wpdb->get_row($wpdb->prepare("SELECT ht.* FROM {$links} hl INNER JOIN {$hck} ht ON ht.id=hl.hck_ticket_id WHERE hl.hc_ticket_id=%d",$id));if($hr){$due=!empty($hr->sla_first_responded_at)?(string)$hr->sla_resolution_due_at:(string)($hr->sla_first_response_due_at?:$hr->sla_resolution_due_at);$ts=$due?strtotime($due.' UTC'):0;$completed=in_array((string)$hr->status,array('closed','resolved'),true);$over=$ts && $ts<current_time('timestamp') && !$completed;$soon=$ts && $ts>=current_time('timestamp') && $ts<=current_time('timestamp')+HOUR_IN_SECONDS;$sla=array('due_at'=>$due,'remaining_seconds'=>(int)($ts?($ts-current_time('timestamp')):0),'overdue'=>(bool)$over,'due_soon'=>(bool)$soon,'completed'=>(bool)$completed,'label'=>$completed?'SLA completed':($over?'SLA overdue':($due?'SLA due '.$due:'SLA not scheduled')),'detail'=>$due?'HCK ticket '.(string)$hr->ticket_number:'No HCK SLA deadline is recorded.');}}
        wp_send_json_success(array('ticket'=>array('id'=>(int)$ticket->id,'visitor_name'=>self::visitor_label($ticket->visitor_name,$ticket->visitor_email),'visitor_email'=>$ticket->visitor_email,'customer_phone'=>$customer_phone,'title'=>(string)$ticket->ai_title,'issue'=>$ticket->issue,'priority'=>$ticket->priority,'status'=>$ticket->status,'assigned_agent_id'=>(int)$ticket->assigned_agent_id,'assigned_agent_name'=>(string)$ticket->assigned_agent_name,'created_at'=>(string)$ticket->created_at,'ai_summary'=>$ticket->ai_summary,'closed_by'=>$closed_by),'messages'=>$msgs,'last_id'=>$last_message_cursor,'last_ai_id'=>$ai_last,'agents'=>$agents,'can_handle'=>$can_handle,'sla'=>$sla,'customer_history'=>self::customer_history((int)$ticket->user_id,(string)$ticket->visitor_email,0)));
    }
    public static function claim() { self::agent_guard();global $wpdb;list($t,$m)=self::tables();$id=absint($_POST['ticket_id']??0);$uid=get_current_user_id();$ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",$id));if(!$ticket||$ticket->status!=='closed')wp_send_json_error(array('message'=>'Only a closed ticket can be claimed from search.'),409);$u=wp_get_current_user();$now=current_time('mysql');$ok=$wpdb->query($wpdb->prepare("UPDATE {$t} SET assigned_agent_id=%d,assigned_agent_name=%s,status='active',closed_at=NULL,closed_by_agent_id=0,last_activity=%s,accepted_at=%s WHERE id=%d AND status='closed'",$uid,$u->display_name,$now,$now,$id));if(!$ok)wp_send_json_error(array('message'=>'Another agent claimed this ticket first. Refresh and try again.'),409);if(function_exists('wp_clear_scheduled_hook'))wp_clear_scheduled_hook('hc_ai_escalation_timeout',array((int)$id));$wpdb->insert($m,array('ticket_id'=>$id,'conversation_id'=>(int)$ticket->conversation_id,'sender_type'=>'system','sender_name'=>'System','content'=>'Ticket reopened and claimed by '.$u->display_name.'. Previous conversation history is retained.','created_at'=>$now));$mid=(int)$wpdb->insert_id;if($mid)$wpdb->update($t,array('last_message_id'=>$mid),array('id'=>$id),array('%d'),array('%d'));if(class_exists('HC_Realtime'))HC_Realtime::publish_ticket_event($id,'ticket.claimed',$mid);wp_send_json_success(array('message'=>'Ticket reopened and assigned to you.')); }
    private static function send_json_success_fast($data, $started_at = 0) {
        if (!function_exists('fastcgi_finish_request')) wp_send_json_success($data);
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-cache, must-revalidate, max-age=0');
            if ($started_at) header('Server-Timing: app;dur=' . number_format(max(0, (microtime(true) - $started_at) * 1000), 1, '.', ''));
        }
        echo wp_json_encode(array('success' => true, 'data' => $data));
        @fastcgi_finish_request();
        exit;
    }

    /**
     * Low-latency server-side relay for public agent replies.
     * This is transport-only: the normal reply endpoint remains responsible
     * for durable persistence and idempotency in hc_ai_escalation_messages.
     */
    public static function realtime_relay() {
        self::agent_guard();
        $id = absint($_POST['ticket_id'] ?? 0);
        $client_id = sanitize_text_field(wp_unslash($_POST['client_message_id'] ?? ''));
        $content = trim(sanitize_textarea_field(wp_unslash($_POST['content'] ?? '')));
        if (!$id || !$content || mb_strlen($content) > 5000) {
            wp_send_json_error(array('message' => 'A valid ticket and public reply are required.'), 400);
        }
        if (!preg_match('/^[A-Za-z0-9._:-]{8,64}$/', $client_id)) {
            wp_send_json_error(array('message' => 'Invalid message delivery ID.'), 400);
        }
        $ticket = self::access_ticket($id);
        if (in_array((string) $ticket->status, array('closed', 'archived', 'converted'), true)) {
            wp_send_json_error(array('message' => 'This ticket is closed or converted.'), 409);
        }
        if (!class_exists('HC_Realtime') || !method_exists('HC_Realtime', 'publish_agent_reply')) {
            wp_send_json_error(array('message' => 'HelpCenter realtime relay is unavailable.'), 503);
        }
        $user = wp_get_current_user();
        $message = array(
            'id' => 0,
            'client_message_id' => $client_id,
            'sender_type' => 'agent',
            'sender_name' => $user->display_name ?: 'Support agent',
            'content' => $content,
            'created_at' => current_time('mysql'),
        );
        $published = HC_Realtime::publish_agent_reply($id, array('ticket_id' => $id, 'message' => $message));
        if (!$published) {
            wp_send_json_error(array('message' => 'Ably did not acknowledge the HelpCenter agent reply. The saved-message recovery path remains active.'), 502);
        }
        wp_send_json_success(array('delivered' => true, 'client_message_id' => $client_id));
    }

    public static function reply() {
        $send_started_at = microtime(true);
        self::agent_guard(); global $wpdb; list($t,$m)=self::tables();
        $id=absint($_POST['ticket_id']??0); $text=trim(sanitize_textarea_field(wp_unslash($_POST['message']??'')));
        $client_id=sanitize_text_field(wp_unslash($_POST['client_message_id']??''));
        $realtime_delivered=!empty($_POST['realtime_delivered']);
        if(!$text||mb_strlen($text)>5000) wp_send_json_error(array('message'=>'Enter a reply up to 5,000 characters.'));
        $ticket=self::access_ticket($id); if(in_array($ticket->status,array('closed','archived','converted'),true)) wp_send_json_error(array('message'=>'This ticket is closed or converted. Continue in its linked HCK ticket.'),409);
        if($client_id!=='') { $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$m} WHERE ticket_id=%d AND client_message_id=%s LIMIT 1",$id,$client_id)); if($existing) { if(class_exists('HC_Realtime'))HC_Realtime::publish_ticket_event($id,'message.created',(int)$existing->id); wp_send_json_success(array('message'=>'Reply was already sent.','message_data'=>array('id'=>(int)$existing->id,'client_message_id'=>(string)$existing->client_message_id,'message_key'=>'ticket:'.(int)$existing->id,'sender_type'=>'agent','sender_name'=>$existing->sender_name,'content'=>$existing->content,'created_at'=>$existing->created_at))); } }
        $now=current_time('mysql'); $u=wp_get_current_user();
        $insert=$wpdb->insert($m,array('ticket_id'=>$id,'conversation_id'=>(int)$ticket->conversation_id,'sender_type'=>'agent','sender_user_id'=>$u->ID,'sender_name'=>$u->display_name,'content'=>$text,'client_message_id'=>$client_id?:null,'created_at'=>$now),array('%d','%d','%s','%d','%s','%s','%s','%s'));
        if(!$insert && $client_id!=='') { $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$m} WHERE ticket_id=%d AND client_message_id=%s LIMIT 1",$id,$client_id)); if($existing) { if(class_exists('HC_Realtime'))HC_Realtime::publish_ticket_event($id,'message.created',(int)$existing->id); wp_send_json_success(array('message'=>'Reply was already sent.','message_data'=>array('id'=>(int)$existing->id,'client_message_id'=>(string)$existing->client_message_id,'message_key'=>'ticket:'.(int)$existing->id,'sender_type'=>'agent','sender_name'=>$existing->sender_name,'content'=>$existing->content,'created_at'=>$existing->created_at))); } }
        if(!$insert) wp_send_json_error(array('message'=>'Reply could not be saved. Please retry.'),500);
        $mid=(int)$wpdb->insert_id;
        $wpdb->query($wpdb->prepare(
            "UPDATE {$t} SET status=IF(last_message_id<=%d AND status NOT IN ('closed','archived','converted'),'waiting_customer',status),last_message_id=GREATEST(last_message_id,%d),last_activity=GREATEST(COALESCE(last_activity,%s),%s),agent_typing_at=NULL WHERE id=%d",
            $mid,$mid,$now,$now,$id
        ));
        // Always broadcast the committed message to the assigned-agent and visitor
        // channels, even when the pre-save Ably publish was acknowledged. That ACK
        // proves broker acceptance, not that the remote browser was subscribed.
        // Clients deduplicate the optimistic and durable copies by client_message_id.
        if(class_exists('HC_Realtime'))HC_Realtime::publish_ticket_event($id,'message.created',$mid);
        // Web Push is a separate alert channel; it never writes chat messages.
        if(class_exists('HC_Web_Push')) HC_Web_Push::send('customer', $id, 'New support reply', wp_trim_words($text, 24, '…'), home_url('/helpcenter/'), 'hc-customer-ticket-'.$id.'-'.$mid, $id, $now);
        self::send_json_success_fast(array('message'=>'Reply sent.','message_data'=>array('id'=>$mid,'client_message_id'=>$client_id,'message_key'=>'ticket:'.$mid,'sender_type'=>'agent','sender_name'=>$u->display_name,'content'=>$text,'created_at'=>$now)), $send_started_at);
    }
    public static function close() {
        self::agent_guard(); global $wpdb; list($t,$m)=self::tables();
        $id=absint($_POST['ticket_id']??0); $ticket=self::access_ticket($id);
        if (in_array($ticket->status,array('closed','archived','converted'),true)) wp_send_json_error(array('message'=>'This ticket is already closed or has been converted to an HCK ticket.'),409);
        $u=wp_get_current_user(); $now=current_time('mysql');
        // Conditional transition prevents duplicate close events when two close requests race.
        $changed=$wpdb->query($wpdb->prepare("UPDATE {$t} SET status='closed',closed_at=%s,closed_by_agent_id=%d,last_activity=%s,agent_typing_at=NULL WHERE id=%d AND status<>'closed'",$now,$u->ID,$now,$id));
        if (!$changed) wp_send_json_success(array('message'=>'Ticket is already closed.','already_closed'=>true));
        $wpdb->insert($m,array('ticket_id'=>$id,'conversation_id'=>(int)$ticket->conversation_id,'sender_type'=>'system','sender_name'=>'System','content'=>'This ticket was closed by '.$u->display_name.'.','created_at'=>$now));
        $mid=(int)$wpdb->insert_id; if($mid)$wpdb->update($t,array('last_message_id'=>$mid),array('id'=>$id),array('%d'),array('%d'));
        $mins=max(0,min(240,absint(HC_Core::get_setting('hc_ai_support_assignment_interval_minutes','7'))));
        if($mins)$wpdb->update($wpdb->prefix.'hc_ai_support_presence',array('cooldown_until'=>wp_date('Y-m-d H:i:s',time()+$mins*MINUTE_IN_SECONDS)),array('user_id'=>$u->ID));
        if(class_exists('HC_Realtime'))HC_Realtime::publish_ticket_event($id,'ticket.closed',$mid);
        if(function_exists('wp_clear_scheduled_hook'))wp_clear_scheduled_hook('hc_agent_generate_handover_summary',array((int)$id));
        if(!wp_next_scheduled('hc_agent_generate_handover_summary',array((int)$id)))wp_schedule_single_event(time()+2,'hc_agent_generate_handover_summary',array((int)$id));
        if(class_exists('HC_Live_Support'))HC_Live_Support::dispatch_queue();
        wp_send_json_success(array('message'=>'Ticket closed.'));
    }
    public static function presence() {
        self::agent_guard(); global $wpdb;
        $table=$wpdb->prefix.'hc_ai_support_presence'; $now=current_time('mysql'); $uid=get_current_user_id();
        self::ensure_availability_session_table();
        if(isset($_POST['manual_toggle'])) {
            $available=absint($_POST['available']??0)?1:0;
            $ok=self::set_availability_session($uid,$available?'available':'offline','helpcenter');
            if($ok===false) wp_send_json_error(array('message'=>'Could not save availability. Please try again.'),500);
            $wpdb->query($wpdb->prepare("INSERT INTO {$table} (user_id,is_available,last_seen,force_logged_out) VALUES (%d,%d,%s,0) ON DUPLICATE KEY UPDATE is_available=VALUES(is_available),last_seen=VALUES(last_seen),force_logged_out=0",$uid,$available,$now));
            if($available&&class_exists('HC_Live_Support')) HC_Live_Support::dispatch_queue();
            if(class_exists('HC_Realtime')) HC_Realtime::publish_agent_event($uid,'agent.presence',array('available'=>(bool)$available));
        } else {
            // Heartbeat never starts or ends a session; refresh/reconnect is not a status change.
            $wpdb->query($wpdb->prepare("INSERT INTO {$table} (user_id,is_available,last_seen,force_logged_out) VALUES (%d,0,%s,0) ON DUPLICATE KEY UPDATE last_seen=VALUES(last_seen)",$uid,$now));
        }
        $row=$wpdb->get_row($wpdb->prepare("SELECT is_available,force_logged_out FROM {$table} WHERE user_id=%d",$uid));
        $state=$row&&empty($row->force_logged_out)&&!empty($row->is_available);
        $totals=self::availability_totals($uid);
        wp_send_json_success(array_merge(array('online'=>(bool)$state,'available'=>(bool)$state,'server_time'=>$now,'forced_logout'=>!empty($row->force_logged_out)), $totals));
    }

    public static function transfer() {
        self::agent_guard();
        global $wpdb;
        list($t,$m)=self::tables();
        $id=absint($_POST['ticket_id']??0);
        $target_id=absint($_POST['agent_id']??0);
        $uid=get_current_user_id();
        $ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",$id));
        if(!$ticket || in_array($ticket->status,array('closed','archived','converted'),true)) wp_send_json_error(array('message'=>'This ticket is closed, converted or unavailable.'),404);
        if((int)$ticket->assigned_agent_id!==$uid && !self::supervisor()) wp_send_json_error(array('message'=>'Only the assigned agent or a supervisor can reassign this ticket.'),403);
        // Prepare an up-to-date handover summary asynchronously after the ticket changes owner.
        $ids=array_values(array_unique(array_filter(array_map('absint',preg_split('/[,;\s]+/',(string)HC_Core::get_setting('hc_ai_support_agent_ids',''))))));
        $role_agent_ids=get_users(array('role'=>'hc_support_agent','fields'=>'ID','number'=>500));
        $ids=array_values(array_unique(array_merge($ids,array_map('absint',(array)$role_agent_ids))));
        $target=$target_id?get_userdata($target_id):false;
        if($target_id && (!$target || !in_array($target_id,$ids,true))) wp_send_json_error(array('message'=>'Choose an enabled support agent.'),400);
        if($target_id) {
            $presence=$wpdb->prefix.'hc_ai_support_presence';
            $presence_state=$wpdb->get_row($wpdb->prepare("SELECT is_available,last_seen FROM {$presence} WHERE user_id=%d",$target_id),ARRAY_A);
            $online=!empty($presence_state['is_available'])&&!empty($presence_state['last_seen'])&&strtotime($presence_state['last_seen'])>=time()-35;
            if(!$online) wp_send_json_error(array('message'=>'That agent is currently unavailable. Ask them to switch to Available and keep their agent session active.'),409);
            $presence_row=$wpdb->get_row($wpdb->prepare("SELECT cooldown_until FROM {$presence} WHERE user_id=%d",$target_id));
            if(!empty($presence_row->cooldown_until) && $presence_row->cooldown_until>current_time('mysql')) wp_send_json_error(array('message'=>'That agent is still in the post-resolution cooldown period.'),409);
            $capacity_map=json_decode((string)HC_Core::get_setting('hc_ai_support_agent_capacity_json','{}'),true);
            $capacity=max(1,min(100,absint($capacity_map[(string)$target_id]??1)));
            $active=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE assigned_agent_id=%d AND status IN ('active','waiting_agent','waiting_customer','pending_email') AND id<>%d",$target_id,$id));
            if($active >= $capacity && $target_id!==(int)$ticket->assigned_agent_id) wp_send_json_error(array('message'=>'That agent has reached their active-ticket capacity.'),409);
        }
        $old_name=$ticket->assigned_agent_name?:'Unassigned';
        $new_name=$target?($target->display_name?:$target->user_login):'Unassigned';
        $now=current_time('mysql');
        $status=$target?($ticket->status==='pending_email'?'pending_email':'active'):'queued';
        // Keep the original handoff timestamp. Assignment and reassignment must never restart the five-minute deadline.
        $original_queue_start = (string) ($ticket->queue_started_at ?: $ticket->created_at);
        $updated=$wpdb->update($t,array('assigned_agent_id'=>$target?(int)$target->ID:0,'assigned_agent_name'=>$new_name,'status'=>$status,'agent_typing_at'=>null,'last_agent_seen_at'=>null,'accepted_at'=>$target?$now:$ticket->accepted_at,'last_activity'=>$now,'queue_started_at'=>$original_queue_start),array('id'=>$id),array('%d','%s','%s','%s','%s','%s','%s','%s'),array('%d'));
        if($updated===false) wp_send_json_error(array('message'=>'Ticket reassignment failed. Please retry.'),500);
        if($target) wp_clear_scheduled_hook('hc_ai_escalation_timeout',array((int)$id));
        if($target_id) { $wpdb->update($t,array('ai_summary'=>'','ai_summary_at'=>null),array('id'=>$id),array('%s','%s'),array('%d')); $links=$wpdb->prefix.'hck_hc_links'; if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links))===$links){$hid=(int)$wpdb->get_var($wpdb->prepare("SELECT hck_ticket_id FROM {$links} WHERE hc_ticket_id=%d LIMIT 1",$id));if($hid)delete_option('hck_ticket_ai_summary_'.$hid);} }
        $wpdb->insert($m,array('ticket_id'=>$id,'conversation_id'=>(int)$ticket->conversation_id,'sender_type'=>'system','sender_name'=>'System','content'=>'Ticket reassigned from '.$old_name.' to '.$new_name.'.','created_at'=>$now));
        if(class_exists('HC_Realtime')) HC_Realtime::publish_ticket_event($id,'ticket.transferred',(int)$wpdb->insert_id);
        if(!$target && class_exists('HC_Live_Support')) HC_Live_Support::dispatch_queue();
        if(function_exists('wp_clear_scheduled_hook')) wp_clear_scheduled_hook('hc_agent_generate_handover_summary',array($id));
        wp_schedule_single_event(time()+2,'hc_agent_generate_handover_summary',array($id));
        wp_send_json_success(array('message'=>'Ticket assigned to '.$new_name.'. A fresh AI handover summary is being prepared.','agent_id'=>$target?(int)$target->ID:0,'agent_name'=>$new_name));
    }


    public static function generate_ticket_title_job($ticket_id) {
        global $wpdb; $id=absint($ticket_id); if(!$id) return; if(!class_exists('HC_AI')){set_transient('hc_ticket_title_retry_'.$id,1,HOUR_IN_SECONDS);return;}
        $table=$wpdb->prefix.'hc_ai_escalations';
        $ticket=$wpdb->get_row($wpdb->prepare("SELECT id,issue,ai_title FROM {$table} WHERE id=%d",$id));
        if(!$ticket) return;
        // Titles are generated once only. Never overwrite an agent-edited or existing title.
        if(trim((string)$ticket->ai_title)!=='') return;
        $issue=trim(wp_strip_all_tags((string)$ticket->issue)); if($issue==='') return;
        try { $answer=HC_AI::chat_model(array(
            array('role'=>'system','content'=>'Create one concise customer-support case title from the customer concern. Return only the title, 4 to 9 words, no quotes, no ticket number, no customer name, no invented details.'),
            array('role'=>'user','content'=>$issue)
        )); } catch (Throwable $e) { error_log('[HelpCenter] AI ticket-title generation failed for '.$id.': '.$e->getMessage()); set_transient('hc_ticket_title_retry_'.$id,1,15*MINUTE_IN_SECONDS); return; }
        if(is_wp_error($answer) || !is_string($answer)) { set_transient('hc_ticket_title_retry_'.$id,1,15*MINUTE_IN_SECONDS); return; }
        $title=trim(wp_strip_all_tags($answer)); $title=preg_replace('/^[\"\'“”]+|[\"\'“”]+$/u','',$title); $title=preg_replace('/\s+/u',' ',$title);
        if($title==='' || mb_strlen($title)>180 || preg_match('/^(as an ai|title:|customer concern:)/i',$title)) { set_transient('hc_ticket_title_retry_'.$id,1,15*MINUTE_IN_SECONDS); return; }
        delete_transient('hc_ticket_title_retry_'.$id);
        $wpdb->query($wpdb->prepare("UPDATE {$table} SET ai_title=%s WHERE id=%d AND (ai_title IS NULL OR ai_title='')",$title,$id));
        $saved_title=(string)$wpdb->get_var($wpdb->prepare("SELECT ai_title FROM {$table} WHERE id=%d",$id));
        if($saved_title!==$title) return;
        // If the live conversation was already converted, keep the linked HCK
        // ticket subject in sync with this single persisted case title.
        $links=$wpdb->prefix.'hck_hc_links'; $hck=$wpdb->prefix.'hck_tickets';
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links))===$links && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hck))===$hck){
            $hck_id=(int)$wpdb->get_var($wpdb->prepare("SELECT hck_ticket_id FROM {$links} WHERE hc_ticket_id=%d LIMIT 1",$id));
            if($hck_id){$subject=sanitize_text_field('HelpCenter follow-up: '.$title);$wpdb->update($hck,array('subject'=>$subject,'updated_at'=>current_time('mysql')),array('id'=>$hck_id),array('%s','%s'),array('%d'));}
        }
        if(class_exists('HC_Realtime')) HC_Realtime::publish_ticket_event($id,'ticket.title_updated',0);
    }

    public static function update_ticket_title() {
        self::agent_guard(); global $wpdb; list($t)=self::tables();
        $id=absint($_POST['ticket_id']??0); $title=sanitize_text_field(wp_unslash($_POST['title']??''));
        $title=trim(preg_replace('/\s+/u',' ',$title));
        if(!$id || $title==='' || mb_strlen($title)>180) wp_send_json_error(array('message'=>'Enter a title between 1 and 180 characters.'),400);
        $ticket=self::access_ticket($id,true);
        if(!$ticket) wp_send_json_error(array('message'=>'Conversation not found.'),404);
        $wpdb->update($t,array('ai_title'=>$title),array('id'=>$id),array('%s'),array('%d'));
        // Keep only linked automatic HelpCenter follow-up subjects in sync.
        $links=$wpdb->prefix.'hck_hc_links'; $hck=$wpdb->prefix.'hck_tickets';
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links))===$links && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hck))===$hck) {
            $hid=(int)$wpdb->get_var($wpdb->prepare("SELECT hck_ticket_id FROM {$links} WHERE hc_ticket_id=%d LIMIT 1",$id));
            if($hid) { $old=(string)$wpdb->get_var($wpdb->prepare("SELECT subject FROM {$hck} WHERE id=%d",$hid)); if(stripos($old,'HelpCenter follow-up:')===0) $wpdb->update($hck,array('subject'=>'HelpCenter follow-up: '.$title,'updated_at'=>current_time('mysql')),array('id'=>$hid),array('%s','%s'),array('%d')); }
        }
        if(class_exists('HC_Realtime')) HC_Realtime::publish_ticket_event($id,'ticket.title_updated',0);
        wp_send_json_success(array('title'=>$title));
    }

    public static function generate_handover_summary_job($ticket_id){
        global $wpdb;list($t,$m)=self::tables();$id=absint($ticket_id);if(!$id||!class_exists('HC_AI')||!method_exists('HC_AI','chat_model'))return;
        $ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",$id));if(!$ticket)return;
        $summary_basis_activity=(string)$ticket->last_activity;
        $events=array();if(class_exists('HC_Live_Support'))foreach(HC_Live_Support::get_ticket_ai_history($ticket,0,1500) as $a)$events[]=array('at'=>(string)$a['created_at'],'text'=>(($a['role']==='user'?'Customer':'AI assistant').': '.wp_strip_all_tags((string)$a['content'])));
        $rows=$wpdb->get_results($wpdb->prepare("SELECT sender_type,sender_name,content,created_at FROM {$m} WHERE ticket_id=%d AND sender_name<>'AI Ticket Summary' ORDER BY id ASC LIMIT 1000",$id));foreach((array)$rows as $r){$label=$r->sender_type==='visitor'?'Customer':($r->sender_type==='system'?'System':($r->sender_type==='internal_note'?'Internal agent note (staff-only)':'Support agent '.$r->sender_name));$events[]=array('at'=>(string)$r->created_at,'text'=>$label.': '.wp_strip_all_tags((string)$r->content));}
        usort($events,function($a,$b){return strcmp($a['at'],$b['at']);});$transcript=implode("\n",array_slice(array_column($events,'text'),-180));if($transcript==='')return;
        try{$summary=HC_AI::chat_model(array(array('role'=>'system','content'=>'You are a senior customer-support case analyst. Produce a complete, concise, factual Markdown case summary with exactly these sections: ## Customer\'s original issue, ## Investigation and agent actions, ## Final resolution and outcome, ## Outstanding items. Start by stating in one sentence what the customer contacted support about. In Investigation and agent actions, describe what the agent actually checked, verified, explained, requested, or changed, in chronological order. In Final resolution and outcome, state what finally happened and the exact resolution communicated or action completed, distinguishing a promise from a completed action. If the transcript does not confirm a final outcome, write **No final resolution was recorded** and explain what remains pending. Never infer that the customer is satisfied or that an issue is fixed without evidence. Preserve exact order IDs, products, amounts, dates and reference numbers only when present. Treat internal notes as staff-only evidence; do not present them as statements made to the customer. Use only verified transcript facts.'),array('role'=>'user','content'=>"Ticket issue: ".(string)$ticket->issue."\n\nChronological transcript:\n".$transcript)));}catch(Throwable $e){error_log('[HelpCenter] Background handover summary failed for ticket '.$id.': '.$e->getMessage());return;}
        if(is_wp_error($summary)||!is_string($summary)||trim($summary)===''){error_log('[HelpCenter] Background handover summary provider error for ticket '.$id.': '.(is_wp_error($summary)?$summary->get_error_message():'Empty response'));return;}
        $fresh=$wpdb->get_row($wpdb->prepare("SELECT status,last_activity FROM {$t} WHERE id=%d",$id));
        if(!$fresh || (string)$fresh->last_activity!==$summary_basis_activity){error_log('[HelpCenter] Discarded stale handover summary for ticket '.$id.' because the conversation changed during generation.');return;}
        $now=current_time('mysql');$summary=mb_substr(trim($summary),0,8000);$wpdb->update($t,array('ai_summary'=>$summary,'ai_summary_at'=>$now),array('id'=>$id),array('%s','%s'),array('%d'));
        $links=$wpdb->prefix.'hck_hc_links';$hck=$wpdb->prefix.'hck_tickets';
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$links))===$links && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$hck))===$hck){$hck_id=(int)$wpdb->get_var($wpdb->prepare("SELECT hck_ticket_id FROM {$links} WHERE hc_ticket_id=%d LIMIT 1",$id));if($hck_id)update_option('hck_ticket_ai_summary_'.$hck_id,array('summary'=>$summary,'generated_at'=>$now,'source'=>'helpcenter_agent_handover'),false);}
        if((string)$ticket->status==='closed'){$note_prefix='AI handover summary:';$note=$note_prefix."\n\n".$summary;$existing_note=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$m} WHERE ticket_id=%d AND sender_type='internal_note' AND content LIKE %s ORDER BY id DESC LIMIT 1",$id,$wpdb->esc_like($note_prefix).'%'));if($existing_note)$wpdb->update($m,array('content'=>$note,'created_at'=>$now),array('id'=>$existing_note),array('%s','%s'),array('%d'));else{$wpdb->insert($m,array('ticket_id'=>$id,'conversation_id'=>(int)$ticket->conversation_id,'sender_type'=>'internal_note','sender_user_id'=>0,'sender_name'=>'AI Ticket Summary','content'=>$note,'created_at'=>$now),array('%d','%d','%s','%d','%s','%s','%s'));}}
        if(class_exists('HC_Realtime'))HC_Realtime::publish_ticket_event($id,'ticket.summary_updated',0);
    }

    public static function generate_summary() {
        self::guard();
        global $wpdb;
        list($t,$m)=self::tables();
        $id=absint($_POST['ticket_id']??0);
        if (!$id) wp_send_json_error(array('message'=>'Invalid ticket.'),400);
        // Summaries are shared internal case records: every authenticated agent
        // and administrator may view or regenerate them, independent of assignment.
        $ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",$id));
        if (!$ticket) wp_send_json_error(array('message'=>'Ticket not found.'),404);
        // AI summaries are available to authorized support staff whenever the AI provider is configured.
        if(!class_exists('HC_AI') || !method_exists('HC_AI','chat_model')) wp_send_json_error(array('message'=>'The configured AI provider is unavailable.'),503);
        $events=array();
        if(class_exists('HC_Live_Support')) {
            foreach(HC_Live_Support::get_ticket_ai_history($ticket,0,1500) as $a) {
                $events[]=array('at'=>(string)$a['created_at'],'text'=>(($a['role']==='user'?'Customer':'AI assistant').': '.wp_strip_all_tags((string)$a['content'])));
            }
        }
        $rows=$wpdb->get_results($wpdb->prepare("SELECT sender_type,sender_name,content,created_at FROM {$m} WHERE ticket_id=%d AND sender_name<>'AI Ticket Summary' ORDER BY id ASC LIMIT 1000",$id));
        foreach((array)$rows as $r) {
            $label=$r->sender_type==='visitor'?'Customer':($r->sender_type==='system'?'System':($r->sender_type==='internal_note'?'Internal agent note (staff-only)':'Support agent '.$r->sender_name));
            $events[]=array('at'=>(string)$r->created_at,'text'=>$label.': '.wp_strip_all_tags((string)$r->content));
        }
        usort($events,function($a,$b){return strcmp($a['at'],$b['at']);});
        $history=array_slice(array_column($events,'text'),-180);
        $prompt="Create a complete, concise internal case summary in Markdown with exactly these sections: ## Customer's original issue, ## Investigation and agent actions, ## Final resolution and outcome, ## Outstanding items. Start by stating what the customer contacted support about. Explain what the agent actually checked, verified, explained, requested or changed. State exactly what finally happened and distinguish completed actions from promises. If no final outcome is confirmed, write **No final resolution was recorded** and identify what remains pending. Never claim the issue is fixed or the customer is satisfied without transcript evidence. Include exact order IDs, products, amounts, dates and reference numbers only when present. Internal agent notes are staff-only evidence and must not be described as customer-facing statements. Use only verified transcript facts; do not invent facts.\n\nTicket issue: ".(string)$ticket->issue."\nTicket status: ".(string)$ticket->status."\n\nChronological transcript:\n".implode("\n",$history);
        try {
            $summary=HC_AI::chat_model(array(
                array('role'=>'system','content'=>'You are a precise internal customer-support case summarizer. Do not reply to the customer. Produce a Markdown handover summary using only facts in the transcript.'),
                array('role'=>'user','content'=>$prompt)
            ));
        } catch (Throwable $e) {
            error_log('[HelpCenter] Agent summary exception for ticket '.$id.': '.$e->getMessage());
            wp_send_json_error(array('message'=>'The AI provider failed while generating the summary. Check the HelpCenter PHP error log for details.'),502);
        }
        if(is_wp_error($summary)||!is_string($summary)||trim($summary)==='') {
            $reason=is_wp_error($summary)?$summary->get_error_message():'The AI provider returned an empty summary.';
            error_log('[HelpCenter] Agent summary provider error for ticket '.$id.': '.$reason);
            wp_send_json_error(array('message'=>$reason),502);
        }
        $summary=mb_substr(trim($summary),0,8000);
        $now=current_time('mysql');
        $wpdb->update($t,array('ai_summary'=>$summary,'ai_summary_at'=>$now),array('id'=>$id),array('%s','%s'),array('%d'));
        wp_send_json_success(array('summary'=>$summary,'generated_at'=>$now));
    }

    public static function text_assist() {
        self::agent_guard();
        $text = trim(sanitize_textarea_field(wp_unslash($_POST['text'] ?? '')));
        $mode = sanitize_key($_POST['mode'] ?? 'grammar');
        if ($text === '') wp_send_json_error(array('message' => 'Enter text first.'));
        if (!in_array($mode, array('grammar','expand','context'), true)) $mode = 'grammar';
        $instructions = array(
            'grammar' => 'You are a proofreading engine. Your only task is to correct the exact text supplied by the user. Fix spelling, grammar, punctuation, capitalization and awkward sentence construction. Preserve meaning, facts, names, amounts, dates, tone and commitments. Do not answer the text, do not ask questions, do not request more information, do not add explanations, and do not use a knowledge base. If the input is already correct, return it unchanged. Output only the corrected text.',
            'expand' => 'You are a text expansion editor. Expand ONLY the supplied draft into a clearer, more complete and professionally worded version. Stay strictly within the meaning and facts already present in that draft. Do not use ticket history, external context, assumptions or invented details. Do not answer the draft or ask follow-up questions. Output only the expanded text.',
            'context' => 'You are a customer-support reply editor. Rewrite the supplied draft using only relevant facts from the supplied conversation context. Do not invent facts, dates, refunds, actions or commitments. Do not ask the customer for information unless the draft/context explicitly requires it. Output only the rewritten reply.'
        );
        $context = '';
        if ($mode === 'context') {
            global $wpdb;
            list($t, $m) = self::tables();
            $id = absint($_POST['ticket_id'] ?? 0);
            $ticket = self::access_ticket($id);
            $rows = $wpdb->get_results($wpdb->prepare("SELECT sender_type,content FROM {$m} WHERE ticket_id=%d ORDER BY id DESC LIMIT 20", $id));
            $context = "\n\nConversation context (reference only):\n";
            foreach (array_reverse((array)$rows) as $row) $context .= $row->sender_type . ': ' . wp_strip_all_tags($row->content) . "\n";
            if (!empty($ticket->conversation_id)) {
                $ai = $wpdb->get_results($wpdb->prepare("SELECT role,content FROM {$wpdb->prefix}hc_ai_messages WHERE conversation_id=%d ORDER BY id DESC LIMIT 20", (int)$ticket->conversation_id));
                foreach (array_reverse((array)$ai) as $row) $context .= ($row->role === 'user' ? 'Customer' : 'AI Assistant') . ': ' . wp_strip_all_tags($row->content) . "\n";
            }
        }
        if (!class_exists('HC_AI')) wp_send_json_error(array('message' => 'AI text assistance is not configured.'));
        // Grammar and expansion receive only the draft. Ticket context is deliberately excluded.
        $messages = array(
            array('role' => 'system', 'content' => $instructions[$mode]),
            array('role' => 'user', 'content' => "TEXT TO EDIT:\n" . $text . $context)
        );
        $result = HC_AI::chat_model($messages, true);
        if (is_wp_error($result) || !is_string($result) || trim($result) === '') wp_send_json_error(array('message' => 'The text editor could not process this draft. Please retry.'), 502);
        $result = trim(preg_replace('/^```(?:text|markdown)?\s*|\s*```$/i', '', trim($result)));
        wp_send_json_success(array('text' => $result));
    }

    /** Load a customer's prior HCK ticket in the same agent workspace, after validating it belongs to the currently assigned customer. */
    public static function hck_previous_ticket_detail() {
        self::agent_guard();
        if (!function_exists('hck_get_ticket') || !function_exists('hck_get_messages')) wp_send_json_error(array('message'=>'HCK ticket integration is unavailable.'),503);
        $hc_id=absint($_POST['current_hc_ticket_id']??0); $hck_id=absint($_POST['ticket_id']??0);
        global $wpdb; $current_table=$wpdb->prefix.'hc_ai_escalations';
        $current=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$current_table} WHERE id=%d",$hc_id));
        if(!$current) wp_send_json_error(array('message'=>'The source HelpCenter conversation could not be found.'),404);
        $owns_context=(int)$current->assigned_agent_id===get_current_user_id() || ((string)$current->status==='closed' && (int)$current->closed_by_agent_id===get_current_user_id());
        $has_agent_read_access=current_user_can('hc_manage_ai_escalations') || current_user_can('hck_view_tickets') || self::supervisor();
        if(!$owns_context && !$has_agent_read_access) wp_send_json_error(array('message'=>'You do not have permission to view this customer history.'),403);
        $ticket=hck_get_ticket($hck_id);
        if (!$ticket || !empty($ticket->merged_into)) wp_send_json_error(array('message'=>'Previous ticket not found.'),404);
        $current_uid=(int)$current->user_id; $old_uid=function_exists('hck_get_ticket_user_id')?hck_get_ticket_user_id($ticket):(int)($ticket->user_id??0);
        $current_email=strtolower(trim((string)$current->visitor_email)); $old_email=strtolower(trim((string)($ticket->customer_email??'')));
        if (!(($current_uid>0 && $old_uid===$current_uid) || ($current_email!=='' && $old_email!=='' && hash_equals($current_email,$old_email)))) wp_send_json_error(array('message'=>'This ticket does not belong to the current customer.'),403);
        $agent_id=function_exists('hck_get_ticket_agent_id')?hck_get_ticket_agent_id($ticket):(int)($ticket->agent_id??0);
        $can_handle=function_exists('hck_user_can_handle_ticket')?hck_user_can_handle_ticket($ticket):($agent_id===get_current_user_id());
        $can_claim=(!$agent_id && in_array((string)$ticket->status,array('open','in_progress','awaiting_reply'),true));
        if (function_exists('hck_user_can_access_ticket') && !hck_user_can_access_ticket($ticket) && !$can_claim) wp_send_json_error(array('message'=>'You do not have permission to view this ticket.'),403);
        $messages=hck_get_messages($hck_id,true); $out=array(); $handoff_brief=''; $attachments_by_message=function_exists('hck_get_attachments_for_messages')?hck_get_attachments_for_messages(wp_list_pluck($messages,'id')):array();
        foreach ((array)$messages as $m) {
            if (!empty($m->is_internal) && (string)($m->sender_name??'')==='HelpCenter Handoff Brief') $handoff_brief=(string)$m->message;
            $attachments=array(); foreach ((array)($attachments_by_message[(int)$m->id]??(function_exists('hck_get_attachments')?hck_get_attachments((int)$m->id):array())) as $att) $attachments[]=array('filename'=>(string)$att->filename,'mime'=>(string)((wp_check_filetype((string)$att->filename)['type']??'')?:($att->file_type??'')),'size'=>(int)($att->file_size??0),'url'=>function_exists('hck_attachment_url')?hck_attachment_url($att):'');
            $edited_by=!empty($m->edited_by)?get_userdata((int)$m->edited_by):false; $deleted_by=!empty($m->deleted_by)?get_userdata((int)$m->deleted_by):false;
            $can_edit_note=!empty($m->is_internal) && empty($m->is_system) && empty($m->is_deleted) && ((int)$m->user_id===get_current_user_id() || (function_exists('hck_is_supervisor_user') ? hck_is_supervisor_user() : current_user_can('manage_options'))) && !in_array((string)($m->sender_name??''),array('HelpCenter Handoff Brief','AI Ticket Summary'),true);
            $out[]=array('id'=>(int)$m->id,'user_id'=>(int)($m->user_id??0),'sender_type'=>(string)($m->sender_type??(!empty($m->is_admin)?'agent':'customer')),'sender_name'=>(string)($m->sender_name??''),'message'=>(string)$m->message,'created_at'=>(string)$m->created_at,'is_admin'=>(int)$m->is_admin,'is_internal'=>(int)$m->is_internal,'is_system'=>(int)$m->is_system,'edited_at'=>(string)($m->edited_at??''),'edited_by_name'=>$edited_by?($edited_by->display_name?:$edited_by->user_login):'','is_deleted'=>(int)($m->is_deleted??0),'deleted_at'=>(string)($m->deleted_at??''),'deleted_by_name'=>$deleted_by?($deleted_by->display_name?:$deleted_by->user_login):'','can_edit'=>$can_edit_note,'attachments'=>$attachments);
        }
        $due=!empty($ticket->sla_first_responded_at)?(string)($ticket->sla_resolution_due_at??''):(string)(($ticket->sla_first_response_due_at??'')?:($ticket->sla_resolution_due_at??''));
        $due_ts=$due?strtotime($due.' UTC'):0; $now=current_time('timestamp'); $completed=in_array((string)$ticket->status,array('resolved','closed'),true); $overdue=$due_ts && $due_ts<$now && !$completed;
        update_user_meta(get_current_user_id(),'hck_agent_last_seen_'.$hck_id,current_time('mysql'));
        $saved_summary=get_option('hck_ticket_ai_summary_'.$hck_id,array()); $ai_summary=is_array($saved_summary)?(string)($saved_summary['summary']??''):'';
        $logs_table=$wpdb->prefix.'hck_ticket_logs'; $logs=$wpdb->get_results($wpdb->prepare("SELECT id,user_id,action,details,created_at FROM {$logs_table} WHERE ticket_id=%d ORDER BY id ASC LIMIT 100",$hck_id),ARRAY_A); $activity=array(); foreach((array)$logs as $log){$actor=!empty($log['user_id'])?get_userdata((int)$log['user_id']):false;$activity[]=array('title'=>ucwords(str_replace('_',' ',(string)$log['action'])),'detail'=>(string)$log['details'],'actor'=>$actor?($actor->display_name?:$actor->user_login):'System','created_at'=>(string)$log['created_at']);}
        wp_send_json_success(array('ticket'=>array('id'=>$hck_id,'number'=>function_exists('hck_get_ticket_number')?hck_get_ticket_number($ticket):(string)$ticket->ticket_number,'subject'=>(string)$ticket->subject,'status'=>(string)$ticket->status,'priority'=>(string)$ticket->priority,'customer_name'=>(string)($ticket->customer_name??$current->visitor_name),'customer_email'=>(string)($ticket->customer_email??$current->visitor_email),'customer_phone'=>(string)($old_uid?(get_user_meta($old_uid,'billing_phone',true)?:get_user_meta($old_uid,'phone',true)?:get_user_meta($old_uid,'billing_phone_number',true)):''),'ai_summary'=>$ai_summary,'agent_name'=>$agent_id&&get_userdata($agent_id)?get_userdata($agent_id)->display_name:'Unassigned','updated_at'=>(string)$ticket->updated_at),'messages'=>$out,'handoff_brief'=>$handoff_brief,'activity'=>$activity,'can_handle'=>(bool)$can_handle,'can_claim'=>(bool)$can_claim,'sla'=>array('due_at'=>$due,'remaining_seconds'=>(int)($due_ts?($due_ts-$now):0),'overdue'=>(bool)$overdue,'completed'=>(bool)$completed,'label'=>$completed?'SLA completed':($due?($overdue?'SLA overdue':'SLA due '.$due):'SLA not scheduled'),'detail'=>$completed?'Ticket is resolved or closed.':($due?'HCK ticket '.$ticket->ticket_number:'No HCK SLA deadline is recorded.'))));
    }

    /** Atomically claim an unassigned prior HCK ticket for the current agent. */
    public static function hck_previous_ticket_claim() {
        self::agent_guard(); global $wpdb;
        if (!function_exists('hck_get_ticket')) wp_send_json_error(array('message'=>'HCK ticket integration is unavailable.'),503);
        $hc_id=absint($_POST['current_hc_ticket_id']??0); $hck_id=absint($_POST['ticket_id']??0); $current_table=$wpdb->prefix.'hc_ai_escalations'; $current=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$current_table} WHERE id=%d",$hc_id)); if(!$current)wp_send_json_error(array('message'=>'The source HelpCenter conversation could not be found.'),404); $owns_context=(int)$current->assigned_agent_id===get_current_user_id() || ((string)$current->status==='closed' && (int)$current->closed_by_agent_id===get_current_user_id()); $has_agent_read_access=current_user_can('hc_manage_ai_escalations') || current_user_can('hck_view_tickets') || self::supervisor(); if(!$owns_context&&!$has_agent_read_access)wp_send_json_error(array('message'=>'You do not have permission to view this customer history.'),403); $ticket=hck_get_ticket($hck_id);
        if (!$ticket || !empty($ticket->merged_into)) wp_send_json_error(array('message'=>'Previous ticket not found.'),404);
        $current_uid=(int)$current->user_id; $old_uid=function_exists('hck_get_ticket_user_id')?hck_get_ticket_user_id($ticket):(int)($ticket->user_id??0); $ce=strtolower(trim((string)$current->visitor_email)); $oe=strtolower(trim((string)($ticket->customer_email??'')));
        if (!(($current_uid>0 && $old_uid===$current_uid) || ($ce!=='' && $oe!=='' && hash_equals($ce,$oe)))) wp_send_json_error(array('message'=>'This ticket does not belong to the current customer.'),403);
        if (!in_array((string)$ticket->status,array('open','in_progress','awaiting_reply'),true)) wp_send_json_error(array('message'=>'Only an open ticket can be taken.'),409);
        $uid=get_current_user_id(); $now=current_time('mysql');
        $changed=$wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}hck_tickets SET agent_id=%d,assigned_to=%d,updated_at=%s WHERE id=%d AND (agent_id IS NULL OR agent_id=0) AND (assigned_to IS NULL OR assigned_to=0) AND status IN ('open','in_progress','awaiting_reply')",$uid,$uid,$now,$hck_id));
        if (!$changed) wp_send_json_error(array('message'=>'Another agent may have taken this ticket. Refresh the ticket list and try again.'),409);
        if (function_exists('hck_add_log')) hck_add_log($hck_id,$uid,'agent_transferred','Ticket taken by '.wp_get_current_user()->display_name.' from the customer history workspace.');
        wp_send_json_success(array('message'=>'Ticket assigned to you.'));
    }

    /** Private CRM workspace tables. These are intentionally separate from customer-visible chat/ticket messages. */
    private static function workspace_table_names() {
        global $wpdb;
        return array(
            'meta' => $wpdb->prefix . 'hc_agent_ticket_meta',
            'notes' => $wpdb->prefix . 'hc_agent_workspace_notes',
            'sides' => $wpdb->prefix . 'hc_agent_side_conversations',
            'side_messages' => $wpdb->prefix . 'hc_agent_side_messages',
        );
    }

    public static function ensure_workspace_tables() {
        if (get_option('hc_agent_workspace_schema_v2') === '1') return;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        global $wpdb;
        $t = self::workspace_table_names();
        $charset = $wpdb->get_charset_collate();
        $sql = array();
        $sql[] = "CREATE TABLE {$t['meta']} (
            ticket_id bigint(20) unsigned NOT NULL,
            sub_status varchar(80) NOT NULL DEFAULT '',
            tags longtext NULL,
            updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (ticket_id),
            KEY updated_at (updated_at)
        ) {$charset};";
        $sql[] = "CREATE TABLE {$t['notes']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            author_id bigint(20) unsigned NOT NULL DEFAULT 0,
            author_name varchar(190) NOT NULL DEFAULT '',
            note longtext NOT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NULL,
            updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
            is_deleted tinyint(1) NOT NULL DEFAULT 0,
            deleted_at datetime NULL,
            deleted_by bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY ticket_id (ticket_id),
            KEY author_id (author_id)
        ) {$charset};";
        $sql[] = "CREATE TABLE {$t['sides']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_by_name varchar(190) NOT NULL DEFAULT '',
            recipient_id bigint(20) unsigned NOT NULL DEFAULT 0,
            recipient_name varchar(190) NOT NULL DEFAULT '',
            subject varchar(190) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'open',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY ticket_id (ticket_id),
            KEY created_by (created_by),
            KEY recipient_id (recipient_id)
        ) {$charset};";
        $sql[] = "CREATE TABLE {$t['side_messages']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            side_id bigint(20) unsigned NOT NULL,
            author_id bigint(20) unsigned NOT NULL DEFAULT 0,
            author_name varchar(190) NOT NULL DEFAULT '',
            content longtext NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY side_id (side_id),
            KEY author_id (author_id)
        ) {$charset};";
        foreach ($sql as $statement) dbDelta($statement);
        $tables_ok = true;
        foreach ($t as $table_name) {
            $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
            if ($found !== $table_name) { $tables_ok = false; break; }
        }
        if ($tables_ok) { update_option('hc_agent_workspace_schema_v1', '1', false); update_option('hc_agent_workspace_schema_v2', '1', false); }
        else error_log('[HelpCenter Agent] CRM workspace table creation did not complete. init will retry on the next request. DB error: ' . $wpdb->last_error);
    }

    private static function workspace_can_access_side($side) {
        $uid = get_current_user_id();
        return $side && ((int)$side->created_by === $uid || (int)$side->recipient_id === $uid || current_user_can('manage_options'));
    }

    public static function workspace_data() {
        self::agent_guard();
        global $wpdb;
        $ticket_id = absint($_POST['ticket_id'] ?? 0);
        self::access_ticket_for_note($ticket_id);
        $t = self::workspace_table_names();
        $uid = get_current_user_id();
        $notes = $wpdb->get_results($wpdb->prepare("SELECT id,author_id,author_name,note,created_at,updated_at,updated_by,is_deleted,deleted_at,deleted_by FROM {$t['notes']} WHERE ticket_id=%d ORDER BY id DESC LIMIT 100", $ticket_id), ARRAY_A);
        foreach ((array)$notes as &$note_row) {
            $note_row['can_edit'] = empty($note_row['is_deleted']) && ((int)$note_row['author_id'] === $uid || self::workspace_note_supervisor());
            $editor = !empty($note_row['updated_by']) ? get_userdata((int)$note_row['updated_by']) : false;
            $deleter = !empty($note_row['deleted_by']) ? get_userdata((int)$note_row['deleted_by']) : false;
            $note_row['updated_by_name'] = $editor ? ($editor->display_name ?: $editor->user_login) : '';
            $note_row['deleted_by_name'] = $deleter ? ($deleter->display_name ?: $deleter->user_login) : '';
        }
        unset($note_row);
        $sides = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['sides']} WHERE ticket_id=%d AND (created_by=%d OR recipient_id=%d) ORDER BY updated_at DESC LIMIT 100", $ticket_id, $uid, $uid), ARRAY_A);
        $meta = $wpdb->get_row($wpdb->prepare("SELECT sub_status,tags,updated_by,updated_at FROM {$t['meta']} WHERE ticket_id=%d", $ticket_id), ARRAY_A);
        $tags = array();
        if (!empty($meta['tags'])) { $decoded = json_decode($meta['tags'], true); if (is_array($decoded)) { foreach ($decoded as $tag) { if (!is_scalar($tag)) continue; $tag = sanitize_text_field((string)$tag); if ($tag !== '') $tags[] = $tag; } } }
        wp_send_json_success(array('notes'=>array_reverse((array)$notes),'side_conversations'=>(array)$sides,'meta'=>array('sub_status'=>$meta['sub_status']??'','tags'=>$tags)));
    }

    public static function workspace_note() {
        self::agent_guard(); global $wpdb;
        $ticket_id = absint($_POST['ticket_id'] ?? 0);
        $ticket = self::access_ticket($ticket_id);
        if (in_array($ticket->status, array('closed','archived'), true)) wp_send_json_error(array('message'=>'Claim the ticket before adding an internal note.'), 409);
        $note = trim(sanitize_textarea_field(wp_unslash($_POST['note'] ?? '')));
        if ($note === '' || mb_strlen($note) > 5000) wp_send_json_error(array('message'=>'Enter an internal note up to 5,000 characters.'), 400);
        $u = wp_get_current_user(); $t = self::workspace_table_names(); $now = current_time('mysql');
        $ok = $wpdb->insert($t['notes'], array('ticket_id'=>$ticket_id,'author_id'=>$u->ID,'author_name'=>$u->display_name ?: $u->user_login,'note'=>$note,'created_at'=>$now), array('%d','%d','%s','%s','%s'));
        if (!$ok) wp_send_json_error(array('message'=>'Internal note could not be saved.'), 500);
        wp_send_json_success(array('id'=>(int)$wpdb->insert_id,'author_name'=>$u->display_name ?: $u->user_login,'note'=>$note,'created_at'=>$now,'message'=>'Private note saved. It is visible only to authorized support agents.'));
    }

    public static function workspace_note_edit() {
        self::agent_guard(); global $wpdb;
        $ticket_id = absint($_POST['ticket_id'] ?? 0);
        self::access_ticket_for_note($ticket_id);
        $note_id = absint($_POST['note_id'] ?? 0);
        $note = trim(sanitize_textarea_field(wp_unslash($_POST['note'] ?? '')));
        if (!$note_id || $note === '' || mb_strlen($note) > 5000) wp_send_json_error(array('message'=>'Enter a private note up to 5,000 characters.'),400);
        $t = self::workspace_table_names(); $uid = get_current_user_id();
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['notes']} WHERE id=%d AND ticket_id=%d",$note_id,$ticket_id));
        if (!$row || !empty($row->is_deleted)) wp_send_json_error(array('message'=>'This private note is no longer available.'),404);
        if ((int)$row->author_id !== $uid && !self::workspace_note_supervisor()) wp_send_json_error(array('message'=>'Only the note author or a supervisor can edit this note.'),403);
        $now = current_time('mysql');
        $ok = $wpdb->update($t['notes'],array('note'=>$note,'updated_at'=>$now,'updated_by'=>$uid),array('id'=>$note_id,'ticket_id'=>$ticket_id),array('%s','%s','%d'),array('%d','%d'));
        if ($ok === false) wp_send_json_error(array('message'=>'The private note could not be updated.'),500);
        $user = wp_get_current_user();
        wp_send_json_success(array('message'=>'Private note updated.','note'=>array('id'=>$note_id,'note'=>$note,'updated_at'=>$now,'updated_by_name'=>$user->display_name ?: $user->user_login)));
    }

    public static function workspace_note_delete() {
        self::agent_guard(); global $wpdb;
        $ticket_id = absint($_POST['ticket_id'] ?? 0);
        self::access_ticket_for_note($ticket_id);
        $note_id = absint($_POST['note_id'] ?? 0);
        if (!$note_id) wp_send_json_error(array('message'=>'Invalid private note.'),400);
        $t = self::workspace_table_names(); $uid = get_current_user_id();
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['notes']} WHERE id=%d AND ticket_id=%d",$note_id,$ticket_id));
        if (!$row || !empty($row->is_deleted)) wp_send_json_error(array('message'=>'This private note is already deleted or unavailable.'),404);
        if ((int)$row->author_id !== $uid && !self::workspace_note_supervisor()) wp_send_json_error(array('message'=>'Only the note author or a supervisor can delete this note.'),403);
        $now = current_time('mysql');
        $ok = $wpdb->update($t['notes'],array('note'=>'','is_deleted'=>1,'deleted_at'=>$now,'deleted_by'=>$uid),array('id'=>$note_id,'ticket_id'=>$ticket_id),array('%s','%d','%s','%d'),array('%d','%d'));
        if ($ok === false) wp_send_json_error(array('message'=>'The private note could not be deleted.'),500);
        $user = wp_get_current_user();
        wp_send_json_success(array('message'=>'Private note deleted.','deleted_by_name'=>$user->display_name ?: $user->user_login,'deleted_at'=>$now));
    }

    public static function workspace_side_create() {
        self::agent_guard(); global $wpdb;
        $ticket_id = absint($_POST['ticket_id'] ?? 0);
        $ticket = self::access_ticket($ticket_id);
        if (in_array($ticket->status, array('closed','archived'), true)) wp_send_json_error(array('message'=>'Claim the ticket before starting a side conversation.'), 409);
        $recipient_id = absint($_POST['recipient_id'] ?? 0);
        $recipient = get_userdata($recipient_id);
        if (!$recipient || $recipient_id === get_current_user_id() || !(in_array('hc_support_agent', (array)$recipient->roles, true) || user_can($recipient, 'hc_agent_portal_access'))) wp_send_json_error(array('message'=>'Choose another active HelpCenter support agent.'), 400);
        $subject = sanitize_text_field(wp_unslash($_POST['subject'] ?? ''));
        $message = trim(sanitize_textarea_field(wp_unslash($_POST['message'] ?? '')));
        if ($subject === '' || $message === '' || mb_strlen($subject) > 180 || mb_strlen($message) > 5000) wp_send_json_error(array('message'=>'Enter a subject and a message (up to 5,000 characters).'), 400);
        $u = wp_get_current_user(); $t = self::workspace_table_names(); $now = current_time('mysql');
        $ok = $wpdb->insert($t['sides'], array('ticket_id'=>$ticket_id,'created_by'=>$u->ID,'created_by_name'=>$u->display_name ?: $u->user_login,'recipient_id'=>$recipient_id,'recipient_name'=>$recipient->display_name ?: $recipient->user_login,'subject'=>$subject,'status'=>'open','created_at'=>$now,'updated_at'=>$now), array('%d','%d','%s','%d','%s','%s','%s','%s','%s'));
        if (!$ok) wp_send_json_error(array('message'=>'Side conversation could not be created.'), 500);
        $side_id = (int)$wpdb->insert_id;
        $first_message_ok = $wpdb->insert($t['side_messages'], array('side_id'=>$side_id,'author_id'=>$u->ID,'author_name'=>$u->display_name ?: $u->user_login,'content'=>$message,'created_at'=>$now), array('%d','%d','%s','%s','%s'));
        if (!$first_message_ok) {
            $wpdb->delete($t['sides'], array('id'=>$side_id), array('%d'));
            wp_send_json_error(array('message'=>'The side conversation was not created because its first message could not be saved.'), 500);
        }
        $url = add_query_arg(array('side_conversation'=>$side_id), home_url('/support-agent/'));
        $mail = 'A private side conversation was started about ticket #'.$ticket_id.'. Open the agent workspace: '.$url;
        wp_mail($recipient->user_email, 'HelpCenter side conversation · Ticket #'.$ticket_id, $mail);
        wp_send_json_success(array('id'=>$side_id,'subject'=>$subject,'recipient_name'=>$recipient->display_name ?: $recipient->user_login,'message'=>'Private side conversation created.','url'=>$url));
    }

    public static function workspace_side_get() {
        self::agent_guard(); global $wpdb;
        $side_id = absint($_POST['side_id'] ?? 0); $t = self::workspace_table_names();
        $side = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['sides']} WHERE id=%d", $side_id));
        if (!self::workspace_can_access_side($side)) wp_send_json_error(array('message'=>'You are not a participant in this side conversation.'), 403);
        $messages = $wpdb->get_results($wpdb->prepare("SELECT id,author_id,author_name,content,created_at FROM {$t['side_messages']} WHERE side_id=%d ORDER BY id ASC LIMIT 300", $side_id), ARRAY_A);
        wp_send_json_success(array('side'=>array('id'=>(int)$side->id,'ticket_id'=>(int)$side->ticket_id,'subject'=>$side->subject,'created_by_name'=>$side->created_by_name,'recipient_name'=>$side->recipient_name,'status'=>$side->status),'messages'=>(array)$messages));
    }

    public static function workspace_side_reply() {
        self::agent_guard(); global $wpdb;
        $side_id = absint($_POST['side_id'] ?? 0); $t = self::workspace_table_names();
        $side = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['sides']} WHERE id=%d", $side_id));
        if (!self::workspace_can_access_side($side)) wp_send_json_error(array('message'=>'You are not a participant in this side conversation.'), 403);
        $message = trim(sanitize_textarea_field(wp_unslash($_POST['message'] ?? '')));
        if ($message === '' || mb_strlen($message) > 5000) wp_send_json_error(array('message'=>'Enter a message up to 5,000 characters.'), 400);
        $u = wp_get_current_user(); $now = current_time('mysql');
        $ok = $wpdb->insert($t['side_messages'], array('side_id'=>$side_id,'author_id'=>$u->ID,'author_name'=>$u->display_name ?: $u->user_login,'content'=>$message,'created_at'=>$now), array('%d','%d','%s','%s','%s'));
        if (!$ok) wp_send_json_error(array('message'=>'Side conversation reply could not be saved.'), 500);
        $wpdb->update($t['sides'], array('updated_at'=>$now), array('id'=>$side_id), array('%s'), array('%d'));
        $other_id = (int)$side->created_by === (int)$u->ID ? (int)$side->recipient_id : (int)$side->created_by;
        $other = get_userdata($other_id);
        if ($other && is_email($other->user_email)) wp_mail($other->user_email, 'New reply · '.$side->subject, $u->display_name.' replied to side conversation for ticket #'.$side->ticket_id.'.');
        wp_send_json_success(array('message'=>'Reply added to private side conversation.'));
    }

    public static function workspace_update() {
        self::agent_guard(); global $wpdb;
        $ticket_id = absint($_POST['ticket_id'] ?? 0);
        $ticket = self::access_ticket($ticket_id);
        if (in_array($ticket->status, array('closed','archived'), true)) wp_send_json_error(array('message'=>'Claim the ticket before editing its details.'), 409);
        $table = $wpdb->prefix . 'hc_ai_escalations';
        $t = self::workspace_table_names();
        $u = wp_get_current_user(); $now = current_time('mysql');
        $priority = sanitize_key($_POST['priority'] ?? '');
        if ($priority !== '' && !in_array($priority, array('low','normal','high','urgent'), true)) wp_send_json_error(array('message'=>'Invalid priority.'), 400);
        $ticket_status = sanitize_key($_POST['ticket_status'] ?? '');
        if ($ticket_status !== '' && !in_array($ticket_status, array('active','waiting_customer'), true)) wp_send_json_error(array('message'=>'Invalid status transition. Use Resolve to close a ticket.'), 400);
        $changes = array(); $formats = array();
        if ($priority !== '') { $changes['priority'] = $priority; $formats[] = '%s'; }
        if ($ticket_status !== '') { $changes['status'] = $ticket_status; $formats[] = '%s'; $changes['last_activity'] = $now; $formats[] = '%s'; }
        $customer_name = isset($_POST['customer_name']) ? sanitize_text_field(wp_unslash($_POST['customer_name'])) : null;
        $customer_email = isset($_POST['customer_email']) ? sanitize_email(wp_unslash($_POST['customer_email'])) : null;
        if ($customer_name !== null) { if ($customer_name === '' || mb_strlen($customer_name)>190) wp_send_json_error(array('message'=>'Enter a valid customer name.'), 400); $changes['visitor_name']=$customer_name; $formats[]='%s'; }
        if ($customer_email !== null) { if (!is_email($customer_email)) wp_send_json_error(array('message'=>'Enter a valid customer email address.'), 400); $changes['visitor_email']=$customer_email; $formats[]='%s'; }
        if ($changes) { $ok=$wpdb->update($table,$changes,array('id'=>$ticket_id),$formats,array('%d')); if ($ok===false) wp_send_json_error(array('message'=>'Ticket/customer fields could not be updated.'),500); }
        $sub = isset($_POST['sub_status']) ? sanitize_text_field(wp_unslash($_POST['sub_status'])) : null;
        $tags = null;
        if (isset($_POST['tags'])) { $raw=wp_unslash($_POST['tags']); if (is_string($raw)) $raw=json_decode($raw,true); if (!is_array($raw)) $raw=array(); $tags=array(); foreach($raw as $tag){if(!is_scalar($tag))continue;$tag=sanitize_text_field((string)$tag);$tag=mb_substr(trim($tag),0,40);if($tag!==''&&!in_array($tag,$tags,true))$tags[]=$tag;} $tags=array_slice($tags,0,12); }
        if ($sub !== null || $tags !== null) {
            $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['meta']} WHERE ticket_id=%d",$ticket_id),ARRAY_A);
            $old_tags=json_decode($existing['tags']??'[]',true);if(!is_array($old_tags))$old_tags=array();$stored_tags=$tags!==null?$tags:$old_tags;
            $values=array('ticket_id'=>$ticket_id,'sub_status'=>$sub!==null?mb_substr($sub,0,80):($existing['sub_status']??''),'tags'=>wp_json_encode($stored_tags),'updated_by'=>$u->ID,'updated_at'=>$now);
            $ok=$wpdb->replace($t['meta'],$values,array('%d','%s','%s','%d','%s'));
            if (!$ok) wp_send_json_error(array('message'=>'Ticket metadata could not be saved.'),500);
        }
        wp_send_json_success(array('message'=>'Ticket details updated.','priority'=>$priority ?: (string)$ticket->priority,'ticket_status'=>$ticket_status ?: (string)$ticket->status,'customer_name'=>$customer_name,'customer_email'=>$customer_email,'sub_status'=>$sub,'tags'=>$tags));
    }

}
