<?php
/**
 * Help Center - JSON-LD Schema Markup
 */

if (!defined('ABSPATH')) exit;

class HC_Schema {

    public static function is_enabled() {
        return HC_Core::get_setting('hc_schema_enabled', '1') === '1';
    }

    /**
     * Print schema for the current help center page.
     * Called from wrapper.php via wp_head.
     */
    public static function output() {
        if (!self::is_enabled()) return;

        $page = get_query_var('hc_page');
        if (!$page) return;

        switch ($page) {
            case 'home':     self::print_home();     break;
            case 'category': self::print_category(); break;
            case 'article':  self::print_article();  break;
            case 'contact':  self::print_contact();  break;
            case 'search': self::print_search(); break;
            case 'latest': self::print_archive('latest'); break;
            case 'popular': self::print_archive('popular'); break;
            case 'categories-all': self::print_categories_all(); break;
        }
    }

    // =============================================
    // HELPERS
    // =============================================
    private static function print_json($data) {
        echo '<script type="application/ld+json">' . "\n";
        echo wp_json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        echo "\n" . '</script>' . "\n";
    }

    private static function organization() {
        $name = HC_Core::get_setting('hc_schema_org_name', get_bloginfo('name'));
        $logo = HC_Core::get_setting('hc_schema_org_logo', '');
        $org = array(
            '@type' => 'Organization',
            'name'  => $name,
            'url'   => home_url('/'),
        );
        if ($logo) {
            $org['logo'] = array(
                '@type' => 'ImageObject',
                'url'   => $logo,
            );
        }
        return $org;
    }

    private static function breadcrumbs() {
        if (HC_Core::get_setting('hc_schema_breadcrumbs', '1') !== '1') return null;

        $page = get_query_var('hc_page');
        $items = array(
            array(
                '@type' => 'ListItem',
                'position' => 1,
                'name' => 'Help Center',
                'item' => home_url('/helpcenter/'),
            ),
        );

        if ($page === 'category') {
            $slug = get_query_var('hc_category');
            $cat = HC_Core::get_category_by_slug($slug);
            if ($cat) {
                if (!empty($cat->parent_id)) {
                    $parent = HC_Core::get_category((int) $cat->parent_id);
                    if ($parent && $parent->status === 'published') {
                        $items[] = array('@type'=>'ListItem','position'=>2,'name'=>$parent->name,'item'=>home_url('/helpcenter/category/' . $parent->slug . '/'));
                    }
                }
                $items[] = array('@type' => 'ListItem','position' => count($items) + 1,'name' => $cat->name,'item' => home_url('/helpcenter/category/' . $cat->slug . '/'));
            }
        } elseif ($page === 'article') {
            $slug = get_query_var('hc_article');
            $article = HC_Core::get_article_by_slug($slug);
            if ($article) {
                $cat = HC_Lifecycle::primary_category($article);
                if ($cat) {
                    if (!empty($article->subcategory_id)) {
                        $subcat = HC_Core::get_category((int)$article->subcategory_id);
                        if ($subcat && (int)$subcat->parent_id === (int)$cat->id && $subcat->status === 'published') {
                            $items[] = array('@type'=>'ListItem','position'=>2,'name'=>$cat->name,'item'=>home_url('/helpcenter/category/' . $cat->slug . '/'));
                            $items[] = array('@type'=>'ListItem','position'=>3,'name'=>$subcat->name,'item'=>home_url('/helpcenter/category/' . $subcat->slug . '/'));
                        } else {
                            $items[] = array('@type'=>'ListItem','position'=>2,'name'=>$cat->name,'item'=>home_url('/helpcenter/category/' . $cat->slug . '/'));
                        }
                    } else {
                        $items[] = array('@type'=>'ListItem','position'=>2,'name'=>$cat->name,'item'=>home_url('/helpcenter/category/' . $cat->slug . '/'));
                    }
                }
                $items[] = array(
                    '@type' => 'ListItem',
                    'position' => count($items) + 1,
                    'name' => $article->title,
                    'item' => home_url('/helpcenter/article/' . $article->slug . '/'),
                );
            }
        } elseif ($page === 'search') {
            $items[] = array(
                '@type' => 'ListItem',
                'position' => 2,
                'name' => 'Search',
                'item' => home_url('/helpcenter/search/'),
            );
        } elseif ($page === 'contact' || $page === 'latest' || $page === 'popular' || $page === 'categories-all') {
            $labels = array('contact'=>'Contact','latest'=>'Latest Articles','popular'=>'Popular Articles','categories-all'=>'All Categories');
            $label = $labels[$page];
            $path = $page === 'categories-all' ? '/categories/' : '/helpcenter/' . $page . '/';
            $items[] = array('@type'=>'ListItem','position'=>2,'name'=>$label,'item'=>home_url($path));
        }

        return array(
            '@type' => 'BreadcrumbList',
            'itemListElement' => $items,
        );
    }

    private static function print_breadcrumbs() {
        $bc = self::breadcrumbs();
        if ($bc) self::print_json(array('@context' => 'https://schema.org') + $bc);
    }

    // =============================================
    // HOME
    // =============================================
    private static function print_home() {
        $title = HC_Core::get_setting('hc_site_title', 'Help Center');

        self::print_json(array(
            '@context' => 'https://schema.org',
            '@type'    => 'WebSite',
            'name'     => $title,
            'url'      => home_url('/helpcenter/'),
            'potentialAction' => array(
                '@type' => 'SearchAction',
                'target' => array(
                    '@type' => 'EntryPoint',
                    'urlTemplate' => home_url('/helpcenter/search/?q={search_term_string}'),
                ),
                'query-input' => 'required name=search_term_string',
            ),
        ));

        self::print_breadcrumbs();
    }

    // =============================================
    // CATEGORY
    // =============================================
    private static function print_category() {
        $slug = get_query_var('hc_category');
        $cat = HC_Core::get_category_by_slug($slug);
        if (!$cat) return;

        $articles = HC_Core::get_articles_by_category($cat->id, 50);
        $items = array();
        $i = 1;
        foreach ($articles as $a) {
            $items[] = array(
                '@type' => 'ListItem',
                'position' => $i++,
                'url' => home_url('/helpcenter/article/' . $a->slug . '/'),
                'name' => $a->title,
            );
        }

        self::print_json(array(
            '@context' => 'https://schema.org',
            '@type'    => 'CollectionPage',
            'name'     => $cat->name,
            'description' => $cat->description,
            'url'      => home_url('/helpcenter/category/' . $cat->slug . '/'),
            'mainEntity' => array(
                '@type' => 'ItemList',
                'itemListElement' => $items,
            ),
        ));

        self::print_breadcrumbs();
    }

    // =============================================
    // ARTICLE
    // =============================================
    private static function print_article() {
        $slug = get_query_var('hc_article');
        $article = HC_Core::get_article_by_slug($slug);
        if (!$article) return;

        // Determine a supported article schema type; keep breadcrumb output even when article schema is disabled.
        $type = $article->schema_type;
        if ($type === 'inherit' || empty($type)) $type = HC_Core::get_setting('hc_schema_article_type', 'TechArticle');
        $schema_disabled = ($type === 'none');
        $allowed = array('Article','TechArticle','HowTo','BlogPosting','NewsArticle');
        if (!$schema_disabled && !in_array($type, $allowed, true)) $type = 'TechArticle';
        $author_name = HC_Core::get_setting('hc_schema_author', 'Support Team');
        $article_url = home_url('/helpcenter/article/' . $article->slug . '/');
        $description = $article->excerpt ?: wp_trim_words(wp_strip_all_tags($article->content), 35);
        $word_count = str_word_count(wp_strip_all_tags($article->content));
        $data = array(
            '@context' => 'https://schema.org',
            '@type' => $type,
            '@id' => $article_url . '#article',
            'url' => $article_url,
            'headline' => $article->title,
            'description' => $description,
            'inLanguage' => get_bloginfo('language'),
            'datePublished' => mysql2date('c', $article->created_at, false),
            'dateModified' => mysql2date('c', $article->updated_at, false),
            'wordCount' => $word_count,
            'author' => array('@type' => 'Organization', 'name' => $author_name),
            'publisher' => self::organization(),
            'isPartOf' => array('@type'=>'WebSite','name'=>HC_Core::get_setting('hc_site_title','Help Center'),'url'=>home_url('/helpcenter/')),
            'mainEntityOfPage' => array('@type' => 'WebPage','@id' => $article_url),
        );
        $category = HC_Lifecycle::primary_category($article);
        if ($category) $data['articleSection'] = $category->name;
        if (preg_match('/<img[^>]+src=["\']([^"\']+)/i', $article->content, $image_match)) $data['image'] = esc_url_raw($image_match[1]);
        if (!$schema_disabled) self::print_json($data);

        // FAQ schema
        if (HC_Core::get_setting('hc_schema_faq', '1') === '1') {
            $faqs = HC_Core::get_faqs('article', $article->id);
            if (!empty($faqs)) {
                $faq_items = array();
                foreach ($faqs as $f) {
                    $faq_items[] = array(
                        '@type' => 'Question',
                        'name'  => $f->question,
                        'acceptedAnswer' => array(
                            '@type' => 'Answer',
                            'text'  => wp_strip_all_tags($f->answer),
                        ),
                    );
                }
                self::print_json(array(
                    '@context' => 'https://schema.org',
                    '@type'    => 'FAQPage',
                    'mainEntity' => $faq_items,
                ));
            }
        }

        self::print_breadcrumbs();
    }

    private static function print_search() {
        self::print_json(array('@context'=>'https://schema.org','@type'=>'SearchResultsPage','name'=>'Help Center Search','url'=>home_url('/helpcenter/search/'),'isPartOf'=>array('@type'=>'WebSite','name'=>HC_Core::get_setting('hc_site_title','Help Center'),'url'=>home_url('/helpcenter/'))));
        self::print_breadcrumbs();
    }

    private static function print_archive($kind) {
        $name = $kind === 'popular' ? 'Popular Articles' : 'Latest Articles';
        $rows = $kind === 'popular' ? HC_Core::get_popular_articles(50) : HC_Core::get_latest_articles(50);
        $items = array(); $i=1;
        foreach ((array)$rows as $a) $items[] = array('@type'=>'ListItem','position'=>$i++,'url'=>home_url('/helpcenter/article/'.$a->slug.'/'),'name'=>$a->title);
        self::print_json(array('@context'=>'https://schema.org','@type'=>'CollectionPage','name'=>$name,'url'=>home_url('/helpcenter/'.$kind.'/'),'mainEntity'=>array('@type'=>'ItemList','itemListElement'=>$items)));
        self::print_breadcrumbs();
    }

    private static function print_categories_all() {
        $items=array(); $i=1;
        foreach (HC_Core::get_categories(0,'published') as $c) $items[]=array('@type'=>'ListItem','position'=>$i++,'url'=>home_url('/helpcenter/category/'.$c->slug.'/'),'name'=>$c->name);
        self::print_json(array('@context'=>'https://schema.org','@type'=>'CollectionPage','name'=>'All Help Center Categories','url'=>home_url('/categories/'),'mainEntity'=>array('@type'=>'ItemList','itemListElement'=>$items)));
        self::print_breadcrumbs();
    }

    // =============================================
    // CONTACT
    // =============================================
    private static function print_contact() {
        self::print_json(array(
            '@context' => 'https://schema.org',
            '@type'    => 'ContactPage',
            'name'     => 'Contact Support',
            'url'      => home_url('/helpcenter/contact/'),
            'publisher' => self::organization(),
        ));

        self::print_breadcrumbs();
    }
}

// Hook into wp_head
// schema now printed manually in templates/wrapper.php
